# Release Notes — Customer Delivery V14

V14 เพิ่มระบบ Application Backup + Restore สำหรับ Cloudflare D1 โดยเน้นการกู้ข้อมูลธุรกิจแบบ fail-closed และไม่ย้อน identity/security/integration state ของระบบปัจจุบัน

## V14 — Backup / Restore D1

- เพิ่มไฟล์ `.dormbackup` แบบ ZIP ที่มี `manifest.json` + `data.json`
- canonical JSON + SHA-256 ตรวจความสมบูรณ์ของ payload
- Strict schema/field/type/reference validation ก่อนอนุญาต Restore
- Restore Token อายุไม่เกิน 10 นาที ผูกกับ Owner + Backup hash
- Owner/Super Admin เท่านั้น และบังคับ Plan Entitlement ทั้ง UI/API
- Demo ดาวน์โหลด Backup ได้ แต่ Demo ไม่สามารถ Restore ได้
- Basic / Standard / Pro เปิด Backup + Restore
- ก่อนเขียน Restore ระบบสร้าง/ดาวน์โหลด **pre-restore** Backup เพื่อใช้ Recovery
- Restore rewrite ownership เป็น Owner ปัจจุบันและรักษา LINE room linkage ที่มีอยู่
- **users/password not restored**
- **LINE/Google credentials not restored** และไม่ย้อน integration state ปัจจุบัน
- audit history และ subscription metadata ไม่ถูก Restore
- ถ้า D1 write ล้มกลางทาง ระบบคืน recovery-required แทนการรายงาน success
- Express/VPS fail-closed ด้วย `501 D1_REQUIRED`; V14 Admin Restore รองรับ Cloudflare D1 เท่านั้น
- เพิ่ม Safety Matrix และ package parity tests ให้ Demo / Basic / Standard / Pro ใช้ implementation ชุดเดียวกัน

## Recovery Model

V14 แยก Recovery เป็น 3 ชั้น:

1. Application Backup `.dormbackup`
2. **D1 raw export** ผ่าน `npm run d1:backup`
3. **Cloudflare D1 Time Travel** สำหรับเหตุระดับฐานข้อมูล

`.dormbackup` ไม่ใช่ตัวแทนของ D1 raw export หรือ Time Travel และไม่ควรเป็น Backup เพียงชั้นเดียวก่อน Migration/Upgrade สำคัญ

## สิ่งที่สืบทอดจาก V13

- Master Package Builder สร้าง Demo / Basic / Standard / Pro จาก source เดียว พร้อม audit + ZIP verify + SHA-256
- Plan Entitlements แยกจาก RBAC
- Setup/Deploy/Upgrade Manager ใช้ Pages Project + D1 เดิมได้
- Windows launchers รองรับ `.cmd` และ D1 backup
- บิลมือถือคง layout แบบคอมและย่อทั้งใบ
- URL หลัง Deploy อ่านจาก Cloudflare Project Domains จริง
- ไม่มี default admin password fallback ใน Express/VPS path
