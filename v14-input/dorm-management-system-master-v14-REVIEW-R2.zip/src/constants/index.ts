/**
 * Centralized Single Source of Truth for Enums, Roles, Statuses, and Application Constants
 */

export const Roles = {
  SUPER_ADMIN: 'super_admin',
  OWNER: 'owner',
  MANAGER: 'manager',
  STAFF: 'staff',
  TENANT: 'tenant',
  CARETAKER: 'caretaker',
} as const;

export const RoomStatus = {
  VACANT: 'vacant',
  OCCUPIED: 'occupied',
} as const;

export const BillStatus = {
  UNPAID: 'unpaid',
  PAID: 'paid',
} as const;

export const SlipStatus = {
  NONE: 'none',
  PENDING: 'pending',
  VERIFIED: 'verified',
  REJECTED: 'rejected',
} as const;

export const TicketStatus = {
  PENDING: 'pending',
  IN_PROGRESS: 'in_progress',
  COMPLETED: 'completed',
  CANCELLED: 'cancelled',
} as const;

export const TicketPriority = {
  LOW: 'low',
  MEDIUM: 'medium',
  HIGH: 'high',
  URGENT: 'urgent',
} as const;

export const ContractStatus = {
  ACTIVE: 'active',
  EXPIRING_SOON: 'expiring_soon',
  EXPIRED: 'expired',
  TERMINATED: 'terminated',
} as const;

export const AnnouncementCategory = {
  GENERAL: 'general',
  MAINTENANCE: 'maintenance',
  BILLING: 'billing',
  URGENT: 'urgent',
} as const;

export const AppColors = {
  PRIMARY: '#1DB954',
  PRIMARY_HOVER: '#1ED760',
  BACKGROUND: '#F5F5F0',
  TEXT_DARK: '#1A1A1A',
  TEXT_MUTED: '#8A8A85',
  BORDER: '#E0E0DB',
  CARD_BG: '#F0F0EB',
  ERROR: '#E22134',
  WARNING: '#F59B23',
  BLUE: '#2563EB',
  PURPLE: '#A855F7',
} as const;
