export type SubscriptionPlan = 'demo' | 'basic' | 'standard' | 'pro';

export type PlanFeature =
  | 'settings'
  | 'notes'
  | 'promptPay'
  | 'bulkMeter'
  | 'reports'
  | 'recurringCharges'
  | 'staff'
  | 'contracts'
  | 'checkout'
  | 'maintenance'
  | 'housekeeping'
  | 'announcements'
  | 'tenantPortal'
  | 'lineIntegration'
  | 'googleSheets'
  | 'auditLogs'
  | 'backupExport'
  | 'backupRestore';

export type PlanLimit = 'maxRooms' | 'maxStaff';

export interface PlanEntitlements {
  limits: Record<PlanLimit, number>;
  features: Record<PlanFeature, boolean>;
}

const featureSet = (enabled: readonly PlanFeature[]): Record<PlanFeature, boolean> => {
  const all: PlanFeature[] = [
    'settings', 'notes', 'promptPay', 'bulkMeter', 'reports', 'recurringCharges', 'staff',
    'contracts', 'checkout', 'maintenance', 'housekeeping', 'announcements', 'tenantPortal',
    'lineIntegration', 'googleSheets', 'auditLogs', 'backupExport', 'backupRestore',
  ];
  return Object.fromEntries(all.map((feature) => [feature, enabled.includes(feature)])) as Record<PlanFeature, boolean>;
};

export const PLAN_ENTITLEMENTS: Readonly<Record<SubscriptionPlan, PlanEntitlements>> = Object.freeze({
  demo: {
    limits: { maxRooms: 5, maxStaff: 0 },
    features: featureSet(['promptPay', 'bulkMeter', 'reports', 'announcements', 'tenantPortal', 'backupExport']),
  },
  basic: {
    limits: { maxRooms: 10, maxStaff: 0 },
    features: featureSet(['settings', 'notes', 'backupExport', 'backupRestore']),
  },
  standard: {
    limits: { maxRooms: 30, maxStaff: 2 },
    features: featureSet(['settings', 'notes', 'promptPay', 'bulkMeter', 'reports', 'recurringCharges', 'staff', 'backupExport', 'backupRestore']),
  },
  pro: {
    limits: { maxRooms: 100, maxStaff: 5 },
    features: featureSet([
      'settings', 'notes', 'promptPay', 'bulkMeter', 'reports', 'recurringCharges', 'staff',
      'contracts', 'checkout', 'maintenance', 'housekeeping', 'announcements', 'tenantPortal',
      'lineIntegration', 'googleSheets', 'auditLogs', 'backupExport', 'backupRestore',
    ]),
  },
});

export function normalizeSubscriptionPlan(value: unknown): SubscriptionPlan {
  const normalized = String(value ?? '').trim().toLowerCase();
  return normalized === 'demo' || normalized === 'basic' || normalized === 'standard' || normalized === 'pro'
    ? normalized
    : 'pro';
}

export function getPlanEntitlements(plan: unknown): PlanEntitlements {
  return PLAN_ENTITLEMENTS[normalizeSubscriptionPlan(plan)];
}

export function hasPlanFeature(plan: unknown, feature: PlanFeature): boolean {
  return getPlanEntitlements(plan).features[feature];
}

export function getPlanLimit(plan: unknown, limit: PlanLimit): number {
  return getPlanEntitlements(plan).limits[limit];
}

export function isDemoPlan(plan: unknown): boolean {
  return normalizeSubscriptionPlan(plan) === 'demo';
}
