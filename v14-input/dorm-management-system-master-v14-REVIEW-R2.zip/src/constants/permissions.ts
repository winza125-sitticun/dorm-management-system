import type { UserRole } from '../types.ts';

export const PERMISSIONS = {
  VIEW_DASHBOARD: 'view_dashboard',
  VIEW_ROOMS: 'view_rooms',
  MANAGE_ROOMS: 'manage_rooms',
  VIEW_BILLS: 'view_bills',
  MANAGE_BILLS: 'manage_bills',
  EDIT_PAYMENTS: 'edit_payments',
  VIEW_REPORTS: 'view_reports',
  VIEW_CONTRACTS: 'view_contracts',
  MANAGE_CONTRACTS: 'manage_contracts',
  PROCESS_CHECKOUT: 'process_checkout',
  VIEW_MAINTENANCE: 'view_maintenance',
  MANAGE_MAINTENANCE: 'manage_maintenance',
  VIEW_HOUSEKEEPING: 'view_housekeeping',
  MANAGE_HOUSEKEEPING: 'manage_housekeeping',
  MANAGE_ANNOUNCEMENTS: 'manage_announcements',
  MANAGE_SETTINGS: 'manage_settings',
  MANAGE_RECURRING_CHARGES: 'manage_recurring_charges',
} as const;

export type Permission = typeof PERMISSIONS[keyof typeof PERMISSIONS];

export const PERMISSION_CATALOG: Array<{ key: Permission; label: string; group: string }> = [
  { key: PERMISSIONS.VIEW_DASHBOARD, label: 'ดูภาพรวม', group: 'ทั่วไป' },
  { key: PERMISSIONS.VIEW_ROOMS, label: 'ดูข้อมูลห้องพัก', group: 'ห้องพัก' },
  { key: PERMISSIONS.MANAGE_ROOMS, label: 'จัดการห้องพักและผู้เช่า', group: 'ห้องพัก' },
  { key: PERMISSIONS.VIEW_BILLS, label: 'ดูบิล', group: 'การเงิน' },
  { key: PERMISSIONS.MANAGE_BILLS, label: 'สร้างและแก้ไขบิล', group: 'การเงิน' },
  { key: PERMISSIONS.EDIT_PAYMENTS, label: 'ตรวจรับและแก้ไขการชำระ', group: 'การเงิน' },
  { key: PERMISSIONS.VIEW_REPORTS, label: 'ดูรายงาน', group: 'การเงิน' },
  { key: PERMISSIONS.VIEW_CONTRACTS, label: 'ดูสัญญาเช่า', group: 'สัญญา' },
  { key: PERMISSIONS.MANAGE_CONTRACTS, label: 'จัดการสัญญาเช่า', group: 'สัญญา' },
  { key: PERMISSIONS.PROCESS_CHECKOUT, label: 'ย้ายออกและคืนเงินประกัน', group: 'สัญญา' },
  { key: PERMISSIONS.VIEW_MAINTENANCE, label: 'ดูงานแจ้งซ่อม', group: 'งานบริการ' },
  { key: PERMISSIONS.MANAGE_MAINTENANCE, label: 'จัดการงานแจ้งซ่อม', group: 'งานบริการ' },
  { key: PERMISSIONS.VIEW_HOUSEKEEPING, label: 'ดูงานแม่บ้าน', group: 'งานบริการ' },
  { key: PERMISSIONS.MANAGE_HOUSEKEEPING, label: 'จัดการงานแม่บ้าน', group: 'งานบริการ' },
  { key: PERMISSIONS.MANAGE_ANNOUNCEMENTS, label: 'จัดการประกาศ', group: 'ทั่วไป' },
  { key: PERMISSIONS.MANAGE_RECURRING_CHARGES, label: 'จัดการค่าบริการประจำ', group: 'ระบบ' },
  { key: PERMISSIONS.MANAGE_SETTINGS, label: 'จัดการตั้งค่าระบบ', group: 'ระบบ' },
];

export const ROLE_LABELS: Record<string, string> = {
  super_admin: 'ผู้ดูแลระบบสูงสุด',
  owner: 'เจ้าของหอพัก',
  caretaker: 'ผู้ดูแลทั่วไป',
  accountant: 'พนักงานบัญชี',
  technician: 'ช่าง',
  housekeeper: 'แม่บ้าน',
};

export const ROLE_PRESETS: Record<string, Permission[]> = {
  caretaker: [
    PERMISSIONS.VIEW_DASHBOARD, PERMISSIONS.VIEW_ROOMS, PERMISSIONS.MANAGE_ROOMS,
    PERMISSIONS.VIEW_BILLS, PERMISSIONS.MANAGE_BILLS, PERMISSIONS.EDIT_PAYMENTS,
  ],
  accountant: [
    PERMISSIONS.VIEW_DASHBOARD, PERMISSIONS.VIEW_ROOMS, PERMISSIONS.VIEW_BILLS,
    PERMISSIONS.MANAGE_BILLS, PERMISSIONS.EDIT_PAYMENTS, PERMISSIONS.VIEW_REPORTS,
    PERMISSIONS.VIEW_CONTRACTS, PERMISSIONS.PROCESS_CHECKOUT,
  ],
  technician: [
    PERMISSIONS.VIEW_DASHBOARD, PERMISSIONS.VIEW_ROOMS,
    PERMISSIONS.VIEW_MAINTENANCE, PERMISSIONS.MANAGE_MAINTENANCE,
  ],
  housekeeper: [
    PERMISSIONS.VIEW_DASHBOARD, PERMISSIONS.VIEW_ROOMS,
    PERMISSIONS.VIEW_HOUSEKEEPING, PERMISSIONS.MANAGE_HOUSEKEEPING,
  ],
};

const LEGACY_PERMISSION_EXPANSION: Record<string, Permission[]> = {
  manage_rooms: [PERMISSIONS.VIEW_ROOMS, PERMISSIONS.MANAGE_ROOMS, PERMISSIONS.VIEW_CONTRACTS, PERMISSIONS.MANAGE_CONTRACTS],
  manage_bills: [PERMISSIONS.VIEW_BILLS, PERMISSIONS.MANAGE_BILLS, PERMISSIONS.VIEW_REPORTS],
  edit_payments: [PERMISSIONS.EDIT_PAYMENTS],
  manage_settings: [PERMISSIONS.MANAGE_SETTINGS, PERMISSIONS.MANAGE_RECURRING_CHARGES],
};

export function parsePermissions(value?: string | null): Permission[] {
  const raw = String(value || '').split(',').map((item) => item.trim()).filter(Boolean);
  const expanded = raw.flatMap((item) => LEGACY_PERMISSION_EXPANSION[item] || [item as Permission]);
  return Array.from(new Set(expanded));
}

export function hasAppPermission(role: UserRole | string, value: string | null | undefined, permission: Permission): boolean {
  if (role === 'owner' || role === 'super_admin') return true;
  return parsePermissions(value).includes(permission);
}

export function permissionsForRole(role: string): Permission[] {
  return [...(ROLE_PRESETS[role] || ROLE_PRESETS.caretaker)];
}

