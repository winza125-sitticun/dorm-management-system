import React, { useState, useRef } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { useToast } from '../context/ToastContext.tsx';
import { 
  Building2, 
  LogIn, 
  ShieldCheck, 
  Zap, 
  User, 
  Lock, 
  Eye, 
  EyeOff, 
  MessageSquare,
  AlertCircle,
  WifiOff
} from 'lucide-react';
import { motion } from 'motion/react';

interface FieldErrors {
  username?: string;
  password?: string;
}

export const Login: React.FC = () => {
  const { loginWithCredentials, loginPending } = useAuth();
  const { error: toastError } = useToast();
  
  // General (server/network) error
  const [generalError, setGeneralError] = useState<string | null>(null);
  const [isNetworkError, setIsNetworkError] = useState(false);
  
  // Per-field inline validation errors
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({});
  
  // Tracks whether each field has been "touched" (blurred or submitted)
  const [touched, setTouched] = useState<{ username: boolean; password: boolean }>({ username: false, password: false });
  
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  
  // Shake animation trigger
  const [shakeKey, setShakeKey] = useState(0);
  
  const formRef = useRef<HTMLFormElement>(null);

  // ──────────────────────────────────────────────
  //  Inline field validation (client-side)
  // ──────────────────────────────────────────────
  const validateFields = (u: string, p: string): FieldErrors => {
    const errors: FieldErrors = {};
    if (!u.trim()) {
      errors.username = 'กรุณากรอกชื่อผู้ใช้งาน หรือ อีเมล';
    }
    if (!p.trim()) {
      errors.password = 'กรุณากรอกรหัสผ่าน';
    } else if (p.trim().length < 4) {
      errors.password = 'รหัสผ่านต้องมีอย่างน้อย 4 ตัวอักษร';
    }
    return errors;
  };

  const handleFieldChange = (field: 'username' | 'password', value: string) => {
    if (field === 'username') setUsername(value);
    else setPassword(value);

    // Clear field-level error on change if field was previously touched
    if (touched[field]) {
      const newU = field === 'username' ? value : username;
      const newP = field === 'password' ? value : password;
      const errors = validateFields(newU, newP);
      setFieldErrors(prev => ({ ...prev, [field]: errors[field] }));
    }
    // Clear general error when user starts typing again
    if (generalError) setGeneralError(null);
    if (isNetworkError) setIsNetworkError(false);
  };

  const handleBlur = (field: 'username' | 'password') => {
    setTouched(prev => ({ ...prev, [field]: true }));
    const errors = validateFields(username, password);
    setFieldErrors(prev => ({ ...prev, [field]: errors[field] }));
  };

  // ──────────────────────────────────────────────
  //  Submit handler
  // ──────────────────────────────────────────────
  const handleCredentialsLogin = async (e: React.FormEvent) => {
    e.preventDefault();

    // Mark all fields as touched
    setTouched({ username: true, password: true });

    // Run client-side validation
    const errors = validateFields(username, password);
    setFieldErrors(errors);

    if (Object.keys(errors).length > 0) {
      const errMsg = 'กรุณากรอกข้อมูลให้ครบถ้วน';
      setGeneralError(errMsg);
      setIsNetworkError(false);
      toastError(errMsg, 'เข้าสู่ระบบไม่สำเร็จ', 5000);
      setShakeKey(k => k + 1);
      return;
    }

    try {
      setGeneralError(null);
      setIsNetworkError(false);
      await loginWithCredentials(username, password);
    } catch (err: any) {
      console.error('[Login] loginWithCredentials error:', err);

      // Detect network / connectivity errors
      const isNetwork = isNetworkErrorType(err);
      setIsNetworkError(isNetwork);

      const errMsg = isNetwork
        ? 'ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์ได้ กรุณาตรวจสอบการเชื่อมต่ออินเทอร์เน็ต'
        : (typeof err === 'string' ? err : (err?.message && typeof err.message === 'string' ? err.message : 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง'));

      setGeneralError(errMsg);
      toastError(errMsg, 'เข้าสู่ระบบไม่สำเร็จ', 5000);
      setShakeKey(k => k + 1);
    }
  };

  // ──────────────────────────────────────────────
  //  Helper: detect network-level failures
  // ──────────────────────────────────────────────
  const isNetworkErrorType = (err: any): boolean => {
    if (err instanceof TypeError && /fetch|network|failed/i.test(err.message)) return true;
    if (err?.name === 'AbortError') return true;
    if (err?.message && /ไม่สามารถเชื่อมต่อ|network|ECONNREFUSED|ERR_CONNECTION|fetch/i.test(err.message)) return true;
    return false;
  };

  // ──────────────────────────────────────────────
  //  Field border classes — turns red on error
  // ──────────────────────────────────────────────
  const inputBaseClass = 'block w-full py-2.5 bg-[#F0F0EB] border rounded-xl text-[#1A1A1A] text-xs focus:outline-none transition';
  
  const usernameInputClass = `${inputBaseClass} pl-9 pr-3 ${
    fieldErrors.username
      ? 'border-[#E22134] bg-[#E22134]/[0.04] focus:border-[#E22134] focus:bg-white'
      : 'border-transparent focus:border-[#1DB954] focus:bg-white'
  }`;
  
  const passwordInputClass = `${inputBaseClass} pl-9 pr-10 ${
    fieldErrors.password
      ? 'border-[#E22134] bg-[#E22134]/[0.04] focus:border-[#E22134] focus:bg-white'
      : 'border-transparent focus:border-[#1DB954] focus:bg-white'
  }`;

  return (
    <div className="min-h-screen bg-[#F5F5F0] flex flex-col items-center justify-center p-4 relative overflow-hidden font-sans">
      
      {/* Decorative Blur Orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#1DB954]/5 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2 pointer-events-none"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#1DB954]/5 rounded-full blur-3xl translate-x-1/2 translate-y-1/2 pointer-events-none"></div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="max-w-md w-full text-center z-10"
      >
        {/* Logo Icon */}
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-[#1DB954] p-0.5 mb-6">
          <div className="w-full h-full bg-white rounded-[14px] flex items-center justify-center">
            <Building2 className="w-8 h-8 text-[#1DB954]" />
          </div>
        </div>

        {/* Headings */}
        <h1 className="text-3xl font-extrabold tracking-tight text-[#1A1A1A] sm:text-4xl">
          ระบบจัดการค่าเช่าห้องพัก
        </h1>
        <p className="mt-3 text-[#6B6B66] text-sm sm:text-base max-w-xs mx-auto">
          คำนวณค่าไฟ ค่าน้ำ ออกบิล และเก็บบันทึกประวัติ อย่างถูกต้อง รวดเร็ว ตลอด 24 ชม.
        </p>

        {/* Login Box — shakes on error */}
        <motion.div
          key={shakeKey}
          animate={shakeKey > 0 ? { x: [0, -8, 8, -6, 6, -3, 3, 0] } : {}}
          transition={{ duration: 0.5 }}
          className="mt-8 bg-white border border-[#E0E0DB] rounded-2xl p-6 text-left space-y-4"
        >
          <h2 className="text-base font-bold text-[#1A1A1A] flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-[#1DB954]" />
            <span>เข้าสู่ระบบผู้ดูแลระบบ (Admin / Staff)</span>
          </h2>

          <form ref={formRef} onSubmit={handleCredentialsLogin} className="space-y-4" noValidate>

            {/* ── Username Field ── */}
            <div>
              <label htmlFor="login-username" className="block text-[#8A8A85] font-bold mb-1 uppercase tracking-wider text-[10px]">
                ชื่อผู้ใช้งาน หรือ อีเมล (Username / Email)
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <User className={`h-4 w-4 ${fieldErrors.username ? 'text-[#E22134]' : 'text-[#8A8A85]'}`} />
                </div>
                <input
                  id="login-username"
                  type="text"
                  placeholder="กรอก admin, อีเมล หรือ User ID ของคุณ"
                  value={username}
                  onChange={(e) => handleFieldChange('username', e.target.value)}
                  onBlur={() => handleBlur('username')}
                  aria-invalid={!!fieldErrors.username}
                  aria-describedby={fieldErrors.username ? 'username-error' : undefined}
                  className={usernameInputClass}
                  autoComplete="username"
                />
              </div>
              {/* Inline field error */}
              {fieldErrors.username && (
                <p id="username-error" role="alert" className="mt-1.5 flex items-center gap-1 text-[#E22134] text-[11px] font-semibold">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  {fieldErrors.username}
                </p>
              )}
            </div>

            {/* ── Password Field ── */}
            <div>
              <label htmlFor="login-password" className="block text-[#8A8A85] font-bold mb-1 uppercase tracking-wider text-[10px]">
                รหัสผ่าน (Password)
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock className={`h-4 w-4 ${fieldErrors.password ? 'text-[#E22134]' : 'text-[#8A8A85]'}`} />
                </div>
                <input
                  id="login-password"
                  type={showPassword ? "text" : "password"}
                  placeholder="กรอก admin หรือรหัสผ่านของคุณ"
                  value={password}
                  onChange={(e) => handleFieldChange('password', e.target.value)}
                  onBlur={() => handleBlur('password')}
                  aria-invalid={!!fieldErrors.password}
                  aria-describedby={fieldErrors.password ? 'password-error' : undefined}
                  className={passwordInputClass}
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-[#8A8A85] hover:text-[#1A1A1A] cursor-pointer"
                  tabIndex={-1}
                  aria-label={showPassword ? 'ซ่อนรหัสผ่าน' : 'แสดงรหัสผ่าน'}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              {/* Inline field error */}
              {fieldErrors.password && (
                <p id="password-error" role="alert" className="mt-1.5 flex items-center gap-1 text-[#E22134] text-[11px] font-semibold">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  {fieldErrors.password}
                </p>
              )}
            </div>

            {/* ── General Error Banner (server / network) ── */}
            {generalError && (
              <motion.div
                initial={{ opacity: 0, y: -6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.25 }}
                role="alert"
                aria-live="assertive"
                className="p-3 rounded-xl text-[11px] leading-relaxed space-y-2"
                style={{
                  backgroundColor: isNetworkError ? 'rgba(245, 155, 35, 0.08)' : 'rgba(226, 33, 52, 0.08)',
                  border: `1px solid ${isNetworkError ? 'rgba(245, 155, 35, 0.30)' : 'rgba(226, 33, 52, 0.30)'}`,
                }}
              >
                <div className="flex items-start gap-2">
                  {isNetworkError
                    ? <WifiOff className="w-4 h-4 shrink-0 mt-0.5" style={{ color: '#F59B23' }} />
                    : <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" style={{ color: '#E22134' }} />
                  }
                  <div>
                    <p className="font-extrabold" style={{ color: isNetworkError ? '#F59B23' : '#E22134' }}>
                      {isNetworkError ? 'ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์:' : 'เข้าสู่ระบบไม่สำเร็จ:'}
                    </p>
                    <p className="font-semibold" style={{ color: isNetworkError ? '#F59B23' : '#E22134' }}>
                      {generalError}
                    </p>
                  </div>
                </div>
                
                <div
                  className="pt-1.5 space-y-1 text-[10px]"
                  style={{
                    borderTop: `1px solid ${isNetworkError ? 'rgba(245, 155, 35, 0.20)' : 'rgba(226, 33, 52, 0.20)'}`,
                    color: isNetworkError ? '#F59B23' : '#E22134',
                  }}
                >
                  {isNetworkError ? (
                    <>
                      <p className="font-bold">🔌 คำแนะนำ:</p>
                      <p>• ตรวจสอบว่าอุปกรณ์มีการเชื่อมต่ออินเทอร์เน็ต</p>
                      <p>• ลองรีเฟรชหน้าเว็บ (กด F5 หรือ Ctrl+R)</p>
                      <p>• หากยังใช้งานไม่ได้ อาจเป็นเพราะเซิร์ฟเวอร์กำลังบำรุงรักษา</p>
                    </>
                  ) : (
                    <>
                      <p className="font-bold">💡 คำแนะนำช่วยตรวจทาน:</p>
                      <p>• <b>ชื่อผู้ใช้และรหัสผ่าน:</b> กรุณาใช้ชื่อผู้ใช้และรหัสผ่านที่ตั้งไว้ในขั้นตอนเริ่มต้นใช้งาน (First Setup Wizard)</p>
                      <p>• <b>ตัวพิมพ์เล็ก-ใหญ่มีผล (Case-sensitive):</b> ตรวจสอบว่าคุณกดปุ่ม Caps Lock ค้างไว้หรือไม่</p>
                    </>
                  )}
                </div>
              </motion.div>
            )}

            <button
              type="submit"
              disabled={loginPending}
              className="w-full py-3 px-4 rounded-full bg-[#1DB954] hover:bg-[#1ED760] disabled:bg-[#1DB954]/30 text-white font-bold flex items-center justify-center gap-2 transition hover:scale-[1.04] cursor-pointer text-xs"
            >
              {loginPending ? (
                <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
              ) : (
                <>
                  <LogIn className="w-4 h-4" />
                  <span>เข้าสู่ระบบ Cloudflare Native</span>
                </>
              )}
            </button>
          </form>

          <div className="pt-2 border-t border-[#E0E0DB] text-center">
            <button
              onClick={() => {
                window.history.pushState({}, '', '/line-register');
                window.dispatchEvent(new PopStateEvent('popstate'));
              }}
              className="text-xs text-[#1DB954] hover:text-[#1ED760] font-extrabold transition cursor-pointer"
            >
              สำหรับผู้เช่า: ตรวจสอบบิล & เชื่อมต่อ LINE →
            </button>
          </div>
        </motion.div>

        {/* Mini Features List */}
        <div className="mt-8 grid grid-cols-3 gap-4 text-[#6B6B66] text-center text-xxs font-sans">
          <div className="flex flex-col items-center gap-1.5">
            <Zap className="w-4 h-4 text-[#1DB954]" />
            <p className="font-semibold text-[#6B6B66]">คำนวณมิเตอร์แม่นยำ</p>
          </div>
          <div className="flex flex-col items-center gap-1.5">
            <MessageSquare className="w-4 h-4 text-[#1DB954]" />
            <p className="font-semibold text-[#6B6B66]">ส่งบิลเข้า LINE</p>
          </div>
          <div className="flex flex-col items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-[#1DB954]" />
            <p className="font-semibold text-[#6B6B66]">Cloudflare D1 Database</p>
          </div>
        </div>

      </motion.div>
    </div>
  );
};
