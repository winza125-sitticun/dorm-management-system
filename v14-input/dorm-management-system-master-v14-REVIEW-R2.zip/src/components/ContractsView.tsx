import React, { useState } from 'react';
import { 
  FileText, 
  Plus, 
  Search, 
  Calendar, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  DollarSign, 
  User, 
  Phone, 
  CreditCard, 
  FileSignature, 
  Eye, 
  Edit3, 
  Trash2, 
  LogOut, 
  Calculator, 
  X, 
  Check, 
  FileDown, 
  Download,
  AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Room, LeaseContract, ContractStatus } from '../types.ts';
import { TenantService } from '../services/tenant.service.ts';

interface ContractsViewProps {
  contracts: LeaseContract[];
  rooms: Room[];
  idToken: string | null;
  onRefresh: () => void;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  canManage?: boolean;
  canCheckout?: boolean;
}

const STATUS_BADGES: Record<ContractStatus, { label: string; bg: string; icon: any }> = {
  active: { label: 'สัญญาปกติ', bg: 'bg-[#1DB954]/8 text-[#1DB954] border-[#1DB954]/30', icon: CheckCircle2 },
  expiring_soon: { label: 'ใกล้อายุนัดหมาย ⚠️', bg: 'bg-[#F59B23]/8 text-[#F59B23] border-[#F59B23]/30 font-bold animate-pulse', icon: AlertTriangle },
  expired: { label: 'หมดสัญญาแล้ว', bg: 'bg-[#E22134]/8 text-[#E22134] border-[#E22134]/30 font-semibold', icon: Clock },
  terminated: { label: 'ย้ายออก / สิ้นสุด', bg: 'bg-[#F0F0EB] text-[#6B6B66] border-[#E0E0DB]', icon: XCircle },
};

export const ContractsView: React.FC<ContractsViewProps> = ({
  contracts,
  rooms,
  idToken,
  onRefresh,
  showToast,
  canManage = true,
  canCheckout = true,
}) => {
  const getApiErrorMessage = (payload: any, fallback: string) => {
    if (typeof payload?.error === 'string') return payload.error;
    if (typeof payload?.error?.message === 'string') return payload.error.message;
    if (typeof payload?.message === 'string') return payload.message;
    return fallback;
  };
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  
  // Modals
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [selectedContract, setSelectedContract] = useState<LeaseContract | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isCheckoutModalOpen, setIsCheckoutModalOpen] = useState(false);

  const handleCheckoutOpen = (contract: LeaseContract) => {
    setSelectedContract(contract);
    setCheckoutOtherDeduction(0);
    setCheckoutNote('');
    setIsCheckoutModalOpen(true);
  };

  // Create contract form state
  const [newRoomId, setNewRoomId] = useState<string>('');
  const [newTenantName, setNewTenantName] = useState<string>('');
  const [newTenantPhone, setNewTenantPhone] = useState<string>('');
  const [newIdCardNumber, setNewIdCardNumber] = useState<string>('');
  const [newStartDate, setNewStartDate] = useState<string>(new Date().toISOString().substring(0, 10));
  const [newEndDate, setNewEndDate] = useState<string>(
    new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().substring(0, 10)
  );
  const [newMonthlyRent, setNewMonthlyRent] = useState<number>(0);
  const [newDepositAmount, setNewDepositAmount] = useState<number>(0);
  const [newAdvanceRentAmount, setNewAdvanceRentAmount] = useState<number>(0);
  const [newContractDocumentUrl, setNewContractDocumentUrl] = useState<string>('');
  const [newNote, setNewNote] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Edit contract form state
  const [editTenantName, setEditTenantName] = useState('');
  const [editTenantPhone, setEditTenantPhone] = useState('');
  const [editIdCardNumber, setEditIdCardNumber] = useState('');
  const [editStartDate, setEditStartDate] = useState('');
  const [editEndDate, setEditEndDate] = useState('');
  const [editMonthlyRent, setEditMonthlyRent] = useState(0);
  const [editDepositAmount, setEditDepositAmount] = useState(0);
  const [editAdvanceRentAmount, setEditAdvanceRentAmount] = useState(0);
  const [editContractDocumentUrl, setEditContractDocumentUrl] = useState('');
  const [editNote, setEditNote] = useState('');

  // Checkout deposit calculator state
  const [checkoutUtilityDeduction, setCheckoutUtilityDeduction] = useState<number>(0);
  const [checkoutDamageDeduction, setCheckoutDamageDeduction] = useState<number>(0);
  const [checkoutOtherDeduction, setCheckoutOtherDeduction] = useState<number>(0);
  const [checkoutNote, setCheckoutNote] = useState<string>('');

  const getHeaders = () => ({
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${idToken}`,
  });

  // Automatically update rent/deposit defaults when room selected
  const handleRoomSelect = (roomIdStr: string) => {
    setNewRoomId(roomIdStr);
    const room = rooms.find(r => r.id === parseInt(roomIdStr));
    if (room) {
      setNewMonthlyRent(room.monthlyRent);
      setNewDepositAmount(room.monthlyRent * 2); // default 2 months deposit
      setNewAdvanceRentAmount(room.monthlyRent);
      if (room.tenantName) setNewTenantName(room.tenantName);
      if (room.tenantPhone) setNewTenantPhone(room.tenantPhone);
    }
  };

  // Helper for quick contract duration selection
  const setQuickDuration = (months: number) => {
    if (!newStartDate) return;
    const start = new Date(newStartDate);
    start.setMonth(start.getMonth() + months);
    setNewEndDate(start.toISOString().substring(0, 10));
  };

  // Stats
  const totalContracts = contracts.length;
  const activeCount = contracts.filter(c => c.status === 'active').length;
  const expiringSoonCount = contracts.filter(c => c.status === 'expiring_soon').length;
  const expiredCount = contracts.filter(c => c.status === 'expired').length;
  const totalDepositHold = contracts
    .filter(c => c.status === 'active' || c.status === 'expiring_soon')
    .reduce((acc, c) => acc + (c.depositAmount || 0), 0);

  // Filtered contracts
  const filteredContracts = contracts.filter(c => {
    const matchesSearch =
      c.roomNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.tenantName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (c.tenantPhone && c.tenantPhone.includes(searchTerm)) ||
      (c.idCardNumber && c.idCardNumber.includes(searchTerm));

    const matchesStatus = selectedStatus === 'all' || c.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  const handleCreateContract = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoomId || !newTenantName.trim() || !newStartDate || !newEndDate) {
      showToast('กรุณากรอกข้อมูลที่จำเป็นให้ครบถ้วน', 'error');
      return;
    }

    // Validate room occupancy before creating contract
    const occupancyValidation = TenantService.validateRoomOccupancy(parseInt(newRoomId), rooms, contracts);
    if (occupancyValidation.isOccupied) {
      showToast(occupancyValidation.message || 'ห้องนี้มีผู้เช่าอยู่แล้ว ไม่สามารถทำสัญญาเช่าซ้ำซ้อนได้', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/contracts', {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify({
          roomId: parseInt(newRoomId),
          tenantName: newTenantName,
          tenantPhone: newTenantPhone,
          idCardNumber: newIdCardNumber,
          startDate: newStartDate,
          endDate: newEndDate,
          monthlyRent: newMonthlyRent,
          depositAmount: newDepositAmount,
          advanceRentAmount: newAdvanceRentAmount,
          contractDocumentUrl: newContractDocumentUrl || null,
          note: newNote,
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(getApiErrorMessage(err, 'ไม่สามารถทำสัญญาเช่าได้'));
      }

      showToast('ทำสัญญาเช่าใหม่เรียบร้อยแล้ว', 'success');
      setIsCreateModalOpen(false);
      // Reset form
      setNewRoomId('');
      setNewTenantName('');
      setNewTenantPhone('');
      setNewIdCardNumber('');
      setNewContractDocumentUrl('');
      setNewNote('');
      onRefresh();
    } catch (err: any) {
      showToast(err.message || 'เกิดข้อผิดพลาดในการทำสัญญา', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const openEditModal = (contract: LeaseContract) => {
    setSelectedContract(contract);
    setEditTenantName(contract.tenantName);
    setEditTenantPhone(contract.tenantPhone || '');
    setEditIdCardNumber(contract.idCardNumber || '');
    setEditStartDate(contract.startDate);
    setEditEndDate(contract.endDate);
    setEditMonthlyRent(contract.monthlyRent);
    setEditDepositAmount(contract.depositAmount);
    setEditAdvanceRentAmount(contract.advanceRentAmount);
    setEditContractDocumentUrl(contract.contractDocumentUrl || '');
    setEditNote(contract.note || '');
    setIsEditModalOpen(true);
  };

  const handleUpdateContract = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedContract) return;

    setIsSubmitting(true);
    try {
      const res = await fetch(`/api/contracts/${selectedContract.id}`, {
        method: 'PUT',
        headers: getHeaders(),
        body: JSON.stringify({
          tenantName: editTenantName,
          tenantPhone: editTenantPhone,
          idCardNumber: editIdCardNumber,
          startDate: editStartDate,
          endDate: editEndDate,
          monthlyRent: editMonthlyRent,
          depositAmount: editDepositAmount,
          advanceRentAmount: editAdvanceRentAmount,
          contractDocumentUrl: editContractDocumentUrl || null,
          note: editNote,
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(getApiErrorMessage(err, 'ไม่สามารถอัปเดตสัญญาเช่าได้'));
      }

      showToast('อัปเดตข้อมูลสัญญาเช่าเรียบร้อยแล้ว', 'success');
      setIsEditModalOpen(false);
      onRefresh();
    } catch (err: any) {
      showToast(err.message || 'เกิดข้อผิดพลาดในการอัปเดตสัญญา', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const openCheckoutModal = (contract: LeaseContract) => {
    setSelectedContract(contract);
    setCheckoutUtilityDeduction(0);
    setCheckoutDamageDeduction(0);
    setCheckoutOtherDeduction(0);
    setCheckoutNote('');
    setIsCheckoutModalOpen(true);
  };

  const handleCheckoutSubmit = async () => {
    if (!selectedContract) return;

    if (!window.confirm(`ยืนยันการทำรายการย้ายออกสำหรับ ห้อง ${selectedContract.roomNumber} (${selectedContract.tenantName}) ใช่หรือไม่?\nสถานะห้องจะถูกเปลี่ยนเป็น "ห้องว่าง" อัตโนมัติ`)) {
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch(`/api/contracts/${selectedContract.id}/checkout`, {
        method: 'POST',
        headers: getHeaders(),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(getApiErrorMessage(err, 'ไม่สามารถทำรายการย้ายออกได้'));
      }

      showToast(`ทำรายการย้ายออก ห้อง ${selectedContract.roomNumber} เรียบร้อยแล้ว`, 'success');
      setIsCheckoutModalOpen(false);
      onRefresh();
    } catch (err: any) {
      showToast(err.message || 'เกิดข้อผิดพลาดในการทำรายการย้ายออก', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteContract = async (id: number) => {
    if (!window.confirm('คุณต้องการลบข้อมูลสัญญาเช่านี้ใช่หรือไม่?')) return;

    try {
      const res = await fetch(`/api/contracts/${id}`, {
        method: 'DELETE',
        headers: getHeaders(),
      });

      if (!res.ok) throw new Error('Failed to delete contract');

      showToast('ลบสัญญาเช่าเรียบร้อยแล้ว', 'success');
      onRefresh();
    } catch (err: any) {
      showToast('เกิดข้อผิดพลาดในการลบสัญญา', 'error');
    }
  };

  return (
    <div className="space-y-6 pb-12 font-sans">
      {/* Top Banner Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-[#E0E0DB]">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-[#1DB954]/8 rounded-xl text-[#1DB954]">
            <FileSignature className="w-7 h-7" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[#1A1A1A]">ระบบจัดการสัญญาเช่า & เงินประกัน</h1>
            <p className="text-sm text-[#8A8A85]">บันทึกสัญญาเช่า ติดตามวันหมดอายุ และคำนวณเงินประกันคืนเมื่อย้ายออก</p>
          </div>
        </div>

        {canManage && <button
          onClick={() => setIsCreateModalOpen(true)}
          className="flex items-center justify-center gap-2 bg-[#1DB954] hover:bg-[#1ED760] hover:scale-[1.04] text-[#1A1A1A] px-5 py-2.5 rounded-xl font-medium transition-all text-sm cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>ทำสัญญาเช่าใหม่</span>
        </button>}
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-[#E0E0DB] flex items-center gap-4">
          <div className="p-3 rounded-xl bg-[#1DB954]/8 text-[#1DB954]">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-medium text-[#8A8A85]">สัญญายังมีผลบังคับ</p>
            <p className="text-2xl font-bold text-[#1DB954]">{activeCount}</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-[#E0E0DB] flex items-center gap-4">
          <div className="p-3 rounded-xl bg-[#F59B23]/8 text-[#F59B23]">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-medium text-[#8A8A85]">ใกล้อายุนัดหมาย (60 วัน)</p>
            <p className="text-2xl font-bold text-[#F59B23]">{expiringSoonCount}</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-[#E0E0DB] flex items-center gap-4">
          <div className="p-3 rounded-xl bg-[#E22134]/8 text-[#E22134]">
            <Clock className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-medium text-[#8A8A85]">หมดสัญญาแล้ว</p>
            <p className="text-2xl font-bold text-[#E22134]">{expiredCount}</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-[#E0E0DB] flex items-center gap-4">
          <div className="p-3 rounded-xl bg-[#A855F7]/8 text-[#A855F7]">
            <DollarSign className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-medium text-[#8A8A85]">เงินประกันถือครองรวม</p>
            <p className="text-2xl font-bold text-[#A855F7]">฿{totalDepositHold.toLocaleString()}</p>
          </div>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="bg-white p-4 rounded-2xl border border-[#E0E0DB] flex flex-col md:flex-row gap-3 items-center justify-between">
        {/* Search */}
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8A8A85]" />
          <input
            type="text"
            placeholder="ค้นหาห้อง, ชื่อผู้เช่า, เลขบัตร..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20"
          />
          {searchTerm && (
            <button onClick={() => setSearchTerm('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8A8A85] hover:text-slate-600">
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Status Filter */}
        <div className="flex items-center gap-1 bg-[#F0F0EB] p-1 rounded-xl text-xs font-medium w-full md:w-auto overflow-x-auto">
          <button
            onClick={() => setSelectedStatus('all')}
            className={`px-3 py-1.5 rounded-lg transition-all ${selectedStatus === 'all' ? 'bg-white text-[#1A1A1A] font-bold' : 'text-[#6B6B66]'}`}
          >
            ทั้งหมด ({totalContracts})
          </button>
          <button
            onClick={() => setSelectedStatus('active')}
            className={`px-3 py-1.5 rounded-lg transition-all ${selectedStatus === 'active' ? 'bg-white text-[#1DB954] font-bold' : 'text-[#6B6B66]'}`}
          >
            ปกติ ({activeCount})
          </button>
          <button
            onClick={() => setSelectedStatus('expiring_soon')}
            className={`px-3 py-1.5 rounded-lg transition-all ${selectedStatus === 'expiring_soon' ? 'bg-white text-amber-700 font-bold' : 'text-[#6B6B66]'}`}
          >
            ใกล้หมดอายุ ({expiringSoonCount})
          </button>
          <button
            onClick={() => setSelectedStatus('expired')}
            className={`px-3 py-1.5 rounded-lg transition-all ${selectedStatus === 'expired' ? 'bg-white text-[#E22134] font-bold' : 'text-[#6B6B66]'}`}
          >
            หมดอายุ ({expiredCount})
          </button>
          <button
            onClick={() => setSelectedStatus('terminated')}
            className={`px-3 py-1.5 rounded-lg transition-all ${selectedStatus === 'terminated' ? 'bg-white text-[#6B6B66] font-bold' : 'text-[#6B6B66]'}`}
          >
            ย้ายออกแล้ว
          </button>
        </div>
      </div>

      {/* Contracts List Grid */}
      {filteredContracts.length === 0 ? (
        <div className="bg-white p-12 rounded-2xl border border-[#E0E0DB] text-center">
          <div className="w-16 h-16 bg-[#F0F0EB] rounded-full flex items-center justify-center mx-auto mb-4 text-[#8A8A85]">
            <FileSignature className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-[#6B6B66] mb-1">ไม่พบข้อมูลสัญญาเช่า</h3>
          <p className="text-sm text-[#8A8A85]">ยังไม่มีข้อมูลสัญญาเช่าตรงตามเงื่อนไขที่คุณเลือก</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredContracts.map((contract) => {
            const statusInfo = STATUS_BADGES[contract.status] || STATUS_BADGES.active;
            const StatusIcon = statusInfo.icon;

            return (
              <motion.div
                key={contract.id}
                layout
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-white rounded-2xl border border-[#E0E0DB] transition-all flex flex-col justify-between overflow-hidden"
              >
                <div>
                  {/* Card Header */}
                  <div className="p-4 pb-3 border-b border-[#E0E0DB] flex items-center justify-between bg-[#282828]/60">
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-xl text-[#1A1A1A] px-3 py-1 bg-white border border-[#E0E0DB] rounded-xl shadow-2xs">
                        ห้อง {contract.roomNumber}
                      </span>
                    </div>

                    <span className={`text-xs px-2.5 py-1 rounded-full font-medium flex items-center gap-1 border ${statusInfo.bg}`}>
                      <StatusIcon className="w-3.5 h-3.5" />
                      {statusInfo.label}
                    </span>
                  </div>

                  {/* Card Body */}
                  <div className="p-4 space-y-3">
                    <div>
                      <h3 className="font-bold text-[#1A1A1A] text-base flex items-center gap-1.5">
                        <User className="w-4 h-4 text-[#1DB954]" />
                        {contract.tenantName}
                      </h3>
                      {contract.tenantPhone && (
                        <p className="text-xs text-[#8A8A85] flex items-center gap-1 mt-0.5">
                          <Phone className="w-3.5 h-3.5 text-[#8A8A85]" />
                          {contract.tenantPhone}
                        </p>
                      )}
                      {contract.idCardNumber && (
                        <p className="text-xs text-[#8A8A85] flex items-center gap-1 mt-0.5">
                          <CreditCard className="w-3.5 h-3.5 text-[#8A8A85]" />
                          เลขบัตร: {contract.idCardNumber}
                        </p>
                      )}
                    </div>

                    {/* Lease Duration */}
                    <div className="bg-[#F0F0EB] p-3 rounded-xl border border-[#E0E0DB] text-xs space-y-1.5">
                      <div className="flex justify-between items-center text-[#6B6B66]">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5 text-[#8A8A85]" /> วันเริ่มสัญญา:
                        </span>
                        <span className="font-semibold text-[#1A1A1A]">{contract.startDate}</span>
                      </div>
                      <div className="flex justify-between items-center text-[#6B6B66]">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-[#8A8A85]" /> วันสิ้นสุดสัญญา:
                        </span>
                        <span className="font-semibold text-[#E22134]">{contract.endDate}</span>
                      </div>
                    </div>

                    {/* Rent & Deposit Money */}
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="bg-[#1DB954]/10/60 border border-blue-100 p-2.5 rounded-xl">
                        <p className="text-[10px] text-blue-700 font-medium">ค่าเช่าต่อเดือน</p>
                        <p className="text-sm font-extrabold text-blue-900">฿{contract.monthlyRent.toLocaleString()}</p>
                      </div>

                      <div className="bg-[#A855F7]/10/60 border border-purple-100 p-2.5 rounded-xl">
                        <p className="text-[10px] text-purple-700 font-medium">เงินประกันมัดจำ</p>
                        <p className="text-sm font-extrabold text-purple-900">฿{contract.depositAmount.toLocaleString()}</p>
                      </div>
                    </div>

                    {/* Note if available */}
                    {contract.note && (
                      <p className="text-xs text-[#8A8A85] bg-[#F0F0EB] p-2 rounded-lg border border-[#E0E0DB] line-clamp-2">
                        <span className="font-semibold">หมายเหตุ: </span>{contract.note}
                      </p>
                    )}
                  </div>
                </div>

                {/* Card Action Footer */}
                <div className="p-3 border-t border-[#E0E0DB] bg-[#282828]/30 flex items-center justify-between">
                  {canManage ? <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleDeleteContract(contract.id)}
                      className="p-2 text-[#E22134] hover:bg-rose-50 rounded-xl transition-colors text-xs"
                      title="ลบสัญญา"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => openEditModal(contract)}
                      className="p-2 text-[#6B6B66] hover:bg-[#E8E8E3] rounded-xl transition-colors text-xs"
                      title="แก้ไขสัญญา"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                  </div> : <span />}

                  {canCheckout && contract.status !== 'terminated' && (
                    <button
                      onClick={() => openCheckoutModal(contract)}
                      className="flex items-center gap-1 text-xs bg-rose-600 hover:bg-rose-700 text-[#1A1A1A] font-medium px-3.5 py-2 rounded-xl transition-all shadow-2xs cursor-pointer"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>แจ้งย้ายออก & คืนเงินประกัน</span>
                    </button>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* MODAL: Create New Lease Contract */}
      <AnimatePresence>
        {isCreateModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl shadow-xl border border-[#E0E0DB] max-w-lg w-full overflow-hidden max-h-[90vh] flex flex-col"
            >
              {/* Header */}
              <div className="p-5 border-b border-[#E0E0DB] flex items-center justify-between bg-[#F0F0EB]">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-[#1DB954]/8 text-blue-700 rounded-xl">
                    <FileSignature className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="font-bold text-[#1A1A1A] text-lg">ทำสัญญาเช่าใหม่</h2>
                    <p className="text-xs text-[#8A8A85]">บันทึกสัญญาเช่า กำหนดวันหมดอายุ และรับเงินประกัน</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsCreateModalOpen(false)}
                  className="p-2 text-[#8A8A85] hover:text-slate-600 rounded-full hover:bg-slate-200/50 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Form Body */}
              <form onSubmit={handleCreateContract} className="p-6 space-y-4 overflow-y-auto flex-1 text-xs">
                {/* Select Room */}
                <div>
                  <label className="block font-semibold text-[#6B6B66] mb-1.5">เลือกห้องพัก *</label>
                  <select
                    value={newRoomId}
                    onChange={(e) => handleRoomSelect(e.target.value)}
                    required
                    className="w-full p-2.5 border border-[#E0E0DB] rounded-xl bg-[#F0F0EB] focus:outline-none focus:ring-2 focus:ring-blue-500/20 font-bold text-[#1A1A1A]"
                  >
                    <option value="">-- เลือกห้องพัก --</option>
                    {rooms.map((r) => (
                      <option key={r.id} value={r.id}>
                        ห้อง {r.roomNumber} {r.status === 'occupied' ? `(มีผู้เช่า: ${r.tenantName})` : '(ว่าง)'}
                      </option>
                    ))}
                  </select>

                  {/* Room occupancy warning badge if selected room is already occupied */}
                  {newRoomId && (() => {
                    const check = TenantService.validateRoomOccupancy(parseInt(newRoomId), rooms, contracts);
                    if (check.isOccupied) {
                      return (
                        <div className="mt-2 p-2.5 bg-[#E22134]/10 border border-[#E22134]/30 rounded-xl text-[#E22134] text-xs font-semibold flex items-center gap-2">
                          <AlertTriangle className="w-4 h-4 shrink-0 text-[#E22134]" />
                          <span>{check.message}</span>
                        </div>
                      );
                    }
                    return null;
                  })()}
                </div>

                {/* Tenant Details */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-[#6B6B66] mb-1.5">ชื่อ-นามสกุล ผู้เช่า *</label>
                    <input
                      type="text"
                      required
                      placeholder="เช่น สมชาย ใจดี"
                      value={newTenantName}
                      onChange={(e) => setNewTenantName(e.target.value)}
                      className="w-full p-2.5 border border-[#E0E0DB] rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[#6B6B66] mb-1.5">เบอร์โทรศัพท์</label>
                    <input
                      type="tel"
                      placeholder="0812345678"
                      value={newTenantPhone}
                      onChange={(e) => setNewTenantPhone(e.target.value)}
                      className="w-full p-2.5 border border-[#E0E0DB] rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-[#6B6B66] mb-1.5">เลขบัตรประชาชน / พาสปอร์ต</label>
                  <input
                    type="text"
                    placeholder="1100200300400"
                    value={newIdCardNumber}
                    onChange={(e) => setNewIdCardNumber(e.target.value)}
                    className="w-full p-2.5 border border-[#E0E0DB] rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>

                {/* Contract Dates */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-[#6B6B66] mb-1.5">วันเริ่มสัญญา *</label>
                    <input
                      type="date"
                      required
                      value={newStartDate}
                      onChange={(e) => setNewStartDate(e.target.value)}
                      className="w-full p-2.5 border border-[#E0E0DB] rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[#6B6B66] mb-1.5">วันสิ้นสุดสัญญา *</label>
                    <input
                      type="date"
                      required
                      value={newEndDate}
                      onChange={(e) => setNewEndDate(e.target.value)}
                      className="w-full p-2.5 border border-[#E0E0DB] rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    />
                  </div>
                </div>

                {/* Quick duration buttons */}
                <div className="flex items-center gap-2 pt-1">
                  <span className="text-[11px] text-[#8A8A85] font-medium">คำนวณวันสิ้นสุด:</span>
                  <button type="button" onClick={() => setQuickDuration(6)} className="px-2.5 py-1 bg-[#F0F0EB] hover:bg-slate-200 rounded-lg text-[11px] font-semibold text-[#6B6B66]">
                    6 เดือน
                  </button>
                  <button type="button" onClick={() => setQuickDuration(12)} className="px-2.5 py-1 bg-[#1DB954]/8 hover:bg-blue-100 rounded-full text-[11px] font-semibold text-blue-700">
                    1 ปี
                  </button>
                  <button type="button" onClick={() => setQuickDuration(24)} className="px-2.5 py-1 bg-[#F0F0EB] hover:bg-slate-200 rounded-lg text-[11px] font-semibold text-[#6B6B66]">
                    2 ปี
                  </button>
                </div>

                {/* Money Details */}
                <div className="grid grid-cols-3 gap-2 pt-2">
                  <div>
                    <label className="block font-semibold text-[#6B6B66] mb-1">ค่าเช่า/เดือน (บาท)</label>
                    <input
                      type="number"
                      min="0"
                      value={newMonthlyRent}
                      onChange={(e) => setNewMonthlyRent(Number(e.target.value))}
                      className="w-full p-2.5 border border-[#E0E0DB] rounded-xl font-bold text-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-[#6B6B66] mb-1">เงินประกันมัดจำ (บาท)</label>
                    <input
                      type="number"
                      min="0"
                      value={newDepositAmount}
                      onChange={(e) => setNewDepositAmount(Number(e.target.value))}
                      className="w-full p-2.5 border border-[#E0E0DB] rounded-xl font-bold text-purple-700 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-[#6B6B66] mb-1">ค่าเช่าล่วงหน้า (บาท)</label>
                    <input
                      type="number"
                      min="0"
                      value={newAdvanceRentAmount}
                      onChange={(e) => setNewAdvanceRentAmount(Number(e.target.value))}
                      className="w-full p-2.5 border border-[#E0E0DB] rounded-xl font-bold text-[#6B6B66] focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    />
                  </div>
                </div>

                {/* Contract Document URL */}
                <div>
                  <label className="block font-semibold text-[#6B6B66] mb-1.5">URL เอกสารสัญญา (PDF/รูปถ่าย)</label>
                  <input
                    type="url"
                    placeholder="https://..."
                    value={newContractDocumentUrl}
                    onChange={(e) => setNewContractDocumentUrl(e.target.value)}
                    className="w-full p-2.5 border border-[#E0E0DB] rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>

                {/* Note */}
                <div>
                  <label className="block font-semibold text-[#6B6B66] mb-1.5">หมายเหตุเพิ่มเติม</label>
                  <textarea
                    rows={2}
                    placeholder="เช่น เงื่อนไขพิเศษ, ทรัพย์สินติดห้อง..."
                    value={newNote}
                    onChange={(e) => setNewNote(e.target.value)}
                    className="w-full p-2.5 border border-[#E0E0DB] rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>

                {/* Submit Actions */}
                <div className="pt-3 border-t border-[#E0E0DB] flex items-center justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setIsCreateModalOpen(false)}
                    className="px-4 py-2.5 text-[#6B6B66] hover:bg-[#E8E8E3] rounded-xl transition-colors font-medium"
                  >
                    ยกเลิก
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-5 py-2.5 bg-[#1DB954] hover:bg-[#1ED760] hover:scale-[1.04] text-[#1A1A1A] rounded-xl font-bold transition-all flex items-center gap-1.5"
                  >
                    {isSubmitting ? 'กำลังบันทึก...' : 'บันทึกสัญญาเช่า'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL: Checkout & Deposit Refund Calculator */}
      <AnimatePresence>
        {isCheckoutModalOpen && selectedContract && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl shadow-xl border border-[#E0E0DB] max-w-lg w-full overflow-hidden max-h-[90vh] flex flex-col"
            >
              {/* Header */}
              <div className="p-5 border-b border-[#E0E0DB] flex items-center justify-between bg-[#E22134]/8">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-[#E22134]/8 text-[#E22134] rounded-xl">
                    <LogOut className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="font-bold text-rose-900 text-lg">สรุปรายการคืนเงินประกันเมื่อย้ายออก</h2>
                    <p className="text-xs text-[#E22134]">ห้อง {selectedContract.roomNumber} - {selectedContract.tenantName}</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsCheckoutModalOpen(false)}
                  className="p-2 text-[#8A8A85] hover:text-slate-600 rounded-full hover:bg-slate-200/50 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Body */}
              <div className="p-6 space-y-4 overflow-y-auto flex-1 text-xs">
                {/* Deposit Base */}
                <div className="bg-[#A855F7]/8 p-4 rounded-2xl border border-purple-100 flex items-center justify-between">
                  <div>
                    <p className="text-xs font-semibold text-purple-700">เงินประกันมัดจำเดิม</p>
                    <p className="text-xs text-[#A855F7]">ได้รับชำระไว้เมื่อวันทำสัญญา</p>
                  </div>
                  <p className="text-xl font-black text-purple-900">฿{selectedContract.depositAmount.toLocaleString()}</p>
                </div>

                {/* Deductions input */}
                <div className="space-y-3 pt-2">
                  <h3 className="font-bold text-[#1A1A1A] border-b border-[#E0E0DB] pb-1.5">รายการหักค่าใช้จ่าย ณ วันย้ายออก</h3>

                  <div>
                    <label className="block font-medium text-[#6B6B66] mb-1">หัก ค่าน้ำ-ค่าไฟ ค้างชำระ (บาท)</label>
                    <input
                      type="number"
                      min="0"
                      value={checkoutUtilityDeduction}
                      onChange={(e) => setCheckoutUtilityDeduction(Number(e.target.value))}
                      className="w-full p-2.5 border border-[#E0E0DB] rounded-xl font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500/20"
                    />
                  </div>

                  <div>
                    <label className="block font-medium text-[#6B6B66] mb-1">หัก ค่าความเสียหาย/ทำความสะอาด (บาท)</label>
                    <input
                      type="number"
                      min="0"
                      value={checkoutDamageDeduction}
                      onChange={(e) => setCheckoutDamageDeduction(Number(e.target.value))}
                      className="w-full p-2.5 border border-[#E0E0DB] rounded-xl font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500/20"
                    />
                  </div>

                  <div>
                    <label className="block font-medium text-[#6B6B66] mb-1">หัก ค่าใช้จ่ายอื่น ๆ (บาท)</label>
                    <input
                      type="number"
                      min="0"
                      value={checkoutOtherDeduction}
                      onChange={(e) => setCheckoutOtherDeduction(Number(e.target.value))}
                      className="w-full p-2.5 border border-[#E0E0DB] rounded-xl font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500/20"
                    />
                  </div>

                  <div>
                    <label className="block font-medium text-[#6B6B66] mb-1">หมายเหตุการย้ายออก</label>
                    <textarea
                      rows={2}
                      placeholder="เช่น รายละเอียดความเสียหาย หรือข้อตกลง..."
                      value={checkoutNote}
                      onChange={(e) => setCheckoutNote(e.target.value)}
                      className="w-full p-2.5 border border-[#E0E0DB] rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500/20"
                    />
                  </div>
                </div>

                {/* Final Calculation Result */}
                {(() => {
                  const totalDeductions = checkoutUtilityDeduction + checkoutDamageDeduction + checkoutOtherDeduction;
                  const netRefund = selectedContract.depositAmount - totalDeductions;

                  return (
                    <div className={`p-4 rounded-2xl border flex items-center justify-between ${netRefund >= 0 ? 'bg-[#1DB954]/8 border-[#1DB954]/30 text-[#1DB954]' : 'bg-[#E22134]/8 border-[#E22134]/30 text-[#E22134]'}`}>
                      <div>
                        <p className="text-xs font-semibold">{netRefund >= 0 ? 'เงินประกันคงเหลือที่ต้องคืนผู้เช่า' : 'ผู้เช่าต้องชำระเงินเพิ่ม'}</p>
                        <p className="text-[10px] opacity-80">(เงินประกัน ฿{selectedContract.depositAmount.toLocaleString()} - หักรวม ฿{totalDeductions.toLocaleString()})</p>
                      </div>
                      <p className="text-2xl font-black">฿{Math.abs(netRefund).toLocaleString()}</p>
                    </div>
                  );
                })()}

                {/* Actions */}
                <div className="pt-3 border-t border-[#E0E0DB] flex items-center justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setIsCheckoutModalOpen(false)}
                    className="px-4 py-2.5 text-[#6B6B66] hover:bg-[#E8E8E3] rounded-xl transition-colors font-medium"
                  >
                    ยกเลิก
                  </button>
                  <button
                    type="button"
                    onClick={handleCheckoutSubmit}
                    disabled={isSubmitting}
                    className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-[#1A1A1A] rounded-xl font-bold transition-all flex items-center gap-1.5"
                  >
                    {isSubmitting ? 'กำลังบันทึก...' : 'ยืนยันทำรายการย้ายออก'}
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL: Edit Lease Contract */}
      <AnimatePresence>
        {isEditModalOpen && selectedContract && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl shadow-xl border border-[#E0E0DB] max-w-lg w-full overflow-hidden max-h-[90vh] flex flex-col"
            >
              {/* Header */}
              <div className="p-5 border-b border-[#E0E0DB] flex items-center justify-between bg-[#F0F0EB]">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-[#1DB954]/8 text-blue-700 rounded-xl">
                    <Edit3 className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="font-bold text-[#1A1A1A] text-lg">แก้ไขข้อมูลสัญญาเช่า</h2>
                    <p className="text-xs text-[#8A8A85]">ห้อง {selectedContract.roomNumber} - {selectedContract.tenantName}</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsEditModalOpen(false)}
                  className="p-2 text-[#8A8A85] hover:text-slate-600 rounded-full hover:bg-slate-200/50 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Form Body */}
              <form onSubmit={handleUpdateContract} className="p-6 space-y-4 overflow-y-auto flex-1 text-xs">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-[#6B6B66] mb-1.5">ชื่อ-นามสกุล ผู้เช่า *</label>
                    <input
                      type="text"
                      required
                      value={editTenantName}
                      onChange={(e) => setEditTenantName(e.target.value)}
                      className="w-full p-2.5 border border-[#E0E0DB] rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[#6B6B66] mb-1.5">เบอร์โทรศัพท์</label>
                    <input
                      type="tel"
                      value={editTenantPhone}
                      onChange={(e) => setEditTenantPhone(e.target.value)}
                      className="w-full p-2.5 border border-[#E0E0DB] rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-[#6B6B66] mb-1.5">เลขบัตรประชาชน / พาสปอร์ต</label>
                  <input
                    type="text"
                    value={editIdCardNumber}
                    onChange={(e) => setEditIdCardNumber(e.target.value)}
                    className="w-full p-2.5 border border-[#E0E0DB] rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-[#6B6B66] mb-1.5">วันเริ่มสัญญา *</label>
                    <input
                      type="date"
                      required
                      value={editStartDate}
                      onChange={(e) => setEditStartDate(e.target.value)}
                      className="w-full p-2.5 border border-[#E0E0DB] rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[#6B6B66] mb-1.5">วันสิ้นสุดสัญญา *</label>
                    <input
                      type="date"
                      required
                      value={editEndDate}
                      onChange={(e) => setEditEndDate(e.target.value)}
                      className="w-full p-2.5 border border-[#E0E0DB] rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block font-semibold text-[#6B6B66] mb-1">ค่าเช่า/เดือน (บาท)</label>
                    <input
                      type="number"
                      min="0"
                      value={editMonthlyRent}
                      onChange={(e) => setEditMonthlyRent(Number(e.target.value))}
                      className="w-full p-2.5 border border-[#E0E0DB] rounded-xl font-bold text-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-[#6B6B66] mb-1">เงินประกันมัดจำ (บาท)</label>
                    <input
                      type="number"
                      min="0"
                      value={editDepositAmount}
                      onChange={(e) => setEditDepositAmount(Number(e.target.value))}
                      className="w-full p-2.5 border border-[#E0E0DB] rounded-xl font-bold text-purple-700 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-[#6B6B66] mb-1">ค่าเช่าล่วงหน้า (บาท)</label>
                    <input
                      type="number"
                      min="0"
                      value={editAdvanceRentAmount}
                      onChange={(e) => setEditAdvanceRentAmount(Number(e.target.value))}
                      className="w-full p-2.5 border border-[#E0E0DB] rounded-xl font-bold text-[#6B6B66] focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-[#6B6B66] mb-1.5">URL เอกสารสัญญา</label>
                  <input
                    type="url"
                    value={editContractDocumentUrl}
                    onChange={(e) => setEditContractDocumentUrl(e.target.value)}
                    className="w-full p-2.5 border border-[#E0E0DB] rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#6B6B66] mb-1.5">หมายเหตุเพิ่มเติม</label>
                  <textarea
                    rows={2}
                    value={editNote}
                    onChange={(e) => setEditNote(e.target.value)}
                    className="w-full p-2.5 border border-[#E0E0DB] rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>

                <div className="pt-3 border-t border-[#E0E0DB] flex items-center justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setIsEditModalOpen(false)}
                    className="px-4 py-2.5 text-[#6B6B66] hover:bg-[#E8E8E3] rounded-xl transition-colors font-medium"
                  >
                    ยกเลิก
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-[#1A1A1A] rounded-xl font-bold transition-all flex items-center gap-1.5"
                  >
                    {isSubmitting ? 'กำลังบันทึก...' : 'บันทึกการแก้ไข'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
