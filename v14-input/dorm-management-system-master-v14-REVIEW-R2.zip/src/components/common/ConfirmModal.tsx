import React from 'react';
import { AlertTriangle, Trash2, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ConfirmModalProps {
  isOpen: boolean;
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  isDanger?: boolean;
  loading?: boolean;
  onConfirm: () => void;
  onClose: () => void;
}

export const ConfirmModal: React.FC<ConfirmModalProps> = ({
  isOpen,
  title,
  message,
  confirmText = 'ยืนยัน',
  cancelText = 'ยกเลิก',
  isDanger = true,
  loading = false,
  onConfirm,
  onClose
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-[9999] animate-fadeIn cursor-pointer" onClick={onClose}>
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        transition={{ duration: 0.2 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-white dark:bg-zinc-900 border border-[#E0E0DB] dark:border-zinc-800 rounded-3xl max-w-sm w-full p-6 space-y-4 shadow-2xl cursor-default"
      >
        <div className="flex items-start justify-between">
          <div className={`p-3 rounded-2xl ${isDanger ? 'bg-red-500/10 text-[#E22134]' : 'bg-[#1DB954]/10 text-[#1DB954]'}`}>
            <AlertTriangle className="w-6 h-6" />
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-[#8A8A85] hover:text-[#1A1A1A] dark:hover:text-white transition cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div>
          <h3 className="text-base font-extrabold text-[#1A1A1A] dark:text-zinc-100">{title}</h3>
          <p className="text-xs text-[#8A8A85] dark:text-zinc-400 mt-1.5 leading-relaxed">{message}</p>
        </div>

        <div className="flex items-center gap-3 pt-2">
          <button
            onClick={onClose}
            disabled={loading}
            className="flex-1 py-2.5 px-4 bg-[#F0F0EB] dark:bg-zinc-800 hover:bg-[#E0E0DB] dark:hover:bg-zinc-700 text-[#1A1A1A] dark:text-zinc-200 font-bold rounded-xl text-xs transition cursor-pointer"
          >
            {cancelText}
          </button>
          <button
            onClick={onConfirm}
            disabled={loading}
            className={`flex-1 py-2.5 px-4 font-bold text-white rounded-xl text-xs flex items-center justify-center gap-2 transition cursor-pointer ${
              isDanger
                ? 'bg-[#E22134] hover:bg-red-600 shadow-md shadow-red-500/20'
                : 'bg-[#1DB954] hover:bg-[#1ED760] shadow-md shadow-emerald-500/20'
            }`}
          >
            {loading ? (
              <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
            ) : (
              <>
                <Trash2 className="w-3.5 h-3.5" />
                <span>{confirmText}</span>
              </>
            )}
          </button>
        </div>
      </motion.div>
    </div>
  );
};
