import React, { ReactNode } from 'react';
import { Inbox, Plus } from 'lucide-react';
import { AppColors } from '../../constants/index.ts';

interface EmptyStateProps {
  icon?: ReactNode;
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
  className?: string;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  icon,
  title,
  description,
  actionLabel,
  onAction,
  className = ''
}) => {
  return (
    <div className={`flex flex-col items-center justify-center py-12 px-4 text-center bg-white dark:bg-zinc-900 border border-dashed border-[#E0E0DB] dark:border-zinc-800 rounded-3xl ${className}`}>
      <div className="w-14 h-14 rounded-2xl bg-[#1DB954]/10 dark:bg-[#1DB954]/20 flex items-center justify-center text-[#1DB954] mb-3 shadow-xs">
        {icon || <Inbox className="w-7 h-7" />}
      </div>
      <h3 className="text-base font-extrabold text-[#1A1A1A] dark:text-zinc-100">{title}</h3>
      <p className="text-xs text-[#8A8A85] dark:text-zinc-400 mt-1 max-w-sm leading-relaxed">{description}</p>
      {actionLabel && onAction && (
        <button
          onClick={onAction}
          className="mt-4 px-4 py-2 bg-[#1DB954] hover:bg-[#1ED760] text-white font-bold rounded-full text-xs flex items-center gap-1.5 transition hover:scale-105 cursor-pointer shadow-md"
        >
          <Plus className="w-4 h-4" />
          <span>{actionLabel}</span>
        </button>
      )}
    </div>
  );
};
