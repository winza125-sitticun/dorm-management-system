import React from 'react';
import { Skeleton } from './Skeleton.tsx';

interface TableSkeletonProps {
  rows?: number;
  columns?: number;
}

export const TableSkeleton: React.FC<TableSkeletonProps> = ({ rows = 5, columns = 5 }) => {
  return (
    <div className="w-full bg-white dark:bg-zinc-900 border border-[#E0E0DB] dark:border-zinc-800 rounded-2xl p-4 space-y-4">
      <div className="flex items-center justify-between pb-3 border-b border-[#E0E0DB] dark:border-zinc-800">
        <Skeleton className="h-5 w-40" />
        <Skeleton className="h-8 w-24 rounded-full" />
      </div>
      <div className="space-y-3">
        {Array.from({ length: rows }).map((_, rIdx) => (
          <div key={rIdx} className="flex items-center gap-4 py-2">
            {Array.from({ length: columns }).map((_, cIdx) => (
              <Skeleton key={cIdx} className="h-4 flex-1" />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};
