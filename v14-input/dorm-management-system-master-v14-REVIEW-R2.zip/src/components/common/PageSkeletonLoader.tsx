import React from 'react';
import { RefreshCw } from 'lucide-react';
import { AppColors } from '../../constants/index.ts';

export const PageSkeletonLoader: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] text-[#8A8A85] font-sans animate-fadeIn">
      <div className="relative mb-4">
        <div className="w-12 h-12 rounded-2xl bg-[#1DB954]/10 flex items-center justify-center border border-[#1DB954]/30 shadow-md">
          <RefreshCw className="w-6 h-6 animate-spin text-[#1DB954]" />
        </div>
      </div>
      <h3 className="text-sm font-bold text-[#1A1A1A]">กำลังโหลดหน้าจอ (Loading Chunk)...</h3>
      <p className="text-xs text-[#8A8A85] mt-1">กรุณารอสักครู่ ระบบกำลังโหลดส่วนประกอบที่จำเป็น</p>
    </div>
  );
};
