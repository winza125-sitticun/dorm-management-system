import React from 'react';
import { Skeleton } from './Skeleton.tsx';

export const CardSkeleton: React.FC = () => {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {Array.from({ length: 4 }).map((_, idx) => (
        <div key={idx} className="bg-white dark:bg-zinc-900 border border-[#E0E0DB] dark:border-zinc-800 rounded-2xl p-5 space-y-3 shadow-xs">
          <div className="flex items-center justify-between">
            <Skeleton className="h-3 w-20" />
            <Skeleton className="h-8 w-8 rounded-xl" />
          </div>
          <Skeleton className="h-7 w-28 mt-2" />
          <Skeleton className="h-3 w-36 mt-1" />
        </div>
      ))}
    </div>
  );
};
