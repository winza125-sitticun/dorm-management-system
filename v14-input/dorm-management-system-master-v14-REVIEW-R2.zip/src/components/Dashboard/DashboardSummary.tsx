import React from 'react';
import { X, CheckCircle, AlertTriangle } from 'lucide-react';
import { Room } from '../../types.ts';
import { AppColors } from '../../constants/index.ts';

interface DashboardSummaryProps {
  activeDetailModal: 'total_rooms' | 'occupied_rooms' | 'vacant_rooms' | 'collection_rate' | null;
  onClose: () => void;
  rooms: Room[];
  revStats: { total: number; paid: number; unpaid: number };
}

export const DashboardSummary: React.FC<DashboardSummaryProps> = ({
  activeDetailModal,
  onClose,
  rooms = [],
  revStats
}) => {
  if (!activeDetailModal) return null;

  const filteredRooms = rooms.filter(r => {
    if (activeDetailModal === 'occupied_rooms') return r.status === 'occupied';
    if (activeDetailModal === 'vacant_rooms') return r.status === 'vacant';
    return true;
  });

  const getTitle = () => {
    if (activeDetailModal === 'total_rooms') return 'รายชื่อห้องพักทั้งหมดในระบบ';
    if (activeDetailModal === 'occupied_rooms') return 'รายชื่อห้องพักที่มีผู้เช่าปัจจุบัน';
    if (activeDetailModal === 'vacant_rooms') return 'รายชื่อห้องว่างที่พร้อมเปิดเช่า';
    if (activeDetailModal === 'collection_rate') return 'สรุปยอดจัดเก็บเงินประจำเดือนนี้';
    return '';
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 z-[999] animate-fadeIn cursor-pointer" onClick={onClose}>
      <div className="bg-white border border-[#E0E0DB] rounded-3xl max-w-lg w-full p-6 space-y-4 shadow-2xl cursor-default" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between border-b border-[#E0E0DB] pb-3">
          <h3 className="text-base font-bold text-[#1A1A1A] flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-[#1DB954]" />
            <span>{getTitle()}</span>
          </h3>
          <button onClick={onClose} className="p-1 rounded-lg text-[#8A8A85] hover:text-[#1A1A1A] hover:bg-[#F0F0EB] transition cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {activeDetailModal === 'collection_rate' ? (
          <div className="space-y-3 text-xs">
            <div className="p-3 bg-[#1DB954]/10 rounded-xl border border-[#1DB954]/30 flex justify-between items-center">
              <span className="font-bold text-[#1A1A1A]">ยอดรวมจัดเก็บทั้งหมดประจำเดือน:</span>
              <span className="font-extrabold text-[#1DB954] text-sm">{revStats.total.toLocaleString()} บาท</span>
            </div>
            <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 flex justify-between items-center">
              <span className="font-bold text-emerald-800">รับชำระเงินแล้ว:</span>
              <span className="font-extrabold text-emerald-600 text-sm">{revStats.paid.toLocaleString()} บาท</span>
            </div>
            <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 flex justify-between items-center">
              <span className="font-bold text-amber-800">มียอดค้างชำระ:</span>
              <span className="font-extrabold text-amber-600 text-sm">{revStats.unpaid.toLocaleString()} บาท</span>
            </div>
          </div>
        ) : (
          <div className="max-h-72 overflow-y-auto divide-y divide-[#E0E0DB] text-xs">
            {filteredRooms.length === 0 ? (
              <p className="text-center py-6 text-[#8A8A85]">ไม่พบข้อมูลห้องพักในหมวดหมู่นี้</p>
            ) : (
              filteredRooms.map(room => (
                <div key={room.id} className="py-2.5 flex items-center justify-between">
                  <div>
                    <p className="font-bold text-[#1A1A1A]">ห้อง {room.roomNumber}</p>
                    <p className="text-[10px] text-[#8A8A85]">{room.tenantName ? `ผู้เช่า: ${room.tenantName}` : 'ห้องว่าง'}</p>
                  </div>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${room.status === 'occupied' ? 'bg-blue-50 text-blue-600' : 'bg-emerald-50 text-emerald-600'}`}>
                    {room.status === 'occupied' ? 'มีผู้เช่า' : 'ห้องว่าง'}
                  </span>
                </div>
              ))
            )}
          </div>
        )}

        <div className="pt-2 text-right">
          <button onClick={onClose} className="px-4 py-2 bg-[#F0F0EB] hover:bg-[#E0E0DB] text-[#1A1A1A] font-bold rounded-xl text-xs transition cursor-pointer">
            ปิดหน้าต่าง
          </button>
        </div>
      </div>
    </div>
  );
};
