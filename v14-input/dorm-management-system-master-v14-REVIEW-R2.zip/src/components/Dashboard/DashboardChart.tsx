import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Calendar } from 'lucide-react';
import { AppColors } from '../../constants/index.ts';

interface DashboardChartProps {
  chartData: Array<{
    name: string;
    'ชำระแล้ว': number;
    'ค้างชำระ': number;
    'ยอดรวม': number;
  }>;
}

export const DashboardChart: React.FC<DashboardChartProps> = ({ chartData }) => {
  return (
    <div className="bg-white border border-[#E0E0DB] rounded-2xl p-5 shadow-xs space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-bold text-[#1A1A1A] flex items-center gap-2">
          <Calendar className="w-4 h-4 text-[#1DB954]" />
          <span>แนวโน้มรายรับย้อนหลัง 6 เดือน</span>
        </h3>
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#1DB954]"></span>
            <span className="text-[#8A8A85]">ชำระแล้ว</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
            <span className="text-[#8A8A85]">ค้างชำระ</span>
          </div>
        </div>
      </div>

      <div className="h-64 sm:h-72 w-full pt-2">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="paidGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={AppColors.PRIMARY} stopOpacity={0.4}/>
                <stop offset="95%" stopColor={AppColors.PRIMARY} stopOpacity={0.0}/>
              </linearGradient>
              <linearGradient id="unpaidGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={AppColors.WARNING} stopOpacity={0.4}/>
                <stop offset="95%" stopColor={AppColors.WARNING} stopOpacity={0.0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#E0E0DB" vertical={false} />
            <XAxis dataKey="name" stroke="#8A8A85" fontSize={11} tickLine={false} />
            <YAxis stroke="#8A8A85" fontSize={11} tickLine={false} tickFormatter={(v) => `${v.toLocaleString()}`} />
            <Tooltip 
              contentStyle={{ backgroundColor: '#1A1A1A', borderColor: '#333', borderRadius: '12px', color: '#fff', fontSize: '12px' }}
              formatter={(val: number) => [`${val.toLocaleString()} บาท`, '']}
            />
            <Area type="monotone" dataKey="ชำระแล้ว" stroke={AppColors.PRIMARY} strokeWidth={2.5} fillOpacity={1} fill="url(#paidGradient)" />
            <Area type="monotone" dataKey="ค้างชำระ" stroke={AppColors.WARNING} strokeWidth={2.5} fillOpacity={1} fill="url(#unpaidGradient)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
