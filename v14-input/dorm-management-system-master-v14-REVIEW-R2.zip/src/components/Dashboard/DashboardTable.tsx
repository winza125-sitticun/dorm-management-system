import React from 'react';
import { AlertTriangle, ChevronRight, Eye, Phone } from 'lucide-react';
import { AppColors } from '../../constants/index.ts';

interface UnpaidRoomItem {
  billId: number;
  roomId: number;
  roomNumber: string;
  tenantName: string;
  amount: number;
  month: string;
}

interface DashboardTableProps {
  unpaidRooms: UnpaidRoomItem[];
  onNavigateToBills: () => void;
  onViewBillById: (billId: number) => void;
}

export const DashboardTable: React.FC<DashboardTableProps> = ({
  unpaidRooms,
  onNavigateToBills,
  onViewBillById
}) => {
  return (
    <div className="bg-white border border-[#E0E0DB] rounded-2xl p-5 shadow-xs space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-bold text-[#1A1A1A] flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-500" />
          <span>รายการห้องพักค้างชำระในระบบ ({unpaidRooms.length} รายการ)</span>
        </h3>
        <button
          onClick={onNavigateToBills}
          className="text-xs text-[#1DB954] hover:text-[#1ED760] font-bold flex items-center gap-1 cursor-pointer transition"
        >
          <span>ดูทั้งหมด</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {unpaidRooms.length === 0 ? (
        <div className="text-center py-8 bg-[#F0F0EB] rounded-xl border border-dashed border-[#E0E0DB] text-[#8A8A85]">
          <p className="text-xs font-semibold">ไม่มีรายการค้างชำระในขณะนี้ 🎉</p>
          <p className="text-[10px] mt-0.5">ผู้เช่าทุกห้องชำระเงินเรียบร้อยแล้วค่ะ</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-[#E0E0DB] text-[10px] uppercase font-bold text-[#8A8A85]">
                <th className="py-2.5 px-3">ห้อง</th>
                <th className="py-2.5 px-3">ผู้เช่า</th>
                <th className="py-2.5 px-3">ประจำเดือน</th>
                <th className="py-2.5 px-3 text-right">ยอดค้างชำระ</th>
                <th className="py-2.5 px-3 text-center">จัดการ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E0E0DB]/60 font-medium">
              {unpaidRooms.slice(0, 5).map((item) => (
                <tr key={item.billId} className="hover:bg-[#F0F0EB]/50 transition">
                  <td className="py-3 px-3 font-bold text-[#1A1A1A]">
                    ห้อง {item.roomNumber}
                  </td>
                  <td className="py-3 px-3 text-[#6B6B66]">
                    {item.tenantName || 'ไม่ระบุชื่อ'}
                  </td>
                  <td className="py-3 px-3 text-[#8A8A85] font-mono text-[11px]">
                    {item.month}
                  </td>
                  <td className="py-3 px-3 text-right font-bold text-amber-600 font-mono">
                    {item.amount.toLocaleString()} ฿
                  </td>
                  <td className="py-3 px-3 text-center">
                    <button
                      onClick={() => onViewBillById(item.billId)}
                      className="px-2.5 py-1 bg-white hover:bg-[#1DB954] hover:text-white border border-[#E0E0DB] rounded-lg text-[10px] font-bold transition flex items-center justify-center gap-1 mx-auto cursor-pointer"
                    >
                      <Eye className="w-3 h-3" />
                      <span>ดูบิล</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
