import React from 'react';
import { TrendingUp, RefreshCw } from 'lucide-react';
import { AppColors } from '../../constants/index.ts';

interface DashboardHeaderProps {
  loading: boolean;
  onRefresh: () => void;
}

export const DashboardHeader: React.FC<DashboardHeaderProps> = ({ loading, onRefresh }) => {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
      <div>
        <h2 className="text-xl font-bold text-[#1A1A1A] flex items-center gap-2">
          <TrendingUp className="w-5 h-5" style={{ color: AppColors.PRIMARY }} />
          <span>ภาพรวมแดชบอร์ด</span>
        </h2>
        <p className="text-xs text-[#8A8A85] mt-1">
          ข้อมูลสรุปผลรายรับและห้องพัก ประจำเดือนนี้
        </p>
      </div>
      <button
        onClick={onRefresh}
        disabled={loading}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-[#E0E0DB] text-[#6B6B66] hover:text-[#1A1A1A] hover:bg-[#E8E8E3] disabled:opacity-50 transition text-xs font-semibold shadow-xs cursor-pointer"
      >
        <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
        <span>รีเฟรชข้อมูล</span>
      </button>
    </div>
  );
};
