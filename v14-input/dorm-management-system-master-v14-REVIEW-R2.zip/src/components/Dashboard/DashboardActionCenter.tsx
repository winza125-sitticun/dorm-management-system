import React, { useMemo } from 'react';
import { AlertCircle, ChevronRight, ClipboardCheck, FileWarning, ReceiptText, Sparkles, Wrench } from 'lucide-react';
import { Bill, HousekeepingTask, LeaseContract, MaintenanceTicket } from '../../types.ts';

interface DashboardActionCenterProps {
  bills: Bill[];
  contracts: LeaseContract[];
  maintenanceTickets: MaintenanceTicket[];
  housekeepingTasks: HousekeepingTask[];
  onNavigate: (tab: 'history' | 'maintenance' | 'housekeeping' | 'contracts') => void;
}

export const DashboardActionCenter: React.FC<DashboardActionCenterProps> = ({
  bills,
  contracts,
  maintenanceTickets,
  housekeepingTasks,
  onNavigate,
}) => {
  const items = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const soon = new Date(today);
    soon.setDate(soon.getDate() + 60);

    const pendingSlips = bills.filter((bill) => bill.slipStatus === 'pending').length;
    const overdueBills = bills.filter((bill) => bill.status === 'unpaid' && bill.dueDate && new Date(`${bill.dueDate}T00:00:00`) < today).length;
    const openRepairs = maintenanceTickets.filter((ticket) => ticket.status === 'pending' || ticket.status === 'in_progress').length;
    const expiringContracts = contracts.filter((contract) => {
      if (contract.status === 'expired' || contract.status === 'terminated') return false;
      const endDate = new Date(`${contract.endDate}T00:00:00`);
      return endDate >= today && endDate <= soon;
    }).length;
    const openHousekeeping = housekeepingTasks.filter((task) => !['completed', 'cancelled'].includes(task.status)).length;

    return [
      { label: 'สลิปรอตรวจสอบ', description: 'ตรวจและยืนยันยอดชำระ', count: pendingSlips, icon: ReceiptText, tab: 'history' as const, tone: 'emerald' },
      { label: 'บิลเกินกำหนด', description: 'ติดตามยอดที่ยังไม่ชำระ', count: overdueBills, icon: AlertCircle, tab: 'history' as const, tone: 'amber' },
      { label: 'งานซ่อมที่ยังเปิดอยู่', description: 'รอดำเนินการหรือกำลังซ่อม', count: openRepairs, icon: Wrench, tab: 'maintenance' as const, tone: 'blue' },
      { label: 'สัญญาใกล้หมดอายุ', description: 'ภายใน 60 วันข้างหน้า', count: expiringContracts, icon: FileWarning, tab: 'contracts' as const, tone: 'violet' },
      { label: 'งานแม่บ้านค้าง', description: 'รอทำ กำลังทำ หรือรอตรวจ', count: openHousekeeping, icon: Sparkles, tab: 'housekeeping' as const, tone: 'rose' },
    ];
  }, [bills, contracts, housekeepingTasks, maintenanceTickets]);

  const total = items.reduce((sum, item) => sum + item.count, 0);
  const tones: Record<string, string> = {
    emerald: 'bg-emerald-50 text-emerald-600 border-emerald-100',
    amber: 'bg-amber-50 text-amber-600 border-amber-100',
    blue: 'bg-blue-50 text-blue-600 border-blue-100',
    violet: 'bg-violet-50 text-violet-600 border-violet-100',
    rose: 'bg-rose-50 text-rose-600 border-rose-100',
  };

  return (
    <section className="overflow-hidden rounded-2xl border border-[#E0E0DB] bg-white shadow-sm">
      <div className="flex items-center justify-between border-b border-[#E0E0DB] px-4 py-3 sm:px-5">
        <div className="flex items-center gap-2">
          <ClipboardCheck className="h-4 w-4 text-[#1DB954]" />
          <div>
            <h3 className="text-xs font-black text-[#1A1A1A]">ศูนย์งานที่ต้องจัดการ</h3>
            <p className="text-[10px] text-[#8A8A85]">รวมรายการสำคัญที่ควรดำเนินการต่อ</p>
          </div>
        </div>
        <span className={`rounded-full px-2.5 py-1 text-[10px] font-black ${total > 0 ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700'}`}>
          {total > 0 ? `${total} รายการ` : 'เรียบร้อย'}
        </span>
      </div>
      <div className="grid sm:grid-cols-2 xl:grid-cols-5">
        {items.map((item) => (
          <button
            type="button"
            key={item.label}
            onClick={() => onNavigate(item.tab)}
            className="group flex items-center gap-3 border-b border-[#E0E0DB] p-4 text-left transition hover:bg-[#FAFAF7] sm:border-r xl:border-b-0 last:border-b-0 xl:last:border-r-0"
          >
            <div className={`rounded-xl border p-2.5 ${tones[item.tone]}`}><item.icon className="h-4 w-4" /></div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <p className="truncate text-[11px] font-black text-[#1A1A1A]">{item.label}</p>
                <span className="text-base font-black text-[#1A1A1A]">{item.count}</span>
              </div>
              <p className="truncate text-[9px] text-[#8A8A85]">{item.description}</p>
            </div>
            <ChevronRight className="h-3.5 w-3.5 text-[#B0B0AA] transition group-hover:translate-x-0.5 group-hover:text-[#1DB954]" />
          </button>
        ))}
      </div>
    </section>
  );
};
