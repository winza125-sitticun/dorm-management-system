import React from 'react';
import { Home, Users, DoorOpen, DollarSign, ChevronRight } from 'lucide-react';
import { RoomService } from '../../services/room.service.ts';
import { PaymentService } from '../../services/payment.service.ts';
import { AppColors } from '../../constants/index.ts';

interface DashboardCardsProps {
  roomsStats: { total: number; occupied: number; vacant: number };
  revStats: { total: number; paid: number; unpaid: number };
  onCardClick: (type: 'total_rooms' | 'occupied_rooms' | 'vacant_rooms' | 'collection_rate') => void;
}

export const DashboardCards: React.FC<DashboardCardsProps> = ({ roomsStats, revStats, onCardClick }) => {
  const occupancyRate = RoomService.calculateOccupancyRate(roomsStats.total, roomsStats.occupied);
  const collectionRate = PaymentService.calculateCollectionRate(revStats.total, revStats.paid);

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {/* Total Rooms */}
      <div 
        onClick={() => onCardClick('total_rooms')}
        className="bg-white border border-[#E0E0DB] rounded-2xl p-4 sm:p-5 flex flex-col justify-between shadow-sm cursor-pointer hover:shadow-md hover:border-[#1DB954] transition-all duration-200 hover:-translate-y-0.5 active:scale-95 group"
      >
        <div className="flex items-center justify-between">
          <span className="text-xxs font-bold text-[#8A8A85] uppercase tracking-wider">ห้องพักทั้งหมด</span>
          <div className="p-2 rounded-xl bg-[#1DB954]/8 text-[#1DB954] group-hover:bg-[#1DB954]/70 transition">
            <Home className="w-5 h-5" />
          </div>
        </div>
        <div className="mt-4">
          <h3 className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A]">{roomsStats.total} <span className="text-sm font-normal text-[#8A8A85]">ห้อง</span></h3>
          <p className="text-xxs text-[#8A8A85] mt-1 flex items-center gap-1">
            <span>อัตราการเข้าพัก:</span>
            <span className="font-bold text-[#1DB954]">{occupancyRate}%</span>
          </p>
        </div>
        <div className="text-[9px] text-[#8A8A85] mt-3.5 pt-1.5 border-t border-[#E0E0DB]/50 text-right group-hover:text-[#1DB954] font-bold transition flex items-center justify-end gap-0.5">
          <span>กดดูรายละเอียด</span>
          <ChevronRight className="w-3 h-3" />
        </div>
      </div>

      {/* Occupied Rooms */}
      <div 
        onClick={() => onCardClick('occupied_rooms')}
        className="bg-white border border-[#E0E0DB] rounded-2xl p-4 sm:p-5 flex flex-col justify-between shadow-sm cursor-pointer hover:shadow-md hover:border-[#1DB954] transition-all duration-200 hover:-translate-y-0.5 active:scale-95 group"
      >
        <div className="flex items-center justify-between">
          <span className="text-xxs font-bold text-[#8A8A85] uppercase tracking-wider">ห้องมีผู้เช่า</span>
          <div className="p-2 rounded-xl bg-blue-50 text-blue-600 group-hover:bg-blue-500 group-hover:text-white transition">
            <Users className="w-5 h-5" />
          </div>
        </div>
        <div className="mt-4">
          <h3 className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A]">{roomsStats.occupied} <span className="text-sm font-normal text-[#8A8A85]">ห้อง</span></h3>
          <p className="text-xxs text-[#8A8A85] mt-1">ผู้เช่าปัจจุบันในระบบ</p>
        </div>
        <div className="text-[9px] text-[#8A8A85] mt-3.5 pt-1.5 border-t border-[#E0E0DB]/50 text-right group-hover:text-blue-600 font-bold transition flex items-center justify-end gap-0.5">
          <span>กดดูรายละเอียด</span>
          <ChevronRight className="w-3 h-3" />
        </div>
      </div>

      {/* Vacant Rooms */}
      <div 
        onClick={() => onCardClick('vacant_rooms')}
        className="bg-white border border-[#E0E0DB] rounded-2xl p-4 sm:p-5 flex flex-col justify-between shadow-sm cursor-pointer hover:shadow-md hover:border-amber-500 transition-all duration-200 hover:-translate-y-0.5 active:scale-95 group"
      >
        <div className="flex items-center justify-between">
          <span className="text-xxs font-bold text-[#8A8A85] uppercase tracking-wider">ห้องว่าง</span>
          <div className="p-2 rounded-xl bg-amber-50 text-amber-600 group-hover:bg-amber-500 group-hover:text-white transition">
            <DoorOpen className="w-5 h-5" />
          </div>
        </div>
        <div className="mt-4">
          <h3 className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A]">{roomsStats.vacant} <span className="text-sm font-normal text-[#8A8A85]">ห้อง</span></h3>
          <p className="text-xxs text-[#8A8A85] mt-1">พร้อมเปิดให้เช่าทันที</p>
        </div>
        <div className="text-[9px] text-[#8A8A85] mt-3.5 pt-1.5 border-t border-[#E0E0DB]/50 text-right group-hover:text-amber-600 font-bold transition flex items-center justify-end gap-0.5">
          <span>กดดูรายละเอียด</span>
          <ChevronRight className="w-3 h-3" />
        </div>
      </div>

      {/* Revenue Collection */}
      <div 
        onClick={() => onCardClick('collection_rate')}
        className="bg-white border border-[#E0E0DB] rounded-2xl p-4 sm:p-5 flex flex-col justify-between shadow-sm cursor-pointer hover:shadow-md hover:border-[#1DB954] transition-all duration-200 hover:-translate-y-0.5 active:scale-95 group"
      >
        <div className="flex items-center justify-between">
          <span className="text-xxs font-bold text-[#8A8A85] uppercase tracking-wider">จัดเก็บได้แล้ว</span>
          <div className="p-2 rounded-xl bg-[#1DB954]/8 text-[#1DB954] group-hover:bg-[#1DB954] group-hover:text-white transition">
            <DollarSign className="w-5 h-5" />
          </div>
        </div>
        <div className="mt-4">
          <h3 className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A]">{revStats.paid.toLocaleString()} <span className="text-sm font-normal text-[#8A8A85]">บาท</span></h3>
          <p className="text-xxs text-[#8A8A85] mt-1 flex items-center gap-1">
            <span>คิดเป็น:</span>
            <span className="font-bold text-[#1DB954]">{collectionRate}% ของยอดรวม</span>
          </p>
        </div>
        <div className="text-[9px] text-[#8A8A85] mt-3.5 pt-1.5 border-t border-[#E0E0DB]/50 text-right group-hover:text-[#1DB954] font-bold transition flex items-center justify-end gap-0.5">
          <span>กดดูรายละเอียด</span>
          <ChevronRight className="w-3 h-3" />
        </div>
      </div>
    </div>
  );
};
