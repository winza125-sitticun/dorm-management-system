import React, { useState } from 'react';
import { 
  Building2, 
  ShieldCheck, 
  User, 
  Lock, 
  Building, 
  CheckCircle2, 
  AlertCircle, 
  Eye, 
  EyeOff, 
  ArrowRight,
  Sparkles,
  KeyRound
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface FirstSetupWizardProps {
  onSetupComplete: (userData: any, token: string) => void;
}

export const FirstSetupWizard: React.FC<FirstSetupWizardProps> = ({ onSetupComplete }) => {
  const [step, setStep] = useState<1 | 2>(1);
  
  // Step 1: Admin Account
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [displayName, setDisplayName] = useState('');

  // Step 2: Dormitory Info
  const [dormName, setDormName] = useState('หอพักกรีนวิลล์');
  
  // State
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Password Policy Checks
  const hasMinLength = password.length >= 8;
  const hasUppercase = /[A-Z]/.test(password);
  const hasLowercase = /[a-z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  const hasSpecial = /[!@#$%^&*(),.?":{}|<>\-_=+]/.test(password);
  const isPasswordValid = hasMinLength && hasUppercase && hasLowercase && hasNumber && hasSpecial;
  const isPasswordMatch = password.length > 0 && password === confirmPassword;

  const handleStep1Submit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!email.trim()) {
      setError('กรุณากรอกชื่อผู้ใช้งาน หรือ อีเมล');
      return;
    }
    if (!isPasswordValid) {
      setError('รหัสผ่านยังไม่ผ่านเงื่อนไขความปลอดภัย กรุณาตรวจสอบข้อกำหนด');
      return;
    }
    if (!isPasswordMatch) {
      setError('รหัสผ่านยืนยันไม่ตรงกัน');
      return;
    }

    setStep(2);
  };

  const handleFinalSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!dormName.trim()) {
      setError('กรุณากรอกชื่อหอพัก/อาคาร');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/setup/init', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: email.trim(),
          password: password.trim(),
          displayName: displayName.trim() || 'Super Admin',
          dormName: dormName.trim()
        })
      });

      const responseData = await res.json();

      if (!res.ok || responseData.success === false) {
        const errMsg = responseData.error?.message || responseData.message || 'เกิดข้อผิดพลาดในการตั้งค่าระบบ';
        throw new Error(errMsg);
      }

      const { user, token } = responseData.data || responseData;
      localStorage.setItem('local_user', JSON.stringify(user));
      localStorage.setItem('local_token', token);

      onSetupComplete(user, token);
    } catch (err: any) {
      setError(err.message || 'เกิดข้อผิดพลาดในการตั้งค่าระบบ');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F5F0] flex flex-col items-center justify-center p-4 relative overflow-hidden font-sans">
      {/* Decorative Orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#1DB954]/10 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2 pointer-events-none"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl translate-x-1/2 translate-y-1/2 pointer-events-none"></div>

      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4 }}
        className="max-w-lg w-full z-10"
      >
        {/* Header Badge */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 bg-[#1DB954]/10 border border-[#1DB954]/30 px-3.5 py-1.5 rounded-full text-xs font-bold text-[#1DB954] mb-3">
            <Sparkles className="w-4 h-4" />
            <span>เริ่มต้นใช้งานระบบครั้งแรก (First Setup Wizard)</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A]">
            ตั้งค่าระบบผู้ดูแลหลัก & หอพัก
          </h1>
          <p className="text-xs sm:text-sm text-[#6B6B66] mt-1.5">
            กรุณากำหนดบัญชี Super Admin เพื่อความปลอดภัยในระดับองค์กร
          </p>
        </div>

        {/* Step Indicator */}
        <div className="flex items-center justify-center gap-4 mb-6">
          <div className={`flex items-center gap-2 text-xs font-bold ${step === 1 ? 'text-[#1DB954]' : 'text-[#8A8A85]'}`}>
            <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${step === 1 ? 'bg-[#1DB954] text-white' : 'bg-[#E0E0DB] text-[#6B6B66]'}`}>1</div>
            <span>สร้างบัญชี Admin</span>
          </div>
          <div className="w-8 h-[2px] bg-[#E0E0DB]"></div>
          <div className={`flex items-center gap-2 text-xs font-bold ${step === 2 ? 'text-[#1DB954]' : 'text-[#8A8A85]'}`}>
            <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${step === 2 ? 'bg-[#1DB954] text-white' : 'bg-[#E0E0DB] text-[#6B6B66]'}`}>2</div>
            <span>ตั้งค่าหอพัก</span>
          </div>
        </div>

        {/* Form Card */}
        <div className="bg-white border border-[#E0E0DB] rounded-3xl p-6 sm:p-8 shadow-xl">
          {error && (
            <div className="mb-5 p-3.5 bg-[#E22134]/8 border border-[#E22134]/30 rounded-2xl text-[#E22134] text-xs font-semibold flex items-center gap-2.5">
              <AlertCircle className="w-4 h-4 text-[#E22134] shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <AnimatePresence mode="wait">
            {step === 1 ? (
              <motion.form
                key="step1"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                onSubmit={handleStep1Submit}
                className="space-y-4"
              >
                <div>
                  <label className="block text-[#8A8A85] font-bold mb-1 uppercase tracking-wider text-[10px]">
                    ชื่อผู้ใช้งาน / อีเมลผู้ดูแลหลัก (Super Admin Username / Email) *
                  </label>
                  <div className="relative">
                    <User className="absolute left-3.5 top-3 w-4 h-4 text-[#8A8A85]" />
                    <input
                      type="text"
                      required
                      placeholder="เช่น admin_owner, owner@dorm.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl pl-10 pr-3 py-2.5 text-xs text-[#1A1A1A] focus:outline-none focus:border-[#1DB954] focus:bg-white transition"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[#8A8A85] font-bold mb-1 uppercase tracking-wider text-[10px]">
                    ชื่อ-นามสกุล หรือชื่อแสดงผล (Display Name)
                  </label>
                  <input
                    type="text"
                    placeholder="เช่น คุณสมชาย (เจ้าของหอพัก)"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    className="w-full bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl px-3 py-2.5 text-xs text-[#1A1A1A] focus:outline-none focus:border-[#1DB954] focus:bg-white transition"
                  />
                </div>

                {/* Password Field */}
                <div>
                  <label className="block text-[#8A8A85] font-bold mb-1 uppercase tracking-wider text-[10px]">
                    ตั้งรหัสผ่านผู้ดูแลหลัก (Super Admin Password) *
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3.5 top-3 w-4 h-4 text-[#8A8A85]" />
                    <input
                      type={showPassword ? "text" : "password"}
                      required
                      placeholder="กำหนดรหัสผ่านความปลอดภัยสูง"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl pl-10 pr-10 py-2.5 text-xs text-[#1A1A1A] focus:outline-none focus:border-[#1DB954] focus:bg-white transition font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-3 text-[#8A8A85] hover:text-[#1A1A1A]"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Confirm Password */}
                <div>
                  <label className="block text-[#8A8A85] font-bold mb-1 uppercase tracking-wider text-[10px]">
                    ยืนยันรหัสผ่าน (Confirm Password) *
                  </label>
                  <div className="relative">
                    <KeyRound className="absolute left-3.5 top-3 w-4 h-4 text-[#8A8A85]" />
                    <input
                      type={showPassword ? "text" : "password"}
                      required
                      placeholder="กรอกรหัสผ่านอีกครั้งเพื่อยืนยัน"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl pl-10 pr-3 py-2.5 text-xs text-[#1A1A1A] focus:outline-none focus:border-[#1DB954] focus:bg-white transition font-mono"
                    />
                  </div>
                </div>

                {/* Password Policy Criteria Box */}
                <div className="p-3 bg-[#F0F0EB] rounded-2xl border border-[#E0E0DB] space-y-1.5 text-[11px]">
                  <p className="font-extrabold text-[#1A1A1A] flex items-center gap-1.5 text-[10px] uppercase tracking-wider">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#1DB954]" />
                    <span>นโยบายความปลอดภัยรหัสผ่าน (Password Policy):</span>
                  </p>
                  <div className="grid grid-cols-2 gap-1 text-[10px]">
                    <div className={`flex items-center gap-1.5 ${hasMinLength ? 'text-emerald-600 font-bold' : 'text-[#8A8A85]'}`}>
                      <CheckCircle2 className="w-3 h-3" />
                      <span>ยาวอย่างน้อย 8 ตัวอักษร</span>
                    </div>
                    <div className={`flex items-center gap-1.5 ${hasUppercase ? 'text-emerald-600 font-bold' : 'text-[#8A8A85]'}`}>
                      <CheckCircle2 className="w-3 h-3" />
                      <span>พิมพ์ใหญ่ (A-Z) อย่างน้อย 1 ตัว</span>
                    </div>
                    <div className={`flex items-center gap-1.5 ${hasLowercase ? 'text-emerald-600 font-bold' : 'text-[#8A8A85]'}`}>
                      <CheckCircle2 className="w-3 h-3" />
                      <span>พิมพ์เล็ก (a-z) อย่างน้อย 1 ตัว</span>
                    </div>
                    <div className={`flex items-center gap-1.5 ${hasNumber ? 'text-emerald-600 font-bold' : 'text-[#8A8A85]'}`}>
                      <CheckCircle2 className="w-3 h-3" />
                      <span>ตัวเลข (0-9) อย่างน้อย 1 ตัว</span>
                    </div>
                    <div className={`flex items-center gap-1.5 ${hasSpecial ? 'text-emerald-600 font-bold' : 'text-[#8A8A85]'}`}>
                      <CheckCircle2 className="w-3 h-3" />
                      <span>อักขระพิเศษ (!@#$%...)</span>
                    </div>
                    <div className={`flex items-center gap-1.5 ${isPasswordMatch ? 'text-emerald-600 font-bold' : 'text-[#8A8A85]'}`}>
                      <CheckCircle2 className="w-3 h-3" />
                      <span>รหัสผ่านยืนยันตรงกัน</span>
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 px-4 bg-[#1DB954] hover:bg-[#1ED760] text-white font-bold rounded-full flex items-center justify-center gap-2 transition hover:scale-[1.02] cursor-pointer text-xs mt-4"
                >
                  <span>ถัดไป: ตั้งค่าหอพัก</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </motion.form>
            ) : (
              <motion.form
                key="step2"
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                onSubmit={handleFinalSubmit}
                className="space-y-4"
              >
                <div>
                  <label className="block text-[#8A8A85] font-bold mb-1 uppercase tracking-wider text-[10px]">
                    ชื่อหอพัก / อพาร์ทเม้นท์ / อาคาร *
                  </label>
                  <div className="relative">
                    <Building className="absolute left-3.5 top-3 w-4 h-4 text-[#8A8A85]" />
                    <input
                      type="text"
                      required
                      placeholder="เช่น หอพักกรีนวิลล์ Mansion"
                      value={dormName}
                      onChange={(e) => setDormName(e.target.value)}
                      className="w-full bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl pl-10 pr-3 py-2.5 text-xs text-[#1A1A1A] focus:outline-none focus:border-[#1DB954] focus:bg-white transition font-bold"
                    />
                  </div>
                </div>

                <div className="p-4 bg-[#1DB954]/10 rounded-2xl border border-[#1DB954]/30 space-y-2 text-xs">
                  <p className="font-extrabold text-[#1A1A1A] flex items-center gap-1.5 text-xs">
                    <Building2 className="w-4 h-4 text-[#1DB954]" />
                    <span>สรุปการตั้งค่าระบบ:</span>
                  </p>
                  <div className="text-[11px] text-[#6B6B66] space-y-1">
                    <p>• <b>บทบาทหลัก:</b> <span className="text-[#1DB954] font-bold">Super Admin</span></p>
                    <p>• <b>Username:</b> <span className="font-mono text-[#1A1A1A] font-bold">{email}</span></p>
                    <p>• <b>การเข้ารหัส:</b> PBKDF2 SHA-256 (100,000 Iterations)</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="py-3 px-4 bg-[#F0F0EB] hover:bg-[#E0E0DB] text-[#6B6B66] font-bold rounded-full text-xs transition cursor-pointer"
                  >
                    ย้อนกลับ
                  </button>

                  <button
                    type="submit"
                    disabled={loading}
                    className="flex-1 py-3 px-4 bg-[#1DB954] hover:bg-[#1ED760] disabled:bg-[#1DB954]/40 text-white font-bold rounded-full flex items-center justify-center gap-2 transition hover:scale-[1.02] cursor-pointer text-xs"
                  >
                    {loading ? (
                      <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                    ) : (
                      <>
                        <CheckCircle2 className="w-4 h-4" />
                        <span>เสร็จสิ้น และเข้าสู่ระบบทันที</span>
                      </>
                    )}
                  </button>
                </div>
              </motion.form>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
};
