import React, { useState, useEffect } from 'react';
import { Room, Bill, Settings, MaintenanceTicket, Announcement } from '../types.ts';
import { PromptPayQR } from '../utils/promptpay.tsx';
import { getApiErrorMessage, unwrapApiData } from '../utils/api.ts';
import { APP_VERSION_LABEL } from '../generated/version.ts';
import { 
 Building2, 
 Search, 
 Phone, 
 Calendar, 
 CreditCard, 
 Coins, 
 Zap, 
 Droplet, 
 Upload, 
 CheckCircle2, 
 AlertTriangle, 
 History, 
 Download, 
 Link as LinkIcon, 
 Copy, 
 Clock, 
 X, 
 QrCode, 
 ArrowLeft,
 FileText,
 HelpCircle,
 TrendingUp,
 Image as ImageIcon,
 Check,
 Wrench,
 Plus,
 Megaphone,
 Pin
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const TenantPortalView: React.FC = () => {
 // Navigation / Loading state
 const [roomId, setRoomId] = useState<number | null>(null);
 const [tenantToken, setTenantToken] = useState<string | null>(null);
 const [loading, setLoading] = useState(false);
 const [error, setError] = useState<string | null>(null);

 // Lookup Form state (if no direct link or to switch rooms)
 const [roomNumberInput, setRoomNumberInput] = useState('');
 const [tenantPhoneInput, setTenantPhoneInput] = useState('');
 
 // Data State
 const [room, setRoom] = useState<Room | null>(null);
 const [settings, setSettings] = useState<Settings | null>(null);
 const [unpaidBills, setUnpaidBills] = useState<Bill[]>([]);
 const [paidBills, setPaidBills] = useState<Bill[]>([]);

 // Slip Upload state (tracked per billId)
 const [selectedBillForSlip, setSelectedBillForSlip] = useState<number | null>(null);
 const [slipBase64, setSlipBase64] = useState<string | null>(null);
 const [uploading, setUploading] = useState(false);
 const [uploadSuccess, setUploadSuccess] = useState<string | null>(null);
 const [uploadError, setUploadError] = useState<string | null>(null);

 // Link copy toast
 const [copiedLink, setCopiedLink] = useState(false);

 // PromptPay QR modal
 const [showQrModal, setShowQrModal] = useState<Bill | null>(null);

 // Maintenance State
 const [maintenanceTickets, setMaintenanceTickets] = useState<MaintenanceTicket[]>([]);
 const [isRepairModalOpen, setIsRepairModalOpen] = useState(false);
 const [repairTitle, setRepairTitle] = useState('');
 const [repairCategory, setRepairCategory] = useState<'plumbing' | 'electrical' | 'appliance' | 'furniture' | 'structure' | 'other'>('other');
 const [repairPriority, setRepairPriority] = useState<'low' | 'medium' | 'high' | 'urgent'>('medium');
 const [repairDescription, setRepairDescription] = useState('');
 const [repairImageUrl, setRepairImageUrl] = useState('');
 const [submittingRepair, setSubmittingRepair] = useState(false);

 // Announcements State
 const [announcements, setAnnouncements] = useState<Announcement[]>([]);

 // Detect Room ID from URL
 useEffect(() => {
 const params = new URLSearchParams(window.location.search);
 const idParam = params.get('roomId') || params.get('id') || params.get('room');
 if (idParam) {
 const parsedId = parseInt(idParam);
 if (!isNaN(parsedId)) {
 setRoomId(parsedId);
 fetchRoomData(parsedId);
 }
 }
 }, []);

 // Fetch Room & Bills data publicly
 const fetchRoomData = async (targetRoomId: number, accessToken = tenantToken) => {
 if (!accessToken) {
 setError('กรุณายืนยันตัวตนด้วยเลขห้องและเบอร์โทรศัพท์ก่อนดูข้อมูล');
 return;
 }
 setLoading(true);
 setError(null);
 try {
 const res = await fetch(`/api/public/rooms/${targetRoomId}`, { headers: { Authorization: `Bearer ${accessToken}` } });
 const payload = await res.json();
 if (!res.ok) {
 throw new Error(getApiErrorMessage(payload, 'ไม่สามารถดึงข้อมูลห้องพักได้'));
 }
 const data = unwrapApiData<any>(payload);
 setTenantToken(data.tenantToken || accessToken);
 setRoom(data.room);
 setSettings(data.settings);
 setUnpaidBills(data.unpaidBills);
 setPaidBills(data.paidBills);
 setRoomId(targetRoomId);

 // Also fetch maintenance tickets & announcements
 fetchMaintenanceTickets(targetRoomId, data.tenantToken || accessToken);
 fetchTenantAnnouncements(targetRoomId, data.tenantToken || accessToken);
 } catch (err: any) {
 console.error(err);
 setError(err.message || 'เกิดข้อผิดพลาดในการโหลดข้อมูลบิลห้องพัก');
 } finally {
 setLoading(false);
 }
 };

 const fetchTenantAnnouncements = async (targetRoomId: number, accessToken = tenantToken) => {
 try {
 if (!accessToken) return;
 const res = await fetch(`/api/public/announcements?roomId=${targetRoomId}`, { headers: { Authorization: `Bearer ${accessToken}` } });
 if (res.ok) {
 const data = unwrapApiData<Announcement[]>(await res.json());
 setAnnouncements(data);
 }
 } catch (err) {
 console.error("Failed to fetch tenant announcements:", err);
 }
 };

 const fetchMaintenanceTickets = async (targetRoomId: number, accessToken = tenantToken) => {
 try {
 if (!accessToken) return;
 const res = await fetch(`/api/tenant/maintenance?roomId=${targetRoomId}`, { headers: { Authorization: `Bearer ${accessToken}` } });
 if (res.ok) {
 const data = unwrapApiData<MaintenanceTicket[]>(await res.json());
 setMaintenanceTickets(data);
 }
 } catch (err) {
 console.error("Failed to fetch tenant maintenance tickets:", err);
 }
 };

 const handleCreateRepairTicket = async (e: React.FormEvent) => {
 e.preventDefault();
 if (!room || !repairTitle.trim()) return;

 setSubmittingRepair(true);
 try {
 const res = await fetch('/api/maintenance', {
 method: 'POST',
 headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tenantToken}` },
 body: JSON.stringify({
 roomId: room.id,
 roomNumber: room.roomNumber,
 tenantName: room.tenantName,
 tenantPhone: room.tenantPhone,
 title: repairTitle,
 category: repairCategory,
 priority: repairPriority,
 description: repairDescription,
 imageUrl: repairImageUrl || null,
 }),
 });

 if (!res.ok) {
 throw new Error('เกิดข้อผิดพลาดในการบันทึกแจ้งซ่อม');
 }

 setUploadSuccess('ส่งรายการแจ้งซ่อมเรียบร้อยแล้ว เจ้าของหอพักจะดำเนินการตรวจสอบโดยเร็วที่สุด');
 setIsRepairModalOpen(false);
 setRepairTitle('');
 setRepairCategory('other');
 setRepairPriority('medium');
 setRepairDescription('');
 setRepairImageUrl('');
 if (roomId) fetchMaintenanceTickets(roomId);
 } catch (err: any) {
 setUploadError(err.message || 'เกิดข้อผิดพลาดในการส่งข้อมูล');
 } finally {
 setSubmittingRepair(false);
 }
 };

 // Manual Room Lookup
 const handleManualLookup = async (e: React.FormEvent) => {
 e.preventDefault();
 if (!roomNumberInput || !tenantPhoneInput) {
 setError('กรุณากรอกเลขห้องพักและเบอร์โทรศัพท์มือถือ');
 return;
 }

 setLoading(true);
 setError(null);

 try {
 const res = await fetch('/api/public/line/verify', {
 method: 'POST',
 headers: { 'Content-Type': 'application/json' },
 body: JSON.stringify({
 roomNumber: roomNumberInput,
 tenantPhone: tenantPhoneInput
 })
 });

 const payload = await res.json();
 if (!res.ok) {
 throw new Error(getApiErrorMessage(payload, 'ไม่พบข้อมูลเลขห้องหรือเบอร์โทรไม่ถูกต้อง'));
 }

 const data = unwrapApiData<any>(payload);
 setRoom(data.room);
 setSettings(data.settings);
 setUnpaidBills(data.unpaidBills);
 setPaidBills(data.paidBills);
 setTenantToken(data.tenantToken);
 setRoomId(data.room.id);

 fetchMaintenanceTickets(data.room.id, data.tenantToken);
 fetchTenantAnnouncements(data.room.id, data.tenantToken);

 // Do not put a room id in a shareable URL; access requires a tenant token.
 window.history.replaceState({}, '', window.location.pathname);

 } catch (err: any) {
 console.error(err);
 setError(err.message || 'เกิดข้อผิดพลาดในการค้นหาข้อมูล');
 } finally {
 setLoading(false);
 }
 };

 // Handle local File Selection and Conversion to Base64
 const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
 const file = e.target.files?.[0];
 if (!file) return;

 if (!file.type.startsWith('image/')) {
 setUploadError('กรุณาเลือกไฟล์ที่เป็นรูปภาพเท่านั้น (PNG, JPG, JPEG)');
 return;
 }

 // Limit file size to 4MB for safe transfer
 if (file.size > 4 * 1024 * 1024) {
 setUploadError('ขนาดรูปภาพใหญ่เกิน 4MB กรุณาลดขนาดภาพหรือถ่ายภาพใหม่');
 return;
 }

 setUploadError(null);
 const reader = new FileReader();
 reader.onloadend = () => {
 setSlipBase64(reader.result as string);
 };
 reader.readAsDataURL(file);
 };

 // Drag and Drop files
 const handleDragOver = (e: React.DragEvent) => {
 e.preventDefault();
 };

 const handleDrop = (e: React.DragEvent) => {
 e.preventDefault();
 const file = e.dataTransfer.files?.[0];
 if (!file) return;

 if (!file.type.startsWith('image/')) {
 setUploadError('กรุณาเลือกไฟล์ที่เป็นรูปภาพเท่านั้น');
 return;
 }

 if (file.size > 4 * 1024 * 1024) {
 setUploadError('ขนาดรูปภาพใหญ่เกิน 4MB');
 return;
 }

 setUploadError(null);
 const reader = new FileReader();
 reader.onloadend = () => {
 setSlipBase64(reader.result as string);
 };
 reader.readAsDataURL(file);
 };

 // Submit payment slip
 const handleUploadSlip = async (billId: number) => {
 if (!slipBase64) {
 setUploadError('กรุณาแนบรูปภาพสลิปการโอนเงิน');
 return;
 }

 setUploading(true);
 setUploadError(null);
 setUploadSuccess(null);

 try {
 const res = await fetch(`/api/public/bills/${billId}/upload-slip`, {
 method: 'POST',
 headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tenantToken}` },
 body: JSON.stringify({ slipImage: slipBase64 })
 });

 if (!res.ok) {
 const data = await res.json();
 throw new Error(getApiErrorMessage(data, 'ไม่สามารถอัปโหลดสลิปโอนเงินได้'));
 }

 setUploadSuccess('อัปโหลดสลิปโอนเงินสําเร็จเรียบร้อยแล้วค่ะ! ระบบกําลังรอเจ้าของหอพักตรวจสอบ');
 setSlipBase64(null);
 setSelectedBillForSlip(null);
 
 // Refresh room data to update UI
 if (roomId) {
 fetchRoomData(roomId);
 }

 } catch (err: any) {
 console.error(err);
 setUploadError(err.message || 'เกิดข้อผิดพลาดในการส่งข้อมูล');
 } finally {
 setUploading(false);
 }
 };

 // Copy Room specific link
 const handleCopyLink = () => {
 if (!room) return;
 const directLink = `${window.location.origin}${window.location.pathname}?roomId=${room.id}`;
 navigator.clipboard.writeText(directLink);
 setCopiedLink(true);
 setTimeout(() => setCopiedLink(false), 3000);
 };

 // Log out or back to search
 const handleExitPortal = () => {
 setRoomId(null);
 setTenantToken(null);
 setRoom(null);
 setUnpaidBills([]);
 setPaidBills([]);
 setSelectedBillForSlip(null);
 setSlipBase64(null);
 setUploadSuccess(null);
 setUploadError(null);
 setError(null);

 const newUrl = window.location.pathname;
 window.history.pushState({ path: newUrl }, '', newUrl);
 };

 // Date/Month formatters
 const formatThaiMonth = (monthStr: string) => {
 const [year, month] = monthStr.split('-');
 const months = [
 'มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน',
 'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'
 ];
 return `${months[parseInt(month) - 1]} ${parseInt(year) + 543}`;
 };

 const formatThaiDate = (dateStr: string) => {
 if (!dateStr) return '';
 const [year, month, day] = dateStr.split('-');
 const monthsShort = [
 'ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.',
 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'
 ];
 return `${parseInt(day)} ${monthsShort[parseInt(month) - 1]} ${(parseInt(year) + 543)}`;
 };

 const isOverdue = (dueDateStr: string) => {
 const today = new Date().toISOString().substring(0, 10);
 return dueDateStr < today;
 };

 // Render Room Search / Lookup interface
 if (!roomId || !room) {
 return (
 <div className="min-h-screen bg-[#F0F0EB] flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8 font-sans">
 
 <div className="sm:mx-auto sm:w-full sm:max-w-md text-center space-y-4">
 <div className="mx-auto h-16 w-16 bg-gradient-to-tr from-blue-600 to-indigo-500 rounded-3xl shadow-lg flex items-center justify-center text-[#1A1A1A]">
 <Building2 className="w-8 h-8" />
 </div>
 <div className="space-y-1.5">
 <h1 className="text-xl font-extrabold tracking-tight text-[#1A1A1A] sm:text-2xl">
 ระบบตรวจสอบบิลหอพักและอัปโหลดสลิป
 </h1>
 <p className="text-xs text-[#8A8A85] font-semibold uppercase tracking-wider">
 Tenant Portal Access
 </p>
 <p className="text-[9px] font-mono text-[#8A8A85]">{APP_VERSION_LABEL}</p>
 </div>
 </div>

 <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
 <div className="bg-white py-8 px-6 border border-[#E0E0DB] rounded-3xl shadow-xl space-y-6">
 
 <div className="text-center bg-[#1DB954]/10/50 p-4 rounded-2xl border border-blue-100">
 <p className="text-xs font-bold text-blue-800 leading-normal">
 กรุณากรอกข้อมูลห้องพักและเบอร์โทรศัพท์ที่ใช้ลงทะเบียนในสัญญาเช่า เพื่อยืนยันตัวตนและเข้าดูบิลของท่านค่ะ
 </p>
 </div>

 {error && (
 <div className="p-4 bg-[#E22134]/8 border border-[#E22134]/30 rounded-2xl text-xs text-[#E22134] font-semibold flex items-center gap-2.5 ">
 <AlertTriangle className="w-5 h-5 text-[#E22134] shrink-0" />
 <span className="whitespace-pre-line">{error}</span>
 </div>
 )}

 <form onSubmit={handleManualLookup} className="space-y-4">
 <div>
 <label className="block text-xxs font-extrabold text-[#8A8A85] uppercase tracking-wider mb-1.5">
 หมายเลขห้องพัก (Room Number)
 </label>
 <div className="relative">
 <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#8A8A85]">
 <Building2 className="w-4 h-4" />
 </div>
 <input
 type="text"
 required
 placeholder="เช่น 101, A2"
 value={roomNumberInput}
 onChange={(e) => setRoomNumberInput(e.target.value)}
 className="block w-full pl-10 pr-3 py-3 bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl text-xs text-[#1A1A1A] font-bold focus:outline-none focus:bg-white focus:border-[#1DB954] focus:ring-1 focus:ring-blue-500 transition"
 />
 </div>
 </div>

 <div>
 <label className="block text-xxs font-extrabold text-[#8A8A85] uppercase tracking-wider mb-1.5">
 เบอร์โทรศัพท์มือถือผู้เช่า (Phone Number)
 </label>
 <div className="relative">
 <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#8A8A85]">
 <Phone className="w-4 h-4" />
 </div>
 <input
 type="tel"
 required
 placeholder="กรอกตัวเลข 10 หลัก เช่น 0812345678"
 value={tenantPhoneInput}
 onChange={(e) => setTenantPhoneInput(e.target.value)}
 className="block w-full pl-10 pr-3 py-3 bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl text-xs text-[#1A1A1A] font-bold focus:outline-none focus:bg-white focus:border-[#1DB954] focus:ring-1 focus:ring-blue-500 transition"
 />
 </div>
 </div>

 <button
 type="submit"
 disabled={loading}
 className="w-full py-3.5 px-4 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 active:scale-[0.98] text-[#1A1A1A] rounded-xl text-xs font-black shadow-lg shadow-blue-200 cursor-pointer flex items-center justify-center gap-2 transition disabled:from-slate-300 disabled:to-slate-400 disabled:text-slate-500"
 >
 {loading ? (
 <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
 ) : (
 <Search className="w-4 h-4" />
 )}
 <span>{loading ? 'กำลังตรวจสอบ...' : 'ค้นหารายการบิลของฉัน'}</span>
 </button>
 </form>

 <div className="text-center pt-2">
 <p className="text-[10px] text-[#8A8A85] font-medium">
 หากพบปัญหาไม่สามารถเข้าใช้งานได้ กรุณาติดต่อผู้ดูแลหอพักเพื่อตรวจสอบความถูกต้องของเบอร์โทรศัพท์ในระบบสัญญาเช่าค่ะ
 </p>
 </div>

 </div>
 </div>
 </div>
 );
 }

 // Render Active Tenant Portal Dashboard
 return (
 <div className="min-h-screen bg-[#F0F0EB] text-[#1A1A1A] py-6 px-4 sm:px-6 lg:px-8 font-sans">
 <div className="max-w-4xl mx-auto space-y-6">

 <p className="text-right text-[9px] font-mono text-[#8A8A85]">{APP_VERSION_LABEL}</p>

 {/* Portal Top Navigation bar */}
 <div className="flex items-center justify-between">
 <button
 onClick={handleExitPortal}
 className="flex items-center gap-1.5 px-3 py-2 bg-white border border-[#E0E0DB] hover:bg-[#E8E8E3] text-[#6B6B66] rounded-xl text-xs font-bold transition cursor-pointer "
 >
 <ArrowLeft className="w-4 h-4 text-[#8A8A85]" />
 <span>ออกจากระบบ / ค้นหาใหม่</span>
 </button>

 <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1DB954]/8 text-[#1DB954] text-[10px] font-extrabold uppercase tracking-wider border border-[#1DB954]/30">
 <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
 <span>ยืนยันตัวตนสำเร็จแล้ว</span>
 </span>
 </div>

 {/* Main Header Card */}
 <div className="bg-slate-900 text-[#1A1A1A] p-6 rounded-2xl shadow-xl border border-[#E0E0DB] relative overflow-hidden">
 <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-64 h-64 rounded-full bg-[#1DB954]/8 blur-3xl pointer-events-none" />
 <div className="absolute left-1/3 bottom-0 w-44 h-44 rounded-full bg-indigo-600/5 blur-3xl pointer-events-none" />
 
 <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 relative z-10">
 <div className="space-y-1">
 <span className="text-xxs font-extrabold tracking-wider text-[#1DB954] uppercase bg-[#1DB954]/8 px-2.5 py-0.5 rounded-full border border-[#1DB954]/30/20">
 {settings?.dormName || 'หอพักของฉัน'}
 </span>
 <h2 className="text-xl font-black tracking-tight text-[#1A1A1A] mt-1.5">
 ห้องพัก {room.roomNumber}
 </h2>
 <p className="text-xs text-[#8A8A85] font-bold">
 ผู้เช่า: <span className="text-slate-200">{room.tenantName}</span> | โทร: <span className="text-slate-200">{room.tenantPhone}</span>
 </p>
 </div>

 <div className="flex flex-wrap gap-2 shrink-0">
 <button
 onClick={() => setIsRepairModalOpen(true)}
 className="px-3.5 py-2 bg-amber-500 hover:bg-amber-600 active:scale-[0.98] text-[#1A1A1A] rounded-xl text-[11px] font-bold transition flex items-center gap-1.5 cursor-pointer "
 >
 <Wrench className="w-3.5 h-3.5" />
 <span>แจ้งซ่อมอุปกรณ์</span>
 </button>
 <button
 onClick={handleCopyLink}
 className="px-3.5 py-2 bg-[#181818]/10 hover:bg-white/15 active:scale-[0.98] border border-white/10 text-[#1A1A1A] rounded-xl text-[11px] font-bold transition flex items-center gap-1.5 cursor-pointer"
 >
 {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
 <span>{copiedLink ? 'คัดลอกสำเร็จ!' : 'บันทึกลิงก์เข้าสู่ห้องนี้'}</span>
 </button>
 </div>
 </div>
 </div>

 {/* Action alerts */}
 {uploadSuccess && (
 <div className="p-4 bg-[#1DB954]/8 border border-[#1DB954]/30 rounded-2xl text-xs text-[#1DB954] font-bold flex items-start gap-2.5 ">
 <CheckCircle2 className="w-5 h-5 text-[#1DB954] shrink-0 mt-0.5" />
 <span>{uploadSuccess}</span>
 </div>
 )}

 {uploadError && (
 <div className="p-4 bg-[#E22134]/8 border border-[#E22134]/30 rounded-2xl text-xs text-[#E22134] font-bold flex items-start gap-2.5 ">
 <AlertTriangle className="w-5 h-5 text-[#E22134] shrink-0 mt-0.5" />
 <span>{uploadError}</span>
 </div>
 )}

 {/* Section: Announcements & Notice Board */}
 {announcements.length > 0 && (
 <div className="bg-white p-5 rounded-2xl border border-[#6366F1]/30 space-y-3">
 <div className="flex items-center gap-2 border-b border-[#E0E0DB] pb-3">
 <div className="p-2 bg-[#6366F1]/8 text-[#6366F1] rounded-xl">
 <Megaphone className="w-4 h-4" />
 </div>
 <div>
 <h3 className="font-extrabold text-sm text-[#1A1A1A]">ประกาศ & ข่าวสารหอพัก (Notice Board)</h3>
 <p className="text-[11px] text-[#8A8A85]">อัปเดตข้อมูลจากทางหอพัก</p>
 </div>
 </div>

 <div className="space-y-3 pt-1">
 {announcements.map((item) => {
 const isPinned = item.isPinned === 1;
 const isUrgent = item.category === 'urgent';

 return (
 <div
 key={item.id}
 className={`p-4 rounded-xl border text-xs space-y-2 transition-all ${
 isUrgent 
 ? 'bg-[#E22134]/10/70 border-[#E22134]/30 text-rose-950' 
 : isPinned 
 ? 'bg-[#F59B23]/10/70 border-amber-200 text-amber-950' 
 : 'bg-[#282828]/80 border-[#E0E0DB] text-[#1A1A1A]'
 }`}
 >
 <div className="flex items-start justify-between gap-2">
 <div className="flex items-center gap-2">
 {isPinned && (
 <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-200/80 text-amber-900 font-bold flex items-center gap-1 border border-[#F59B23]/30 shrink-0">
 <Pin className="w-3 h-3 fill-amber-700 text-amber-700" />
 ประกาศสำคัญ
 </span>
 )}
 <h4 className="font-bold text-sm leading-snug">{item.title}</h4>
 </div>
 <span className="text-[10px] text-[#8A8A85] shrink-0">
 {new Date(item.createdAt).toLocaleDateString('th-TH', { month: 'short', day: 'numeric' })}
 </span>
 </div>

 <p className="leading-relaxed whitespace-pre-line text-[#6B6B66]">{item.content}</p>

 {item.imageUrl && (
 <a href={item.imageUrl} target="_blank" rel="noreferrer" className="inline-block pt-1">
 <img src={item.imageUrl} alt={item.title} className="max-h-40 rounded-xl object-cover border border-[#E0E0DB]" />
 </a>
 )}
 </div>
 );
 })}
 </div>
 </div>
 )}

 {/* Section: Bills that need payment */}
 <div className="space-y-4">
 <div className="flex items-center gap-2">
 <CreditCard className="w-5 h-5 text-[#1DB954]" />
 <h3 className="text-xs font-extrabold text-[#6B6B66] uppercase tracking-wider">
 ยอดค้างชำระ / รอดำเนินการ ({unpaidBills.length} รายการ)
 </h3>
 </div>

 {unpaidBills.length === 0 ? (
 <div className="bg-white border border-[#E0E0DB] rounded-2xl p-10 text-center space-y-3 ">
 <div className="w-12 h-12 rounded-full bg-[#1DB954]/8 text-[#1DB954] flex items-center justify-center mx-auto border border-[#1DB954]/30">
 <CheckCircle2 className="w-6 h-6" />
 </div>
 <div>
 <p className="text-xs font-bold text-[#1A1A1A]">เย้! ยอดค้างชำระของท่านหมดเกลี้ยงแล้วค่ะ 🎉</p>
 <p className="text-[11px] text-[#8A8A85] mt-1 leading-normal">
 ท่านไม่มีบิลค่าเช่าค้างชำระในระบบขณะนี้ หากท่านพึ่งทำการโอน ยอดเงินจะได้รับยืนยันความถูกต้องในไม่ช้าค่ะ
 </p>
 </div>
 </div>
 ) : (
 <div className="grid grid-cols-1 gap-5">
 {unpaidBills.map((bill) => {
 const elecUnits = Math.max(0, bill.currentElec - bill.priorElec);
 const waterUnits = Math.max(0, bill.currentWater - bill.priorWater);
 const overdue = isOverdue(bill.dueDate);
 
 return (
 <div key={bill.id} className="bg-white border border-[#E0E0DB] rounded-2xl overflow-hidden flex flex-col md:flex-row divide-y md:divide-y-0 md:divide-x divide-slate-100">
 
 {/* Bill breakdown column */}
 <div className="p-5 flex-1 space-y-4">
 
 {/* Month & Overdue Badges */}
 <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#E0E0DB] pb-3">
 <div>
 <p className="text-[10px] text-[#8A8A85] font-bold uppercase tracking-wider">รอบประจำเดือน</p>
 <h4 className="text-sm font-black text-[#1A1A1A] mt-0.5">
 {formatThaiMonth(bill.billMonth)}
 </h4>
 </div>
 
 <div className="flex gap-1.5">
 {bill.slipStatus === 'pending' ? (
 <span className="px-2.5 py-1 text-[9px] font-bold text-[#F59B23] bg-[#F59B23]/8 rounded-full border border-amber-200 flex items-center gap-1 animate-pulse">
 <Clock className="w-3.5 h-3.5 text-[#F59B23]" />
 <span>⌛ รอตรวจสอบความถูกต้อง</span>
 </span>
 ) : bill.slipStatus === 'rejected' ? (
 <span className="px-2.5 py-1 text-[9px] font-bold text-[#E22134] bg-[#E22134]/8 rounded-full border border-[#E22134]/30 flex items-center gap-1 animate-shake">
 <AlertTriangle className="w-3.5 h-3.5 text-[#E22134]" />
 <span>❌ สลิปไม่ถูกต้อง (โปรดอัปโหลดใหม่)</span>
 </span>
 ) : overdue ? (
 <span className="px-2.5 py-1 text-[9px] font-bold text-[#E22134] bg-[#E22134]/8 rounded-full border border-[#E22134]/30 flex items-center gap-1">
 <Clock className="w-3.5 h-3.5 text-[#E22134]" />
 <span>เกินกำหนดชำระ</span>
 </span>
 ) : (
 <span className="px-2.5 py-1 text-[9px] font-bold text-blue-800 bg-[#1DB954]/8 rounded-full border border-[#1DB954]/30 flex items-center gap-1">
 <Clock className="w-3.5 h-3.5 text-[#1DB954]" />
 <span>ยังไม่ชำระเงิน</span>
 </span>
 )}
 </div>
 </div>

 {/* Line Item Pricing breakdowns */}
 <div className="space-y-2 text-xxs font-semibold">
 
 {/* Rent base */}
 <div className="flex justify-between items-center text-[#6B6B66]">
 <span className="flex items-center gap-1.5">
 <Building2 className="w-3.5 h-3.5 text-[#8A8A85]" />
 <span>ค่าเช่าห้องพัก (Monthly Rent)</span>
 </span>
 <span className="font-extrabold text-[#1A1A1A]">{bill.rentCost.toLocaleString()} บาท</span>
 </div>

 {/* Electricity cost */}
 <div className="flex justify-between items-start text-[#6B6B66]">
 <div className="space-y-0.5">
 <span className="flex items-center gap-1.5">
 <Zap className="w-3.5 h-3.5 text-[#F59B23]" />
 <span>ค่าไฟฟ้า (Electricity)</span>
 </span>
 <p className="text-[9px] text-[#8A8A85] pl-5">
 เลขมิเตอร์: {bill.priorElec} → {bill.currentElec} หน่วย (ใช้ {elecUnits} หน่วย)
 </p>
 </div>
 <span className="font-extrabold text-[#1A1A1A]">
 {(bill.elecCost ?? Math.round(elecUnits * bill.elecUnitCost)).toLocaleString()} บาท <span className="text-[9px] text-[#8A8A85]">({bill.elecUnitCost}/หน่วย)</span>
 </span>
 </div>

 {/* Water cost */}
 <div className="flex justify-between items-start text-[#6B6B66]">
 <div className="space-y-0.5">
 <span className="flex items-center gap-1.5">
 <Droplet className="w-3.5 h-3.5 text-[#1DB954]" />
 <span>ค่าน้ำประปา (Water)</span>
 </span>
 <p className="text-[9px] text-[#8A8A85] pl-5">
 เลขมิเตอร์: {bill.priorWater} → {bill.currentWater} หน่วย (ใช้ {waterUnits} หน่วย)
 </p>
 </div>
 <span className="font-extrabold text-[#1A1A1A]">
 {bill.waterCost.toLocaleString()} บาท <span className="text-[9px] text-[#8A8A85]">({bill.waterUnitCost}/หน่วย)</span>
 </span>
 </div>

 {/* Snapshotted recurring/manual charges with legacy fallback. */}
 {(bill.chargeItems?.length ? bill.chargeItems : (bill.otherCost > 0 ? [{ label: bill.otherDescription || 'ค่าใช้จ่ายอื่น ๆ', amount: bill.otherCost }] : [])).map((item, index) => (
 <div key={`${item.label}-${index}`} className="flex justify-between items-start text-[#6B6B66]">
 <div className="space-y-0.5">
 <span className="flex items-center gap-1.5">
 <Coins className="w-3.5 h-3.5 text-[#1DB954]" />
 <span>{item.label}</span>
 </span>
 </div>
 <span className="font-extrabold text-[#1A1A1A]">
 {Number(item.amount).toLocaleString()} บาท
 </span>
 </div>
 ))}

 </div>

 {/* Total and Due Date Footer */}
 <div className="pt-3 border-t border-dashed border-[#E0E0DB] flex items-center justify-between">
 <div>
 <p className="text-[10px] text-[#8A8A85] font-bold">กำหนดชำระเงินไม่เกิน</p>
 <p className={`text-xxs font-black mt-0.5 ${overdue ? 'text-[#E22134]' : 'text-[#6B6B66]'}`}>
 {formatThaiDate(bill.dueDate)}
 </p>
 </div>
 <div className="text-right">
 <p className="text-[10px] text-[#8A8A85] font-bold">ยอดสุทธิรวมทั้งสิ้น</p>
 <p className="text-lg font-black text-[#1DB954]">{bill.totalCost.toLocaleString()} บาท</p>
 </div>
 </div>

 </div>

 {/* QR Payment and Slip Submission column */}
 <div className="p-5 w-full md:w-80 bg-[#282828]/50 flex flex-col justify-between gap-4">
 
 <div className="space-y-3">
 <div className="text-center md:text-left">
 <h5 className="text-[10px] font-extrabold text-[#8A8A85] uppercase tracking-wider">ช่องทางการชำระเงิน</h5>
 </div>

 {/* PromptPay Detail Card */}
 {settings?.promptpayId ? (
 <div className="p-3 bg-white border border-[#E0E0DB] rounded-xl space-y-2 text-center md:text-left relative ">
 <div className="flex items-center gap-1.5 text-blue-800 font-black text-xxs">
 <CreditCard className="w-4 h-4 text-[#1DB954]" />
 <span>พร้อมเพย์ (PromptPay)</span>
 </div>
 <div className="text-xxs text-[#6B6B66] font-medium space-y-0.5">
 <p>หมายเลข: <strong className="text-[#1A1A1A] text-xs font-black">{settings.promptpayId}</strong></p>
 {settings.promptpayName && <p>ชื่อบัญชี: <strong className="text-[#1A1A1A]">{settings.promptpayName}</strong></p>}
 </div>
 <button
 type="button"
 onClick={() => setShowQrModal(bill)}
 className="w-full py-1.5 px-2 bg-[#1DB954]/8 hover:bg-blue-100 text-blue-700 rounded-full text-[10px] font-bold transition flex items-center justify-center gap-1 cursor-pointer"
 >
 <QrCode className="w-3.5 h-3.5" />
 <span>สแกน QR Code พร้อมเพย์</span>
 </button>
 </div>
 ) : (
 <div className="p-3 bg-white border border-[#E0E0DB] rounded-xl text-center md:text-left text-xxs text-[#8A8A85]">
 <p>กรุณาติดต่อผู้ดูแลหอเพื่อขอรับข้อมูลบัญชีธนาคารโอนเงินค่ะ</p>
 </div>
 )}
 </div>

 {/* Slip uploading / review preview container */}
 <div className="space-y-2.5">
 
 {/* Display existing uploaded slip if pending review */}
 {bill.slipImage && bill.slipStatus === 'pending' ? (
 <div className="space-y-2">
 <p className="text-[9px] text-[#8A8A85] font-bold uppercase text-center">สลิปที่อัปโหลดไปแล้ว</p>
 <div className="relative group rounded-xl overflow-hidden aspect-[4/3] border border-[#E0E0DB] bg-white max-w-[160px] mx-auto">
 <img src={bill.slipImage} alt="slip uploaded" className="w-full h-full object-contain" />
 <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition flex items-center justify-center">
 <span className="text-[9px] text-[#1A1A1A] font-bold bg-black/40 px-2 py-1 rounded-md">รอเจ้าของหออนุมัติ</span>
 </div>
 </div>
 </div>
 ) : (bill.slipStatus === 'none' || bill.slipStatus === 'rejected' || selectedBillForSlip === bill.id) ? (
 
 // File attachment logic
 <div>
 {selectedBillForSlip === bill.id ? (
 <div className="space-y-2">
 
 {/* Upload Box Area */}
 <div
 onDragOver={handleDragOver}
 onDrop={handleDrop}
 className="border-2 border-dashed border-[#E0E0DB] rounded-xl p-3 text-center bg-white hover:bg-[#E8E8E3] transition relative cursor-pointer group"
 >
 {slipBase64 ? (
 <div className="space-y-1.5">
 <div className="relative h-24 w-full rounded-md overflow-hidden bg-[#F0F0EB] border border-[#E0E0DB] flex items-center justify-center">
 <img src={slipBase64} alt="slip preview" className="h-full object-contain" />
 <button
 type="button"
 onClick={() => setSlipBase64(null)}
 className="absolute top-1 right-1 p-1 rounded-full bg-black/40 text-[#1A1A1A] hover:bg-slate-900 transition"
 >
 <X className="w-3 h-3" />
 </button>
 </div>
 <p className="text-[9px] text-[#8A8A85] truncate font-semibold">เลือกภาพสลิปแล้ว</p>
 </div>
 ) : (
 <div className="space-y-1">
 <Upload className="w-6 h-6 text-[#8A8A85] mx-auto group-hover:text-[#1DB954] transition" />
 <p className="text-[10px] font-bold text-[#6B6B66]">กดเพื่อเลือกรูป หรือลากไฟล์มาวาง</p>
 <p className="text-[8px] text-[#8A8A85]">รูปภาพสลิป .jpg, .png</p>
 </div>
 )}
 <input
 type="file"
 accept="image/*"
 onChange={handleFileChange}
 className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
 />
 </div>

 {/* Confirmation buttons */}
 <div className="grid grid-cols-2 gap-2 text-xxs font-bold">
 <button
 type="button"
 onClick={() => {
 setSelectedBillForSlip(null);
 setSlipBase64(null);
 }}
 className="py-2 bg-white hover:bg-[#E8E8E3] border border-[#E0E0DB] text-[#6B6B66] rounded-lg text-center cursor-pointer transition"
 >
 ยกเลิก
 </button>
 <button
 type="button"
 disabled={uploading || !slipBase64}
 onClick={() => handleUploadSlip(bill.id)}
 className="py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 disabled:text-slate-500 text-[#1A1A1A] rounded-lg text-center cursor-pointer transition flex items-center justify-center gap-1"
 >
 {uploading ? (
 <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
 ) : (
 <Check className="w-3.5 h-3.5" />
 )}
 <span>{uploading ? 'กำลังบันทึก...' : 'ส่งสลิป'}</span>
 </button>
 </div>

 </div>
 ) : (
 <button
 type="button"
 onClick={() => setSelectedBillForSlip(bill.id)}
 className="w-full py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] text-[#1A1A1A] rounded-xl text-xxs font-extrabold transition flex items-center justify-center gap-1.5 cursor-pointer"
 >
 <Upload className="w-4 h-4" />
 <span>อัปโหลดสลิปโอนเงิน (แจ้งชำระ)</span>
 </button>
 )}
 </div>
 ) : null}
 </div>

 </div>

 </div>
 );
 })}
 </div>
 )}
 </div>

 {/* Section: Historical Receipts Collapsible */}
 <div className="space-y-4 pt-4">
 <div className="flex items-center gap-2">
 <History className="w-5 h-5 text-[#8A8A85]" />
 <h3 className="text-xs font-extrabold text-[#6B6B66] uppercase tracking-wider">
 ประวัติการชำระเงินย้อนหลัง (คลังใบเสร็จ)
 </h3>
 </div>

 {paidBills.length === 0 ? (
 <div className="bg-white border border-[#E0E0DB] rounded-2xl p-6 text-center text-xxs text-[#8A8A85]">
 ไม่พบประวัติการชำระเงินที่อนุมัติแล้วในระบบขณะนี้
 </div>
 ) : (
 <div className="bg-white border border-[#E0E0DB] rounded-2xl overflow-hidden divide-y divide-slate-100">
 {paidBills.map((bill) => (
 <div key={bill.id} className="p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 hover:bg-[#E8E8E3] transition">
 <div className="space-y-0.5">
 <p className="text-xs font-bold text-[#1A1A1A]">รอบเดือน {formatThaiMonth(bill.billMonth)}</p>
 <div className="flex flex-wrap gap-2 text-[10px] text-[#8A8A85] font-semibold">
 <span>ยอดจ่ายรวม: <strong className="text-[#6B6B66]">{bill.totalCost.toLocaleString()} บาท</strong></span>
 <span>•</span>
 {bill.paidAt && (
 <span>อนุมัติเมื่อ: <strong className="text-[#1DB954]">{formatThaiDate(bill.paidAt.substring(0, 10))}</strong></span>
 )}
 </div>
 </div>
 
 <div className="flex items-center gap-1.5 self-start sm:self-auto">
 <span className="px-2 py-0.5 text-[9px] font-bold text-[#1DB954] bg-[#1DB954]/8 rounded-full border border-[#1DB954]/30">
 ชำระเงินเสร็จสิ้น (Paid)
 </span>
 </div>
 </div>
 ))}
 </div>
 )}
 </div>

 {/* Section: Repair Tickets (ประวัติการแจ้งซ่อมของห้องนี้) */}
 <div className="space-y-4 pt-4 border-t border-[#E0E0DB]">
 <div className="flex items-center justify-between">
 <div className="flex items-center gap-2">
 <div className="p-1.5 bg-[#F59B23]/8 rounded-lg text-amber-700">
 <Wrench className="w-4 h-4" />
 </div>
 <h3 className="font-extrabold text-sm text-[#1A1A1A] uppercase tracking-wider">
 รายการแจ้งซ่อมของห้องพัก ({maintenanceTickets.length})
 </h3>
 </div>
 <button
 onClick={() => setIsRepairModalOpen(true)}
 className="flex items-center gap-1.5 text-xs font-bold text-amber-700 bg-[#F59B23]/8 hover:bg-amber-100 border border-amber-200 px-3 py-1.5 rounded-xl transition cursor-pointer"
 >
 <Plus className="w-3.5 h-3.5" />
 <span>แจ้งซ่อมใหม่</span>
 </button>
 </div>

 {maintenanceTickets.length === 0 ? (
 <div className="bg-white p-6 rounded-2xl border border-[#E0E0DB] text-center text-xs text-[#8A8A85]">
 ยังไม่มีการแจ้งซ่อมอุปกรณ์สำหรับห้องพักนี้
 </div>
 ) : (
 <div className="space-y-3">
 {maintenanceTickets.map((ticket) => {
 const statusMap: Record<string, { label: string; bg: string }> = {
 pending: { label: 'รอดำเนินการ', bg: 'bg-[#F59B23]/8 text-[#F59B23] border-[#F59B23]/30' },
 in_progress: { label: 'กำลังซ่อมแซม', bg: 'bg-[#1DB954]/8 text-blue-800 border-[#1DB954]/30' },
 completed: { label: 'เสร็จสิ้นแล้ว', bg: 'bg-[#1DB954]/8 text-[#1DB954] border-[#1DB954]/30' },
 cancelled: { label: 'ยกเลิก', bg: 'bg-[#F0F0EB] text-[#6B6B66] border-[#E0E0DB]' },
 };
 const st = statusMap[ticket.status] || statusMap.pending;

 return (
 <div key={ticket.id} className="bg-white p-4 rounded-2xl border border-[#E0E0DB] flex flex-col sm:flex-row justify-between gap-3 text-xs">
 <div className="space-y-1">
 <div className="flex items-center gap-2">
 <span className="font-bold text-[#1A1A1A] text-sm">{ticket.title}</span>
 <span className={`px-2 py-0.5 rounded-md border text-[10px] font-semibold ${st.bg}`}>
 {st.label}
 </span>
 </div>
 {ticket.description && (
 <p className="text-[#6B6B66] leading-relaxed">{ticket.description}</p>
 )}
 {ticket.technicianNote && (
 <div className="mt-1 bg-[#F59B23]/8 border border-[#F59B23]/30 p-2 rounded-lg text-amber-900 text-[11px]">
 <strong>ตอบกลับจากหอพัก:</strong> {ticket.technicianNote}
 </div>
 )}
 <p className="text-[10px] text-[#8A8A85]">
 แจ้งเมื่อ: {new Date(ticket.createdAt).toLocaleDateString('th-TH', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
 </p>
 </div>
 {ticket.imageUrl && (
 <a href={ticket.imageUrl} target="_blank" rel="noreferrer" className="shrink-0">
 <img src={ticket.imageUrl} alt={ticket.title} className="w-16 h-16 rounded-xl object-cover border border-[#E0E0DB]" />
 </a>
 )}
 </div>
 );
 })}
 </div>
 )}
 </div>

 </div>

 {/* MODAL: Submit Repair Request */}
 <AnimatePresence>
 {isRepairModalOpen && (
 <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 z-50 font-sans text-[#1A1A1A]">
 <motion.div
 initial={{ opacity: 0, scale: 0.95 }}
 animate={{ opacity: 1, scale: 1 }}
 exit={{ opacity: 0, scale: 0.95 }}
 className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl relative space-y-4 border border-[#E0E0DB] text-left max-h-[90vh] overflow-y-auto"
 >
 <div className="flex justify-between items-center border-b border-[#E0E0DB] pb-3">
 <div className="flex items-center gap-2">
 <div className="p-2 bg-[#F59B23]/8 text-amber-700 rounded-xl">
 <Wrench className="w-5 h-5" />
 </div>
 <div>
 <h3 className="font-extrabold text-sm text-slate-950">แจ้งซ่อมอุปกรณ์ในห้องพัก</h3>
 <p className="text-xxs text-[#8A8A85]">ห้องพัก {room.roomNumber} ({room.tenantName})</p>
 </div>
 </div>
 <button
 onClick={() => setIsRepairModalOpen(false)}
 className="p-1 rounded-lg hover:bg-[#E8E8E3] text-[#8A8A85] hover:text-slate-600 transition cursor-pointer"
 >
 <X className="w-5 h-5" />
 </button>
 </div>

 <form onSubmit={handleCreateRepairTicket} className="space-y-4 text-xs">
 <div>
 <label className="block font-bold text-[#6B6B66] mb-1">หัวข้อ / อุปกรณ์ที่ชำรุด *</label>
 <input
 type="text"
 required
 placeholder="เช่น ก๊อกน้ำอ่างล้างหน้า leakage, หลอดไฟดับ"
 value={repairTitle}
 onChange={(e) => setRepairTitle(e.target.value)}
 className="w-full p-2.5 border border-[#E0E0DB] rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500/20"
 />
 </div>

 <div className="grid grid-cols-2 gap-3">
 <div>
 <label className="block font-bold text-[#6B6B66] mb-1">หมวดหมู่</label>
 <select
 value={repairCategory}
 onChange={(e) => setRepairCategory(e.target.value as any)}
 className="w-full p-2.5 border border-[#E0E0DB] rounded-xl bg-[#F0F0EB] focus:outline-none focus:ring-2 focus:ring-amber-500/20"
 >
 <option value="plumbing">🚰 ประปา/ห้องน้ำ</option>
 <option value="electrical">⚡ ไฟฟ้า/หลอดไฟ</option>
 <option value="appliance">❄️ เครื่องใช้ไฟฟ้า</option>
 <option value="furniture">🪑 เฟอร์นิเจอร์</option>
 <option value="structure">🚪 ตัวห้อง/ประตู</option>
 <option value="other">🔧 อื่นๆ</option>
 </select>
 </div>

 <div>
 <label className="block font-bold text-[#6B6B66] mb-1">ความเร่งด่วน</label>
 <select
 value={repairPriority}
 onChange={(e) => setRepairPriority(e.target.value as any)}
 className="w-full p-2.5 border border-[#E0E0DB] rounded-xl bg-[#F0F0EB] focus:outline-none focus:ring-2 focus:ring-amber-500/20"
 >
 <option value="low">ปกติ</option>
 <option value="medium">ปานกลาง</option>
 <option value="high">สูง</option>
 <option value="urgent">ด่วนมาก ⚠️</option>
 </select>
 </div>
 </div>

 <div>
 <label className="block font-bold text-[#6B6B66] mb-1">รายละเอียดเพิ่มเติม</label>
 <textarea
 rows={3}
 placeholder="อธิบายรายละเอียดปัญหา อาการ หรือช่วงเวลาที่สะดวกให้ช่างเข้า..."
 value={repairDescription}
 onChange={(e) => setRepairDescription(e.target.value)}
 className="w-full p-3 border border-[#E0E0DB] rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500/20"
 />
 </div>

 <div>
 <label className="block font-bold text-[#6B6B66] mb-1">URL รูปถ่ายประกอบ (ถ้ามี)</label>
 <input
 type="url"
 placeholder="https://..."
 value={repairImageUrl}
 onChange={(e) => setRepairImageUrl(e.target.value)}
 className="w-full p-2.5 border border-[#E0E0DB] rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500/20"
 />
 </div>

 <div className="pt-2 flex justify-end gap-2">
 <button
 type="button"
 onClick={() => setIsRepairModalOpen(false)}
 className="px-4 py-2.5 bg-[#F0F0EB] hover:bg-slate-200 text-[#6B6B66] rounded-xl font-bold transition cursor-pointer"
 >
 ยกเลิก
 </button>
 <button
 type="submit"
 disabled={submittingRepair}
 className="px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-[#1A1A1A] rounded-xl font-bold transition cursor-pointer"
 >
 {submittingRepair ? 'กำลังส่งข้อมูล...' : 'ส่งรายการแจ้งซ่อม'}
 </button>
 </div>
 </form>
 </motion.div>
 </div>
 )}
 </AnimatePresence>

 {/* MODAL: Scan PromptPay QR Code overlay */}
 <AnimatePresence>
 {showQrModal && (
 <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 z-50 font-sans text-[#1A1A1A]">
 <motion.div
 initial={{ opacity: 0, scale: 0.95 }}
 animate={{ opacity: 1, scale: 1 }}
 exit={{ opacity: 0, scale: 0.95 }}
 className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl relative space-y-4 border border-[#E0E0DB] text-center"
 >
 <div className="flex justify-between items-center border-b border-[#E0E0DB] pb-3">
 <div className="text-left">
 <h3 className="font-extrabold text-sm text-slate-950">พร้อมเพย์ QR Code</h3>
 <p className="text-xxs text-[#8A8A85]">สแกนชำระด้วยแอปพลิเคชันธนาคารบนมือถือ</p>
 </div>
 <button
 onClick={() => setShowQrModal(null)}
 className="p-1 rounded-lg hover:bg-[#E8E8E3] text-[#8A8A85] hover:text-slate-600 transition cursor-pointer"
 >
 <X className="w-5 h-5" />
 </button>
 </div>

 {/* QR Image with dynamic promptpay API */}
 <div className="bg-[#F0F0EB] p-4 rounded-2xl border border-[#E0E0DB] max-w-[240px] mx-auto shadow-inner space-y-2">
 <PromptPayQR
 target={settings?.promptpayId || ''}
 amount={showQrModal.totalCost}
 className="w-full aspect-square object-contain rounded-lg"
 />
 <div className="flex items-center justify-center gap-1 bg-white border border-[#E0E0DB] rounded-full px-3 py-1 mt-1">
 <span className="w-1.5 h-1.5 rounded-full bg-[#1DB954]" />
 <span className="text-[10px] font-extrabold text-blue-800">พร้อมเพย์นำจ่ายยอดอัตโนมัติ</span>
 </div>
 </div>

 <div className="space-y-1.5">
 <p className="text-xxs text-[#8A8A85] font-bold uppercase tracking-wider">ยอดเงินที่เรียกชำระ</p>
 <p className="text-2xl font-black text-[#1DB954]">{showQrModal.totalCost.toLocaleString()} <span className="text-xs font-semibold text-[#8A8A85]">บาท</span></p>
 <div className="text-[11px] text-[#8A8A85] font-semibold space-y-0.5">
 <p>หมายเลขพร้อมเพย์: <strong className="text-[#1A1A1A]">{settings?.promptpayId}</strong></p>
 {settings?.promptpayName && <p>ชื่อบัญชี: <strong className="text-[#1A1A1A]">{settings.promptpayName}</strong></p>}
 </div>
 </div>

 <button
 type="button"
 onClick={() => setShowQrModal(null)}
 className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-[#1A1A1A] font-extrabold text-xs rounded-xl transition cursor-pointer"
 >
 เสร็จสิ้น / ปิดหน้าต่าง
 </button>
 </motion.div>
 </div>
 )}
 </AnimatePresence>

 </div>
 );
};
