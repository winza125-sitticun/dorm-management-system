import React, { useState, useEffect, useMemo } from 'react';
import { useDebounce } from '../hooks/useDebounce.ts';
import { Bill, Room, Settings, UserProfile } from '../types.ts';
import { 
 FileText, 
 Search, 
 Filter, 
 Eye, 
 Edit, 
 Trash2, 
 CheckCircle, 
 XCircle, 
 Calendar,
 AlertTriangle,
 X,
 RefreshCw,
 Clock,
 Coins,
 Download,
 MessageSquare,
 FileSpreadsheet,
 Check
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../context/AuthContext.tsx';
import { exportBillsToGoogleSheets } from '../lib/googleSheets.ts';
import { ConfirmModal } from './common/ConfirmModal.tsx';
import { EmptyState } from './common/EmptyState.tsx';

interface HistoryViewProps {
 bills: Bill[];
 rooms: Room[];
 settings: Settings;
 loading: boolean;
 onUpdateBill: (billId: number, billData: Partial<Bill>) => Promise<void>;
 onDeleteBill: (billId: number) => Promise<void>;
 onViewBillDetails: (bill: Bill) => void;
 idToken?: string | null;
 userProfile?: UserProfile | null;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
 bills,
 rooms,
 settings,
 loading,
 onUpdateBill,
 onDeleteBill,
 onViewBillDetails,
 idToken,
 userProfile
}) => {
 const { getGoogleAccessToken } = useAuth();
 const canEditBills = userProfile?.role === 'owner' || userProfile?.permissions?.split(',').includes('manage_bills');
 const canEditPayments = userProfile?.role === 'owner' || userProfile?.permissions?.split(',').includes('edit_payments');

 const [exportingSheet, setExportingSheet] = useState(false);
 const [exportSuccess, setExportSuccess] = useState(false);
 const [exportError, setExportError] = useState<string | null>(null);

 const [searchTerm, setSearchTerm] = useState('');
 const debouncedSearchTerm = useDebounce(searchTerm, 300);
 const [selectedMonth, setSelectedMonth] = useState('');
 const [selectedStatus, setSelectedStatus] = useState<string>('');

 const safeBills = useMemo(() => (Array.isArray(bills) ? bills.filter(Boolean) : []), [bills]);

 const filteredBills = useMemo(() => {
   return safeBills.filter(bill => {
     if (!bill) return false;
     const roomNumStr = String(bill.roomNumber || '');
     const tenantNameStr = String(bill.tenantName || '');
     const searchStr = String(debouncedSearchTerm || '').toLowerCase();

     const matchesSearch = 
       roomNumStr.toLowerCase().includes(searchStr) ||
       tenantNameStr.toLowerCase().includes(searchStr);
     const matchesMonth = selectedMonth ? bill.billMonth === selectedMonth : true;
     const matchesStatus = selectedStatus ? bill.status === selectedStatus : true;
     return matchesSearch && matchesMonth && matchesStatus;
   });
 }, [safeBills, debouncedSearchTerm, selectedMonth, selectedStatus]);

 const [isEditModalOpen, setIsEditModalOpen] = useState(false);
 const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
 const [targetBill, setTargetBill] = useState<Bill | null>(null);
 const [selectedSlipBill, setSelectedSlipBill] = useState<Bill | null>(null);

 const handleExportToGoogleSheets = async () => {
 setExportError(null);
 setExportSuccess(false);
 setExportingSheet(true);
 try {
 const spreadsheetId = settings?.googleSpreadsheetId;
 if (!spreadsheetId) {
 throw new Error('ยังไม่ได้เชื่อมโยง Google Spreadsheet กรุณาตั้งค่าเชื่อมโยงในส่วน "ตั้งค่าระบบ" ก่อนค่ะ');
 }

 const token = await getGoogleAccessToken();
 if (!token) {
 throw new Error('ไม่สามารถรับสิทธิ์การเขียน Google Sheets ได้ กรุณาเชื่อมต่อบัญชี Google ก่อนค่ะ');
 }

 await exportBillsToGoogleSheets(token, spreadsheetId, bills);
 setExportSuccess(true);
 setTimeout(() => setExportSuccess(false), 4000);
 } catch (err: any) {
 console.error(err);
 setExportError(err.message || 'เกิดข้อผิดพลาดในการส่งออกข้อมูล กรุณาเชื่อมโยง ID ในหน้าตั้งค่า หรือกดปุ่ม "ส่งออกเป็น CSV" ด้านขวาได้ทันทีครับ');
 } finally {
 setExportingSheet(false);
 }
 };

 // Edit Bill form fields
 const [editMonth, setEditMonth] = useState('');
 const [editPriorElec, setEditPriorElec] = useState('');
 const [editCurrentElec, setEditCurrentElec] = useState('');
 const [editElecDeduct, setEditElecDeduct] = useState('');
 const [editElecCost, setEditElecCost] = useState('');
 const [isEditElecCostManual, setIsEditElecCostManual] = useState<boolean>(false);
 const [editElecCostUnit, setEditElecCostUnit] = useState('');
 const [editPriorWater, setEditPriorWater] = useState('');
 const [editCurrentWater, setEditCurrentWater] = useState('');
 const [editWaterCost, setEditWaterCost] = useState('');
 const [isEditWaterCostManual, setIsEditWaterCostManual] = useState<boolean>(false);
 const [editWaterCostUnit, setEditWaterCostUnit] = useState('');
 const [editRentCost, setEditRentCost] = useState('');
 const [editDepositCost, setEditDepositCost] = useState('');
 const [editOtherCost, setEditOtherCost] = useState('');
 const [editOtherDescription, setEditOtherDescription] = useState('');
 const [editDueDate, setEditDueDate] = useState('');
 const [editStatus, setEditStatus] = useState<'unpaid' | 'paid'>('unpaid');

 const [formError, setFormError] = useState<string | null>(null);
 const [submitting, setSubmitting] = useState(false);

 const openEditModal = (bill: Bill) => {
 setTargetBill(bill);
 setEditMonth(bill.billMonth);
 setEditPriorElec(bill.priorElec.toString());
 setEditCurrentElec(bill.currentElec.toString());
 setEditElecDeduct((bill.elecDeduct ?? 0).toString());
 setEditElecCostUnit(bill.elecUnitCost.toString());
 const elecUnits = Math.max(0, bill.currentElec - bill.priorElec - (bill.elecDeduct ?? 0));
 const expectedElecCalc = Math.round(elecUnits * bill.elecUnitCost);
 const actualElecCost = (bill.elecCost !== undefined && bill.elecCost !== null) ? bill.elecCost : expectedElecCalc;
 setEditElecCost(actualElecCost.toString());
 setIsEditElecCostManual(bill.elecCost !== undefined && bill.elecCost !== null && bill.elecCost !== expectedElecCalc);
 setEditPriorWater(bill.priorWater.toString());
 setEditCurrentWater(bill.currentWater.toString());
 setEditWaterCostUnit(bill.waterUnitCost.toString());
 setEditWaterCost(bill.waterCost.toString());
 const waterUnits = Math.max(0, bill.currentWater - bill.priorWater);
 const expectedCalc = waterUnits > 0 ? Math.round(waterUnits * bill.waterUnitCost) : 0;
 setIsEditWaterCostManual(bill.waterCost !== expectedCalc);
 setEditRentCost(bill.rentCost.toString());
 setEditDepositCost(bill.depositCost.toString());
 setEditOtherCost(bill.otherCost.toString());
 setEditOtherDescription(bill.otherDescription || '');
 setEditDueDate(bill.dueDate);
 setEditStatus(bill.status);
 setFormError(null);
 setIsEditModalOpen(true);
 };

 const openDeleteConfirm = (bill: Bill) => {
 setTargetBill(bill);
 setIsDeleteConfirmOpen(true);
 };

 const handleToggleStatus = async (bill: Bill) => {
 if (!canEditPayments) {
 alert('คุณไม่มีสิทธิ์บันทึกหรือแก้ไขสถานะการชำระเงิน');
 return;
 }
 const nextStatus = bill.status === 'paid' ? 'unpaid' : 'paid';
 try {
 await onUpdateBill(bill.id, { 
 status: nextStatus,
 paidAt: nextStatus === 'paid' ? new Date().toISOString() : null
 });
 } catch (err: any) {
 alert('ไม่สามารถอัปเดตสถานะบิลได้: ' + err.message);
 }
 };

 const handleEditSubmit = async (e: React.FormEvent) => {
 e.preventDefault();
 if (!targetBill) return;

 if (parseFloat(editCurrentElec) < parseFloat(editPriorElec)) {
 setFormError('แจ้งเตือน: มิเตอร์ไฟครั้งหลัง น้อยกว่ามิเตอร์ไฟครั้งก่อน กรุณาตรวจสอบความถูกต้อง');
 return;
 }
 if (parseFloat(editCurrentWater) < parseFloat(editPriorWater)) {
 setFormError('แจ้งเตือน: มิเตอร์น้ำครั้งหลัง น้อยกว่ามิเตอร์น้ำครั้งก่อน กรุณาตรวจสอบความถูกต้อง');
 return;
 }

 setSubmitting(true);
 setFormError(null);

 const billData = {
 billMonth: editMonth,
 priorElec: parseFloat(editPriorElec) || 0,
 currentElec: parseFloat(editCurrentElec) || 0,
 elecDeduct: parseFloat(editElecDeduct) || 0,
 elecUnitCost: parseFloat(editElecCostUnit) || 7,
 elecCost: finalElecCost,
 priorWater: parseFloat(editPriorWater) || 0,
 currentWater: parseFloat(editCurrentWater) || 0,
 waterUnitCost: parseFloat(editWaterCostUnit) || 13,
 waterCost: finalWaterCost,
 rentCost: parseInt(editRentCost) || 0,
 depositCost: parseInt(editDepositCost) || 0,
 otherCost: parseInt(editOtherCost) || 0,
 otherDescription: editOtherDescription,
 dueDate: editDueDate,
 status: editStatus,
 paidAt: editStatus === 'paid' ? (targetBill.paidAt || new Date().toISOString()) : null
 };

 try {
 await onUpdateBill(targetBill.id, billData);
 setIsEditModalOpen(false);
 } catch (err: any) {
 setFormError(err.message || 'เกิดข้อผิดพลาดในการแก้ไขบิล');
 } finally {
 setSubmitting(false);
 }
 };

 const handleDeleteBill = async () => {
 if (!targetBill) return;
 setSubmitting(true);
 try {
 await onDeleteBill(targetBill.id);
 setIsDeleteConfirmOpen(false);
 } catch (err: any) {
 alert('ไม่สามารถลบบิลพักได้: ' + err.message);
 } finally {
 setSubmitting(false);
 }
 };

 const handleSendBillLine = async (billId: number, roomNum: string) => {
 try {
 const res = await fetch(`/api/line/send-bill/${billId}`, {
 method: 'POST',
 headers: {
 'Authorization': `Bearer ${idToken}`
 }
 });
  const data = await res.json();
  if (res.ok) {
  alert(`ส่งบิลแจ้งหนี้ห้อง ${roomNum} เข้าไลน์สำเร็จเรียบร้อยแล้วค่ะ!`);
  } else {
  const errorMessage = typeof data.error === 'string'
    ? data.error
    : (data.error?.message || data.message || 'ไม่มีคู่สาย LINE ที่เชื่อมต่ออยู่กับห้องนี้');
  alert(`ไม่สามารถส่งบิลเข้าไลน์ได้: ${errorMessage}`);
 }
 } catch (err: any) {
 alert(`เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์: ${err.message}`);
 }
 };

 const [sendingOverdue, setSendingOverdue] = useState(false);

 const handleSendOverdueLINE = async () => {
 if (!confirm('คุณแน่ใจหรือไม่ที่จะส่งข้อความแจ้งเตือนบิลค้างชำระทั้งหมดที่เกินกำหนดเวลาเข้าแชท LINE ของผู้เช่าแต่ละห้อง?')) return;
 setSendingOverdue(true);
 try {
 const res = await fetch('/api/line/send-overdue', {
 method: 'POST',
 headers: {
 'Content-Type': 'application/json',
 'Authorization': `Bearer ${idToken}`
 }
 });
 const data = await res.json();
 if (res.ok) {
 alert(data.message || 'ส่งแจ้งเตือนสำเร็จแล้ว!');
 } else {
 alert(typeof data.error === 'string' ? data.error : (data.error?.message || data.message || 'เกิดข้อผิดพลาดในการส่งแจ้งเตือน'));
 }
 } catch (err: any) {
 alert('เชื่อมต่อเซิร์ฟเวอร์ล้มเหลว: ' + err.message);
 } finally {
 setSendingOverdue(false);
 }
 };

 const formatThaiMonth = (monthStr: string) => {
 const [year, month] = monthStr.split('-');
 const months = [
 'มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน',
 'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'
 ];
 return `${months[parseInt(month) - 1]} ${parseInt(year) + 543}`;
 };

 const formatThaiDate = (dateStr: string) => {
 if (!dateStr) return '';
 const [year, month, day] = dateStr.split('-');
 const monthsShort = [
 'ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.',
 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'
 ];
 return `${parseInt(day)} ${monthsShort[parseInt(month) - 1]} ${(parseInt(year) + 543).toString().substring(2)}`;
 };

 // Live total in Edit Form
 const liveElecUnits = Math.max(0, (parseFloat(editCurrentElec) || 0) - (parseFloat(editPriorElec) || 0) - (parseFloat(editElecDeduct) || 0));
 const calculatedElecCost = Math.round(liveElecUnits * (parseFloat(editElecCostUnit) || 7));
 const finalElecCost = isEditElecCostManual ? (parseFloat(editElecCost) || 0) : calculatedElecCost;

 useEffect(() => {
 if (!isEditElecCostManual) {
 setEditElecCost(calculatedElecCost.toString());
 }
 }, [calculatedElecCost, isEditElecCostManual]);

 const liveWaterUnits = Math.max(0, (parseFloat(editCurrentWater) || 0) - (parseFloat(editPriorWater) || 0));
 const calculatedWaterCost = liveWaterUnits > 0 ? Math.round(liveWaterUnits * (parseFloat(editWaterCostUnit) || 13)) : 0;
 const finalWaterCost = isEditWaterCostManual ? (parseFloat(editWaterCost) || 0) : calculatedWaterCost;

 useEffect(() => {
 if (!isEditWaterCostManual) {
 setEditWaterCost(calculatedWaterCost.toString());
 }
 }, [calculatedWaterCost, isEditWaterCostManual]);

 const liveGrandTotal = (parseInt(editRentCost) || 0) + finalElecCost + finalWaterCost + (parseInt(editDepositCost) || 0) + (parseInt(editOtherCost) || 0);

 const handleExportCSV = () => {
 if (filteredBills.length === 0) {
 alert('ไม่มีข้อมูลบิลที่จะส่งออก');
 return;
 }

 // Column Headers in Thai and English
 const headers = [
 'เลขห้อง (Room Number)',
 'ชื่อผู้เช่า (Tenant Name)',
 'เบอร์โทรศัพท์ (Phone Number)',
 'ประจำรอบเดือน (Billing Month)',
 'ค่าเช่าห้อง (Room Rent)',
 'เลขมิเตอร์ไฟครั้งก่อน (Prior Electricity Meter)',
 'เลขมิเตอร์ไฟครั้งหลัง (Current Electricity Meter)',
 'หน่วยหักล้างไฟฟ้า (Electricity Deduct Units)',
 'หน่วยไฟฟ้าที่ใช้ (Electricity Units Used)',
 'ราคาไฟฟ้าต่อหน่วย (Electricity Rate per Unit)',
 'รวมค่าไฟฟ้า (Electricity Cost)',
 'เลขมิเตอร์น้ำครั้งก่อน (Prior Water Meter)',
 'เลขมิเตอร์น้ำครั้งหลัง (Current Water Meter)',
 'หน่วยน้ำประปาที่ใช้ (Water Units Used)',
 'ราคาน้ำประปาต่อหน่วย (Water Rate per Unit)',
 'รวมค่าน้ำประปา (Water Cost)',
 'ค่าประกัน (Deposit)',
 'ค่าใช้จ่ายอื่น ๆ (Other Expense)',
 'คำอธิบายค่าใช้จ่ายอื่น ๆ (Other Expense Description)',
 'รายละเอียดรายการค่าบริการ (Charge Items)',
 'ยอดรวมสุทธิทั้งสิ้น (Grand Total)',
 'วันครบกำหนดชำระ (Due Date)',
 'สถานะการชำระเงิน (Payment Status)',
 'วันที่บันทึกชำระเงิน (Payment Date)'
 ];

 // Helper to escape values for CSV standard format
 const escapeCSVValue = (val: any) => {
 if (val === null || val === undefined) return '';
 let str = String(val);
 if (str.includes(',') || str.includes('"') || str.includes('\n') || str.includes('\r')) {
 str = '"' + str.replace(/"/g, '""') + '"';
 }
 return str;
 };

 // Construct CSV content
 const csvRows = [];
 csvRows.push(headers.join(','));

 filteredBills.forEach(bill => {
 const elecUnits = Math.max(0, bill.currentElec - bill.priorElec - (bill.elecDeduct ?? 0));
 const elecCost = Math.round(elecUnits * bill.elecUnitCost);
 const waterUnits = Math.max(0, bill.currentWater - bill.priorWater);
 const waterCost = bill.waterCost !== undefined ? bill.waterCost : (waterUnits > 0 ? Math.round(waterUnits * bill.waterUnitCost) : 0);

 const row = [
 escapeCSVValue(bill.roomNumber),
 escapeCSVValue(bill.tenantName || 'ไม่ระบุ'),
 escapeCSVValue(bill.tenantPhone || 'ไม่ระบุ'),
 escapeCSVValue(bill.billMonth),
 escapeCSVValue(bill.rentCost),
 escapeCSVValue(bill.priorElec),
 escapeCSVValue(bill.currentElec),
 escapeCSVValue(bill.elecDeduct ?? 0),
 escapeCSVValue(elecUnits),
 escapeCSVValue(bill.elecUnitCost),
 escapeCSVValue(elecCost),
 escapeCSVValue(bill.priorWater),
 escapeCSVValue(bill.currentWater),
 escapeCSVValue(waterUnits),
 escapeCSVValue(bill.waterUnitCost),
 escapeCSVValue(waterCost),
 escapeCSVValue(bill.depositCost),
 escapeCSVValue(bill.otherCost),
 escapeCSVValue(bill.otherDescription || ''),
 escapeCSVValue((bill.chargeItems || []).map((item) => `${item.label}: ${item.amount}`).join(' | ')),
 escapeCSVValue(bill.totalCost),
 escapeCSVValue(bill.dueDate),
 escapeCSVValue(bill.status === 'paid' ? 'ชำระแล้ว (Paid)' : 'ค้างชำระ (Unpaid)'),
 escapeCSVValue(bill.paidAt ? bill.paidAt.substring(0, 10) : '-')
 ];
 csvRows.push(row.join(','));
 });

 // Create file and download using UTF-8 BOM to prevent Thai garbled characters in Excel
 const csvContent = '\uFEFF' + csvRows.join('\n');
 const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
 const url = URL.createObjectURL(blob);
 
 const link = document.createElement('a');
 link.setAttribute('href', url);
 
 let filename = 'dorm_billing_records';
 if (selectedMonth) {
 filename += `_${selectedMonth}`;
 }
 if (selectedStatus) {
 filename += `_${selectedStatus}`;
 }
 filename += '.csv';
 
 link.setAttribute('download', filename);
 link.style.visibility = 'hidden';
 document.body.appendChild(link);
 link.click();
 document.body.removeChild(link);
 };

  // Export to Google Sheet (API Integration - New Sheet)
  const handleExportGoogleSheet = async () => {
    if (!settings?.googleSpreadsheetId) {
      alert('กรุณาตั้งค่า Google Spreadsheet ID ในหน้าการตั้งค่าก่อนครับ');
      return;
    }

    try {
      setExportingSheet(true);
      const headers = [
        'เลขห้อง (Room Number)',
        'ชื่อผู้เช่า (Tenant Name)',
        'เบอร์โทรศัพท์ (Tenant Phone)',
        'รอบเดือน (Bill Month)',
        'ค่าเช่าบ้าน (Rent Cost)',
        'เลขมิเตอร์ไฟรอบก่อน (Prior Elec)',
        'เลขมิเตอร์ไฟรอบปัจจุบัน (Current Elec)',
        'หักลดหน่วยไฟ (Elec Deduct)',
        'หน่วยไฟที่ใช้ (Elec Units)',
        'หน่วยละ (Elec Unit Cost)',
        'รวมค่าไฟ (Elec Total Cost)',
        'เลขมิเตอร์น้ำรอบก่อน (Prior Water)',
        'เลขมิเตอร์น้ำรอบปัจจุบัน (Current Water)',
        'หน่วยน้ำที่ใช้ (Water Units)',
        'หน่วยละ (Water Unit Cost)',
        'รวมค่าน้ำ (Water Total Cost)',
        'เงินประกัน (Deposit)',
        'ค่าใช้จ่ายอื่น ๆ (Other Expense)',
        'คำอธิบายค่าใช้จ่ายอื่น ๆ (Other Expense Description)',
        'รายละเอียดรายการค่าบริการ (Charge Items)',
        'ยอดรวมสุทธิทั้งสิ้น (Grand Total)',
        'วันครบกำหนดชำระ (Due Date)',
        'สถานะการชำระเงิน (Payment Status)',
        'วันที่บันทึกชำระเงิน (Payment Date)'
      ];

      const escapeAPIValue = (val) => {
        if (val === null || val === undefined) return '';
        return String(val);
      };

      const rowsData = filteredBills.map(bill => {
        const elecUnits = Math.max(0, bill.currentElec - bill.priorElec - (bill.elecDeduct ?? 0));
        const elecCost = Math.round(elecUnits * bill.elecUnitCost);
        const waterUnits = Math.max(0, bill.currentWater - bill.priorWater);
        const waterCost = bill.waterCost !== undefined ? bill.waterCost : (waterUnits > 0 ? Math.round(waterUnits * bill.waterUnitCost) : 0);

        return [
          escapeAPIValue(bill.roomNumber),
          escapeAPIValue(bill.tenantName || 'ไม่ระบุ'),
          escapeAPIValue(bill.tenantPhone || 'ไม่ระบุ'),
          escapeAPIValue(bill.billMonth),
          escapeAPIValue(bill.rentCost),
          escapeAPIValue(bill.priorElec),
          escapeAPIValue(bill.currentElec),
          escapeAPIValue(bill.elecDeduct ?? 0),
          escapeAPIValue(elecUnits),
          escapeAPIValue(bill.elecUnitCost),
          escapeAPIValue(elecCost),
          escapeAPIValue(bill.priorWater),
          escapeAPIValue(bill.currentWater),
          escapeAPIValue(waterUnits),
          escapeAPIValue(bill.waterUnitCost),
          escapeAPIValue(waterCost),
          escapeAPIValue(bill.depositCost),
          escapeAPIValue(bill.otherCost),
          escapeAPIValue(bill.otherDescription || ''),
          escapeAPIValue((bill.chargeItems || []).map((item) => `${item.label}: ${item.amount}`).join(' | ')),
          escapeAPIValue(bill.totalCost),
          escapeAPIValue(bill.dueDate),
          escapeAPIValue(bill.status === 'paid' ? 'ชำระแล้ว (Paid)' : 'ค้างชำระ (Unpaid)'),
          escapeAPIValue(bill.paidAt ? bill.paidAt.substring(0, 10) : '-')
        ];
      });

      // 1. Get access token
      const tokenRes = await fetch('/api/google-sheets/token', {
        headers: { 'Authorization': `Bearer ${idToken}` }
      });
      if (!tokenRes.ok) {
        const err = await tokenRes.json().catch(() => ({}));
        throw new Error(err.error?.message || 'ไม่สามารถดึงข้อมูล Token ได้ กรุณาเชื่อมต่อบัญชี Google ใหม่อีกครั้งในการตั้งค่า');
      }
      const tokenData = await tokenRes.json();
      const accessToken = tokenData.data.accessToken;
      const spreadsheetId = settings.googleSpreadsheetId;
      
      const monthLabel = selectedMonth || 'All';
      const sheetTitle = `History_${monthLabel}_${Date.now().toString().slice(-4)}`;

      // 2. Create new sheet
      const batchUpdateRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}:batchUpdate`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          requests: [{ addSheet: { properties: { title: sheetTitle } } }]
        })
      });

      if (!batchUpdateRes.ok) {
        const err = await batchUpdateRes.json().catch(() => ({}));
        throw new Error(err.error?.message || 'ไม่สามารถสร้างแผ่นงานใหม่ใน Google Sheet ได้');
      }

      // 3. Append data
      const appendRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(sheetTitle)}!A1:append?valueInputOption=USER_ENTERED`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ values: [headers, ...rowsData] })
      });

      if (!appendRes.ok) {
        const err = await appendRes.json().catch(() => ({}));
        throw new Error(err.error?.message || 'ไม่สามารถเพิ่มข้อมูลลงในแผ่นงานได้');
      }

      alert('ส่งออกข้อมูลไปยัง Google Sheet สำเร็จแล้วครับ!');
      window.open(`https://docs.google.com/spreadsheets/d/${spreadsheetId}`, '_blank');
    } catch (err) {
      console.error('Export error:', err);
      alert('เกิดข้อผิดพลาด: ' + (err.message || String(err)));
    } finally {
      setExportingSheet(false);
    }
  };

 return (
 <div className="space-y-6 font-sans">
 
 {/* Header Panel */}
 <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
 <div>
 <h2 className="text-xl font-bold text-[#1A1A1A] flex items-center gap-2">
 <FileText className="w-5 h-5 text-[#1DB954]" />
 <span>ประวัติบิลเรียกเก็บเงิน</span>
 </h2>
 <p className="text-xs text-[#8A8A85] mt-1">
 ค้นหา ตรวจสอบรายละเอียด พิมพ์บิล รวมถึงแก้ไขข้อมูลย้อนหลัง และลบบิลที่ไม่ถูกต้องออกจากฐานข้อมูล
 </p>
 </div>
 
 <div className="flex flex-wrap items-center gap-2">
 <button
 onClick={handleSendOverdueLINE}
 disabled={sendingOverdue}
 className="flex items-center justify-center gap-1.5 px-4 py-2.5 text-xs font-bold text-[#1A1A1A] bg-rose-600 hover:bg-rose-700 disabled:opacity-50 rounded-xl transition cursor-pointer "
 >
 {sendingOverdue ? (
 <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
 ) : (
 <AlertTriangle className="w-4 h-4" />
 )}
 <span>แจ้งเตือนค้างชำระทั้งหมดเข้า LINE</span>
 </button>

  <button
  onClick={handleExportGoogleSheet}
  className="flex items-center justify-center gap-1.5 px-4 py-2.5 text-xs font-semibold text-[#6B6B66] bg-white border border-[#E0E0DB] rounded-xl hover:bg-[#E8E8E3] hover:text-slate-900 transition cursor-pointer self-start sm:self-auto"
  title="คัดลอกข้อมูลและเปิดหน้าต่าง Google Sheet ใหม่"
  >
  <FileSpreadsheet className="w-4 h-4 text-[#1DB954]" />
  <span>ส่งออกไป Google Sheet</span>
  </button>

 <button
 onClick={handleExportCSV}
 className="flex items-center justify-center gap-1.5 px-4 py-2.5 text-xs font-semibold text-[#6B6B66] bg-white border border-[#E0E0DB] rounded-xl hover:bg-[#E8E8E3] hover:text-slate-900 transition cursor-pointer self-start sm:self-auto"
 >
 <Download className="w-4 h-4 text-[#8A8A85]" />
 <span>ส่งออกเป็น CSV (Export CSV)</span>
 </button>
 </div>
 </div>

 {(() => {
 const pendingSlipBills = (bills || []).filter(b => b && b.slipStatus === 'pending');
 if (pendingSlipBills.length === 0) return null;
 return (
 <div className="p-4 bg-[#F59B23]/8 border border-amber-200 rounded-2xl text-xs space-y-3 ">
 <div className="flex items-center gap-2.5">
 <Coins className="w-5 h-5 text-[#F59B23] animate-pulse flex-shrink-0" />
 <div>
 <p className="font-extrabold text-amber-900">มีสลิปโอนเงินรอตรวจสอบ ({pendingSlipBills.length} รายการ) 🧾</p>
 <p className="text-[11px] text-[#8A8A85]">กรุณาตรวจสอบความถูกต้องของสลิปเพื่อยืนยันการชำระเงินของห้องพักเหล่านี้</p>
 </div>
 </div>
 <div className="flex flex-wrap gap-2">
 {pendingSlipBills.map(bill => (
 <button
 key={bill.id}
 type="button"
 onClick={() => setSelectedSlipBill(bill)}
 className="py-1.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-[#1A1A1A] font-bold text-xxs transition cursor-pointer flex items-center gap-1"
 >
 <span>ห้อง {bill.roomNumber} (ยอด {bill.totalCost.toLocaleString()} บ.)</span>
 </button>
 ))}
 </div>
 </div>
 );
 })()}

 {/* Search & Filter Bar */}
 <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-white border border-[#E0E0DB] rounded-2xl p-4 ">
 
 {/* Search */}
 <div className="relative">
 <Search className="absolute left-3 top-2.5 h-4 w-4 text-[#8A8A85]" />
 <input
 type="text"
 placeholder="ค้นหาเลขห้อง หรือผู้เช่า..."
 value={searchTerm}
 onChange={(e) => setSearchTerm(e.target.value)}
 className="w-full bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl py-2 pl-9 pr-4 text-xs text-[#1A1A1A] placeholder-slate-400 focus:outline-none focus:bg-white focus:border-[#1DB954] transition"
 />
 </div>

 {/* Filter Month */}
 <div className="relative">
 <input
 type="month"
 value={selectedMonth}
 onChange={(e) => setSelectedMonth(e.target.value)}
 className="w-full bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl py-2 px-3 text-xs text-[#1A1A1A] focus:outline-none focus:bg-white focus:border-[#1DB954] transition cursor-pointer"
 />
 </div>

 {/* Filter Status */}
 <div>
 <select
 value={selectedStatus}
 onChange={(e) => setSelectedStatus(e.target.value)}
 className="w-full bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl py-2 px-3 text-xs text-[#1A1A1A] focus:outline-none focus:bg-white focus:border-[#1DB954] transition cursor-pointer"
 >
 <option value="">-- สถานะการชำระเงิน --</option>
 <option value="unpaid">ค้างชำระ (Unpaid)</option>
 <option value="paid">ชำระเงินแล้ว (Paid)</option>
 </select>
 </div>

 </div>

 {loading && bills.length === 0 ? (
 <div className="flex justify-center items-center py-20 text-[#8A8A85]">
 <RefreshCw className="w-6 h-6 animate-spin text-[#1DB954] mr-2" />
 <span className="text-sm font-medium">กำลังโหลดประวัติบิลพัก...</span>
 </div>
 ) : filteredBills.length === 0 ? (
 <div className="text-center py-20 bg-white rounded-2xl border border-dashed border-[#E0E0DB]">
 <FileText className="w-12 h-12 text-[#8A8A85] mx-auto mb-3" />
 <p className="text-sm font-medium text-[#8A8A85]">ไม่พบบิลตามเงื่อนไขการค้นหา/ฟิลเตอร์</p>
 </div>
 ) : (
 /* Bills List Desktop Table / Mobile Card */
 <div className="bg-white border border-[#E0E0DB] rounded-2xl overflow-hidden">
 
 {/* Table for Desktop */}
 <div className="hidden md:block overflow-x-auto">
 <table className="w-full text-left text-xs border-collapse">
 <thead>
 <tr className="bg-[#F0F0EB] border-b border-[#E0E0DB] text-[#8A8A85] font-bold uppercase tracking-wider">
 <th className="py-3 px-4">เลขห้อง</th>
 <th className="py-3 px-4">ประจำรอบเดือน</th>
 <th className="py-3 px-4">ชื่อผู้เช่า</th>
 <th className="py-3 px-4 text-right">ยอดรวม</th>
 <th className="py-3 px-4">วันครบกำหนด</th>
 <th className="py-3 px-4 text-center">สถานะ</th>
 <th className="py-3 px-4 text-right">เครื่องมือ</th>
 </tr>
 </thead>
 <tbody className="divide-y divide-slate-100 text-[#6B6B66]">
 {filteredBills.map((bill) => (
 <tr key={bill.id} className="hover:bg-[#E8E8E3] transition">
 <td className="py-3.5 px-4 font-extrabold text-[#1A1A1A]">ห้อง {bill.roomNumber}</td>
 <td className="py-3.5 px-4 font-medium">{formatThaiMonth(bill.billMonth)}</td>
 <td className="py-3.5 px-4 text-[#8A8A85] font-medium">{bill.tenantName || 'ไม่ระบุ'}</td>
 <td className="py-3.5 px-4 text-right font-bold text-[#1A1A1A]">{bill.totalCost.toLocaleString()} บ.</td>
 <td className="py-3.5 px-4 font-medium text-[#8A8A85]">{formatThaiDate(bill.dueDate)}</td>
 <td className="py-3.5 px-4 text-center">
 {bill.slipStatus === 'pending' ? (
 <button
 type="button"
 onClick={() => setSelectedSlipBill(bill)}
 className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold border border-amber-200 bg-[#F59B23]/8 text-amber-700 cursor-pointer animate-pulse hover:bg-amber-100 transition"
 title="คลิกตรวจเช็คสลิปโอนเงิน"
 >
 <Coins className="w-3.5 h-3.5 text-[#F59B23]" />
 <span>ตรวจสลิป</span>
 </button>
 ) : (
 <button
 onClick={() => handleToggleStatus(bill)}
 disabled={!canEditPayments}
 className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold border transition ${
 !canEditPayments ? 'opacity-80 cursor-default' : 'cursor-pointer'
 } ${
 bill.status === 'paid'
 ? 'bg-[#1DB954]/8 border-[#1DB954]/30 text-[#1DB954] '
 : 'bg-[#E22134]/8 border-[#E22134]/30 text-[#E22134] '
 }`}
 title={canEditPayments ? "คลิกสลับสถานะ" : "ค้างจ่าย (ไม่มีสิทธิ์แก้ไข)"}
 >
 {bill.status === 'paid' ? (
 <>
 <CheckCircle className="w-3.5 h-3.5" />
 <span>ชำระแล้ว</span>
 </>
 ) : (
 <>
 <Clock className="w-3.5 h-3.5" />
 <span>ค้างจ่าย</span>
 </>
 )}
 </button>
 )}
 </td>
 <td className="py-3.5 px-4 text-right space-x-1 font-semibold">
 <button
 onClick={() => onViewBillDetails(bill)}
 className="p-1.5 rounded-lg bg-[#F0F0EB] hover:bg-[#E8E8E3] text-[#6B6B66] hover:text-slate-900 transition inline-flex items-center cursor-pointer"
 title="เปิดดูบิลเรียกเก็บเงิน"
 >
 <Eye className="w-3.5 h-3.5" />
 </button>
 <button
 onClick={() => handleSendBillLine(bill.id, bill.roomNumber)}
 className="p-1.5 rounded-lg bg-[#1DB954]/8 hover:bg-emerald-100 text-[#1DB954] transition inline-flex items-center cursor-pointer"
 title="ส่งบิลแจ้งหนี้เข้าแชท LINE"
 >
 <MessageSquare className="w-3.5 h-3.5" />
 </button>
 {canEditBills && (
 <button
 onClick={() => openEditModal(bill)}
 className="p-1.5 rounded-lg bg-[#F0F0EB] hover:bg-[#E8E8E3] text-[#6B6B66] hover:text-slate-900 transition inline-flex items-center cursor-pointer"
 title="แก้ไขมิเตอร์/ยอดเงิน"
 >
 <Edit className="w-3.5 h-3.5" />
 </button>
 )}
 {canEditBills && (
 <button
 onClick={() => openDeleteConfirm(bill)}
 className="p-1.5 rounded-lg bg-red-50 hover:bg-red-100 text-red-600 transition inline-flex items-center cursor-pointer"
 title="ลบบิล"
 >
 <Trash2 className="w-3.5 h-3.5" />
 </button>
 )}
 </td>
 </tr>
 ))}
 </tbody>
 </table>
 </div>

 {/* Cards for Mobile Devices */}
 <div className="block md:hidden divide-y divide-slate-100 text-xs">
 {filteredBills.map((bill) => (
 <div key={bill.id} className="p-4 space-y-3.5 hover:bg-[#282828]/40">
 <div className="flex justify-between items-start">
 <div>
 <h4 className="font-extrabold text-[#1A1A1A] text-sm">ห้อง {bill.roomNumber}</h4>
 <p className="text-xxs text-[#8A8A85] mt-0.5">{formatThaiMonth(bill.billMonth)}</p>
 </div>
 <button
 onClick={() => handleToggleStatus(bill)}
 disabled={!canEditPayments}
 className={`px-3 py-1 rounded-full text-[10px] font-bold border transition ${
 !canEditPayments ? 'opacity-80 cursor-default' : 'cursor-pointer'
 } ${
 bill.status === 'paid'
 ? 'bg-[#1DB954]/8 border-[#1DB954]/30 text-[#1DB954] '
 : 'bg-[#E22134]/8 border-[#E22134]/30 text-[#E22134] '
 }`}
 >
 {bill.status === 'paid' ? 'ชำระแล้ว' : 'ค้างจ่าย'}
 </button>
 </div>

 <div className="grid grid-cols-2 gap-2 text-xxs text-[#8A8A85]">
 <p>ผู้เช่า: <span className="font-bold text-[#1A1A1A]">{bill.tenantName || 'ไม่ระบุ'}</span></p>
 <p className="text-right">วันครบกำหนด: <span className="font-bold text-[#1A1A1A]">{formatThaiDate(bill.dueDate)}</span></p>
 <p className="col-span-2 text-[#6B6B66] mt-1 font-semibold">ยอดรวมทั้งสิ้น: <span className="text-[#1DB954] font-black text-sm">{bill.totalCost.toLocaleString()} บาท</span></p>
 </div>

 <div className="flex gap-2 pt-2 border-t border-[#E0E0DB]">
 <button
 onClick={() => onViewBillDetails(bill)}
 className="flex-1 py-1.5 bg-[#F0F0EB] rounded-lg text-[#6B6B66] flex items-center justify-center gap-1 hover:text-slate-900 cursor-pointer text-xxs font-bold"
 >
 <Eye className="w-3.5 h-3.5" />
 <span>เปิดบิล</span>
 </button>
 <button
 onClick={() => handleSendBillLine(bill.id, bill.roomNumber)}
 className="py-1.5 px-3 bg-[#1DB954]/8 rounded-full text-[#1DB954] hover:bg-emerald-100/50 flex items-center justify-center gap-1 transition cursor-pointer text-xxs font-bold"
 title="ส่งบิลเข้า LINE"
 >
 <MessageSquare className="w-3.5 h-3.5" />
 <span>ส่งไลน์</span>
 </button>
 {canEditBills && (
 <button
 onClick={() => openEditModal(bill)}
 className="py-1.5 px-3 bg-[#F0F0EB] rounded-lg text-[#6B6B66] hover:text-slate-900 cursor-pointer text-xxs font-bold"
 title="แก้ไข"
 >
 <Edit className="w-3.5 h-3.5" />
 <span>แก้ไข</span>
 </button>
 )}
 {canEditBills && (
 <button
 onClick={() => openDeleteConfirm(bill)}
 className="py-1.5 px-3 bg-red-50 rounded-lg text-red-600 hover:bg-red-100 cursor-pointer text-xxs font-bold"
 title="ลบ"
 >
 <Trash2 className="w-3.5 h-3.5" />
 <span>ลบ</span>
 </button>
 )}
 </div>
 </div>
 ))}
 </div>

 </div>
 )}

 {/* Edit Bill Dialog Modal */}
 <AnimatePresence>
 {isEditModalOpen && targetBill && (
 <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto font-sans">
 <motion.div 
 initial={{ opacity: 0, scale: 0.95 }}
 animate={{ opacity: 1, scale: 1 }}
 exit={{ opacity: 0, scale: 0.95 }}
 className="bg-white border border-[#E0E0DB] rounded-2xl max-w-xl w-full overflow-hidden shadow-xl my-8"
 >
 <div className="p-4 border-b border-[#E0E0DB] flex justify-between items-center bg-[#F0F0EB]">
 <h3 className="font-bold text-[#1A1A1A] text-xs sm:text-sm">
 แก้ไขและคำนวณใหม่ บิลห้อง {targetBill.roomNumber}
 </h3>
 <button onClick={() => setIsEditModalOpen(false)} className="text-[#8A8A85] hover:text-slate-600 cursor-pointer">
 <X className="w-5 h-5" />
 </button>
 </div>

 <form onSubmit={handleEditSubmit} className="p-5 space-y-4 text-xs">
 {formError && (
 <div className="p-3 bg-red-50 border border-red-100 text-red-600 rounded-lg font-bold">
 {formError}
 </div>
 )}

 <div className="grid grid-cols-2 gap-3">
 <div>
 <label className="block text-[#8A8A85] font-bold mb-1">รอบเดือนประจำบิล</label>
 <input
 type="month"
 value={editMonth}
 onChange={(e) => setEditMonth(e.target.value)}
 className="w-full bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl p-2.5 text-[#1A1A1A] focus:outline-none focus:bg-white focus:border-[#1DB954] transition"
 />
 </div>
 <div>
 <label className="block text-[#8A8A85] font-bold mb-1">กำหนดจ่ายล่าช้าได้ถึง</label>
 <input
 type="date"
 value={editDueDate}
 onChange={(e) => setEditDueDate(e.target.value)}
 className="w-full bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl p-2.5 text-[#1A1A1A] focus:outline-none focus:bg-white focus:border-[#1DB954] transition"
 />
 </div>
 </div>

 {/* Electricity section */}
 <div className="p-3.5 bg-[#F0F0EB] rounded-xl border border-[#E0E0DB] space-y-2">
 <h4 className="text-xxs font-bold text-[#F59B23] uppercase tracking-wider flex items-center gap-1">
 <Coins className="w-3.5 h-3.5 text-[#F59B23]" /> ค่าไฟฟ้า
 </h4>
 <div className="grid grid-cols-5 gap-1.5">
 <div>
 <label className="block text-[#8A8A85] text-[9px] mb-1">ก่อน (Prior)</label>
 <input
 type="number"
 step="any"
 value={editPriorElec}
 onChange={(e) => setEditPriorElec(e.target.value)}
 className="w-full bg-white border border-[#E0E0DB] rounded-lg p-2 text-xs text-[#1A1A1A] focus:outline-none focus:border-amber-500 transition"
 />
 </div>
 <div>
 <label className="block text-[#8A8A85] text-[9px] mb-1">หลัง (Current)</label>
 <input
 type="number"
 step="any"
 value={editCurrentElec}
 onChange={(e) => setEditCurrentElec(e.target.value)}
 className="w-full bg-white border border-[#E0E0DB] rounded-lg p-2 text-xs text-[#1A1A1A] focus:outline-none focus:border-amber-500 transition"
 />
 </div>
 <div>
 <label className="block text-[#8A8A85] text-[9px] mb-1">หักล้าง (Deduct)</label>
 <input
 type="number"
 step="any"
 value={editElecDeduct}
 onChange={(e) => setEditElecDeduct(e.target.value)}
 className="w-full bg-white border border-[#E0E0DB] rounded-lg p-2 text-xs text-[#1A1A1A] focus:outline-none focus:border-amber-500 transition"
 />
 </div>
 <div>
 <div className="flex justify-between items-center mb-1">
 <label className="block text-[#8A8A85] text-[9px]">ค่าไฟ (฿)</label>
 {isEditElecCostManual && (
 <button
 type="button"
 onClick={() => setIsEditElecCostManual(false)}
 className="text-[7.5px] text-[#F59B23] hover:underline font-bold"
 >
 ออโต้
 </button>
 )}
 </div>
 <input
 type="number"
 step="any"
 value={editElecCost}
 onChange={(e) => {
 setIsEditElecCostManual(true);
 setEditElecCost(e.target.value);
 }}
 className={`w-full bg-white border rounded-lg p-2 text-xs text-[#1A1A1A] focus:outline-none focus:border-amber-500 transition ${isEditElecCostManual ? 'border-amber-400 focus:border-amber-500 font-bold' : 'border-[#E0E0DB]'}`}
 />
 </div>
 <div>
 <label className="block text-[#8A8A85] text-[9px] mb-1">หน่วยละ (Rate)</label>
 <input
 type="number"
 step="any"
 value={editElecCostUnit}
 onChange={(e) => setEditElecCostUnit(e.target.value)}
 className="w-full bg-white border border-[#E0E0DB] rounded-lg p-2 text-xs text-[#1A1A1A] focus:outline-none focus:border-amber-500 transition"
 />
 </div>
 </div>
 <p className="text-[10px] text-[#F59B23] font-bold text-right">
 สุทธิ: {liveElecUnits} หน่วย{(parseFloat(editElecDeduct) || 0) > 0 && ` (หักล้าง ${editElecDeduct} หน่วย)`} = {finalElecCost.toLocaleString()} บาท {isEditElecCostManual && '(กำหนดเอง)'}
 </p>
 </div>

 {/* Water section */}
 <div className="p-3.5 bg-[#F0F0EB] rounded-xl border border-[#E0E0DB] space-y-2">
 <h4 className="text-xxs font-bold text-[#1DB954] uppercase tracking-wider flex items-center gap-1">
 <Coins className="w-3.5 h-3.5 text-[#1DB954]" /> ค่าน้ำ
 </h4>
 <div className="grid grid-cols-4 gap-1.5">
 <div>
 <label className="block text-[#8A8A85] text-[9px] mb-1">ก่อน (Prior)</label>
 <input
 type="number"
 step="any"
 value={editPriorWater}
 onChange={(e) => setEditPriorWater(e.target.value)}
 className="w-full bg-white border border-[#E0E0DB] rounded-lg p-2 text-xs text-[#1A1A1A] focus:outline-none focus:border-[#1DB954] transition"
 />
 </div>
 <div>
 <label className="block text-[#8A8A85] text-[9px] mb-1">หลัง (Current)</label>
 <input
 type="number"
 step="any"
 value={editCurrentWater}
 onChange={(e) => setEditCurrentWater(e.target.value)}
 className="w-full bg-white border border-[#E0E0DB] rounded-lg p-2 text-xs text-[#1A1A1A] focus:outline-none focus:border-[#1DB954] transition"
 />
 </div>
 <div>
 <div className="flex justify-between items-center mb-1">
 <label className="block text-[#8A8A85] text-[9px]">ค่าน้ำ (฿)</label>
 {isEditWaterCostManual && (
 <button
 type="button"
 onClick={() => setIsEditWaterCostManual(false)}
 className="text-[7.5px] text-[#1DB954] hover:underline font-bold"
 >
 ออโต้
 </button>
 )}
 </div>
 <input
 type="number"
 step="any"
 value={editWaterCost}
 onChange={(e) => {
 setIsEditWaterCostManual(true);
 setEditWaterCost(e.target.value);
 }}
 className={`w-full bg-white border rounded-lg p-2 text-xs text-[#1A1A1A] focus:outline-none focus:border-[#1DB954] transition ${isEditWaterCostManual ? 'border-amber-400 focus:border-amber-500 font-bold' : 'border-[#E0E0DB]'}`}
 />
 </div>
 <div>
 <label className="block text-[#8A8A85] text-[9px] mb-1">หน่วยละ (Rate)</label>
 <input
 type="number"
 step="any"
 value={editWaterCostUnit}
 onChange={(e) => setEditWaterCostUnit(e.target.value)}
 className="w-full bg-white border border-[#E0E0DB] rounded-lg p-2 text-xs text-[#1A1A1A] focus:outline-none focus:border-[#1DB954] transition"
 />
 </div>
 </div>
 <p className="text-[10px] text-[#1DB954] font-bold text-right">
 สุทธิ: {liveWaterUnits} หน่วย = {finalWaterCost.toLocaleString()} บาท {isEditWaterCostManual && '(กำหนดเอง)'}
 </p>
 </div>

 {/* Extra charges */}
 <div className="grid grid-cols-3 gap-2">
 <div>
 <label className="block text-[#8A8A85] font-bold mb-1 text-[10px]">ค่าเช่าห้องพัก</label>
 <input
 type="number"
 value={editRentCost}
 onChange={(e) => setEditRentCost(e.target.value)}
 className="w-full bg-[#F0F0EB] border border-[#E0E0DB] rounded-lg p-2 text-[#1A1A1A] focus:outline-none focus:border-[#1DB954] transition"
 />
 </div>
 <div>
 <label className="block text-[#8A8A85] font-bold mb-1 text-[10px]">ค่าประกัน</label>
 <input
 type="number"
 value={editDepositCost}
 onChange={(e) => setEditDepositCost(e.target.value)}
 className="w-full bg-[#F0F0EB] border border-[#E0E0DB] rounded-lg p-2 text-[#1A1A1A] focus:outline-none focus:border-[#1DB954] transition"
 />
 </div>
 <div>
 <label className="block text-[#8A8A85] font-bold mb-1 text-[10px]">ค่าใช้จ่ายอื่น ๆ</label>
 <input
 type="number"
 value={editOtherCost}
 onChange={(e) => setEditOtherCost(e.target.value)}
 className="w-full bg-[#F0F0EB] border border-[#E0E0DB] rounded-lg p-2 text-[#1A1A1A] focus:outline-none focus:border-[#1DB954] transition"
 />
 </div>
 </div>

 <div>
 <label className="block text-[#8A8A85] font-bold mb-1 text-[10px]">คำอธิบายเพิ่มเติมเกี่ยวกับค่าอื่น ๆ</label>
 <input
 type="text"
 placeholder="เช่น ค่าส่วนกลาง, ค่าคีย์การ์ด"
 value={editOtherDescription}
 onChange={(e) => setEditOtherDescription(e.target.value)}
 className="w-full bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl p-2.5 text-[#1A1A1A] focus:outline-none focus:bg-white focus:border-[#1DB954] transition"
 />
 </div>

 <div className="pt-3 border-t border-[#E0E0DB] flex items-center justify-between">
 <div>
 <p className="text-[10px] text-[#8A8A85] font-bold">ยอดเงินคำนวณใหม่สุทธิ</p>
 <p className="text-lg font-black text-[#1DB954]">{liveGrandTotal.toLocaleString()} บาท</p>
 </div>
 
 <div className="flex items-center gap-2">
 <select
 value={editStatus}
 onChange={(e) => setEditStatus(e.target.value as 'unpaid' | 'paid')}
 className="bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl p-2 text-[#6B6B66] text-xs focus:outline-none cursor-pointer"
 >
 <option value="unpaid">ค้างชำระ</option>
 <option value="paid">ชำระเงินแล้ว</option>
 </select>
 <button
 type="submit"
 disabled={submitting}
 className="py-2 px-4 rounded-xl bg-[#1DB954] hover:bg-[#1ED760] hover:scale-[1.04] text-white font-bold transition cursor-pointer"
 >
 {submitting ? 'กำลังบันทึก...' : 'คำนวณและบันทึก'}
 </button>
 </div>
 </div>
 </form>
 </motion.div>
 </div>
 )}
 </AnimatePresence>

 {/* Delete Confirmation Modal */}
 <AnimatePresence>
 {isDeleteConfirmOpen && targetBill && (
 <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 font-sans">
 <motion.div 
 initial={{ opacity: 0, scale: 0.95 }}
 animate={{ opacity: 1, scale: 1 }}
 exit={{ opacity: 0, scale: 0.95 }}
 className="bg-white border border-[#E0E0DB] rounded-2xl max-w-sm w-full p-5 shadow-xl"
 >
 <div className="text-center">
 <div className="inline-flex p-3 bg-red-50 text-red-600 rounded-full mb-3">
 <AlertTriangle className="w-6 h-6" />
 </div>
 <h3 className="text-sm font-bold text-[#1A1A1A]">ลบบิลเรียกเก็บเงิน?</h3>
 <p className="text-xxs text-[#8A8A85] mt-2 leading-relaxed">
 คุณแน่ใจหรือไม่ว่าต้องการทำการลบประวัติบิลเรียกเก็บเงินของห้อง <strong className="text-[#1A1A1A]">ห้อง {targetBill.roomNumber}</strong> รอบประจำเดือน <strong className="text-[#1A1A1A]">{formatThaiMonth(targetBill.billMonth)}</strong> ยอดเงินสุทธิ <strong className="text-[#1A1A1A]">{targetBill.totalCost.toLocaleString()} บาท</strong>? การกระทำนี้ไม่สามารถยกเลิกได้
 </p>
 </div>

 <div className="mt-5 grid grid-cols-2 gap-3 text-xs">
 <button
 onClick={() => setIsDeleteConfirmOpen(false)}
 className="py-2.5 rounded-xl bg-[#F0F0EB] hover:bg-[#E8E8E3] text-[#6B6B66] font-bold border border-[#E0E0DB] transition cursor-pointer"
 >
 ยกเลิก
 </button>
 <button
 onClick={handleDeleteBill}
 disabled={submitting}
 className="py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-[#1A1A1A] font-bold transition cursor-pointer"
 >
 {submitting ? 'กำลังลบ...' : 'ยืนยันลบถาวร'}
 </button>
 </div>
 </motion.div>
 </div>
 )}
 </AnimatePresence>

 {/* Slip Verification Modal */}
 <AnimatePresence>
 {selectedSlipBill && (
 <div className="fixed inset-0 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 z-50 font-sans text-[#1A1A1A]">
 <motion.div
 initial={{ opacity: 0, scale: 0.95 }}
 animate={{ opacity: 1, scale: 1 }}
 exit={{ opacity: 0, scale: 0.95 }}
 className="bg-white rounded-3xl max-w-sm w-full p-5 shadow-2xl relative space-y-4 border border-[#E0E0DB]"
 >
 <div className="flex justify-between items-center border-b border-[#E0E0DB] pb-2">
 <div>
 <h3 className="font-extrabold text-sm text-slate-950">ตรวจสอบสลิปโอนเงิน</h3>
 <p className="text-xxs text-[#8A8A85]">ห้อง {selectedSlipBill.roomNumber} | ประจำเดือน {formatThaiMonth(selectedSlipBill.billMonth)}</p>
 </div>
 <button
 onClick={() => setSelectedSlipBill(null)}
 className="p-1 rounded-lg hover:bg-[#E8E8E3] text-[#8A8A85] hover:text-slate-600 transition cursor-pointer"
 >
 <X className="w-4 h-4" />
 </button>
 </div>

 {/* Base64 Slip Image Preview */}
 <div className="bg-[#F0F0EB] rounded-2xl overflow-hidden aspect-[3/4] flex items-center justify-center relative border border-[#E0E0DB] shadow-inner">
 {selectedSlipBill.slipImage ? (
 <img
 src={selectedSlipBill.slipImage}
 alt="Transfer Slip"
 className="w-full h-full object-contain"
 />
 ) : (
 <div className="text-center p-4 text-[#8A8A85] space-y-2">
 <AlertTriangle className="w-8 h-8 text-[#8A8A85] mx-auto" />
 <p className="text-xxs">ไม่พบภาพสลิปในฐานข้อมูล</p>
 </div>
 )}
 </div>

 <div className="p-3 bg-[#1DB954]/10/75 rounded-xl border border-blue-100 text-xxs text-blue-800 flex justify-between">
 <span className="font-semibold text-[#6B6B66]">ยอดเงินที่เรียกเก็บ:</span>
 <span className="font-extrabold text-blue-700">{selectedSlipBill.totalCost.toLocaleString()} บาท</span>
 </div>

 {/* Actions row */}
 <div className="grid grid-cols-2 gap-3 pt-1">
 <button
 type="button"
 onClick={async () => {
 if (!confirm('คุณต้องการปฏิเสธสลิปโอนเงินนี้ใช่หรือไม่? บิลจะกลับมาแสดงสถานะค้างชำระดังเดิม')) return;
 try {
 await onUpdateBill(selectedSlipBill.id, { slipStatus: 'rejected' });
 setSelectedSlipBill(null);
 } catch (err: any) {
 alert('ไม่สามารถปฏิเสธสลิปได้: ' + err.message);
 }
 }}
 className="py-2.5 rounded-xl border border-[#E22134]/30 text-[#E22134] font-bold text-center hover:bg-rose-50 transition cursor-pointer text-xxs"
 >
 ปฏิเสธ (สลิปไม่ถูกต้อง)
 </button>
 <button
 type="button"
 onClick={async () => {
 try {
 await onUpdateBill(selectedSlipBill.id, { 
 status: 'paid', 
 slipStatus: 'verified',
 paidAt: new Date().toISOString()
 });
 setSelectedSlipBill(null);
 } catch (err: any) {
 alert('ไม่สามารถตรวจสอบผ่านได้: ' + err.message);
 }
 }}
 className="py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-[#1A1A1A] font-bold text-center transition cursor-pointer shadow-emerald-200/50 text-xxs"
 >
 ยืนยันความถูกต้อง (รับเงิน)
 </button>
 </div>
 </motion.div>
      <ConfirmModal
        isOpen={isDeleteConfirmOpen}
        title={`ยืนยันการลบบิลห้อง ${targetBill?.roomNumber || ''}`}
        message="คุณแน่ใจหรือไม่ว่าต้องการลบบิลนี้ออกจากระบบ? บิลจะถูกย้ายไปยังถังขยะ (Soft Delete) และสามารถกู้คืนได้"
        confirmText="ยืนยันลบบิล"
        cancelText="ยกเลิก"
        isDanger={true}
        loading={submitting}
        onConfirm={handleDeleteBill}
        onClose={() => setIsDeleteConfirmOpen(false)}
      />
 </div>
 )}
 </AnimatePresence>

 </div>
 );
};
// Force Vite HMR reload
