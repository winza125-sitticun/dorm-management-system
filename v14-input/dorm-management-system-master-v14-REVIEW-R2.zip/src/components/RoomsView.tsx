import React, { useState, useMemo, useCallback } from 'react';
import { useDebounce } from '../hooks/useDebounce.ts';
import { 
 Plus, 
 Edit2, 
 Trash2, 
 Home, 
 User, 
 Phone, 
 DollarSign, 
 Eye, 
 ChevronRight, 
 Search,
 X,
 AlertTriangle,
 MessageSquare,
 QrCode,
 Copy,
 ExternalLink,
 Check,
 FileSpreadsheet,
 Link
 ,CalendarClock
} from 'lucide-react';
import { Room, UserProfile, Settings } from '../types.ts';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../context/AuthContext.tsx';
import { exportRoomsToGoogleSheets } from '../lib/googleSheets.ts';
import { EmptyState } from './common/EmptyState.tsx';
import { ConfirmModal } from './common/ConfirmModal.tsx';
import { RoomRecurringChargesModal } from './RoomRecurringChargesModal.tsx';
import { hasAppPermission, PERMISSIONS } from '../constants/permissions.ts';

interface RoomsViewProps {
 rooms: Room[];
 loading: boolean;
 onCreateRoom: (roomData: Omit<Room, 'id'>) => Promise<void>;
 onUpdateRoom: (roomId: number, roomData: Omit<Room, 'id'>) => Promise<void>;
 onDeleteRoom: (roomId: number) => Promise<void>;
 idToken?: string | null;
 onRefreshRooms?: () => void;
 userProfile?: UserProfile | null;
 settings?: Settings | null;
}

export const RoomsView: React.FC<RoomsViewProps> = ({
 rooms,
 loading,
 onCreateRoom,
 onUpdateRoom,
 onDeleteRoom,
 idToken,
 onRefreshRooms,
 userProfile,
 settings
}) => {
 const { getGoogleAccessToken, googleAccessToken } = useAuth();
 const [exportingSheet, setExportingSheet] = useState(false);
 const [exportSuccess, setExportSuccess] = useState(false);
 const [exportError, setExportError] = useState<string | null>(null);

 const [searchTerm, setSearchTerm] = useState('');
 const [isModalOpen, setIsModalOpen] = useState(false);
 const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
 const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
 const [recurringRoom, setRecurringRoom] = useState<Room | null>(null);
 const canManageRecurring = hasAppPermission(userProfile?.role || '', userProfile?.permissions, PERMISSIONS.MANAGE_RECURRING_CHARGES) || hasAppPermission(userProfile?.role || '', userProfile?.permissions, PERMISSIONS.MANAGE_ROOMS);
 
 const [instructionRoom, setInstructionRoom] = useState<Room | null>(null);
 const [copiedLink, setCopiedLink] = useState(false);
 const [copiedTenantRoomId, setCopiedTenantRoomId] = useState<number | null>(null);

 const handleCopyTenantLink = (roomId: number) => {
 const link = `${window.location.origin}?roomId=${roomId}`;
 navigator.clipboard.writeText(link);
 setCopiedTenantRoomId(roomId);
 setTimeout(() => setCopiedTenantRoomId(null), 2000);
 };

 const handleExportToGoogleSheets = async () => {
 setExportError(null);
 setExportSuccess(false);
 setExportingSheet(true);
 try {
 const spreadsheetId = settings?.googleSpreadsheetId;
 if (!spreadsheetId) {
 throw new Error('ยังไม่ได้เชื่อมโยง Google Spreadsheet กรุณาตั้งค่าเชื่อมโยงในส่วน "ตั้งค่าระบบ" ก่อนค่ะ');
 }

 const token = await getGoogleAccessToken();
 if (!token) {
 throw new Error('ไม่สามารถรับสิทธิ์การเขียน Google Sheets ได้ กรุณาเชื่อมต่อบัญชี Google ก่อนค่ะ');
 }

 await exportRoomsToGoogleSheets(token, spreadsheetId, rooms);
 setExportSuccess(true);
 setTimeout(() => setExportSuccess(false), 4000);
 } catch (err: any) {
 console.error(err);
 setExportError(err.message || 'เกิดข้อผิดพลาดในการส่งออกข้อมูล');
 } finally {
 setExportingSheet(false);
 }
 };

 // Form states
 const [roomNumber, setRoomNumber] = useState('');
 const [monthlyRent, setMonthlyRent] = useState('');
 const [status, setStatus] = useState<'vacant' | 'occupied'>('vacant');
 const [tenantName, setTenantName] = useState('');
 const [tenantPhone, setTenantPhone] = useState('');
 const [lineNotifyToken, setLineNotifyToken] = useState('');

 const [formError, setFormError] = useState<string | null>(null);
 const [submitting, setSubmitting] = useState(false);

 // Quick Filters State
 const [statusFilter, setStatusFilter] = useState<'all' | 'vacant' | 'occupied'>('all');
 const [selectedFloor, setSelectedFloor] = useState<string>('all');
 const [selectedBuilding, setSelectedBuilding] = useState<string>('all');
 const [viewMode, setViewMode] = useState<'grid' | 'by_floor'>('grid');

 const safeRooms = useMemo(() => (Array.isArray(rooms) ? rooms.filter(Boolean) : []), [rooms]);

 // Helper to extract building & floor from room number
 const getRoomMeta = (roomNumberStr?: string | null) => {
   const str = String(roomNumberStr || '').trim();
   const buildingMatch = str.match(/^([A-Za-z]+)-?(\d+)/);
   let building = 'อาคารหลัก';
   let numPart = str;

   if (buildingMatch) {
     building = `อาคาร ${buildingMatch[1].toUpperCase()}`;
     numPart = buildingMatch[2];
   }

   let floor = '1';
   if (numPart.length >= 3) {
     floor = numPart.substring(0, numPart.length - 2);
   } else if (numPart.length > 0) {
     floor = numPart.substring(0, 1);
   }

   return { building, floor };
 };

 const debouncedSearchTerm = useDebounce(searchTerm, 300);

 // Derive unique buildings & floors from room list
 const allBuildings = useMemo(() => Array.from(new Set(safeRooms.map(r => getRoomMeta(r?.roomNumber).building))).sort(), [safeRooms]);
 const allFloors = useMemo(() => Array.from(new Set(safeRooms.map(r => getRoomMeta(r?.roomNumber).floor)))
   .sort((a, b) => parseInt(String(a)) - parseInt(String(b))), [safeRooms]);

 // Filtered rooms
 const filteredRooms = useMemo(() => {
   return safeRooms.filter(room => {
     const roomNumStr = String(room?.roomNumber || '');
     const tenantNameStr = String(room?.tenantName || '');
     const searchStr = String(debouncedSearchTerm || '').toLowerCase();

     const matchesSearch = 
       roomNumStr.toLowerCase().includes(searchStr) ||
       tenantNameStr.toLowerCase().includes(searchStr);

     const matchesStatus = statusFilter === 'all' || room?.status === statusFilter;

     const { building, floor } = getRoomMeta(roomNumStr);
     const matchesBuilding = selectedBuilding === 'all' || building === selectedBuilding;
     const matchesFloor = selectedFloor === 'all' || floor === selectedFloor;

     return matchesSearch && matchesStatus && matchesBuilding && matchesFloor;
   });
 }, [safeRooms, debouncedSearchTerm, statusFilter, selectedBuilding, selectedFloor]);

 // Group rooms by floor when viewMode === 'by_floor'
 const roomsByFloor = useMemo(() => {
   return allFloors.map(floorNum => {
     const floorRooms = filteredRooms.filter(r => getRoomMeta(r?.roomNumber).floor === floorNum);
     return { floor: floorNum, rooms: floorRooms };
   }).filter(group => group.rooms.length > 0);
 }, [allFloors, filteredRooms]);

 const openAddModal = () => {
 setSelectedRoom(null);
 setRoomNumber('');
 setMonthlyRent('3000');
 setStatus('vacant');
 setTenantName('');
 setTenantPhone('');
 setLineNotifyToken('');
 setFormError(null);
 setIsModalOpen(true);
 };

 const openEditModal = (room: Room) => {
 setSelectedRoom(room);
 setRoomNumber(room.roomNumber);
 setMonthlyRent(room.monthlyRent.toString());
 setStatus(room.status);
 setTenantName(room.tenantName || '');
 setTenantPhone(room.tenantPhone || '');
 setLineNotifyToken(room.lineNotifyToken || '');
 setFormError(null);
 setIsModalOpen(true);
 };

 const openDeleteConfirm = (room: Room) => {
 setSelectedRoom(room);
 setIsDeleteConfirmOpen(true);
 };

 const handleSubmit = async (e: React.FormEvent) => {
 e.preventDefault();
 if (!roomNumber) {
 setFormError('กรุณากรอกหมายเลขห้องพัก');
 return;
 }
 if (status === 'occupied' && !tenantName) {
 setFormError('กรุณากรอกชื่อผู้เช่าเมื่อสถานะห้อง "มีผู้เช่า"');
 return;
 }

 setSubmitting(true);
 setFormError(null);

 const roomData = {
 roomNumber,
 monthlyRent: parseInt(monthlyRent) || 0,
 status,
 tenantName: status === 'vacant' ? '' : tenantName,
 tenantPhone: status === 'vacant' ? '' : tenantPhone,
 lineNotifyToken: status === 'vacant' ? '' : lineNotifyToken,
 };

 try {
 if (selectedRoom) {
 await onUpdateRoom(selectedRoom.id, roomData);
 } else {
 await onCreateRoom(roomData);
 }
 setIsModalOpen(false);
 } catch (err: any) {
 setFormError(err.message || 'เกิดข้อผิดพลาดในการบันทึกข้อมูลห้องพัก');
 } finally {
 setSubmitting(false);
 }
 };

 const handleDelete = async () => {
 if (!selectedRoom) return;
 setSubmitting(true);
 try {
 await onDeleteRoom(selectedRoom.id);
 setIsDeleteConfirmOpen(false);
 } catch (err: any) {
 alert('ไม่สามารถลบห้องพักได้: ' + err.message);
 } finally {
 setSubmitting(false);
 }
 };

 const handleSendTestLine = async (roomId: number, roomNum: string) => {
 try {
 const res = await fetch(`/api/line/send-test/${roomId}`, {
 method: 'POST',
 headers: {
 'Authorization': `Bearer ${idToken}`
 }
 });
 const data = await res.json();
  if (res.ok) {
  alert(`ส่งข้อความทดสอบไปยังไลน์ห้องพักหมายเลข ${roomNum} สำเร็จแล้วค่ะ!`);
  } else {
  const errorMessage = typeof data.error === 'string'
    ? data.error
    : (data.error?.message || data.message || 'เกิดข้อผิดพลาดที่ไม่ทราบสาเหตุ');
  alert(`ไม่สามารถส่งข้อความทดสอบได้: ${errorMessage}`);
 }
 } catch (err: any) {
 alert(`เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์: ${err.message}`);
 }
 };

 const handleUnlinkLine = async (roomId: number, roomNum: string) => {
 if (!confirm(`คุณต้องการยกเลิกสายสัญญาณ LINE บอท ของห้องพักหมายเลข ${roomNum} ใช่หรือไม่?`)) return;
 try {
 const res = await fetch(`/api/line/unlink/${roomId}`, {
 method: 'POST',
 headers: {
 'Authorization': `Bearer ${idToken}`
 }
 });
 const data = await res.json();
  if (res.ok) {
  alert(`ยกเลิกคู่สาย LINE ห้องพัก ${roomNum} สำเร็จเรียบร้อยค่ะ!`);
  if (onRefreshRooms) onRefreshRooms();
  } else {
  const errorMessage = typeof data.error === 'string'
    ? data.error
    : (data.error?.message || data.message || 'เกิดข้อผิดพลาดที่ไม่ทราบสาเหตุ');
  alert(`ยกเลิกคู่สายไม่สำเร็จ: ${errorMessage}`);
 }
 } catch (err: any) {
 alert(`เกิดข้อผิดพลาด: ${err.message}`);
 }
 };

 const handleCopyRegisterLink = (roomNum: string) => {
 const link = `${window.location.origin}/line-register?room=${encodeURIComponent(roomNum)}`;
 navigator.clipboard.writeText(link);
 setCopiedLink(true);
 setTimeout(() => setCopiedLink(false), 2000);
 };

 // Counts for status pills
 const vacantCount = rooms.filter(r => r.status === 'vacant').length;
 const occupiedCount = rooms.filter(r => r.status === 'occupied').length;

 return (
 <div className="space-y-6 font-sans">
 
 {/* Header Panel */}
 <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
 <div>
 <h2 className="text-xl font-bold text-[#1A1A1A] flex items-center gap-2">
 <Home className="w-5 h-5 text-[#1DB954]" />
 <span>จัดการข้อมูลห้องพัก</span>
 </h2>
 <p className="text-xs text-[#8A8A85] mt-1">
 เพิ่ม แก้ไข และลบข้อมูลห้องพักทั้งหมด รวมถึงกำหนดค่าเช่าและข้อมูลผู้เช่า
 </p>
 </div>
 
 <div className="flex flex-wrap items-center gap-2">
 <button
 onClick={openAddModal}
 className="py-2.5 px-4 rounded-xl bg-[#1DB954] hover:bg-[#1ED760] hover:scale-[1.04] text-white text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer"
 >
 <Plus className="w-4 h-4" />
 <span>เพิ่มห้องพักใหม่</span>
 </button>
 </div>
 </div>

 {/* QUICK FILTERS BAR & CONTROLS */}
 <div className="bg-white p-4 rounded-2xl border border-[#E0E0DB] space-y-3">
 <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
 
 {/* Search Input */}
 <div className="relative w-full lg:w-72">
 <Search className="absolute left-3 top-2.5 h-4 w-4 text-[#8A8A85]" />
 <input
 type="text"
 placeholder="ค้นหาเลขห้อง หรือชื่อผู้เช่า..."
 value={searchTerm}
 onChange={(e) => setSearchTerm(e.target.value)}
 className="w-full bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl py-2 pl-9 pr-4 text-xs text-[#1A1A1A] placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition"
 />
 {searchTerm && (
 <button onClick={() => setSearchTerm('')} className="absolute right-3 top-2.5 text-[#8A8A85] hover:text-[#B3B3B3]">
 <X className="w-3.5 h-3.5" />
 </button>
 )}
 </div>

 {/* Status Quick Filters */}
 <div className="flex items-center gap-1 bg-[#F0F0EB] p-1 rounded-xl text-xs font-medium overflow-x-auto">
 <button
 onClick={() => setStatusFilter('all')}
 className={`px-3 py-1.5 rounded-lg transition-all ${statusFilter === 'all' ? 'bg-white text-[#1A1A1A] font-bold' : 'text-[#6B6B66] hover:text-white'}`}
 >
 ทั้งหมด ({rooms.length})
 </button>
 <button
 onClick={() => setStatusFilter('vacant')}
 className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${statusFilter === 'vacant' ? 'bg-white text-[#1DB954] font-bold' : 'text-[#6B6B66] hover:text-white'}`}
 >
 <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
 ห้องว่าง ({vacantCount})
 </button>
 <button
 onClick={() => setStatusFilter('occupied')}
 className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${statusFilter === 'occupied' ? 'bg-white text-blue-700 font-bold' : 'text-[#6B6B66] hover:text-white'}`}
 >
 <span className="w-2 h-2 rounded-full bg-[#1DB954]"></span>
 มีผู้เช่า ({occupiedCount})
 </button>
 </div>

 {/* View Mode Toggle */}
 <div className="flex items-center gap-1 bg-[#F0F0EB] p-1 rounded-xl text-xs font-medium shrink-0">
 <button
 onClick={() => setViewMode('grid')}
 className={`px-3 py-1.5 rounded-lg transition-all ${viewMode === 'grid' ? 'bg-white text-[#1A1A1A] font-bold' : 'text-[#8A8A85]'}`}
 >
 มุมมองการ์ด
 </button>
 <button
 onClick={() => setViewMode('by_floor')}
 className={`px-3 py-1.5 rounded-lg transition-all ${viewMode === 'by_floor' ? 'bg-white text-blue-700 font-bold' : 'text-[#8A8A85]'}`}
 >
 มุมมองแยกตามชั้น 🏢
 </button>
 </div>
 </div>

 {/* Building & Floor Selector Bar */}
 <div className="pt-2 border-t border-[#E0E0DB] flex flex-wrap items-center gap-3 text-xs">
 {/* Building Filter (If multiple) */}
 {allBuildings.length > 1 && (
 <div className="flex items-center gap-1">
 <span className="text-[#8A8A85] font-medium">อาคาร:</span>
 <div className="flex items-center gap-1">
 <button
 onClick={() => setSelectedBuilding('all')}
 className={`px-2.5 py-1 rounded-lg text-xs transition-all ${selectedBuilding === 'all' ? 'bg-[#1DB954]/8 text-blue-700 font-bold border border-[#1DB954]/30' : 'bg-[#F0F0EB] text-[#6B6B66] border border-[#E0E0DB]'}`}
 >
 ทุกอาคาร
 </button>
 {allBuildings.map(b => (
 <button
 key={b}
 onClick={() => setSelectedBuilding(b)}
 className={`px-2.5 py-1 rounded-lg text-xs transition-all ${selectedBuilding === b ? 'bg-[#1DB954]/8 text-blue-700 font-bold border border-[#1DB954]/30' : 'bg-[#F0F0EB] text-[#6B6B66] border border-[#E0E0DB]'}`}
 >
 {b}
 </button>
 ))}
 </div>
 </div>
 )}

 {/* Floor Quick Pills */}
 <div className="flex items-center gap-1 overflow-x-auto py-0.5">
 <span className="text-[#8A8A85] font-medium shrink-0">เลือกชั้น:</span>
 <button
 onClick={() => setSelectedFloor('all')}
 className={`px-2.5 py-1 rounded-lg text-xs transition-all shrink-0 ${selectedFloor === 'all' ? 'bg-[#1DB954] text-[#1A1A1A] font-bold' : 'bg-[#F0F0EB] text-[#6B6B66] hover:bg-[#E8E8E3]'}`}
 >
 ทุกชั้น
 </button>
 {allFloors.map(f => (
 <button
 key={f}
 onClick={() => setSelectedFloor(f)}
 className={`px-2.5 py-1 rounded-lg text-xs transition-all shrink-0 ${selectedFloor === f ? 'bg-[#1DB954] text-[#1A1A1A] font-bold' : 'bg-[#F0F0EB] text-[#6B6B66] hover:bg-[#E8E8E3]'}`}
 >
 ชั้น {f}
 </button>
 ))}
 </div>
 </div>
 </div>

 {loading && rooms.length === 0 ? (
 <div className="flex justify-center items-center py-20 text-[#8A8A85]">
 <span className="w-6 h-6 border-2 border-[#E0E0DB] border-t-blue-600 rounded-full animate-spin"></span>
 <span className="ml-3 text-sm">กำลังโหลดห้องพัก...</span>
 </div>
 ) : filteredRooms.length === 0 ? (
 <div className="text-center py-20 bg-white rounded-2xl border border-dashed border-[#E0E0DB]">
 <Home className="w-12 h-12 text-[#8A8A85] mx-auto mb-3" />
 <p className="text-sm font-medium text-[#8A8A85]">ไม่พบห้องพักตามเงื่อนไขที่คุณกรอง</p>
 <button 
 onClick={() => { setStatusFilter('all'); setSelectedFloor('all'); setSelectedBuilding('all'); setSearchTerm(''); }}
 className="mt-3 text-xs font-bold text-[#1DB954] hover:text-blue-700 cursor-pointer"
 >
 ล้างตัวกรองทั้งหมด
 </button>
 </div>
 ) : viewMode === 'by_floor' ? (
 /* GROUPED BY FLOOR VIEW */
 <div className="space-y-6">
 {roomsByFloor.map(({ floor, rooms: floorRooms }) => {
 const vacantCount = floorRooms.filter(r => r.status === 'vacant').length;
 const occupiedCount = floorRooms.filter(r => r.status === 'occupied').length;

 return (
 <div key={floor} className="bg-white rounded-2xl border border-[#E0E0DB] p-5 space-y-4">
 {/* Floor Header */}
 <div className="flex items-center justify-between border-b border-[#E0E0DB] pb-3">
 <div className="flex items-center gap-2">
 <span className="p-2 bg-[#1DB954]/8 text-blue-700 font-extrabold rounded-xl text-sm">
 🏢 ชั้น {floor}
 </span>
 <span className="text-xs font-bold text-[#6B6B66]">
 (รวม {floorRooms.length} ห้อง)
 </span>
 </div>

 <div className="flex items-center gap-2 text-xs font-medium">
 <span className="px-2.5 py-1 rounded-full bg-[#1DB954]/8 text-[#1DB954] border border-[#1DB954]/30">
 ว่าง {vacantCount}
 </span>
 <span className="px-2.5 py-1 rounded-full bg-[#1DB954]/8 text-blue-700 border border-[#1DB954]/30">
 มีผู้เช่า {occupiedCount}
 </span>
 </div>
 </div>

 {/* Floor Grid */}
 <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
 {floorRooms.map(room => (
 <div 
 key={room.id}
 className="bg-[#282828]/70 border border-[#282828]/80 hover:border-[#282828] rounded-2xl p-4 shadow-2xs flex flex-col justify-between transition relative overflow-hidden"
 >
 <div className={`absolute top-0 right-0 h-1 w-20 ${room.status === 'occupied' ? 'bg-[#1DB954]' : 'bg-emerald-500'}`}></div>

 <div>
 <div className="flex items-center justify-between">
 <h3 className="text-base font-extrabold text-[#1A1A1A]">ห้อง {room.roomNumber}</h3>
 <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
 room.status === 'occupied' 
 ? 'bg-[#1DB954]/8 text-blue-700 border-[#1DB954]/30' 
 : 'bg-[#1DB954]/8 text-[#1DB954] border-[#1DB954]/30'
 }`}>
 {room.status === 'occupied' ? 'มีผู้เช่า' : 'ห้องว่าง'}
 </span>
 </div>

 <div className="mt-3 space-y-1.5 text-xs text-[#6B6B66]">
 <p className="flex justify-between">
 <span className="text-[#8A8A85]">ค่าเช่า:</span>
 <span className="font-extrabold text-[#1A1A1A]">{room.monthlyRent.toLocaleString()} บ.</span>
 </p>

 {room.status === 'occupied' && (
 <p className="flex justify-between">
 <span className="text-[#8A8A85]">ผู้เช่า:</span>
 <span className="font-bold text-blue-700">{room.tenantName}</span>
 </p>
 )}
 </div>
 </div>

 <div className="mt-4 pt-3 border-t border-[#E0E0DB] flex items-center justify-between">
 <button
 onClick={() => handleCopyTenantLink(room.id)}
 className="text-[11px] text-[#1DB954] font-bold hover:underline flex items-center gap-1 cursor-pointer"
 >
 {copiedTenantRoomId === room.id ? <Check className="w-3 h-3 text-[#1DB954]" /> : <Link className="w-3 h-3" />}
 <span>{copiedTenantRoomId === room.id ? 'คัดลอกลิงก์แล้ว' : 'คัดลอกลิงก์ผู้เช่า'}</span>
 </button>

 <div className="flex items-center gap-1">
 {canManageRecurring && <button onClick={() => setRecurringRoom(room)} className="p-1.5 text-[#6B6B66] hover:bg-[#E8E8E3] rounded-lg" title="ค่าบริการประจำ"><CalendarClock className="w-3.5 h-3.5" /></button>}
 <button
 onClick={() => openEditModal(room)}
 className="p-1.5 text-[#6B6B66] hover:bg-[#E8E8E3] rounded-lg text-xs cursor-pointer"
 title="แก้ไข"
 >
 <Edit2 className="w-3.5 h-3.5" />
 </button>
 </div>
 </div>
 </div>
 ))}
 </div>
 </div>
 );
 })}
 </div>
 ) : (
 /* Rooms Grid */
 <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
 {filteredRooms.map((room) => (
 <div 
 key={room.id}
 className="bg-white border border-[#282828]/80 hover:border-slate-350 rounded-2xl p-5 flex flex-col justify-between transition group relative overflow-hidden"
 >
 {/* Card Status Banner Accent */}
 <div className={`absolute top-0 right-0 h-1 w-20 ${room.status === 'occupied' ? 'bg-[#1DB954]' : 'bg-slate-300'}`}></div>

 <div>
 {/* Number & Status */}
 <div className="flex items-center justify-between">
 <h3 className="text-lg font-extrabold text-[#1A1A1A] font-sans">ห้อง {room.roomNumber}</h3>
 <span className={`text-xxs font-bold px-2.5 py-1 rounded-full border ${
 room.status === 'occupied' 
 ? 'bg-[#1DB954]/8 text-blue-700 border-blue-100' 
 : 'bg-[#F0F0EB] text-[#8A8A85] border-[#E0E0DB]'
 }`}>
 {room.status === 'occupied' ? 'มีผู้เช่า' : 'ห้องว่าง'}
 </span>
 </div>

 {/* Info List */}
 <div className="mt-4 space-y-2.5 text-xs text-[#6B6B66]">
 <div className="flex items-center gap-2">
 <DollarSign className="w-4 h-4 text-[#1DB954]" />
 <p>ค่าเช่ารายเดือน: <span className="font-extrabold text-[#1A1A1A]">{room.monthlyRent.toLocaleString()} บ.</span></p>
 </div>

 {room.status === 'occupied' ? (
 <>
 <div className="flex items-center gap-2">
 <User className="w-4 h-4 text-[#1DB954]" />
 <p>ผู้เช่า: <span className="font-medium text-[#1A1A1A]">{room.tenantName}</span></p>
 </div>
 {room.tenantPhone && (
 <div className="flex items-center gap-2">
 <Phone className="w-4 h-4 text-[#1DB954]" />
 <p>เบอร์โทร: <span className="text-[#6B6B66] font-mono">{room.tenantPhone}</span></p>
 </div>
 )}

 {/* LINE Connection Status */}
 <div className="mt-3 pt-3 border-t border-[#E0E0DB] space-y-2">
 <div className="flex items-center justify-between text-[10px] font-bold text-[#8A8A85]">
 <span>สายเชื่อมต่อ LINE:</span>
 {room.lineUserId ? (
 <span className="text-[#1DB954] bg-[#1DB954]/8 px-2 py-0.5 rounded-full border border-[#1DB954]/30 flex items-center gap-1 font-extrabold text-[9px]">
 🟢 เชื่อมต่อแล้ว
 </span>
 ) : (
 <span className="text-[#8A8A85] bg-[#F0F0EB] px-2 py-0.5 rounded-full border border-[#E0E0DB] flex items-center gap-1 text-[9px]">
 ⚪ ยังไม่เชื่อมต่อ
 </span>
 )}
 </div>

 {room.lineUserId ? (
 <div className="bg-[#F0F0EB] p-2 rounded-xl border border-[#E0E0DB] flex items-center justify-between gap-1">
 <div className="flex items-center gap-1.5 overflow-hidden">
 {room.linePictureUrl ? (
 <img src={room.linePictureUrl} alt="" className="w-5 h-5 rounded-full border border-[#E0E0DB]" referrerPolicy="no-referrer" />
 ) : (
 <div className="w-5 h-5 rounded-full bg-[#F0F0EB] flex items-center justify-center font-bold text-[8px] text-[#6B6B66]">
 {room.lineDisplayName?.substring(0, 1) || 'L'}
 </div>
 )}
 <span className="text-[10px] font-extrabold text-[#6B6B66] truncate">{room.lineDisplayName || 'LINE User'}</span>
 </div>

 <div className="flex items-center gap-1 flex-shrink-0">
 <button
 onClick={() => handleSendTestLine(room.id, room.roomNumber)}
 className="text-[9px] font-extrabold text-[#1DB954] hover:text-blue-500 bg-[#1DB954]/8 hover:bg-blue-100/50 border border-blue-100 px-1.5 py-1 rounded-full cursor-pointer transition"
 >
 ทดสอบส่ง
 </button>
 <button
 onClick={() => handleUnlinkLine(room.id, room.roomNumber)}
 className="text-[9px] font-extrabold text-red-600 hover:text-red-500 bg-red-50 hover:bg-red-100/50 border border-red-100 px-1.5 py-1 rounded-lg cursor-pointer transition"
 >
 ยกเลิก
 </button>
 </div>
 </div>
 ) : (
 <div className="bg-[#F0F0EB] p-2 rounded-xl border border-[#E0E0DB] flex items-center justify-between gap-2">
 <span className="text-[9px] text-[#8A8A85] leading-tight">
 ส่งคิวอาร์ลิ้งก์ให้ผู้เช่าสแกนเชื่อมต่อบอท
 </span>
 <button
 onClick={() => setInstructionRoom(room)}
 className="text-[9px] font-extrabold text-[#1DB954] hover:text-blue-500 bg-[#1DB954]/8 hover:bg-blue-100 border border-blue-100 px-2 py-1 rounded-full cursor-pointer transition flex-shrink-0"
 >
 คิวอาร์โค้ด
 </button>
 </div>
 )}
 </div>
 </>
 ) : (
 <div className="flex items-center gap-2 text-[#8A8A85] py-2 italic">
 <p>ไม่มีประวัติการเช่าพักในปัจจุบัน</p>
 </div>
 )}
 </div>
 </div>

 {/* Actions Footer */}
 <div className="mt-6 pt-4 border-t border-[#E0E0DB] flex items-center justify-end gap-2">
 <button
 onClick={() => handleCopyTenantLink(room.id)}
 className={`p-2 rounded-lg border transition cursor-pointer flex items-center gap-1 mt-0.5 font-bold mr-auto ${
 copiedTenantRoomId === room.id
 ? 'bg-[#1DB954]/8 border-[#1DB954]/30 text-[#1DB954]'
 : 'bg-[#1DB954]/8 border-blue-150 text-blue-700 hover:bg-blue-100'
 }`}
 title="คัดลอกลิงก์เฉพาะห้องสำหรับผู้เช่า"
 >
 {copiedTenantRoomId === room.id ? (
 <>
 <Check className="w-3.5 h-3.5" />
 <span className="text-[10px]">คัดลอกแล้ว!</span>
 </>
 ) : (
 <>
 <Link className="w-3.5 h-3.5" />
 <span className="text-[10px]">ลิงก์ผู้เช่า</span>
 </>
 )}
 </button>
 {canManageRecurring && <button onClick={() => setRecurringRoom(room)} className="p-2 rounded-lg bg-[#F0F0EB] hover:bg-[#E8E8E3] border border-[#E0E0DB] text-[#8A8A85]" title="ค่าบริการประจำ"><CalendarClock className="w-3.5 h-3.5" /></button>}
 <button
 onClick={() => openEditModal(room)}
 className="p-2 rounded-lg bg-[#F0F0EB] hover:bg-[#E8E8E3] border border-[#E0E0DB] text-[#8A8A85] hover:text-white transition cursor-pointer"
 title="แก้ไขห้องพัก"
 >
 <Edit2 className="w-3.5 h-3.5" />
 </button>
 {userProfile?.role !== 'caretaker' && (
 <button
 onClick={() => openDeleteConfirm(room)}
 className="p-2 rounded-lg bg-[#F0F0EB] hover:bg-rose-50 border border-[#E0E0DB] text-[#8A8A85] hover:text-rose-600 transition cursor-pointer"
 title="ลบห้องพัก"
 >
 <Trash2 className="w-3.5 h-3.5" />
 </button>
 )}
 </div>
 </div>
 ))}
 </div>
 )}

 {/* Add / Edit Room Modal */}
 <AnimatePresence>
 {isModalOpen && (
 <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 font-sans">
 <motion.div 
 initial={{ opacity: 0, scale: 0.95 }}
 animate={{ opacity: 1, scale: 1 }}
 exit={{ opacity: 0, scale: 0.95 }}
 className="bg-white border border-[#E0E0DB] rounded-2xl max-w-md w-full overflow-hidden shadow-xl"
 >
 <div className="p-5 border-b border-[#E0E0DB] flex justify-between items-center bg-[#F0F0EB]">
 <h3 className="font-bold text-[#1A1A1A] text-sm">
 {selectedRoom ? `แก้ไขข้อมูลห้อง ${selectedRoom.roomNumber}` : 'เพิ่มห้องพักใหม่'}
 </h3>
 <button onClick={() => setIsModalOpen(false)} className="text-[#8A8A85] hover:text-[#B3B3B3] cursor-pointer">
 <X className="w-5 h-5" />
 </button>
 </div>

 <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs">
 {formError && (
 <div className="p-3 bg-red-50 border border-red-100 text-red-600 rounded-lg font-semibold">
 {formError}
 </div>
 )}

 <div className="grid grid-cols-2 gap-4">
 <div>
 <label className="block text-[#8A8A85] font-bold mb-1.5 uppercase tracking-wider text-[10px]">หมายเลขห้องพัก *</label>
 <input
 type="text"
 placeholder="เช่น 101, ห้อง A"
 value={roomNumber}
 onChange={(e) => setRoomNumber(e.target.value)}
  className="w-full bg-white border border-[#D8D8D2] rounded-xl p-3 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-green-600 focus:ring-2 focus:ring-green-100 transition"
 />
 </div>
 <div>
 <label className="block text-[#8A8A85] font-bold mb-1.5 uppercase tracking-wider text-[10px]">ค่าเช่าห้องต่อเดือน *</label>
 <input
 type="number"
 placeholder="3000"
 value={monthlyRent}
 onChange={(e) => setMonthlyRent(e.target.value)}
  className="w-full bg-white border border-[#D8D8D2] rounded-xl p-3 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-green-600 focus:ring-2 focus:ring-green-100 transition"
 />
 </div>
 </div>

 <div>
 <label className="block text-[#8A8A85] font-bold mb-1.5 uppercase tracking-wider text-[10px]">สถานะห้องพัก</label>
 <div className="grid grid-cols-2 gap-2">
 <button
 type="button"
 onClick={() => setStatus('vacant')}
 className={`py-2.5 px-4 rounded-xl border font-bold text-center transition cursor-pointer ${
 status === 'vacant'
  ? 'bg-slate-900 border-slate-900 text-white shadow-sm'
  : 'bg-white border-[#D8D8D2] text-slate-700 hover:bg-slate-100 hover:text-slate-900'
 }`}
 >
 ว่าง (Vacant)
 </button>
 <button
 type="button"
 onClick={() => setStatus('occupied')}
 className={`py-2.5 px-4 rounded-xl border font-bold text-center transition cursor-pointer ${
 status === 'occupied'
  ? 'bg-green-600 border-green-600 text-white shadow-sm'
  : 'bg-white border-[#D8D8D2] text-slate-700 hover:bg-slate-100 hover:text-slate-900'
 }`}
 >
 มีผู้เช่า (Occupied)
 </button>
 </div>
 </div>

 {status === 'occupied' && (
 <motion.div 
 initial={{ opacity: 0, y: -5 }}
 animate={{ opacity: 1, y: 0 }}
 className="space-y-4"
 >
 <div>
 <label className="block text-[#8A8A85] font-bold mb-1.5 uppercase tracking-wider text-[10px]">ชื่อผู้เช่าห้องพัก *</label>
 <input
 type="text"
 placeholder="กรอกชื่อ-นามสกุลผู้เช่า"
 value={tenantName}
 onChange={(e) => setTenantName(e.target.value)}
  className="w-full bg-white border border-[#D8D8D2] rounded-xl p-3 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-green-600 focus:ring-2 focus:ring-green-100 transition"
 />
 </div>
 <div>
 <label className="block text-[#8A8A85] font-bold mb-1.5 uppercase tracking-wider text-[10px]">เบอร์โทรศัพท์ติดต่อ</label>
 <input
 type="tel"
 placeholder="08X-XXXXXXX"
 value={tenantPhone}
 onChange={(e) => setTenantPhone(e.target.value)}
  className="w-full bg-white border border-[#D8D8D2] rounded-xl p-3 text-slate-900 placeholder:text-slate-400 font-mono focus:outline-none focus:border-green-600 focus:ring-2 focus:ring-green-100 transition"
 />
 </div>
 <div>
 <label className="block text-[#8A8A85] font-bold mb-1.5 uppercase tracking-wider text-[10px]">LINE Notify Access Token (สำหรับส่งบิลตรงผู้เช่า)</label>
 <input
 type="text"
 placeholder="กรอก LINE Notify Token (ถ้ามี)"
 value={lineNotifyToken}
 onChange={(e) => setLineNotifyToken(e.target.value)}
  className="w-full bg-white border border-[#D8D8D2] rounded-xl p-3 text-slate-900 placeholder:text-slate-400 font-mono focus:outline-none focus:border-green-600 focus:ring-2 focus:ring-green-100 transition"
 />
 <p className="text-[10px] text-[#8A8A85] mt-1 leading-relaxed">
 *หากระบุ ระบบจะจัดส่งบิลผ่าน LINE Notify โดยตรง (ไม่จำเป็นต้องสแกน QR เพื่อลิงก์บัญชีกับบอท)*
 </p>
 </div>
 </motion.div>
 )}

 <div className="pt-4 border-t border-[#E0E0DB] flex items-center justify-end gap-2">
 <button
 type="button"
 onClick={() => setIsModalOpen(false)}
  className="py-2.5 px-4 rounded-xl bg-white hover:bg-slate-100 border border-[#D8D8D2] text-slate-700 hover:text-slate-900 font-bold transition cursor-pointer"
 >
 ยกเลิก
 </button>
 <button
 type="submit"
 disabled={submitting}
 className="py-2.5 px-5 rounded-xl bg-[#1DB954] hover:bg-[#1ED760] hover:scale-[1.04] text-white font-bold transition disabled:opacity-50 cursor-pointer"
 >
 {submitting ? 'กำลังบันทึก...' : 'บันทึกข้อมูล'}
 </button>
 </div>
 </form>
 </motion.div>
 </div>
 )}
 </AnimatePresence>

 {/* Delete Confirmation Dialog */}
 <AnimatePresence>
 {isDeleteConfirmOpen && selectedRoom && (
 <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 font-sans">
 <motion.div 
 initial={{ opacity: 0, scale: 0.95 }}
 animate={{ opacity: 1, scale: 1 }}
 exit={{ opacity: 0, scale: 0.95 }}
 className="bg-white border border-[#E0E0DB] rounded-2xl max-w-sm w-full p-5 shadow-xl"
 >
 <div className="text-center">
 <div className="inline-flex p-3 bg-red-50 text-red-600 rounded-full mb-3">
 <AlertTriangle className="w-6 h-6" />
 </div>
 <h3 className="text-sm font-bold text-[#1A1A1A]">ยืนยันลบห้องพัก {selectedRoom.roomNumber}?</h3>
 <p className="text-xxs text-[#8A8A85] mt-2 leading-relaxed">
 เมื่อยืนยัน ระบบจะทำการลบข้อมูลห้องพักเครื่องนี้พร้อมกับลบ **ประวัติบิลเรียกเก็บเงินทั้งหมด** ที่เชื่อมโยงกับห้องนี้อย่างถาวรและไม่สามารถกู้คืนได้!
 </p>
 </div>

 <div className="mt-5 grid grid-cols-2 gap-3 text-xs">
 <button
 onClick={() => setIsDeleteConfirmOpen(false)}
 className="py-2.5 rounded-xl bg-white hover:bg-[#E8E8E3] text-[#6B6B66] font-bold border border-[#E0E0DB] transition cursor-pointer"
 >
 ยกเลิก
 </button>
 <button
 onClick={handleDelete}
 disabled={submitting}
  className="py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold transition disabled:opacity-50 cursor-pointer"
 >
 {submitting ? 'กำลังลบ...' : 'ยืนยันลบถาวร'}
 </button>
 </div>
 </motion.div>
 </div>
 )}
 </AnimatePresence>

 {/* LINE Registration Instructions Dialog */}
 <AnimatePresence>
 {instructionRoom && (
 <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 font-sans">
 <motion.div
 initial={{ opacity: 0, scale: 0.95 }}
 animate={{ opacity: 1, scale: 1 }}
 exit={{ opacity: 0, scale: 0.95 }}
 className="bg-white border border-[#E0E0DB] rounded-2xl max-w-sm w-full overflow-hidden shadow-xl"
 >
 <div className="p-5 border-b border-[#E0E0DB] flex justify-between items-center bg-[#F0F0EB]">
 <h3 className="font-bold text-[#1A1A1A] text-sm flex items-center gap-2">
 <MessageSquare className="w-4 h-4 text-green-500 fill-green-50/20" />
 <span>เชื่อมต่อ LINE สำหรับห้อง {instructionRoom.roomNumber}</span>
 </h3>
 <button onClick={() => setInstructionRoom(null)} className="text-[#8A8A85] hover:text-[#B3B3B3] cursor-pointer">
 <X className="w-5 h-5" />
 </button>
 </div>

 <div className="p-5 space-y-4 text-xs text-[#6B6B66]">
 <div className="text-center space-y-2">
 <p className="font-semibold text-[#6B6B66]">ให้ผู้เช่าของห้อง {instructionRoom.roomNumber} สแกน QR โค้ดนี้:</p>
 
 {/* High Quality QR code using official open API */}
 <div className="inline-block p-3 bg-white border border-[#E0E0DB] rounded-2xl ">
 <img 
 src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(`${window.location.origin}/line-register?room=${instructionRoom.roomNumber}`)}`} 
 alt="Register QR Code"
 className="w-40 h-40 mx-auto"
 />
 </div>
 
 <p className="text-[10px] text-[#8A8A85] leading-normal">
 หรือส่งลิงก์ด้านล่างนี้ให้ผู้เช่าผ่านทางแชท/SMS เพื่อเข้าไปลงทะเบียนและตรวจยอดเงินใน LINE ทันที
 </p>
 </div>

 <div className="bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl p-3 space-y-1.5">
 <p className="font-bold text-[#8A8A85] text-[9px] uppercase tracking-wider">ลิงก์คู่สายลงทะเบียน:</p>
 <div className="flex items-center gap-1.5 bg-white border border-[#E0E0DB] rounded-lg p-1.5 pl-2.5">
 <span className="flex-1 text-[10px] text-[#6B6B66] truncate select-all">{`${window.location.origin}/line-register?room=${instructionRoom.roomNumber}`}</span>
 <button
 type="button"
 onClick={() => handleCopyRegisterLink(instructionRoom.roomNumber)}
 className="p-1.5 bg-[#F0F0EB] hover:bg-[#E8E8E3] text-[#6B6B66] rounded-md transition cursor-pointer flex items-center justify-center"
 title="คัดลอกลิงก์"
 >
 {copiedLink ? <Check className="w-3.5 h-3.5 text-green-600" /> : <Copy className="w-3.5 h-3.5" />}
 </button>
 </div>
 </div>

 <div className="text-[10px] text-[#8A8A85] leading-relaxed border-t border-[#E0E0DB] pt-3">
 <p className="font-bold text-[#8A8A85]">💡 ขั้นตอนง่ายๆ สำหรับผู้เช่า:</p>
 <ol className="list-decimal pl-4 space-y-1 mt-1 text-[9px]">
 <li>กดสแกนคิวอาร์โค้ด หรือ เข้าลิงก์ที่ส่งให้</li>
 <li>ระบบจะกรอกข้อมูลห้องพักโดยอัตโนมัติ</li>
 <li>กดยืนยันตัวตนเพื่อผูกกับ LINE ของตนเอง</li>
 <li>รับบิลเรียกเก็บเงินอัตโนมัติผ่านทางแชท LINE ทุกสิ้นเดือน!</li>
 </ol>
 </div>
 </div>

 <div className="p-4 bg-[#F0F0EB] border-t border-[#E0E0DB] flex justify-end">
 <button
 type="button"
 onClick={() => setInstructionRoom(null)}
  className="py-2 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold transition cursor-pointer"
 >
 เรียบร้อย
 </button>
 </div>
 </motion.div>
 </div>
 )}
 </AnimatePresence>

      {/* Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={isDeleteConfirmOpen}
        title={`ยืนยันการลบห้องพัก ${selectedRoom?.roomNumber || ''}`}
        message="คุณแน่ใจหรือไม่ว่าต้องการลบห้องพักนี้ออกจากระบบ? ข้อมูลประวัติเดิมจะถูกย้ายไปยังถังขยะ (Soft Delete) และสามารถกู้คืนได้โดยผู้ดูแลระบบ"
        confirmText="ยืนยันลบห้องพัก"
        cancelText="ยกเลิก"
        isDanger={true}
        loading={submitting}
        onConfirm={handleDelete}
        onClose={() => setIsDeleteConfirmOpen(false)}
      />
      {recurringRoom && <RoomRecurringChargesModal room={recurringRoom} idToken={idToken} onClose={() => setRecurringRoom(null)} />}
    </div>
  );
};
