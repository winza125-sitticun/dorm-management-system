import React, { useState } from 'react';
import { 
 Megaphone, 
 Plus, 
 Search, 
 Pin, 
 AlertTriangle, 
 Wrench, 
 CreditCard, 
 Info, 
 Edit3, 
 Trash2, 
 Eye, 
 X, 
 Check, 
 Calendar,
 Image as ImageIcon,
 Tag
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Announcement, AnnouncementCategory, Room } from '../types.ts';

interface AnnouncementsViewProps {
 announcements: Announcement[];
 rooms: Room[];
 idToken: string | null;
 onRefresh: () => void;
 showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

const CATEGORY_CONFIG: Record<AnnouncementCategory, { label: string; icon: any; badgeClass: string }> = {
 general: { label: 'ข่าวสารทั่วไป', icon: Info, badgeClass: 'bg-[#1DB954]/8 text-blue-700 border-[#1DB954]/30' },
 maintenance: { label: 'ซ่อมบำรุง/ระบบหอพัก', icon: Wrench, badgeClass: 'bg-[#F59B23]/8 text-amber-700 border-amber-200' },
 billing: { label: 'แจ้งชำระเงิน', icon: CreditCard, badgeClass: 'bg-[#A855F7]/8 text-purple-700 border-purple-200' },
 urgent: { label: 'ด่วนมาก ⚠️', icon: AlertTriangle, badgeClass: 'bg-[#E22134]/8 text-[#E22134] border-[#E22134]/30 font-bold' },
};

export const AnnouncementsView: React.FC<AnnouncementsViewProps> = ({
 announcements,
 rooms,
 idToken,
 onRefresh,
 showToast,
}) => {
 const getApiErrorMessage = (payload: any, fallback: string) => {
  if (typeof payload?.error === 'string') return payload.error;
  if (typeof payload?.error?.message === 'string') return payload.error.message;
  if (typeof payload?.message === 'string') return payload.message;
  return fallback;
 };
 const [searchTerm, setSearchTerm] = useState('');
 const [selectedCategory, setSelectedCategory] = useState<string>('all');
 
 // Modals
 const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
 const [selectedAnnouncement, setSelectedAnnouncement] = useState<Announcement | null>(null);
 const [isEditModalOpen, setIsEditModalOpen] = useState(false);

 // Form states
 const [title, setTitle] = useState('');
 const [content, setContent] = useState('');
 const [category, setCategory] = useState<AnnouncementCategory>('general');
 const [isPinned, setIsPinned] = useState(false);
 const [imageUrl, setImageUrl] = useState('');
 const [isSubmitting, setIsSubmitting] = useState(false);

 const getHeaders = () => ({
 'Content-Type': 'application/json',
 'Authorization': `Bearer ${idToken}`,
 });

 // Stats
 const totalCount = announcements.length;
 const pinnedCount = announcements.filter(a => a.isPinned === 1).length;
 const urgentCount = announcements.filter(a => a.category === 'urgent').length;

 // Filtered list
 const filteredAnnouncements = announcements.filter(a => {
 const matchesSearch = 
 a.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
 a.content.toLowerCase().includes(searchTerm.toLowerCase());
 const matchesCat = selectedCategory === 'all' || a.category === selectedCategory;
 return matchesSearch && matchesCat;
 });

 const handleCreate = async (e: React.FormEvent) => {
 e.preventDefault();
 if (!title.trim() || !content.trim()) {
 showToast('กรุณากรอกหัวข้อและเนื้อหาประกาศ', 'error');
 return;
 }

 setIsSubmitting(true);
 try {
 const res = await fetch('/api/announcements', {
 method: 'POST',
 headers: getHeaders(),
 body: JSON.stringify({
 title,
 content,
 category,
 isPinned: isPinned ? 1 : 0,
 imageUrl: imageUrl || null,
 }),
 });

 if (!res.ok) {
 const err = await res.json();
 throw new Error(getApiErrorMessage(err, 'ไม่สามารถสร้างประกาศได้'));
 }

 showToast('สร้างประกาศข่าวสารเรียบร้อยแล้ว', 'success');
 setIsCreateModalOpen(false);
 resetForm();
 onRefresh();
 } catch (err: any) {
 showToast(err.message || 'เกิดข้อผิดพลาดในการสร้างประกาศ', 'error');
 } finally {
 setIsSubmitting(false);
 }
 };

 const handleOpenEdit = (item: Announcement) => {
 setSelectedAnnouncement(item);
 setTitle(item.title);
 setContent(item.content);
 setCategory(item.category);
 setIsPinned(item.isPinned === 1);
 setImageUrl(item.imageUrl || '');
 setIsEditModalOpen(true);
 };

 const handleUpdate = async (e: React.FormEvent) => {
 e.preventDefault();
 if (!selectedAnnouncement) return;

 setIsSubmitting(true);
 try {
 const res = await fetch(`/api/announcements/${selectedAnnouncement.id}`, {
 method: 'PUT',
 headers: getHeaders(),
 body: JSON.stringify({
 title,
 content,
 category,
 isPinned: isPinned ? 1 : 0,
 imageUrl: imageUrl || null,
 }),
 });

 if (!res.ok) throw new Error('Failed to update announcement');

 showToast('อัปเดตประกาศข่าวสารเรียบร้อยแล้ว', 'success');
 setIsEditModalOpen(false);
 resetForm();
 onRefresh();
 } catch (err: any) {
 showToast(err.message || 'เกิดข้อผิดพลาดในการอัปเดต', 'error');
 } finally {
 setIsSubmitting(false);
 }
 };

 const handleTogglePin = async (item: Announcement) => {
 try {
 const res = await fetch(`/api/announcements/${item.id}`, {
 method: 'PUT',
 headers: getHeaders(),
 body: JSON.stringify({
 isPinned: item.isPinned === 1 ? 0 : 1,
 }),
 });

 if (!res.ok) throw new Error('Failed to toggle pin');

 showToast(item.isPinned === 1 ? 'ยกเลิกการปักหมุดแล้ว' : 'ปักหมุดประกาศเรียบร้อยแล้ว', 'success');
 onRefresh();
 } catch (err: any) {
 showToast('เกิดข้อผิดพลาดในการปักหมุด', 'error');
 }
 };

 const handleDelete = async (id: number) => {
 if (!window.confirm('คุณต้องการลบประกาศข่าวสารนี้ใช่หรือไม่?')) return;

 try {
 const res = await fetch(`/api/announcements/${id}`, {
 method: 'DELETE',
 headers: getHeaders(),
 });

 if (!res.ok) throw new Error('Failed to delete announcement');

 showToast('ลบประกาศเรียบร้อยแล้ว', 'success');
 onRefresh();
 } catch (err: any) {
 showToast('เกิดข้อผิดพลาดในการลบประกาศ', 'error');
 }
 };

 const resetForm = () => {
 setTitle('');
 setContent('');
 setCategory('general');
 setIsPinned(false);
 setImageUrl('');
 setSelectedAnnouncement(null);
 };

 return (
 <div className="space-y-6 pb-12 font-sans">
 {/* Top Banner Header */}
 <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-[#E0E0DB]">
 <div className="flex items-center gap-3">
 <div className="p-3 bg-[#6366F1]/8 rounded-xl text-[#6366F1]">
 <Megaphone className="w-7 h-7" />
 </div>
 <div>
 <h1 className="text-2xl font-bold text-[#1A1A1A]">ระบบประกาศ & บอร์ดข่าวสารหอพัก</h1>
 <p className="text-sm text-[#8A8A85]">บรอดแคสต์ข่าวสาร แจ้งซ่อมบำรุง กฎระเบียบ และปักหมุดข่าวสารสำคัญ</p>
 </div>
 </div>

 <button
 onClick={() => { resetForm(); setIsCreateModalOpen(true); }}
 className="flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-[#1A1A1A] px-5 py-2.5 rounded-xl font-medium transition-all text-sm cursor-pointer"
 >
 <Plus className="w-4 h-4" />
 <span>สร้างประกาศใหม่</span>
 </button>
 </div>

 {/* Overview Stats */}
 <div className="grid grid-cols-3 gap-4">
 <div className="bg-white p-5 rounded-2xl border border-[#E0E0DB] flex items-center gap-4">
 <div className="p-3 rounded-xl bg-[#6366F1]/8 text-[#6366F1]">
 <Megaphone className="w-6 h-6" />
 </div>
 <div>
 <p className="text-xs font-medium text-[#8A8A85]">ประกาศทั้งหมด</p>
 <p className="text-2xl font-bold text-[#6366F1]">{totalCount}</p>
 </div>
 </div>

 <div className="bg-white p-5 rounded-2xl border border-[#E0E0DB] flex items-center gap-4">
 <div className="p-3 rounded-xl bg-[#F59B23]/8 text-[#F59B23]">
 <Pin className="w-6 h-6" />
 </div>
 <div>
 <p className="text-xs font-medium text-[#8A8A85]">ประกาศที่ปักหมุดไว้</p>
 <p className="text-2xl font-bold text-[#F59B23]">{pinnedCount}</p>
 </div>
 </div>

 <div className="bg-white p-5 rounded-2xl border border-[#E0E0DB] flex items-center gap-4">
 <div className="p-3 rounded-xl bg-[#E22134]/8 text-[#E22134]">
 <AlertTriangle className="w-6 h-6" />
 </div>
 <div>
 <p className="text-xs font-medium text-[#8A8A85]">ประกาศด่วนมาก ⚠️</p>
 <p className="text-2xl font-bold text-[#E22134]">{urgentCount}</p>
 </div>
 </div>
 </div>

 {/* Filters & Search */}
 <div className="bg-white p-4 rounded-2xl border border-[#E0E0DB] flex flex-col md:flex-row gap-3 items-center justify-between">
 {/* Search */}
 <div className="relative w-full md:w-80">
 <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8A8A85]" />
 <input
 type="text"
 placeholder="ค้นหาหัวข้อประกาศ..."
 value={searchTerm}
 onChange={(e) => setSearchTerm(e.target.value)}
 className="w-full pl-10 pr-4 py-2 bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
 />
 {searchTerm && (
 <button onClick={() => setSearchTerm('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8A8A85] hover:text-slate-600">
 <X className="w-4 h-4" />
 </button>
 )}
 </div>

 {/* Category Select */}
 <div className="flex items-center gap-1 bg-[#F0F0EB] p-1 rounded-xl text-xs font-medium w-full md:w-auto overflow-x-auto">
 <button
 onClick={() => setSelectedCategory('all')}
 className={`px-3 py-1.5 rounded-lg transition-all ${selectedCategory === 'all' ? 'bg-white text-[#1A1A1A] font-bold' : 'text-[#6B6B66]'}`}
 >
 ทั้งหมด ({totalCount})
 </button>
 <button
 onClick={() => setSelectedCategory('general')}
 className={`px-3 py-1.5 rounded-lg transition-all ${selectedCategory === 'general' ? 'bg-white text-blue-700 font-bold' : 'text-[#6B6B66]'}`}
 >
 ข่าวสารทั่วไป
 </button>
 <button
 onClick={() => setSelectedCategory('maintenance')}
 className={`px-3 py-1.5 rounded-lg transition-all ${selectedCategory === 'maintenance' ? 'bg-white text-amber-700 font-bold' : 'text-[#6B6B66]'}`}
 >
 งานซ่อมบำรุง
 </button>
 <button
 onClick={() => setSelectedCategory('urgent')}
 className={`px-3 py-1.5 rounded-lg transition-all ${selectedCategory === 'urgent' ? 'bg-white text-[#E22134] font-bold' : 'text-[#6B6B66]'}`}
 >
 ด่วนมาก ⚠️
 </button>
 </div>
 </div>

 {/* Announcements Feed Grid */}
 {filteredAnnouncements.length === 0 ? (
 <div className="bg-white p-12 rounded-2xl border border-[#E0E0DB] text-center">
 <div className="w-16 h-16 bg-[#F0F0EB] rounded-full flex items-center justify-center mx-auto mb-4 text-[#8A8A85]">
 <Megaphone className="w-8 h-8" />
 </div>
 <h3 className="text-lg font-bold text-[#6B6B66] mb-1">ยังไม่มีประกาศข่าวสาร</h3>
 <p className="text-sm text-[#8A8A85]">กดปุ่ม "สร้างประกาศใหม่" เพื่อเริ่มบรอดแคสต์ข่าวสารหอพัก</p>
 </div>
 ) : (
 <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
 {filteredAnnouncements.map((item) => {
 const catConfig = CATEGORY_CONFIG[item.category] || CATEGORY_CONFIG.general;
 const CatIcon = catConfig.icon;
 const isPinned = item.isPinned === 1;

 return (
 <motion.div
 key={item.id}
 layout
 initial={{ opacity: 0, y: 10 }}
 animate={{ opacity: 1, y: 0 }}
 exit={{ opacity: 0, scale: 0.95 }}
 className={`bg-white rounded-2xl border transition-all flex flex-col justify-between overflow-hidden ${
 isPinned ? 'border-[#F59B23]/30 ring-2 ring-amber-500/10' : 'border-[#E0E0DB]'
 }`}
 >
 <div>
 {/* Card Header Banner */}
 <div className="p-4 pb-3 border-b border-[#E0E0DB] flex items-center justify-between bg-[#282828]/60">
 <div className="flex items-center gap-2">
 <span className={`text-xs px-2.5 py-1 rounded-lg border font-medium flex items-center gap-1.5 ${catConfig.badgeClass}`}>
 <CatIcon className="w-3.5 h-3.5" />
 {catConfig.label}
 </span>
 {isPinned && (
 <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#F59B23]/8 text-[#F59B23] font-bold flex items-center gap-1 border border-amber-200">
 <Pin className="w-3 h-3 fill-amber-600 text-[#F59B23]" />
 ปักหมุด
 </span>
 )}
 </div>

 <span className="text-[11px] text-[#8A8A85] flex items-center gap-1">
 <Calendar className="w-3 h-3" />
 {new Date(item.createdAt).toLocaleDateString('th-TH', { month: 'short', day: 'numeric', year: 'numeric' })}
 </span>
 </div>

 {/* Card Content */}
 <div className="p-5 space-y-3">
 <h3 className="font-bold text-[#1A1A1A] text-base leading-snug">{item.title}</h3>
 <p className="text-xs text-[#6B6B66] leading-relaxed whitespace-pre-line">{item.content}</p>

 {/* Image Preview */}
 {item.imageUrl && (
 <div className="mt-2 rounded-xl overflow-hidden border border-[#E0E0DB] bg-[#F0F0EB] max-h-48">
 <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover" />
 </div>
 )}
 </div>
 </div>

 {/* Card Actions Footer */}
 <div className="p-3 border-t border-[#E0E0DB] bg-[#282828]/30 flex items-center justify-between">
 <button
 onClick={() => handleTogglePin(item)}
 className={`flex items-center gap-1 text-xs font-semibold px-3 py-1.5 rounded-xl border transition-all cursor-pointer ${
 isPinned 
 ? 'bg-[#F59B23]/8 text-[#F59B23] border-amber-200 hover:bg-amber-200' 
 : 'bg-white text-[#6B6B66] border-[#E0E0DB] hover:bg-[#E8E8E3]'
 }`}
 >
 <Pin className={`w-3.5 h-3.5 ${isPinned ? 'fill-amber-600 text-[#F59B23]' : ''}`} />
 <span>{isPinned ? 'ถอนการปักหมุด' : 'ปักหมุดบนสุด'}</span>
 </button>

 <div className="flex items-center gap-1">
 <button
 onClick={() => handleOpenEdit(item)}
 className="p-2 text-[#6B6B66] hover:bg-[#E8E8E3] rounded-xl transition-colors text-xs cursor-pointer"
 title="แก้ไขประกาศ"
 >
 <Edit3 className="w-4 h-4" />
 </button>
 <button
 onClick={() => handleDelete(item.id)}
 className="p-2 text-[#E22134] hover:bg-rose-50 rounded-xl transition-colors text-xs cursor-pointer"
 title="ลบประกาศ"
 >
 <Trash2 className="w-4 h-4" />
 </button>
 </div>
 </div>
 </motion.div>
 );
 })}
 </div>
 )}

 {/* MODAL: Create / Edit Announcement */}
 <AnimatePresence>
 {(isCreateModalOpen || isEditModalOpen) && (
 <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
 <motion.div
 initial={{ opacity: 0, scale: 0.95 }}
 animate={{ opacity: 1, scale: 1 }}
 exit={{ opacity: 0, scale: 0.95 }}
 className="bg-white rounded-3xl shadow-xl border border-[#E0E0DB] max-w-lg w-full overflow-hidden max-h-[90vh] flex flex-col"
 >
 {/* Header */}
 <div className="p-5 border-b border-[#E0E0DB] flex items-center justify-between bg-[#F0F0EB]">
 <div className="flex items-center gap-2">
 <div className="p-2 bg-[#6366F1]/8 text-indigo-700 rounded-xl">
 <Megaphone className="w-5 h-5" />
 </div>
 <div>
 <h2 className="font-bold text-[#1A1A1A] text-lg">
 {isEditModalOpen ? 'แก้ไขประกาศข่าวสาร' : 'สร้างประกาศข่าวสารใหม่'}
 </h2>
 <p className="text-xs text-[#8A8A85]">ข่าวสารจะถูกส่งไปแสดงที่ Tenant Portal ของผู้เช่าทันที</p>
 </div>
 </div>
 <button
 onClick={() => { setIsCreateModalOpen(false); setIsEditModalOpen(false); }}
 className="p-2 text-[#8A8A85] hover:text-slate-600 rounded-full hover:bg-slate-200/50 transition-colors"
 >
 <X className="w-5 h-5" />
 </button>
 </div>

 {/* Form Body */}
 <form onSubmit={isEditModalOpen ? handleUpdate : handleCreate} className="p-6 space-y-4 overflow-y-auto flex-1 text-xs">
 {/* Title */}
 <div>
 <label className="block font-semibold text-[#6B6B66] mb-1.5">หัวข้อประกาศ *</label>
 <input
 type="text"
 required
 placeholder="เช่น แจ้งล้างถังน้ำประปาประจำปี, ปิดปรับปรุงระบบไฟ"
 value={title}
 onChange={(e) => setTitle(e.target.value)}
 className="w-full p-2.5 border border-[#E0E0DB] rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 font-medium"
 />
 </div>

 {/* Category & Pin Toggle */}
 <div className="grid grid-cols-2 gap-3">
 <div>
 <label className="block font-semibold text-[#6B6B66] mb-1.5">หมวดหมู่ข่าวสาร</label>
 <select
 value={category}
 onChange={(e) => setCategory(e.target.value as AnnouncementCategory)}
 className="w-full p-2.5 border border-[#E0E0DB] rounded-xl bg-[#F0F0EB] focus:outline-none focus:ring-2 focus:ring-indigo-500/20 font-medium"
 >
 <option value="general">📢 ข่าวสารทั่วไป</option>
 <option value="maintenance">🔧 ซ่อมบำรุง/ระบบหอพัก</option>
 <option value="billing">💳 แจ้งชำระเงิน</option>
 <option value="urgent">⚠️ ด่วนมาก</option>
 </select>
 </div>

 <div className="flex flex-col justify-end">
 <label 
 onClick={() => setIsPinned(!isPinned)}
 className={`p-2.5 border rounded-xl flex items-center justify-between cursor-pointer transition-all ${
 isPinned ? 'border-amber-400 bg-[#F59B23]/8 text-amber-900 font-bold' : 'border-[#E0E0DB] bg-[#F0F0EB] text-[#6B6B66]'
 }`}
 >
 <span className="flex items-center gap-1.5">
 <Pin className={`w-4 h-4 ${isPinned ? 'fill-amber-600 text-[#F59B23]' : ''}`} />
 ปักหมุดไว้บนสุด
 </span>
 <input
 type="checkbox"
 checked={isPinned}
 onChange={(e) => setIsPinned(e.target.checked)}
 className="rounded text-[#F59B23] focus:ring-amber-500 h-4 w-4"
 />
 </label>
 </div>
 </div>

 {/* Content */}
 <div>
 <label className="block font-semibold text-[#6B6B66] mb-1.5">รายละเอียดประกาศ *</label>
 <textarea
 rows={4}
 required
 placeholder="เขียนรายละเอียด คำอธิบาย คำแนะนำเพิ่มเติม..."
 value={content}
 onChange={(e) => setContent(e.target.value)}
 className="w-full p-3 border border-[#E0E0DB] rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 leading-relaxed"
 />
 </div>

 {/* Image URL */}
 <div>
 <label className="block font-semibold text-[#6B6B66] mb-1.5">URL รูปภาพประกอบ (ถ้ามี)</label>
 <input
 type="url"
 placeholder="https://..."
 value={imageUrl}
 onChange={(e) => setImageUrl(e.target.value)}
 className="w-full p-2.5 border border-[#E0E0DB] rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
 />
 </div>

 {/* Actions */}
 <div className="pt-3 border-t border-[#E0E0DB] flex items-center justify-end gap-3">
 <button
 type="button"
 onClick={() => { setIsCreateModalOpen(false); setIsEditModalOpen(false); }}
 className="px-4 py-2.5 text-[#6B6B66] hover:bg-[#E8E8E3] rounded-xl transition-colors font-medium"
 >
 ยกเลิก
 </button>
 <button
 type="submit"
 disabled={isSubmitting}
 className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-[#1A1A1A] rounded-xl font-bold transition-all flex items-center gap-1.5 cursor-pointer"
 >
 {isSubmitting ? 'กำลังบันทึก...' : isEditModalOpen ? 'บันทึกการแก้ไข' : 'โพสต์ประกาศข่าวสาร'}
 </button>
 </div>
 </form>
 </motion.div>
 </div>
 )}
 </AnimatePresence>
 </div>
 );
};
