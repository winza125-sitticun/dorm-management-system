import React, { useEffect, useMemo, useState } from 'react';
import { AlertTriangle, CheckCircle, DatabaseBackup, Download, FileArchive, Lock, RefreshCw, Upload } from 'lucide-react';
import { BACKUP_ARCHIVE_MAX_BYTES, type BackupDataV1, type BackupManifestV1 } from '../utils/backupFormat.ts';
import { createDormBackupArchive, parseDormBackupArchive } from '../utils/backupArchive.ts';
import { getApiErrorMessage, unwrapApiData } from '../utils/api.ts';
import { hasPlanFeature, normalizeSubscriptionPlan } from '../constants/planEntitlements.ts';
import { backupFilename, canStartRestore } from '../utils/backupRestoreUi.ts';

type Preview = Record<string, { current: number; backup: number }>;
type ReadyState = {
  manifest: BackupManifestV1;
  data: BackupDataV1;
  restoreToken: string;
  preview: Preview;
  warnings: string[];
};

interface BackupRestoreSettingsProps {
  idToken?: string | null;
  subscriptionPlan?: string | null;
  role?: string | null;
  showToast?: (message: string, type?: 'success' | 'error' | 'info' | 'warning') => void;
  onRestoreSuccess?: () => Promise<void> | void;
}

function downloadBytes(bytes: Uint8Array, filename: string) {
  const copy = new Uint8Array(bytes.byteLength);
  copy.set(bytes);
  const blob = new Blob([copy.buffer], { type: 'application/octet-stream' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 0);
}

export const BackupRestoreSettings: React.FC<BackupRestoreSettingsProps> = ({
  idToken,
  subscriptionPlan,
  role,
  showToast,
  onRestoreSuccess,
}) => {
  const plan = normalizeSubscriptionPlan(subscriptionPlan);
  const isAdmin = ['owner', 'super_admin'].includes(String(role || '').toLowerCase());
  const canBackup = isAdmin && hasPlanFeature(plan, 'backupExport');
  const canRestore = isAdmin && hasPlanFeature(plan, 'backupRestore');
  const [deploymentMode, setDeploymentMode] = useState<'checking' | 'd1' | 'unsupported'>('checking');
  const [busy, setBusy] = useState(false);
  const [ready, setReady] = useState<ReadyState | null>(null);
  const [confirmed, setConfirmed] = useState(false);
  const [typed, setTyped] = useState('');
  const [message, setMessage] = useState<string | null>(null);
  const [recovery, setRecovery] = useState<{ message: string; preRestoreDataSha256?: string | null } | null>(null);

  const headers = useMemo(() => ({ Authorization: `Bearer ${idToken || ''}` }), [idToken]);

  useEffect(() => {
    let alive = true;
    fetch('/api/health', { headers }).then(async (response) => {
      if (!response.ok) throw new Error('health');
      const payload = unwrapApiData<any>(await response.json());
      if (alive) setDeploymentMode(payload?.mode === 'cloudflare-pages' ? 'd1' : 'unsupported');
    }).catch(() => { if (alive) setDeploymentMode('unsupported'); });
    return () => { alive = false; };
  }, [headers]);

  const fetchExport = async () => {
    const response = await fetch('/api/admin/backup/export', { headers });
    const payload = await response.json().catch(() => null);
    if (!response.ok) throw new Error(getApiErrorMessage(payload, 'ไม่สามารถสร้าง Backup ได้'));
    return unwrapApiData<{ manifest: BackupManifestV1; data: BackupDataV1 }>(payload);
  };

  const handleBackup = async () => {
    setBusy(true); setMessage(null); setRecovery(null);
    try {
      const exported = await fetchExport();
      downloadBytes(createDormBackupArchive(exported.manifest, exported.data), backupFilename());
      setMessage('ดาวน์โหลดไฟล์ .dormbackup เรียบร้อยแล้ว');
      showToast?.('ดาวน์โหลด Backup สำเร็จ', 'success');
    } catch (error: any) {
      const text = error?.message || 'ไม่สามารถสร้าง Backup ได้';
      setMessage(text); showToast?.(text, 'error');
    } finally { setBusy(false); }
  };

  const handleFile = async (file: File | null) => {
    setReady(null); setConfirmed(false); setTyped(''); setMessage(null); setRecovery(null);
    if (!file) return;
    if (file.size > BACKUP_ARCHIVE_MAX_BYTES) { setMessage('ไฟล์ .dormbackup มีขนาดเกิน 10 MB'); return; }
    setBusy(true);
    try {
      const parsed = parseDormBackupArchive(new Uint8Array(await file.arrayBuffer()));
      const response = await fetch('/api/admin/backup/validate', {
        method: 'POST',
        headers: { ...headers, 'Content-Type': 'application/json' },
        body: JSON.stringify(parsed),
      });
      const payload = await response.json().catch(() => null);
      if (!response.ok) throw new Error(getApiErrorMessage(payload, 'ตรวจสอบ Backup ไม่ผ่าน'));
      const validation = unwrapApiData<any>(payload);
      if (validation?.valid !== true || !validation.restoreToken) throw new Error('Server ไม่อนุมัติ Restore');
      setReady({ ...parsed, restoreToken: validation.restoreToken, preview: validation.preview || {}, warnings: validation.warnings || [] });
      setMessage('ตรวจสอบ Backup ผ่าน สามารถตรวจ Preview ก่อน Restore ได้');
    } catch (error: any) {
      setMessage(error?.message || 'ไฟล์ .dormbackup ไม่ถูกต้อง');
    } finally { setBusy(false); }
  };

  const handleRestore = async () => {
    if (!ready || !canStartRestore({ validated: true, confirmed, typed, allowed: canRestore && deploymentMode === 'd1', busy })) return;
    setBusy(true); setMessage(null); setRecovery(null);
    try {
      // Safety invariant: download a fresh logical backup before the destructive request.
      const pre = await fetchExport();
      const preBytes = createDormBackupArchive(pre.manifest, pre.data);
      downloadBytes(preBytes, backupFilename('pre-restore'));

      const response = await fetch('/api/admin/backup/restore', {
        method: 'POST',
        headers: { ...headers, 'Content-Type': 'application/json' },
        body: JSON.stringify({ manifest: ready.manifest, data: ready.data, restoreToken: ready.restoreToken, confirmation: 'RESTORE' }),
      });
      const payload = await response.json().catch(() => null);
      if (!response.ok) {
        const error = payload?.error || {};
        if (error.recoveryRequired) setRecovery({ message: error.message || 'Restore ไม่สมบูรณ์', preRestoreDataSha256: error.preRestoreDataSha256 });
        throw new Error(getApiErrorMessage(payload, 'Restore ไม่สำเร็จ'));
      }
      await onRestoreSuccess?.();
      setMessage('Restore สำเร็จ และรีเฟรชข้อมูลล่าสุดแล้ว');
      setReady(null); setConfirmed(false); setTyped('');
      showToast?.('Restore สำเร็จ', 'success');
    } catch (error: any) {
      const text = error?.message || 'Restore ไม่สำเร็จ';
      setMessage(text); showToast?.(text, 'error');
    } finally { setBusy(false); }
  };

  const disabledByMode = deploymentMode !== 'd1';
  return (
    <div className="space-y-4 pt-4 border-t border-[#E0E0DB]">
      <h3 className="text-xs font-bold text-[#1A1A1A] border-b border-[#E0E0DB] pb-2 flex items-center gap-2">
        <DatabaseBackup className="w-4 h-4 text-[#1DB954]" />
        <span>สำรองและกู้คืนข้อมูล (.dormbackup)</span>
      </h3>

      {deploymentMode === 'checking' && <div className="text-xs text-[#6B6B66] flex gap-2"><RefreshCw className="w-4 h-4 animate-spin" />กำลังตรวจโหมดฐานข้อมูล...</div>}
      {deploymentMode === 'unsupported' && <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900 flex gap-2"><AlertTriangle className="w-4 h-4 shrink-0" />Backup/Restore V14 รองรับ Cloudflare Pages + D1 เท่านั้น</div>}

      <div className="grid md:grid-cols-2 gap-3">
        <div className="p-4 rounded-2xl border border-[#E0E0DB] bg-white space-y-3">
          <div className="font-bold text-xs flex items-center gap-2"><Download className="w-4 h-4" />Backup</div>
          <p className="text-[11px] text-[#6B6B66]">เก็บข้อมูลธุรกิจและ Settings ที่ปลอดภัย ไม่รวมผู้ใช้ รหัสผ่าน LINE/Google secrets หรือประวัติ Audit</p>
          <button type="button" onClick={handleBackup} disabled={!canBackup || disabledByMode || busy} className="px-4 py-2.5 rounded-xl bg-[#1DB954] text-xs font-bold disabled:opacity-40 flex items-center gap-2">
            <FileArchive className="w-4 h-4" />ดาวน์โหลด .dormbackup
          </button>
        </div>

        <div className="p-4 rounded-2xl border border-[#E0E0DB] bg-white space-y-3">
          <div className="font-bold text-xs flex items-center gap-2"><Upload className="w-4 h-4" />Restore</div>
          {!canRestore && <div className="text-[11px] text-amber-800 flex gap-2"><Lock className="w-4 h-4" />แพ็กเกจ Demo สำรองข้อมูลได้ แต่ Restore ต้องใช้ Basic หรือสูงกว่า</div>}
          <input type="file" accept=".dormbackup,application/octet-stream" disabled={!canRestore || disabledByMode || busy} onChange={(event) => void handleFile(event.target.files?.[0] || null)} className="block w-full text-xs" />
        </div>
      </div>

      {ready && (
        <div className="p-4 rounded-2xl border border-blue-200 bg-blue-50 space-y-3">
          <div className="font-bold text-xs">Preview ก่อน Restore</div>
          <div className="overflow-x-auto"><table className="w-full text-[11px]"><thead><tr><th className="text-left">ข้อมูล</th><th>ปัจจุบัน</th><th>Backup</th></tr></thead><tbody>{(Object.entries(ready.preview) as Array<[string, { current: number; backup: number }]>).map(([key, value]) => <tr key={key}><td>{key}</td><td className="text-center">{value.current}</td><td className="text-center">{value.backup}</td></tr>)}</tbody></table></div>
          {ready.warnings.length > 0 && <ul className="text-[11px] list-disc pl-5">{ready.warnings.map((warning) => <li key={warning}>{warning}</li>)}</ul>}
          <label className="flex gap-2 items-start text-[11px]"><input type="checkbox" checked={confirmed} onChange={(e) => setConfirmed(e.target.checked)} />ฉันตรวจ Preview แล้ว และเข้าใจว่า Restore จะแทนที่ข้อมูลธุรกิจปัจจุบัน</label>
          <input value={typed} onChange={(e) => setTyped(e.target.value)} placeholder="พิมพ์ RESTORE" className="border border-[#D4D4CF] rounded-xl px-3 py-2 text-xs" />
          <button type="button" onClick={handleRestore} disabled={!canStartRestore({ validated: true, confirmed, typed, allowed: canRestore && !disabledByMode, busy })} className="px-4 py-2.5 rounded-xl bg-red-600 text-white text-xs font-bold disabled:opacity-40">ดาวน์โหลด pre-restore แล้วเริ่ม Restore</button>
        </div>
      )}

      {recovery && <div className="p-4 rounded-2xl border-2 border-red-300 bg-red-50 text-xs text-red-900 space-y-1"><div className="font-bold flex items-center gap-2"><AlertTriangle className="w-4 h-4" />ต้องกู้คืนระบบ</div><div>{recovery.message}</div>{recovery.preRestoreDataSha256 && <code className="block break-all text-[10px]">preRestoreDataSha256: {recovery.preRestoreDataSha256}</code>}<div>หยุดแก้ข้อมูลต่อ และใช้ไฟล์ pre-restore ที่ดาวน์โหลดไว้ก่อนเริ่มรายการ</div></div>}
      {message && <div className="text-xs flex items-center gap-2">{message.includes('สำเร็จ') || message.includes('ผ่าน') ? <CheckCircle className="w-4 h-4 text-green-600" /> : <AlertTriangle className="w-4 h-4 text-amber-600" />}{message}</div>}
    </div>
  );
};
