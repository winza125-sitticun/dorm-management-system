import React, { useState, useMemo } from 'react';
import { Bill, Room, Settings, UserProfile } from '../types.ts';
import { 
 FileSpreadsheet, 
 Calendar, 
 ChevronRight, 
 TrendingUp, 
 Coins, 
 CheckCircle, 
 XCircle, 
 Clock, 
 Eye, 
 MessageSquare,
 Printer,
 Download,
 Flame,
 Droplet,
 Zap,
 Check,
 AlertCircle,
 HelpCircle,
 TrendingDown
} from 'lucide-react';
import { motion } from 'motion/react';
import { 
 ResponsiveContainer, 
 LineChart, 
 Line, 
 XAxis, 
 YAxis, 
 CartesianGrid, 
 Tooltip, 
 Legend 
} from 'recharts';

interface ReportViewProps {
 bills: Bill[];
 rooms: Room[];
 settings: Settings;
 loading: boolean;
 onUpdateBill: (billId: number, billData: Partial<Bill>) => Promise<void>;
 onViewBillDetails: (bill: Bill) => void;
 idToken?: string | null;
 userProfile?: UserProfile | null;
}

export const ReportView: React.FC<ReportViewProps> = ({
 bills,
 rooms,
 settings,
 loading,
 onUpdateBill,
 onViewBillDetails,
 idToken,
 userProfile
}) => {
 const canEditPayments = userProfile?.role === 'owner' || userProfile?.permissions?.split(',').includes('edit_payments');

 const safeBills = Array.isArray(bills) ? bills : [];
 const safeRooms = Array.isArray(rooms) ? rooms : [];

 // Find latest available month in bills, default to current local year-month
 const latestMonthInBills = useMemo(() => {
 if (safeBills.length === 0) {
 const d = new Date();
 const year = d.getFullYear();
 const month = String(d.getMonth() + 1).padStart(2, '0');
 return `${year}-${month}`;
 }
 const sorted = [...safeBills].sort((a, b) => b.billMonth.localeCompare(a.billMonth));
 return sorted[0].billMonth;
 }, [safeBills]);

 const [selectedMonth, setSelectedMonth] = useState<string>(latestMonthInBills);
 
 // State for the meter history room selection
 const [selectedRoomId, setSelectedRoomId] = useState<number>(() => {
 if (safeRooms.length > 0) {
 // Prioritize occupied rooms
 const occupied = safeRooms.find(r => r.status === 'occupied');
 return occupied ? occupied.id : safeRooms[0].id;
 }
 return 0;
 });

 const [csvCopied, setCsvCopied] = useState(false);
 const [isExportingSheet, setIsExportingSheet] = useState(false);

 // Helper to format Thai months
 const formatThaiMonth = (monthStr: string) => {
 if (!monthStr) return '';
 const [year, month] = monthStr.split('-');
 const months = [
 'มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน',
 'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'
 ];
 return `${months[parseInt(month) - 1]} ${parseInt(year) + 543}`;
 };

 const formatThaiMonthShort = (monthStr: string) => {
 if (!monthStr) return '';
 const [year, month] = monthStr.split('-');
 const monthsShort = [
 'ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.',
 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'
 ];
 return `${monthsShort[parseInt(month) - 1]} ${(parseInt(year) + 543).toString().substring(2)}`;
 };

 // 1. MONTHLY SUMMARY REPORT CALCULATIONS
 // We want to list ALL rooms, and join with their bill for the selected month (if exists)
 const roomBillsReport = useMemo(() => {
 return rooms.map(room => {
 const bill = bills.find(b => b.roomId === room.id && b.billMonth === selectedMonth);
 
 const elecUnits = bill ? Math.max(0, bill.currentElec - bill.priorElec - (bill.elecDeduct ?? 0)) : 0;
 const elecCost = bill ? ((bill.elecCost !== undefined && bill.elecCost !== null) ? bill.elecCost : Math.round(elecUnits * bill.elecUnitCost)) : 0;
 const waterUnits = bill ? Math.max(0, bill.currentWater - bill.priorWater) : 0;
 const waterCost = bill ? (bill.waterCost !== undefined ? bill.waterCost : (waterUnits > 0 ? Math.round(waterUnits * bill.waterUnitCost) : 0)) : 0;
 const otherCost = bill ? bill.otherCost : 0;
 const rentCost = bill ? bill.rentCost : (room.status === 'occupied' ? room.monthlyRent : 0);
 const totalCost = bill ? bill.totalCost : rentCost;

 return {
 room,
 bill,
 rentCost,
 priorElec: bill ? bill.priorElec : null,
 currentElec: bill ? bill.currentElec : null,
 elecUnits,
 elecCost,
 priorWater: bill ? bill.priorWater : null,
 currentWater: bill ? bill.currentWater : null,
 waterUnits,
 waterCost,
 otherCost,
 totalCost,
 status: bill ? bill.status : 'no_bill'
 };
 }).sort((a, b) => a.room.roomNumber.localeCompare(b.room.roomNumber, undefined, { numeric: true, sensitivity: 'base' }));
 }, [rooms, bills, selectedMonth]);

 // Aggregate metrics for cards and bottom totals row
 const aggregates = useMemo(() => {
 let totalRent = 0;
 let totalElecCost = 0;
 let totalWaterCost = 0;
 let totalOtherCost = 0;
 let grandTotal = 0;
 let paidCount = 0;
 let unpaidCount = 0;
 let noBillCount = 0;
 let totalBillsCount = 0;
 let paidAmount = 0;
 let unpaidAmount = 0;

 roomBillsReport.forEach(item => {
 totalRent += item.rentCost;
 totalElecCost += item.elecCost;
 totalWaterCost += item.waterCost;
 totalOtherCost += item.otherCost;
 grandTotal += item.totalCost;

 if (item.bill) {
 totalBillsCount++;
 if (item.status === 'paid') {
 paidCount++;
 paidAmount += item.totalCost;
 } else {
 unpaidCount++;
 unpaidAmount += item.totalCost;
 }
 } else {
 noBillCount++;
 }
 });

 return {
 totalRent,
 totalElecCost,
 totalWaterCost,
 totalOtherCost,
 grandTotal,
 paidCount,
 unpaidCount,
 noBillCount,
 totalBillsCount,
 paidAmount,
 unpaidAmount,
 completionRate: totalBillsCount > 0 ? Math.round((paidCount / totalBillsCount) * 100) : 0
 };
 }, [roomBillsReport]);

 // 2. METER HISTORY CALCULATIONS (6 MONTHS)
 // For the selected room, retrieve up to 6 months of historical bills in chronological order
 const roomHistoryData = useMemo(() => {
 if (!selectedRoomId) return [];
 
 // Find bills for this room, sort chronologically
 const filtered = bills
 .filter(b => b.roomId === selectedRoomId)
 .sort((a, b) => a.billMonth.localeCompare(b.billMonth));
 
 // Take the last 6 months of bills
 const last6 = filtered.slice(-6);

 return last6.map(b => {
 const elecUnits = Math.max(0, b.currentElec - b.priorElec - (b.elecDeduct ?? 0));
 const waterUnits = Math.max(0, b.currentWater - b.priorWater);
 const waterCost = b.waterCost !== undefined ? b.waterCost : (waterUnits > 0 ? Math.round(waterUnits * b.waterUnitCost) : 0);
 return {
 month: b.billMonth,
 monthThai: formatThaiMonthShort(b.billMonth),
 electricityUnits: elecUnits,
 electricityCost: (b.elecCost !== undefined && b.elecCost !== null) ? b.elecCost : Math.round(elecUnits * b.elecUnitCost),
 waterUnits,
 waterCost,
 totalCost: b.totalCost,
 priorElec: b.priorElec,
 currentElec: b.currentElec,
 priorWater: b.priorWater,
 currentWater: b.currentWater,
 status: b.status,
 bill: b
 };
 });
 }, [bills, selectedRoomId]);

 const selectedRoomDetails = useMemo(() => {
 return rooms.find(r => r.id === selectedRoomId);
 }, [rooms, selectedRoomId]);

 // Quick toggle payment status
 const handleToggleStatus = async (billId: number, currentStatus: 'paid' | 'unpaid') => {
 if (!canEditPayments) {
 alert('คุณไม่มีสิทธิ์ในการแก้ไขสถานะการชำระเงินของบิลพัก');
 return;
 }
 const nextStatus = currentStatus === 'paid' ? 'unpaid' : 'paid';
 try {
 await onUpdateBill(billId, { 
 status: nextStatus,
 paidAt: nextStatus === 'paid' ? new Date().toISOString() : null
 });
 } catch (err: any) {
 alert('เกิดข้อผิดพลาดในการสลับสถานะบิล: ' + err.message);
 }
 };

 // Export CSV Report of the summary table
 const handleExportCSV = () => {
 const headers = [
 'ห้อง (Room)',
 'ค่าเช่าบ้าน (Rent)',
 'มิเตอร์ไฟก่อน (Elec Before)',
 'มิเตอร์ไฟหลัง (Elec After)',
 'จำนวนหน่วยไฟ (Elec Units)',
 'ค่าไฟ (Elec Cost)',
 'มิเตอร์น้ำก่อน (Water Before)',
 'มิเตอร์น้ำหลัง (Water After)',
 'จำนวนหน่วยน้ำ (Water Units)',
 'ค่าน้ำ (Water Cost)',
 'ค่าใช้จ่ายอื่น/บริการ (Other Cost)',
 'รวมยอดสุทธิ (Total Cost)',
 'สถานะบิล (Status)'
 ];

 const rows = roomBillsReport.map(item => [
 item.room.roomNumber,
 item.rentCost,
 item.priorElec !== null ? item.priorElec : '',
 item.currentElec !== null ? item.currentElec : '',
 item.bill ? item.elecUnits : '',
 item.elecCost,
 item.priorWater !== null ? item.priorWater : '',
 item.currentWater !== null ? item.currentWater : '',
 item.bill ? item.waterUnits : '',
 item.waterCost,
 item.otherCost,
 item.totalCost,
 item.status === 'paid' ? 'จ่ายแล้ว' : (item.status === 'unpaid' ? 'ยังไม่ได้จ่าย' : 'ยังไม่มีบิล')
 ]);

 // Footer row
 rows.push([
 'รวมทั้งสิ้น (Total)',
 aggregates.totalRent,
 '',
 '',
 '',
 aggregates.totalElecCost,
 '',
 '',
 '',
 aggregates.totalWaterCost,
 aggregates.totalOtherCost,
 aggregates.grandTotal,
 ''
 ]);

 const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
 const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
 const url = URL.createObjectURL(blob);
 
 const link = document.createElement('a');
 link.setAttribute('href', url);
 link.setAttribute('download', `Dorm_Monthly_Report_${selectedMonth}.csv`);
 link.style.visibility = 'hidden';
 document.body.appendChild(link);
 link.click();
 document.body.removeChild(link);
 };

 // Export to Google Sheet (API Integration)
 const handleExportGoogleSheet = async () => {
 if (!settings?.googleSpreadsheetId) {
 alert('กรุณาตั้งค่า Google Spreadsheet ID ในหน้าการตั้งค่าก่อนครับ');
 return;
 }

 try {
 setIsExportingSheet(true);
 const headers = [
 'ห้อง (Room)', 'ค่าเช่าบ้าน (Rent)', 'มิเตอร์ไฟก่อน (Elec Before)', 'มิเตอร์ไฟหลัง (Elec After)',
 'จำนวนหน่วยไฟ (Elec Units)', 'ค่าไฟ (Elec Cost)', 'มิเตอร์น้ำก่อน (Water Before)', 'มิเตอร์น้ำหลัง (Water After)',
 'จำนวนหน่วยน้ำ (Water Units)', 'ค่าน้ำ (Water Cost)', 'ค่าใช้จ่ายอื่น/บริการ (Other Cost)',
 'รวมยอดสุทธิ (Total Cost)', 'สถานะบิล (Status)'
 ];

 const rows = roomBillsReport.map(item => [
 item.room.roomNumber,
 item.rentCost,
 item.priorElec !== null ? item.priorElec : '',
 item.currentElec !== null ? item.currentElec : '',
 item.bill ? item.elecUnits : '',
 item.elecCost,
 item.priorWater !== null ? item.priorWater : '',
 item.currentWater !== null ? item.currentWater : '',
 item.bill ? item.waterUnits : '',
 item.waterCost,
 item.otherCost,
 item.totalCost,
 item.status === 'paid' ? 'จ่ายแล้ว' : (item.status === 'unpaid' ? 'ยังไม่ได้จ่าย' : 'ยังไม่มีบิล')
 ]);

 rows.push([
 'รวมทั้งสิ้น (Total)', aggregates.totalRent, '', '', '', aggregates.totalElecCost,
 '', '', '', aggregates.totalWaterCost, aggregates.totalOtherCost, aggregates.grandTotal, ''
 ]);

 // 1. Get access token
 const tokenRes = await fetch('/api/google-sheets/token', {
 headers: { 'Authorization': `Bearer ${idToken}` }
 });
 if (!tokenRes.ok) {
 const err = await tokenRes.json().catch(() => ({}));
 throw new Error(err.error?.message || 'ไม่สามารถดึงข้อมูล Token ได้ กรุณาเชื่อมต่อบัญชี Google ใหม่อีกครั้งในการตั้งค่า');
 }
 const tokenData = await tokenRes.json();
 const accessToken = tokenData.data.accessToken;
 const spreadsheetId = settings.googleSpreadsheetId;
 const sheetTitle = `Report_${selectedMonth}_${Date.now().toString().slice(-4)}`;

 // 2. Create new sheet
 const batchUpdateRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}:batchUpdate`, {
 method: 'POST',
 headers: {
 'Authorization': `Bearer ${accessToken}`,
 'Content-Type': 'application/json'
 },
 body: JSON.stringify({
 requests: [{ addSheet: { properties: { title: sheetTitle } } }]
 })
 });

 if (!batchUpdateRes.ok) {
 const err = await batchUpdateRes.json().catch(() => ({}));
 throw new Error(err.error?.message || 'ไม่สามารถสร้างแผ่นงานใหม่ใน Google Sheet ได้');
 }

 // 3. Append data
 const appendRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(sheetTitle)}!A1:append?valueInputOption=USER_ENTERED`, {
 method: 'POST',
 headers: {
 'Authorization': `Bearer ${accessToken}`,
 'Content-Type': 'application/json'
 },
 body: JSON.stringify({ values: [headers, ...rows] })
 });

 if (!appendRes.ok) {
 const err = await appendRes.json().catch(() => ({}));
 throw new Error(err.error?.message || 'ไม่สามารถเพิ่มข้อมูลลงในแผ่นงานได้');
 }

 alert('ส่งออกข้อมูลไปยัง Google Sheet สำเร็จแล้วครับ!');
 window.open(`https://docs.google.com/spreadsheets/d/${spreadsheetId}`, '_blank');
 } catch (err: any) {
 console.error('Export error:', err);
 alert('เกิดข้อผิดพลาด: ' + err.message);
 } finally {
 setIsExportingSheet(false);
 }
 };

 const handleSendBillLine = async (billId: number, roomNum: string) => {
 try {
 const res = await fetch(`/api/line/send-bill/${billId}`, {
 method: 'POST',
 headers: {
 'Content-Type': 'application/json',
 'Authorization': `Bearer ${idToken}`
 }
 });
  const data = await res.json();
  if (res.ok) {
  alert(`ส่งบิลแจ้งหนี้ห้อง ${roomNum} เข้าไลน์สำเร็จเรียบร้อยแล้วค่ะ!`);
  } else {
  const errorMessage = typeof data.error === 'string'
    ? data.error
    : (data.error?.message || data.message || 'ไม่มีคู่สาย LINE ที่เชื่อมต่ออยู่กับห้องนี้');
  alert(`ไม่สามารถส่งบิลเข้าไลน์ได้: ${errorMessage}`);
 }
 } catch (err: any) {
 alert(`เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์: ${err.message}`);
 }
 };

 return (
 <div className="space-y-8 font-sans">
 
 {/* 1. TOP HEADER SECTION */}
 <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-[#E0E0DB] no-print">
 <div>
 <h2 className="text-xl font-bold text-[#1A1A1A] flex items-center gap-2">
 <FileSpreadsheet className="w-5.5 h-5.5 text-[#1DB954]" />
 <span>หน้ารายงานรวมและการใช้พลังงาน</span>
 </h2>
 <p className="text-xs text-[#8A8A85] mt-1">
 รายงานวิเคราะห์ข้อมูลค่าใช้จ่ายหอพักรายเดือนในรูปแบบตารางสรุป และประวัติบันทึกค่ามิเตอร์ไฟ-น้ำย้อนหลัง 6 เดือน
 </p>
 </div>

 <div className="flex flex-wrap items-center gap-2">
 {/* Month selector widget */}
 <div className="flex items-center gap-2 bg-white px-3.5 py-1.5 rounded-xl border border-[#E0E0DB] ">
 <Calendar className="w-4 h-4 text-[#8A8A85]" />
 <input 
 type="month"
 value={selectedMonth}
 onChange={(e) => setSelectedMonth(e.target.value)}
 className="text-xs font-bold text-[#6B6B66] focus:outline-none cursor-pointer"
 />
 </div>

 <button
 onClick={handleExportGoogleSheet}
 disabled={isExportingSheet}
 className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-[#6B6B66] bg-white border border-[#E0E0DB] rounded-xl hover:bg-[#E8E8E3] disabled:opacity-50 transition cursor-pointer"
 title="ส่งออกข้อมูลไปยัง Google Sheet"
 >
 {isExportingSheet ? (
 <span className="w-4 h-4 border-2 border-[#1DB954]/30 border-t-[#1DB954] rounded-full animate-spin"></span>
 ) : (
 <FileSpreadsheet className="w-4 h-4 text-[#1DB954]" />
 )}
 <span>ส่งออกไป Google Sheet</span>
 </button>

 <button
 onClick={handleExportCSV}
 className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-[#6B6B66] bg-white border border-[#E0E0DB] rounded-xl hover:bg-[#E8E8E3] transition cursor-pointer"
 >
 <Download className="w-4 h-4 text-[#8A8A85]" />
 <span>ส่งออกตารางสรุป (CSV)</span>
 </button>

 <button
 onClick={() => window.print()}
 className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-[#1A1A1A] bg-[#1DB954] hover:bg-[#1ED760] hover:scale-[1.04] rounded-xl transition cursor-pointer"
 >
 <Printer className="w-4 h-4" />
 <span>พิมพ์รายงาน (Print)</span>
 </button>
 </div>
 </div>

 {/* 2. STATS OVERVIEW CARDS */}
 <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 no-print">
 <div className="bg-white border border-[#E0E0DB] rounded-2xl p-4.5 ">
 <p className="text-[10px] font-bold text-[#8A8A85] uppercase tracking-wider">ยอดเงินสรุปประจำเดือน ({formatThaiMonthShort(selectedMonth)})</p>
 <div className="flex items-baseline gap-1 mt-1.5">
 <span className="text-xl font-black text-[#1A1A1A] font-sans">{aggregates.grandTotal.toLocaleString()}</span>
 <span className="text-xxs text-[#8A8A85] font-bold">บาท</span>
 </div>
 <div className="mt-2.5 flex items-center gap-1 text-[9px] text-[#8A8A85] font-medium">
 <span>ค่าบ้าน: {aggregates.totalRent.toLocaleString()} บ. | ไฟ: {aggregates.totalElecCost.toLocaleString()} บ.</span>
 </div>
 </div>

 <div className="bg-[#1DB954]/10/50 border border-emerald-150 rounded-2xl p-4.5 ">
 <p className="text-[10px] font-bold text-[#1DB954] uppercase tracking-wider">รับชำระแล้ว (Paid Amount)</p>
 <div className="flex items-baseline gap-1 mt-1.5">
 <span className="text-xl font-black text-[#1DB954] font-sans">{aggregates.paidAmount.toLocaleString()}</span>
 <span className="text-xxs text-[#1DB954] font-bold">บาท</span>
 </div>
 <div className="mt-2.5 flex items-center gap-1 text-[9px] text-[#1DB954] font-bold">
 <CheckCircle className="w-3 h-3 shrink-0" />
 <span>ชำระแล้ว {aggregates.paidCount} ห้อง จากทั้งหมด {aggregates.totalBillsCount} ห้องที่มีบิล</span>
 </div>
 </div>

 <div className="bg-[#E22134]/10/50 border border-rose-150 rounded-2xl p-4.5 ">
 <p className="text-[10px] font-bold text-[#E22134] uppercase tracking-wider">ยอดค้างจ่าย (Unpaid Surcharges)</p>
 <div className="flex items-baseline gap-1 mt-1.5">
 <span className="text-xl font-black text-[#E22134] font-sans">{aggregates.unpaidAmount.toLocaleString()}</span>
 <span className="text-xxs text-[#E22134] font-bold">บาท</span>
 </div>
 <div className="mt-2.5 flex items-center gap-1 text-[9px] text-[#E22134] font-bold">
 <Clock className="w-3 h-3 shrink-0" />
 <span>ค้างชำระอยู่ {aggregates.unpaidCount} ห้อง ({aggregates.noBillCount} ห้องไม่มีข้อมูลบิล)</span>
 </div>
 </div>

 <div className="bg-[#F0F0EB] border border-[#E0E0DB] rounded-2xl p-4.5 ">
 <p className="text-[10px] font-bold text-[#8A8A85] uppercase tracking-wider">อัตราการเก็บค่าเช่าสำเร็จ</p>
 <div className="flex items-baseline gap-1 mt-1.5">
 <span className="text-xl font-black text-[#1A1A1A] font-sans">{aggregates.completionRate}%</span>
 <span className="text-xxs text-[#8A8A85] font-bold">จากยอดเรียกเก็บ</span>
 </div>
 {/* Mini progress bar */}
 <div className="mt-3.5 w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
 <div 
 className="bg-emerald-500 h-full rounded-full transition-all duration-500" 
 style={{ width: `${aggregates.completionRate}%` }}
 />
 </div>
 </div>
 </div>

 {/* 3. SECTION: THE CONSOLIDATED SPREADSHEET */}
 <div className="bg-white border border-[#E0E0DB] rounded-3xl overflow-hidden p-1 sm:p-5">
 <div className="p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-[#E0E0DB] mb-4">
 <div>
 <h3 className="text-sm font-extrabold text-[#1A1A1A] flex items-center gap-1.5">
 <span>ตารางสรุปงบดุลรอบเดือน:</span>
 <span className="text-[#1DB954] font-black underline decoration-dashed decoration-2">{formatThaiMonth(selectedMonth)}</span>
 </h3>
 <p className="text-[10px] text-[#8A8A85] mt-0.5">
 แสดงค่าเช่า, เลขมิเตอร์, หน่วยการใช้, คำนวณค่าน้ำ-ไฟ และยอดสุทธิแบบรวมทุกห้องพัก
 </p>
 </div>
 <div className="flex items-center gap-2 text-xxs bg-[#F59B23]/8 text-[#F59B23] border border-[#F59B23]/30 rounded-xl px-3 py-1.5 font-bold no-print">
 <Zap className="w-3.5 h-3.5 text-[#F59B23]" />
 <span>หมายเหตุ: การคิดค่าน้ำประปา รวมค่าจ่ายบิลพื้นฐาน 10 บาท/ห้อง ในตารางแล้ว</span>
 </div>
 </div>

 {/* Responsive Table Wrapper */}
 <div className="overflow-x-auto">
 <table className="w-full text-left text-xxs border-collapse min-w-[1100px] border border-[#E0E0DB] rounded-2xl overflow-hidden">
 <thead>
 <tr className="bg-[#282828]/80 border-b border-slate-250 text-[#6B6B66] font-bold uppercase tracking-wider text-center">
 <th className="py-3 px-2 border-r border-[#E0E0DB] font-extrabold text-left sticky left-0 bg-[#282828]/90 z-10 w-[110px]">ห้อง (Room)</th>
 <th className="py-3 px-2 border-r border-[#E0E0DB] text-right bg-[#1DB954]/10/30">ค่าบ้าน</th>
 <th className="py-3 px-1.5 border-r border-[#E0E0DB] bg-[#F59B23]/10/20">มิเตอร์ไฟก่อน</th>
 <th className="py-3 px-1.5 border-r border-[#E0E0DB] bg-[#F59B23]/10/30 font-black">มิเตอร์หลัง</th>
 <th className="py-3 px-1.5 border-r border-[#E0E0DB] bg-[#F59B23]/10/20">จำนวนหน่วย</th>
 <th className="py-3 px-2 border-r border-[#E0E0DB] text-right bg-[#F59B23]/10/40 font-bold text-amber-900">ค่าไฟ</th>
 <th className="py-3 px-1.5 border-r border-[#E0E0DB] bg-[#1DB954]/10/10">มิเตอร์น้ำก่อน</th>
 <th className="py-3 px-1.5 border-r border-[#E0E0DB] bg-[#1DB954]/10/20 font-black">มิเตอร์น้ำหลัง</th>
 <th className="py-3 px-1.5 border-r border-[#E0E0DB] bg-[#1DB954]/10/10">จำนวนหน่วย</th>
 <th className="py-3 px-2 border-r border-[#E0E0DB] text-right bg-[#1DB954]/10/30 font-bold text-blue-950">ค่าน้ำ</th>
 <th className="py-3 px-2 border-r border-[#E0E0DB] text-right bg-[#E22134]/10/10">ค่าอื่นๆ/บริการ</th>
 <th className="py-3 px-3 border-r border-slate-250 text-right font-black bg-[#282828]/60 text-[#1A1A1A]">รวมยอดบิล</th>
 <th className="py-3 px-2 border-r border-[#E0E0DB] text-center sticky right-[60px] bg-[#282828]/90 shadow-[-4px_0_12px_rgba(0,0,0,0.03)] z-10">สถานะบิล</th>
 <th className="py-3 px-2 text-center sticky right-0 bg-[#282828]/90 z-10 w-[60px] no-print">เครื่องมือ</th>
 </tr>
 </thead>
 <tbody className="divide-y divide-slate-200 font-sans">
 {roomBillsReport.map(({ room, bill, rentCost, priorElec, currentElec, elecUnits, elecCost, priorWater, currentWater, waterUnits, waterCost, otherCost, totalCost, status }) => {
 const isNoBill = status === 'no_bill';
 return (
 <tr key={room.id} className="hover:bg-[#E8E8E3] transition text-center group">
 {/* Room Number - Sticky Left */}
 <td className="py-2.5 px-3 border-r border-[#E0E0DB] text-left font-black text-[#1A1A1A] sticky left-0 bg-white group-hover:bg-slate-50 z-10">
 <div className="flex items-center justify-between">
 <span>ห้อง {room.roomNumber}</span>
 {room.status === 'vacant' && (
 <span className="text-[8px] px-1 bg-[#F0F0EB] text-[#8A8A85] rounded-sm font-semibold">ว่าง</span>
 )}
 </div>
 </td>
 
 {/* Rent Cost */}
 <td className="py-2.5 px-2 border-r border-[#E0E0DB] text-right font-medium text-[#1A1A1A] bg-[#1DB954]/10/10">
 {rentCost > 0 ? rentCost.toLocaleString() : '-'}
 </td>

 {/* Electricity - Before */}
 <td className="py-2.5 px-1.5 border-r border-[#E0E0DB] text-[#8A8A85] font-mono bg-[#F59B23]/10/5">
 {priorElec !== null ? priorElec : <span className="text-[#8A8A85]">-</span>}
 </td>

 {/* Electricity - After */}
 <td className="py-2.5 px-1.5 border-r border-[#E0E0DB] text-[#1A1A1A] font-mono font-bold bg-[#F59B23]/10/10">
 {currentElec !== null ? currentElec : <span className="text-[#8A8A85]">-</span>}
 </td>

 {/* Electricity - Units */}
 <td className="py-2.5 px-1.5 border-r border-[#E0E0DB] text-[#6B6B66] font-mono font-bold bg-[#F59B23]/10/5">
 {!isNoBill ? elecUnits : <span className="text-[#8A8A85]">-</span>}
 </td>

 {/* Electricity - Cost */}
 <td className="py-2.5 px-2 border-r border-[#E0E0DB] text-right font-bold text-amber-700 bg-[#F59B23]/10/15">
 {!isNoBill && elecCost > 0 ? elecCost.toLocaleString() : <span className="text-[#8A8A85]">-</span>}
 </td>

 {/* Water - Before */}
 <td className="py-2.5 px-1.5 border-r border-[#E0E0DB] text-[#8A8A85] font-mono bg-[#1DB954]/10/5">
 {priorWater !== null ? priorWater : <span className="text-[#8A8A85]">-</span>}
 </td>

 {/* Water - After */}
 <td className="py-2.5 px-1.5 border-r border-[#E0E0DB] text-[#1A1A1A] font-mono font-bold bg-[#1DB954]/10/10">
 {currentWater !== null ? currentWater : <span className="text-[#8A8A85]">-</span>}
 </td>

 {/* Water - Units */}
 <td className="py-2.5 px-1.5 border-r border-[#E0E0DB] text-[#6B6B66] font-mono font-bold bg-[#1DB954]/10/5">
 {!isNoBill ? waterUnits : <span className="text-[#8A8A85]">-</span>}
 </td>

 {/* Water - Cost */}
 <td className="py-2.5 px-2 border-r border-[#E0E0DB] text-right font-bold text-blue-700 bg-[#1DB954]/10/15">
 {!isNoBill && waterCost > 0 ? waterCost.toLocaleString() : <span className="text-[#8A8A85]">-</span>}
 </td>

 {/* Surcharge / Other Cost */}
 <td className="py-2.5 px-2 border-r border-[#E0E0DB] text-right font-medium text-[#E22134] bg-[#E22134]/10/5">
 {otherCost > 0 ? otherCost.toLocaleString() : <span className="text-[#8A8A85]">-</span>}
 </td>

 {/* Grand Total */}
 <td className="py-2.5 px-3 border-r border-slate-250 text-right font-black text-[#1A1A1A] bg-[#282828]/40 text-xs">
 {totalCost > 0 ? totalCost.toLocaleString() : <span className="text-[#8A8A85]">-</span>}
 </td>

 {/* Payment Status Dropdown/Selector Button - Sticky Right */}
 <td className="py-2.5 px-2 border-r border-[#E0E0DB] text-center sticky right-[60px] bg-white group-hover:bg-slate-50 shadow-[-4px_0_12px_rgba(0,0,0,0.03)] z-10">
 {isNoBill ? (
 <span className="inline-flex items-center gap-1 text-[9px] font-bold text-[#8A8A85] bg-[#F0F0EB] px-2 py-0.5 rounded-full">
 ยังไม่มีบิล
 </span>
 ) : (
 <button
 onClick={() => bill && handleToggleStatus(bill.id, bill.status)}
 disabled={!canEditPayments}
 className={`inline-flex items-center justify-center gap-1.5 py-1 px-3.5 rounded-full text-[9.5px] font-bold border transition cursor-pointer ${
 status === 'paid'
 ? 'bg-emerald-600 text-[#1A1A1A] border-emerald-600 hover:bg-emerald-700'
 : 'bg-rose-600 text-[#1A1A1A] border-rose-600 hover:bg-rose-700 animate-pulse'
 }`}
 title={canEditPayments ? 'คลิกสลับสถานะชำระเงิน' : 'ค้างจ่าย (คุณไม่มีสิทธิ์สลับสถานะ)'}
 >
 {status === 'paid' ? (
 <>
 <Check className="w-3 h-3 text-[#1A1A1A]" />
 <span>จ่ายแล้ว</span>
 </>
 ) : (
 <>
 <Clock className="w-3 h-3 text-[#1A1A1A]" />
 <span>ยังไม่จ่าย</span>
 </>
 )}
 </button>
 )}
 </td>

 {/* Action buttons - Sticky Right 2 */}
 <td className="py-2.5 px-2 text-center sticky right-0 bg-white group-hover:bg-slate-50 z-10 no-print">
 {!isNoBill && bill ? (
 <div className="flex justify-center gap-1">
 <button
 onClick={() => onViewBillDetails(bill)}
 className="p-1 rounded bg-[#F0F0EB] hover:bg-slate-200 text-[#6B6B66] transition"
 title="เปิดส่องดูใบแจ้งหนี้"
 >
 <Eye className="w-3 h-3" />
 </button>
 <button
 onClick={() => handleSendBillLine(bill.id, room.roomNumber)}
 className="p-1 rounded bg-[#1DB954]/8 hover:bg-emerald-100 text-[#1DB954] transition"
 title="ส่งสลิปหนี้เข้าแชท LINE"
 >
 <MessageSquare className="w-3 h-3" />
 </button>
 </div>
 ) : (
 <span className="text-[9px] text-[#8A8A85] font-medium">-</span>
 )}
 </td>
 </tr>
 );
 })}

 {/* BOTTOM TOTALS ROW */}
 <tr className="bg-[#282828]/90 border-t-2 border-slate-350 text-center font-black text-[#1A1A1A] text-xs sticky bottom-0">
 <td className="py-3 px-3 border-r border-[#E0E0DB] text-left sticky left-0 bg-[#F0F0EB] z-10 font-black">
 รวมทั้งสิ้น (Total)
 </td>
 <td className="py-3 px-2 border-r border-[#E0E0DB] text-right text-[#1DB954]">
 {aggregates.totalRent.toLocaleString()} บ.
 </td>
 <td className="py-3 px-1.5 border-r border-[#E0E0DB] text-[#8A8A85] bg-[#F0F0EB]" />
 <td className="py-3 px-1.5 border-r border-[#E0E0DB] text-[#8A8A85] bg-[#F0F0EB]" />
 <td className="py-3 px-1.5 border-r border-[#E0E0DB] text-[#8A8A85] bg-[#F0F0EB]" />
 <td className="py-3 px-2 border-r border-[#E0E0DB] text-right text-amber-700 bg-[#F0F0EB]">
 {aggregates.totalElecCost.toLocaleString()} บ.
 </td>
 <td className="py-3 px-1.5 border-r border-[#E0E0DB] text-[#8A8A85] bg-[#F0F0EB]" />
 <td className="py-3 px-1.5 border-r border-[#E0E0DB] text-[#8A8A85] bg-[#F0F0EB]" />
 <td className="py-3 px-1.5 border-r border-[#E0E0DB] text-[#8A8A85] bg-[#F0F0EB]" />
 <td className="py-3 px-2 border-r border-[#E0E0DB] text-right text-blue-700 bg-[#F0F0EB]">
 {aggregates.totalWaterCost.toLocaleString()} บ.
 </td>
 <td className="py-3 px-2 border-r border-[#E0E0DB] text-right text-[#E22134]">
 {aggregates.totalOtherCost.toLocaleString()} บ.
 </td>
 <td className="py-3 px-3 border-r border-slate-250 text-right text-blue-900 bg-[#F0F0EB] text-sm">
 {aggregates.grandTotal.toLocaleString()} บ.
 </td>
 <td className="py-3 px-2 border-r border-[#E0E0DB] text-center sticky right-[60px] bg-[#F0F0EB] shadow-[-4px_0_12px_rgba(0,0,0,0.03)] z-10" />
 <td className="py-3 px-2 text-center sticky right-0 bg-[#F0F0EB] z-10 no-print" />
 </tr>
 </tbody>
 </table>
 </div>
 </div>

 {/* 4. SECTION: 6-MONTH HISTORICAL METER ANALYSIS */}
 <div className="grid grid-cols-1 xl:grid-cols-5 gap-6 no-print">
 
 {/* Left Side Controls & Trend Chart (3/5 Columns) */}
 <div className="xl:col-span-3 bg-white border border-[#E0E0DB] rounded-3xl p-6 space-y-6">
 <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-[#E0E0DB] pb-4">
 <div>
 <h3 className="text-sm font-black text-[#1A1A1A] flex items-center gap-2">
 <TrendingUp className="w-4.5 h-4.5 text-[#1DB954]" />
 <span>วิเคราะห์อัตราใช้พลังงานย้อนหลัง 6 เดือน</span>
 </h3>
 <p className="text-[10px] text-[#8A8A85] mt-0.5">
 เปรียบเทียบพฤติกรรมการใช้น้ำประปาและไฟฟ้าเป็นหน่วยย้อนหลังของแต่ละห้องพัก
 </p>
 </div>

 {/* Room selector */}
 <select
 value={selectedRoomId}
 onChange={(e) => setSelectedRoomId(parseInt(e.target.value) || 0)}
 className="bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl px-3 py-2 text-xs font-bold text-[#1A1A1A] focus:outline-none focus:border-[#1DB954] transition cursor-pointer "
 >
 <option value="0">-- เลือกห้องพักเพื่อวิเคราะห์ --</option>
 {rooms.map(r => (
 <option key={r.id} value={r.id}>
 ห้อง {r.roomNumber} ({r.tenantName || 'ห้องว่าง'})
 </option>
 ))}
 </select>
 </div>

 {roomHistoryData.length === 0 ? (
 <div className="flex flex-col items-center justify-center py-16 text-center text-[#8A8A85] border border-dashed border-[#E0E0DB] rounded-2xl bg-[#282828]/50">
 <AlertCircle className="w-10 h-10 text-[#8A8A85] mb-2" />
 <p className="text-xs font-bold text-[#8A8A85]">ไม่พบประวัติการใช้งาน (มิเตอร์) ของห้องพักนี้ในระบบ</p>
 <p className="text-[10px] text-[#8A8A85] mt-1 max-w-xs">กรุณาสร้างบิลประจำเดือนเพื่อเริ่มสะสมสถิติมิเตอร์น้ำและไฟค่ะ</p>
 </div>
 ) : (
 <div className="space-y-4">
 {/* Highlight summary cards of Selected Room Usage */}
 <div className="grid grid-cols-2 gap-3.5">
 <div className="p-3 bg-[#F59B23]/10/40 border border-[#F59B23]/30 rounded-xl flex items-center gap-3">
 <div className="p-2 bg-[#F59B23]/8 text-[#F59B23] rounded-lg">
 <Zap className="w-4 h-4" />
 </div>
 <div>
 <p className="text-[9px] font-bold text-[#F59B23] uppercase">ค่าเฉลี่ยใช้ไฟฟ้า</p>
 <p className="text-xs font-black text-amber-950 mt-0.5">
 {Math.round(roomHistoryData.reduce((acc, curr) => acc + curr.electricityUnits, 0) / roomHistoryData.length)} หน่วย / เดือน
 </p>
 </div>
 </div>

 <div className="p-3 bg-[#1DB954]/10/40 border border-blue-100 rounded-xl flex items-center gap-3">
 <div className="p-2 bg-[#1DB954]/8 text-[#1DB954] rounded-full">
 <Droplet className="w-4 h-4" />
 </div>
 <div>
 <p className="text-[9px] font-bold text-blue-800 uppercase">ค่าเฉลี่ยใช้น้ำประปา</p>
 <p className="text-xs font-black text-blue-950 mt-0.5">
 {(roomHistoryData.reduce((acc, curr) => acc + curr.waterUnits, 0) / roomHistoryData.length).toFixed(1)} หน่วย / เดือน
 </p>
 </div>
 </div>
 </div>

 {/* Chart of Water & Elec */}
 <div className="w-full h-64 mt-4">
 <ResponsiveContainer width="100%" height="100%">
 <LineChart
 data={roomHistoryData}
 margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
 >
 <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
 <XAxis 
 dataKey="monthThai" 
 tick={{ fontSize: 9, fontWeight: 600, fill: '#64748b' }} 
 stroke="#282828" 
 />
 <YAxis 
 tick={{ fontSize: 9, fontWeight: 600, fill: '#64748b' }} 
 stroke="#282828" 
 />
 <Tooltip 
 contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '12px', color: '#fff', fontSize: '10px', fontWeight: 'bold' }}
 itemStyle={{ color: '#94a3b8' }}
 />
 <Legend 
 verticalAlign="top" 
 height={36} 
 iconType="circle"
 iconSize={6}
 wrapperStyle={{ fontSize: '10px', fontWeight: 'bold' }}
 />
 <Line 
 type="monotone" 
 name="หน่วยไฟฟ้า (Electricity Units)" 
 dataKey="electricityUnits" 
 stroke="#f59e0b" 
 strokeWidth={3} 
 activeDot={{ r: 6 }} 
 />
 <Line 
 type="monotone" 
 name="หน่วยน้ำ (Water Units)" 
 dataKey="waterUnits" 
 stroke="#06b6d4" 
 strokeWidth={3} 
 activeDot={{ r: 6 }} 
 />
 </LineChart>
 </ResponsiveContainer>
 </div>
 </div>
 )}
 </div>

 {/* Right Side Chronological List of readings (2/5 Columns) */}
 <div className="xl:col-span-2 bg-white border border-[#E0E0DB] rounded-3xl p-6 space-y-4">
 <div>
 <h3 className="text-sm font-black text-[#1A1A1A] flex items-center gap-1.5">
 <span>ประวัติมิเตอร์และบิล:</span>
 <span className="text-[#1DB954] font-extrabold">{selectedRoomDetails ? `ห้อง ${selectedRoomDetails.roomNumber}` : '-'}</span>
 </h3>
 <p className="text-[10px] text-[#8A8A85] mt-0.5">
 รายการเลขมิเตอร์ครั้งก่อน-หลัง ยอดสุทธิ และสถานะบิลย้อนหลังสูงสุด 6 เดือน
 </p>
 </div>

 {roomHistoryData.length === 0 ? (
 <div className="py-16 text-center text-[#8A8A85]">
 <p className="text-xs font-semibold">ไม่มีรายการบิลในประวัติ</p>
 </div>
 ) : (
 <div className="space-y-3.5 max-h-[360px] overflow-y-auto pr-1">
 {roomHistoryData.slice().reverse().map((record, index) => (
 <div 
 key={record.month}
 className="p-3.5 bg-[#F0F0EB] border border-[#E0E0DB] rounded-2xl flex flex-col gap-2.5 hover:bg-[#282828]/40 transition text-xxs text-[#6B6B66]"
 >
 <div className="flex justify-between items-center pb-2 border-b border-[#E0E0DB]">
 <p className="font-black text-[11px] text-[#1A1A1A]">{formatThaiMonth(record.month)}</p>
 <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold border ${
 record.status === 'paid' 
 ? 'bg-[#1DB954]/8 border-[#1DB954]/30 text-[#1DB954]' 
 : 'bg-[#E22134]/8 border-[#E22134]/30 text-[#E22134]'
 }`}>
 {record.status === 'paid' ? 'จ่ายแล้ว' : 'ยังไม่ได้จ่าย'}
 </span>
 </div>

 {/* Meter Details layout */}
 <div className="grid grid-cols-2 gap-3.5 font-sans leading-relaxed">
 <div className="space-y-1">
 <p className="font-bold text-amber-700 flex items-center gap-1">
 <Zap className="w-3.5 h-3.5 shrink-0" />
 <span>ระบบไฟฟ้า:</span>
 </p>
 <p className="text-[#8A8A85]">
 มิเตอร์ก่อน-หลัง: <span className="font-bold text-[#1A1A1A]">{record.priorElec} → {record.currentElec}</span>
 </p>
 <p className="font-semibold">
 ใช้ไป: <span className="text-[#F59B23] font-black">{record.electricityUnits} หน่วย</span> = {record.electricityCost.toLocaleString()} บ.
 </p>
 </div>

 <div className="space-y-1">
 <p className="font-bold text-blue-700 flex items-center gap-1">
 <Droplet className="w-3.5 h-3.5 shrink-0" />
 <span>ระบบประปา:</span>
 </p>
 <p className="text-[#8A8A85]">
 มิเตอร์ก่อน-หลัง: <span className="font-bold text-[#1A1A1A]">{record.priorWater} → {record.currentWater}</span>
 </p>
 <p className="font-semibold">
 ใช้ไป: <span className="text-blue-800 font-black">{record.waterUnits} หน่วย</span> = {record.waterCost.toLocaleString()} บ.
 </p>
 </div>
 </div>

 <div className="pt-2 border-t border-dashed border-[#E0E0DB] flex justify-between items-center text-[10.5px]">
 <span className="font-bold text-[#8A8A85]">ยอดสุทธิรวมในบิล:</span>
 <span className="font-black text-[#1A1A1A] text-xs">{record.totalCost.toLocaleString()} บาท</span>
 </div>
 </div>
 ))}
 </div>
 )}
 </div>

 </div>

 </div>
 );
};
// Force Vite HMR reload
