import React, { useState, useEffect } from 'react';
import { Room, Bill, Settings, BillChargeItem } from '../types.ts';
import { 
 Calculator, 
 Zap, 
 Droplet, 
 DollarSign, 
 Calendar, 
 FileText, 
 CheckCircle, 
 AlertTriangle,
 User,
 PlusCircle,
 Layers,
 Sparkles,
 Info
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { buildValidDueDate } from '../utils/settings.ts';

interface CreateBillViewProps {
 rooms: Room[];
 settings: Settings;
 bills: Bill[];
 onCreateBill: (billData: Omit<Bill, 'id' | 'roomNumber' | 'tenantName' | 'tenantPhone'>) => Promise<void>;
 onCreateBulkBills?: (bulkData: { billMonth: string; dueDate: string; bills: any[] }) => Promise<void>;
 onNavigateToHistory: () => void;
 idToken?: string | null;
}

export const CreateBillView: React.FC<CreateBillViewProps> = ({
 rooms,
 settings,
 bills,
 onCreateBill,
 onCreateBulkBills,
 onNavigateToHistory,
 idToken
}) => {
 const [activeTab, setActiveTab] = useState<'single' | 'bulk'>('single');
 const [billMonth, setBillMonth] = useState<string>('');
 const [dueDate, setDueDate] = useState<string>('');
 
 // Single-room state
 const [selectedRoomId, setSelectedRoomId] = useState<string>('');
 const [priorElec, setPriorElec] = useState<string>('0');
 const [currentElec, setCurrentElec] = useState<string>('0');
 const [elecDeduct, setElecDeduct] = useState<string>('0');
 const [elecCost, setElecCost] = useState<string>('0');
 const [isElecCostManual, setIsElecCostManual] = useState<boolean>(false);
 const [priorWater, setPriorWater] = useState<string>('0');
 const [currentWater, setCurrentWater] = useState<string>('0');
 const [waterCost, setWaterCost] = useState<string>('0');
 const [isWaterCostManual, setIsWaterCostManual] = useState<boolean>(false);
 const [rentCost, setRentCost] = useState<string>('0');
 const [depositCost, setDepositCost] = useState<string>('0');
 const [otherCost, setOtherCost] = useState<string>('0');
 const [otherDescription, setOtherDescription] = useState<string>('ค่าส่วนกลาง/บริการ');
 const [status, setStatus] = useState<'unpaid' | 'paid'>('unpaid');
 const [chargeItems, setChargeItems] = useState<BillChargeItem[]>([]);
 const [bulkDueItems, setBulkDueItems] = useState<Record<number, BillChargeItem[]>>({});

 // Bulk-rooms state
 const [bulkInputs, setBulkInputs] = useState<Record<number, {
 priorElec: string;
 currentElec: string;
 elecDeduct: string;
 priorWater: string;
 currentWater: string;
 waterCost: string;
 otherCost: string;
 otherDescription: string;
 }>>({});

 const [formError, setFormError] = useState<string | null>(null);
 const [submitting, setSubmitting] = useState(false);
 const [success, setSuccess] = useState(false);

 const occupiedRooms = rooms.filter(r => r.status === 'occupied');

 // Initialize month & due date
 useEffect(() => {
 const today = new Date();
 const currentMonth = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;
 setBillMonth(currentMonth);

 setDueDate(buildValidDueDate(currentMonth, settings.defaultDueDateDay));
 }, [settings]);

 // Handle single-room prefill
 useEffect(() => {
 if (!selectedRoomId) return;

 const roomId = parseInt(selectedRoomId);
 const room = rooms.find(r => r.id === roomId);
 if (!room) return;

 setRentCost(room.monthlyRent.toString());

 const roomBills = bills
 .filter(b => b.roomId === roomId)
 .sort((a, b) => b.billMonth.localeCompare(a.billMonth));

 if (roomBills.length > 0) {
 const latestBill = roomBills[0];
 setPriorElec(latestBill.currentElec.toString());
 setCurrentElec(latestBill.currentElec.toString());
 setPriorWater(latestBill.currentWater.toString());
 setCurrentWater(latestBill.currentWater.toString());
 } else {
 setPriorElec('0');
 setCurrentElec('0');
 setPriorWater('0');
 setCurrentWater('0');
 }

 setElecDeduct('0');
 setElecCost('0');
 setIsElecCostManual(false);
 setWaterCost('0');
 setIsWaterCostManual(false);
 setDepositCost('0');
 setOtherCost('0');
 setOtherDescription('ค่าส่วนกลาง/บริการ');
 setFormError(null);
 }, [selectedRoomId, rooms, bills]);

 useEffect(() => {
 if (!selectedRoomId || !billMonth || !idToken) { setChargeItems([]); return; }
 const controller = new AbortController();
 fetch(`/api/recurring-charges/due?billMonth=${encodeURIComponent(billMonth)}&roomId=${selectedRoomId}`, { headers: { Authorization: `Bearer ${idToken}` }, signal: controller.signal })
 .then(async (response) => { const payload = await response.json(); if (!response.ok) throw new Error(payload?.error || 'โหลดค่าบริการไม่สำเร็จ'); return payload?.data || []; })
 .then((items) => setChargeItems(items.map((item: any, index: number) => ({ ...item, sortOrder: index }))))
 .catch((error) => { if (error.name !== 'AbortError') setFormError(error.message); });
 return () => controller.abort();
 }, [selectedRoomId, billMonth, idToken]);

 useEffect(() => {
 if (!billMonth || !idToken) return;
 const controller = new AbortController();
 fetch(`/api/recurring-charges/due?billMonth=${encodeURIComponent(billMonth)}`, { headers: { Authorization: `Bearer ${idToken}` }, signal: controller.signal })
 .then((response) => response.json()).then((payload) => { const grouped: Record<number, BillChargeItem[]> = {}; (payload?.data || []).forEach((item: any) => { (grouped[item.roomId] ||= []).push(item); }); setBulkDueItems(grouped); })
 .catch((error) => { if (error.name !== 'AbortError') setFormError('โหลดค่าบริการแบบกลุ่มไม่สำเร็จ'); });
 return () => controller.abort();
 }, [billMonth, idToken]);

 // Bulk input prefill initialization
 useEffect(() => {
 const initial: Record<number, any> = {};
 occupiedRooms.forEach(room => {
 const roomBills = bills
 .filter(b => b.roomId === room.id)
 .sort((a, b) => b.billMonth.localeCompare(a.billMonth));

 let priorE = 0;
 let priorW = 0;
 if (roomBills.length > 0) {
 priorE = roomBills[0].currentElec;
 priorW = roomBills[0].currentWater;
 }

 initial[room.id] = {
 priorElec: priorE.toString(),
 currentElec: priorE.toString(),
 elecDeduct: '0',
 priorWater: priorW.toString(),
 currentWater: priorW.toString(),
 waterCost: '',
 otherCost: '0',
 otherDescription: 'ค่าส่วนกลาง/บริการ',
 };
 });
 setBulkInputs(initial);
 }, [rooms, bills]);

 // Adjust due date when month changes
 const handleMonthChange = (e: React.ChangeEvent<HTMLInputElement>) => {
 const value = e.target.value;
 setBillMonth(value);
 if (value) {
 setDueDate(buildValidDueDate(value, settings.defaultDueDateDay));
 }
 };

 // Helper: standard 6-month average calculator for utility usage
 const get6MonthAverage = (roomId: number, type: 'elec' | 'water') => {
 const roomBills = bills
 .filter(b => b.roomId === roomId)
 .sort((a, b) => b.billMonth.localeCompare(a.billMonth))
 .slice(0, 6);

 if (roomBills.length === 0) return null;

 let sum = 0;
 roomBills.forEach(b => {
 if (type === 'elec') {
 sum += Math.max(0, b.currentElec - b.priorElec);
 } else {
 sum += Math.max(0, b.currentWater - b.priorWater);
 }
 });

 return sum / roomBills.length;
 };

 // Single Calculations
 const elecUnits = Math.max(0, (parseFloat(currentElec) || 0) - (parseFloat(priorElec) || 0) - (parseFloat(elecDeduct) || 0));
 const calculatedElecCost = Math.round(elecUnits * settings.defaultElecRate);
 const finalElecCost = isElecCostManual ? (parseFloat(elecCost) || 0) : calculatedElecCost;

 useEffect(() => {
 if (!isElecCostManual) {
 setElecCost(calculatedElecCost.toString());
 }
 }, [calculatedElecCost, isElecCostManual]);
 
 const waterUnits = Math.max(0, (parseFloat(currentWater) || 0) - (parseFloat(priorWater) || 0));
 const calculatedWaterCost = waterUnits > 0 ? Math.round(waterUnits * settings.defaultWaterRate) : 0;
 const finalWaterCost = isWaterCostManual ? (parseFloat(waterCost) || 0) : calculatedWaterCost;

 useEffect(() => {
 if (!isWaterCostManual) {
 setWaterCost(calculatedWaterCost.toString());
 }
 }, [calculatedWaterCost, isWaterCostManual]);

 const recurringTotal = chargeItems.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
 const grandTotal = (parseInt(rentCost) || 0) + finalElecCost + finalWaterCost + (parseInt(depositCost) || 0) + (parseInt(otherCost) || 0) + recurringTotal;

 // Single form submission
 const handleSubmitSingle = async (e: React.FormEvent) => {
 e.preventDefault();
 setFormError(null);
 setSuccess(false);

 if (!selectedRoomId) {
 setFormError('กรุณาเลือกห้องพักที่ต้องการสร้างบิล');
 return;
 }
 if (!billMonth) {
 setFormError('กรุณาระบุเดือนประจำรอบบิล');
 return;
 }
 if (!dueDate) {
 setFormError('กรุณาระบุวันครบกำหนดชำระเงิน');
 return;
 }

 if (parseFloat(currentElec) < parseFloat(priorElec)) {
 setFormError('แจ้งเตือน: มิเตอร์ไฟครั้งหลัง น้อยกว่ามิเตอร์ไฟครั้งก่อน กรุณาตรวจสอบความถูกต้อง');
 return;
 }
 if (parseFloat(currentWater) < parseFloat(priorWater)) {
 setFormError('แจ้งเตือน: มิเตอร์น้ำครั้งหลัง น้อยกว่ามิเตอร์น้ำครั้งก่อน กรุณาตรวจสอบความถูกต้อง');
 return;
 }

 setSubmitting(true);

 const billData = {
 roomId: parseInt(selectedRoomId),
 billMonth,
 priorElec: parseFloat(priorElec) || 0,
 currentElec: parseFloat(currentElec) || 0,
 elecDeduct: parseFloat(elecDeduct) || 0,
 elecUnitCost: settings.defaultElecRate,
 elecCost: finalElecCost,
 priorWater: parseFloat(priorWater) || 0,
 currentWater: parseFloat(currentWater) || 0,
 waterUnitCost: settings.defaultWaterRate,
 waterCost: finalWaterCost,
 rentCost: parseInt(rentCost) || 0,
 depositCost: parseInt(depositCost) || 0,
 otherCost: parseInt(otherCost) || 0,
 otherDescription,
 chargeItems: [...chargeItems, ...((parseInt(otherCost) || 0) > 0 ? [{ label: otherDescription || 'ค่าใช้จ่ายอื่น', amount: parseInt(otherCost) || 0, kind: 'manual' as const, assignmentId: null }] : [])],
 totalCost: grandTotal,
 dueDate,
 status
 };

 try {
 await onCreateBill(billData);
 setSuccess(true);
 setSelectedRoomId('');
 window.scrollTo({ top: 0, behavior: 'smooth' });
 } catch (err: any) {
 setFormError(err.message || 'เกิดข้อผิดพลาดในการบันทึกข้อมูลบิลพัก');
 } finally {
 setSubmitting(false);
 }
 };

 // Bulk form submission
 const handleSubmitBulk = async (e: React.FormEvent) => {
 e.preventDefault();
 setFormError(null);
 setSuccess(false);

 if (!billMonth || !dueDate) {
 setFormError('กรุณากรอกรอบบิลประจำเดือนและกำหนดชำระเงินให้ครบถ้วน');
 return;
 }

 if (!onCreateBulkBills) {
 setFormError('ระบบยังไม่รองรับการทำงานแบบกลุ่มในขณะนี้');
 return;
 }

 const payloadBills: any[] = [];

 for (const room of occupiedRooms) {
 const inputs = bulkInputs[room.id];
 if (!inputs) continue;

 const roomBills = bills
 .filter(b => b.roomId === room.id)
 .sort((a, b) => b.billMonth.localeCompare(a.billMonth));

 const histE = roomBills.length > 0 ? roomBills[0].currentElec : 0;
 const histW = roomBills.length > 0 ? roomBills[0].currentWater : 0;

 const pE = inputs.priorElec !== undefined ? (parseFloat(inputs.priorElec) || 0) : histE;
 const pW = inputs.priorWater !== undefined ? (parseFloat(inputs.priorWater) || 0) : histW;

 const cE = inputs.currentElec !== undefined ? (parseFloat(inputs.currentElec) || 0) : pE;
 const cW = inputs.currentWater !== undefined ? (parseFloat(inputs.currentWater) || 0) : pW;
 const deductE = parseFloat(inputs.elecDeduct) || 0;

 if (cE < pE) {
 setFormError(`แจ้งเตือน: มิเตอร์ไฟครั้งหลังของห้อง ${room.roomNumber} (${cE} หน่วย) น้อยกว่าครั้งก่อน (${pE} หน่วย)`);
 return;
 }
 if (cW < pW) {
 setFormError(`แจ้งเตือน: มิเตอร์น้ำครั้งหลังของห้อง ${room.roomNumber} (${cW} หน่วย) น้อยกว่าครั้งก่อน (${pW} หน่วย)`);
 return;
 }

 const waterUsed = Math.max(0, cW - pW);
 const autoWaterCost = waterUsed > 0 ? Math.round(waterUsed * settings.defaultWaterRate) : 0;
 const finalWaterCost = inputs.waterCost !== undefined && inputs.waterCost !== '' ? (parseFloat(inputs.waterCost) || 0) : autoWaterCost;

 payloadBills.push({
 roomId: room.id,
 priorElec: pE,
 currentElec: cE,
 elecDeduct: deductE,
 priorWater: pW,
 currentWater: cW,
 waterCost: finalWaterCost,
 rentCost: room.monthlyRent,
 depositCost: 0,
 otherCost: parseFloat(inputs.otherCost) || 0,
 otherDescription: inputs.otherDescription || "",
 chargeItems: [...(bulkDueItems[room.id] || []), ...((parseFloat(inputs.otherCost) || 0) > 0 ? [{ label: inputs.otherDescription || 'ค่าใช้จ่ายอื่น', amount: parseFloat(inputs.otherCost) || 0, kind: 'manual', assignmentId: null }] : [])]
 });
 }

 if (payloadBills.length === 0) {
 setFormError('ไม่มีข้อมูลห้องพักที่เปิดใช้งานสำหรับการออกบิลด่วน');
 return;
 }

 setSubmitting(true);

 try {
 await onCreateBulkBills({
 billMonth,
 dueDate,
 bills: payloadBills
 });
 setSuccess(true);
 window.scrollTo({ top: 0, behavior: 'smooth' });
 } catch (err: any) {
 setFormError(err.message || 'เกิดข้อผิดพลาดในการบันทึกบิลแบบด่วน');
 } finally {
 setSubmitting(false);
 }
 };

 const selectedRoom = rooms.find(r => r.id === parseInt(selectedRoomId));

 // Determine single-room energy anomalies for visual warning in the sidebar
 let singleElecAnomaly = false;
 let singleWaterAnomaly = false;
 let singleElecAvg: number | null = null;
 let singleWaterAvg: number | null = null;

 if (selectedRoomId) {
 const rId = parseInt(selectedRoomId);
 singleElecAvg = get6MonthAverage(rId, 'elec');
 singleWaterAvg = get6MonthAverage(rId, 'water');
 
 if (singleElecAvg !== null && singleElecAvg > 0 && elecUnits > singleElecAvg * 2) {
 singleElecAnomaly = true;
 }
 if (singleWaterAvg !== null && singleWaterAvg > 0 && waterUnits > singleWaterAvg * 2) {
 singleWaterAnomaly = true;
 }
 }

 return (
 <div className="max-w-5xl mx-auto space-y-6 font-sans">
 
 {/* Header Panel */}
 <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
 <div>
 <h2 className="text-xl font-bold text-[#1A1A1A] flex items-center gap-2">
 <Calculator className="w-5 h-5 text-[#1DB954]" />
 <span>สร้างบิลเรียกเก็บเงินประจำงวด</span>
 </h2>
 <p className="text-xs text-[#8A8A85] mt-1">
 คำนวณและออกบิลค่าห้อง ค่าน้ำ ค่าไฟให้ผู้เช่าอย่างรวดเร็วและเป็นระบบ
 </p>
 </div>

 {/* Mode switcher tabs */}
 <div className="flex bg-[#F0F0EB] p-1 rounded-xl self-start">
 <button
 onClick={() => { setActiveTab('single'); setSuccess(false); setFormError(null); }}
 className={`py-1.5 px-3 text-xxs font-bold rounded-lg transition flex items-center gap-1.5 cursor-pointer ${
 activeTab === 'single' ? 'bg-white text-[#1DB954] ' : 'text-[#8A8A85] hover:text-slate-800'
 }`}
 >
 <User className="w-3.5 h-3.5" />
 <span>ออกบิลรายห้อง</span>
 </button>
 <button
 onClick={() => { setActiveTab('bulk'); setSuccess(false); setFormError(null); }}
 className={`py-1.5 px-3 text-xxs font-bold rounded-lg transition flex items-center gap-1.5 cursor-pointer ${
 activeTab === 'bulk' ? 'bg-white text-[#1DB954] ' : 'text-[#8A8A85] hover:text-slate-800'
 }`}
 >
 <Layers className="w-3.5 h-3.5" />
 <span>กรอกมิเตอร์ด่วน (Bulk Entry)</span>
 </button>
 </div>
 </div>

 {success && (
 <div className="p-4 bg-[#1DB954]/8 border border-[#1DB954]/30 text-emerald-850 rounded-2xl text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 ">
 <div className="flex items-center gap-2.5">
 <CheckCircle className="w-5 h-5 text-[#1DB954] flex-shrink-0" />
 <div>
 <p className="font-bold text-emerald-900">สร้างบิลสำเร็จเรียบร้อยแล้ว! 🎉</p>
 <p className="text-[11px] text-[#8A8A85]">ข้อมูลบิลประจำเดือนถูกลงทะเบียนสำเร็จแล้ว คุณสามารถกดเปิดดูหรือส่งทางไลน์ได้ทันที</p>
 </div>
 </div>
 <button
 onClick={onNavigateToHistory}
 className="py-1.5 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-[#1A1A1A] font-bold font-sans text-xxs transition self-end sm:self-auto cursor-pointer"
 >
 เปิดดูประวัติบิล
 </button>
 </div>
 )}

 {formError && (
 <div className="p-4 bg-red-50 border border-red-100 text-red-700 rounded-2xl text-xs flex items-center gap-2.5 ">
 <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0" />
 <p className="font-medium">{formError}</p>
 </div>
 )}

 <AnimatePresence mode="wait">
 {activeTab === 'single' ? (
 /* SINGLE ROOM CREATION */
 <motion.form 
 key="single"
 initial={{ opacity: 0, y: 10 }}
 animate={{ opacity: 1, y: 0 }}
 exit={{ opacity: 0, y: -10 }}
 onSubmit={handleSubmitSingle} 
 className="grid grid-cols-1 md:grid-cols-3 gap-6"
 >
 {/* Left 2 Columns: Billing Input Fields */}
 <div className="md:col-span-2 space-y-6">
 
 {/* Section 1: Target Room & Month */}
 <div className="bg-white border border-[#E0E0DB] rounded-2xl p-5 space-y-4">
 <h3 className="text-sm font-bold text-[#1A1A1A] border-b border-[#E0E0DB] pb-2">1. ข้อมูลหอพักและรอบบิล</h3>
 
 <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
 <div>
 <label className="block text-[#8A8A85] font-bold mb-1.5 uppercase tracking-wider text-[10px]">เลือกห้องพัก (เฉพาะห้องมีผู้เช่า) *</label>
 <select
 value={selectedRoomId}
 onChange={(e) => setSelectedRoomId(e.target.value)}
 className="w-full bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl p-3 text-xs text-[#1A1A1A] focus:outline-none focus:bg-white focus:border-[#1DB954] transition cursor-pointer"
 >
 <option value="">-- เลือกห้องพัก --</option>
 {occupiedRooms.map(room => (
 <option key={room.id} value={room.id}>
 ห้อง {room.roomNumber} ({room.tenantName || 'ไม่ระบุ'})
 </option>
 ))}
 </select>
 {occupiedRooms.length === 0 && (
 <p className="text-[10px] text-[#F59B23] mt-1 leading-relaxed">
 ⚠️ ยังไม่มีห้องพักใดที่ระบุสถานะเป็น "มีผู้เช่า" กรุณาเพิ่มข้อมูลผู้เช่าในเมนู "ห้องพัก" ก่อนเริ่มสร้างบิล
 </p>
 )}
 </div>

 <div>
 <label className="block text-[#8A8A85] font-bold mb-1.5 uppercase tracking-wider text-[10px]">รอบบิลประจำเดือน *</label>
 <input
 type="month"
 value={billMonth}
 onChange={handleMonthChange}
 className="w-full bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl p-3 text-xs text-[#1A1A1A] focus:outline-none focus:bg-white focus:border-[#1DB954] transition"
 />
 </div>
 </div>

 {selectedRoom && (
 <div className="p-3 bg-[#F0F0EB] rounded-xl border border-[#E0E0DB] text-xxs text-[#8A8A85] flex flex-wrap items-center gap-3">
 <div className="flex items-center gap-1">
 <User className="w-3.5 h-3.5 text-[#1DB954]" />
 <span>ผู้เช่า: <span className="font-bold text-[#1A1A1A]">{selectedRoom.tenantName}</span></span>
 </div>
 <div className="w-px h-3 bg-slate-200"></div>
 <div>
 <span>ค่าเช่าพื้นฐาน: <span className="font-bold text-[#1DB954]">{selectedRoom.monthlyRent.toLocaleString()} บ.</span></span>
 </div>
 </div>
 )}
 </div>

 {/* Section 2: Utilities Readings */}
 <div className="bg-white border border-[#E0E0DB] rounded-2xl p-5 space-y-4">
 <h3 className="text-sm font-bold text-[#1A1A1A] border-b border-[#E0E0DB] pb-2 flex items-center gap-1.5">
 <span>2. ข้อมูลมิเตอร์ไฟและมิเตอร์น้ำ</span>
 <span className="text-xxs font-normal text-[#8A8A85]">(อัตรา: ไฟ {settings.defaultElecRate} บ. | น้ำ {settings.defaultWaterRate} บ.)</span>
 </h3>

 {/* Electricity Meter Card */}
 <div className="p-4 bg-[#F0F0EB] rounded-xl border border-[#E0E0DB] space-y-3">
 <div className="flex items-center justify-between">
 <h4 className="text-xs font-bold text-[#6B6B66] flex items-center gap-1.5">
 <Zap className="w-4 h-4 text-[#F59B23]" />
 <span>คำนวณค่าไฟฟ้า</span>
 </h4>
 {singleElecAnomaly && (
 <span className="inline-flex items-center gap-1 bg-amber-500/10 text-amber-700 px-2 py-0.5 rounded-full text-[9px] font-bold border border-amber-500/20">
 <AlertTriangle className="w-3 h-3 text-[#F59B23]" />
 <span>การใช้ไฟสูงกว่าค่าเฉลี่ย 6 เดือน &gt; 100% (เฉลี่ย: {singleElecAvg?.toFixed(1)} หน่วย)</span>
 </span>
 )}
 </div>
 <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
 <div>
 <label className="block text-[#8A8A85] font-bold mb-1 uppercase tracking-wider text-[9px]">เลขครั้งก่อน (Prior)</label>
 <input
 type="number"
 step="any"
 value={priorElec}
 onChange={(e) => setPriorElec(e.target.value)}
 className="w-full bg-white border border-[#E0E0DB] rounded-lg p-2.5 text-xs text-[#1A1A1A] focus:outline-none focus:border-amber-500 transition"
 />
 </div>
 <div>
 <label className="block text-[#8A8A85] font-bold mb-1 uppercase tracking-wider text-[9px]">เลขหลังล่าสุด (Current)</label>
 <input
 type="number"
 step="any"
 value={currentElec}
 onChange={(e) => setCurrentElec(e.target.value)}
 className="w-full bg-white border border-[#E0E0DB] rounded-lg p-2.5 text-xs text-[#1A1A1A] focus:outline-none focus:border-amber-500 transition"
 />
 </div>
 <div>
 <label className="block text-[#8A8A85] font-bold mb-1 uppercase tracking-wider text-[9px]">หน่วยหักล้าง (Deduct)</label>
 <input
 type="number"
 step="any"
 value={elecDeduct}
 onChange={(e) => setElecDeduct(e.target.value)}
 className="w-full bg-white border border-[#E0E0DB] rounded-lg p-2.5 text-xs text-[#1A1A1A] focus:outline-none focus:border-amber-500 transition"
 />
 </div>
 <div>
 <div className="flex justify-between items-center mb-1">
 <label className="block text-[#8A8A85] font-bold uppercase tracking-wider text-[9px]">ค่าไฟ (บาท)</label>
 {isElecCostManual && (
 <button
 type="button"
 onClick={() => setIsElecCostManual(false)}
 className="text-[8.5px] text-[#F59B23] hover:underline font-bold"
 >
 คำนวณออโต้
 </button>
 )}
 </div>
 <input
 type="number"
 step="any"
 value={elecCost}
 onChange={(e) => {
 setIsElecCostManual(true);
 setElecCost(e.target.value);
 }}
 className={`w-full bg-white border rounded-lg p-2.5 text-xs text-[#1A1A1A] focus:outline-none focus:border-amber-500 transition ${isElecCostManual ? 'border-amber-400 focus:border-amber-500 font-bold' : 'border-[#E0E0DB]'}`}
 />
 </div>
 </div>
 <div className="text-xxs flex items-center justify-between pt-1 font-bold text-[#F59B23]">
 <span>ใช้ไฟสุทธิ: {elecUnits} หน่วย{(parseFloat(elecDeduct) || 0) > 0 && ` (หักล้าง ${elecDeduct} หน่วย)`}</span>
 <span>รวมค่าไฟ: {finalElecCost.toLocaleString()} บาท {isElecCostManual && '(กำหนดเอง)'}</span>
 </div>
 </div>

 {/* Water Meter Card */}
 <div className="p-4 bg-[#F0F0EB] rounded-xl border border-[#E0E0DB] space-y-3">
 <div className="flex items-center justify-between">
 <h4 className="text-xs font-bold text-[#6B6B66] flex items-center gap-1.5">
 <Droplet className="w-4 h-4 text-[#1DB954]" />
 <span>คำนวณค่าน้ำ</span>
 </h4>
 {singleWaterAnomaly && (
 <span className="inline-flex items-center gap-1 bg-amber-500/10 text-amber-700 px-2 py-0.5 rounded-full text-[9px] font-bold border border-amber-500/20">
 <AlertTriangle className="w-3 h-3 text-[#F59B23]" />
 <span>การใช้น้ำสูงกว่าค่าเฉลี่ย 6 เดือน &gt; 100% (เฉลี่ย: {singleWaterAvg?.toFixed(1)} หน่วย)</span>
 </span>
 )}
 </div>
 <div className="grid grid-cols-3 gap-2.5">
 <div>
 <label className="block text-[#8A8A85] font-bold mb-1 uppercase tracking-wider text-[9px]">เลขครั้งก่อน (Prior)</label>
 <input
 type="number"
 step="any"
 value={priorWater}
 onChange={(e) => setPriorWater(e.target.value)}
 className="w-full bg-white border border-[#E0E0DB] rounded-lg p-2.5 text-xs text-[#1A1A1A] focus:outline-none focus:border-[#1DB954] transition"
 />
 </div>
 <div>
 <label className="block text-[#8A8A85] font-bold mb-1 uppercase tracking-wider text-[9px]">เลขหลังล่าสุด (Current)</label>
 <input
 type="number"
 step="any"
 value={currentWater}
 onChange={(e) => setCurrentWater(e.target.value)}
 className="w-full bg-white border border-[#E0E0DB] rounded-lg p-2.5 text-xs text-[#1A1A1A] focus:outline-none focus:border-[#1DB954] transition"
 />
 </div>
 <div>
 <div className="flex justify-between items-center mb-1">
 <label className="block text-[#8A8A85] font-bold uppercase tracking-wider text-[9px]">ค่าน้ำ (บาท)</label>
 {isWaterCostManual && (
 <button
 type="button"
 onClick={() => setIsWaterCostManual(false)}
 className="text-[8.5px] text-[#1DB954] hover:underline font-bold"
 >
 คำนวณออโต้
 </button>
 )}
 </div>
 <input
 type="number"
 step="any"
 value={waterCost}
 onChange={(e) => {
 setIsWaterCostManual(true);
 setWaterCost(e.target.value);
 }}
 className={`w-full bg-white border rounded-lg p-2.5 text-xs text-[#1A1A1A] focus:outline-none focus:border-[#1DB954] transition ${isWaterCostManual ? 'border-amber-400 focus:border-amber-500 font-bold' : 'border-[#E0E0DB]'}`}
 />
 </div>
 </div>
 <div className="text-xxs flex items-center justify-between pt-1 font-bold text-[#1DB954]">
 <span>ใช้น้ำสุทธิ: {waterUnits} หน่วย</span>
 <span>รวมค่าน้ำ: {finalWaterCost.toLocaleString()} บาท {isWaterCostManual && '(กำหนดเอง)'}</span>
 </div>
 </div>

 </div>

 {/* Section 3: Extra charges */}
 <div className="bg-white border border-[#E0E0DB] rounded-2xl p-5 space-y-4">
 <h3 className="text-sm font-bold text-[#1A1A1A] border-b border-[#E0E0DB] pb-2">3. ค่าเช่าและค่าใช้จ่ายเพิ่มเติมอื่น ๆ</h3>
 
 <div className="grid grid-cols-2 gap-4">
 <div>
 <label className="block text-[#8A8A85] font-bold mb-1.5 uppercase tracking-wider text-[10px]">ค่าเช่าห้องเรียกเก็บ *</label>
 <div className="relative">
 <span className="absolute left-3.5 top-3.5 text-[#8A8A85]">฿</span>
 <input
 type="number"
 value={rentCost}
 onChange={(e) => setRentCost(e.target.value)}
 className="w-full bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl p-3 pl-8 text-xs text-[#1A1A1A] focus:outline-none focus:bg-white focus:border-[#1DB954] transition"
 />
 </div>
 </div>

 <div>
 <label className="block text-[#8A8A85] font-bold mb-1.5 uppercase tracking-wider text-[10px]">ค่ามัดจำ / ค่าประกัน (ถ้ามี)</label>
 <div className="relative">
 <span className="absolute left-3.5 top-3.5 text-[#8A8A85]">฿</span>
 <input
 type="number"
 value={depositCost}
 onChange={(e) => setDepositCost(e.target.value)}
 className="w-full bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl p-3 pl-8 text-xs text-[#1A1A1A] focus:outline-none focus:bg-white focus:border-[#1DB954] transition"
 />
 </div>
 </div>
 </div>

 {chargeItems.length > 0 && <div className="rounded-xl border border-[#E0E0DB] bg-[#F0F0EB] p-4 space-y-2">
 <p className="text-[10px] font-bold uppercase tracking-wider text-[#6B6B66]">ค่าบริการที่ถึงรอบ (แก้ไขก่อนบันทึกได้)</p>
 {chargeItems.map((item, index) => <div key={`${item.assignmentId}-${index}`} className="grid grid-cols-[1fr_110px_auto] items-center gap-2">
 <input value={item.label} onChange={(e) => setChargeItems((current) => current.map((row, rowIndex) => rowIndex === index ? { ...row, label: e.target.value } : row))} className="rounded-lg border bg-white p-2 text-xs" />
 <input type="number" min="0" value={item.amount} onChange={(e) => setChargeItems((current) => current.map((row, rowIndex) => rowIndex === index ? { ...row, amount: Number(e.target.value) || 0 } : row))} className="rounded-lg border bg-white p-2 text-xs" />
 <button type="button" onClick={() => setChargeItems((current) => current.filter((_, rowIndex) => rowIndex !== index))} className="rounded-lg border bg-white px-2 py-2 text-red-600">ปิด</button>
 </div>)}
 </div>}

 <div className="grid grid-cols-2 gap-4">
 <div>
 <label className="block text-[#8A8A85] font-bold mb-1.5 uppercase tracking-wider text-[10px]">ค่าอื่น ๆ เพิ่มเติม</label>
 <div className="relative">
 <span className="absolute left-3.5 top-3.5 text-[#8A8A85]">฿</span>
 <input
 type="number"
 value={otherCost}
 onChange={(e) => setOtherCost(e.target.value)}
 className="w-full bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl p-3 pl-8 text-xs text-[#1A1A1A] focus:outline-none focus:bg-white focus:border-[#1DB954] transition"
 />
 </div>
 </div>

 <div>
 <label className="block text-[#8A8A85] font-bold mb-1.5 uppercase tracking-wider text-[10px]">รายละเอียดค่าอื่น ๆ</label>
 <input
 type="text"
 placeholder="เช่น ค่าส่วนกลาง, ปรับทำความสะอาด"
 value={otherDescription}
 onChange={(e) => setOtherDescription(e.target.value)}
 className="w-full bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl p-3 text-xs text-[#1A1A1A] focus:outline-none focus:bg-white focus:border-[#1DB954] transition"
 />
 </div>
 </div>
 </div>

 </div>

 {/* Sticky Summary & Actions */}
 <div className="space-y-6">
 <div className="bg-white border border-[#E0E0DB] rounded-2xl p-5 space-y-4 sticky top-6">
 <h3 className="text-sm font-bold text-[#1A1A1A] border-b border-[#E0E0DB] pb-2">สรุปรายการยอดรวม</h3>

 <div className="space-y-3.5 text-xs text-[#6B6B66]">
 <div className="flex justify-between">
 <span>ค่าเช่าห้องพัก:</span>
 <span className="font-bold text-[#1A1A1A]">{parseInt(rentCost || '0').toLocaleString()} บ.</span>
 </div>
 <div className="flex justify-between">
 <span>ค่าไฟฟ้า ({elecUnits} หน่วย):</span>
 <span className="font-bold text-[#1A1A1A]">{elecCost.toLocaleString()} บ.</span>
 </div>
 <div className="flex justify-between">
 <span>ค่าน้ำ ({waterUnits} หน่วย):</span>
 <span className="font-bold text-[#1A1A1A]">{parseFloat(waterCost).toLocaleString()} บ.</span>
 </div>
 {parseInt(depositCost || '0') > 0 && (
 <div className="flex justify-between">
 <span>ค่าประกัน:</span>
 <span className="font-bold text-[#1A1A1A]">{parseInt(depositCost || '0').toLocaleString()} บ.</span>
 </div>
 )}
 {parseInt(otherCost || '0') > 0 && (
 <div className="flex justify-between">
 <span>ค่าใช้จ่ายอื่น ๆ:</span>
 <span className="font-bold text-[#1A1A1A]">{parseInt(otherCost || '0').toLocaleString()} บ.</span>
 </div>
 )}
 {chargeItems.map((item, index) => <div key={`summary-${index}`} className="flex justify-between"><span>{item.label}:</span><span className="font-bold text-[#1A1A1A]">{Number(item.amount).toLocaleString()} บ.</span></div>)}

 <div className="border-t border-[#E0E0DB] my-2 pt-2 flex justify-between items-center">
 <span className="font-bold text-[#1A1A1A] text-sm">ยอดรวมสุทธิ:</span>
 <span className="font-extrabold text-xl text-[#1DB954]">{grandTotal.toLocaleString()} บาท</span>
 </div>
 </div>

 <div className="space-y-3 pt-3 border-t border-[#E0E0DB] text-xs">
 <div>
 <label className="block text-[#8A8A85] font-bold mb-1 uppercase tracking-wider text-[9px]">กำหนดชำระเงินไม่เกิน *</label>
 <input
 type="date"
 value={dueDate}
 onChange={(e) => setDueDate(e.target.value)}
 className="w-full bg-[#F0F0EB] border border-[#E0E0DB] rounded-lg p-2.5 text-xs text-[#1A1A1A] focus:outline-none focus:bg-white focus:border-[#1DB954] transition"
 />
 </div>

 <div>
 <label className="block text-[#8A8A85] font-bold mb-1 uppercase tracking-wider text-[9px]">สถานะการจ่ายเงิน</label>
 <div className="grid grid-cols-2 gap-2">
 <button
 type="button"
 onClick={() => setStatus('unpaid')}
 className={`py-2 px-3 rounded-xl border text-center font-bold transition cursor-pointer ${
 status === 'unpaid'
 ? 'bg-[#E22134]/8 border-[#E22134]/30 text-[#E22134] '
 : 'bg-white border-[#E0E0DB] text-[#8A8A85]'
 }`}
 >
 ค้างชำระ
 </button>
 <button
 type="button"
 onClick={() => setStatus('paid')}
 className={`py-2 px-3 rounded-xl border text-center font-bold transition cursor-pointer ${
 status === 'paid'
 ? 'bg-[#1DB954]/8 border-[#1DB954]/30 text-[#1DB954] '
 : 'bg-white border-[#E0E0DB] text-[#8A8A85]'
 }`}
 >
 ชำระแล้ว
 </button>
 </div>
 </div>
 </div>

 <div className="pt-2">
 <button
 type="submit"
 disabled={submitting || !selectedRoomId}
 className="w-full py-3 px-4 rounded-xl bg-[#1DB954] hover:bg-[#1ED760] hover:scale-[1.04] text-white font-bold transition disabled:bg-slate-100 disabled:text-slate-400 cursor-pointer flex items-center justify-center gap-1.5"
 >
 <PlusCircle className="w-5 h-5" />
 <span>{submitting ? 'กำลังสร้างบิล...' : 'บันทึกบิลเรียกเก็บเงิน'}</span>
 </button>
 </div>
 </div>
 </div>
 </motion.form>
 ) : (
 /* BULK / QUICK METER ENTRY SYSTEM */
 <motion.form
 key="bulk"
 initial={{ opacity: 0, y: 10 }}
 animate={{ opacity: 1, y: 0 }}
 exit={{ opacity: 0, y: -10 }}
 onSubmit={handleSubmitBulk}
 className="space-y-6"
 >
 {/* Quick Settings Panel */}
 <div className="bg-white border border-[#E0E0DB] rounded-2xl p-5 grid grid-cols-1 md:grid-cols-3 gap-6 items-end">
 <div>
 <label className="block text-[#8A8A85] font-bold mb-1.5 uppercase tracking-wider text-[10px]">รอบบิลประจำเดือนทั้งหมด *</label>
 <input
 type="month"
 value={billMonth}
 onChange={handleMonthChange}
 className="w-full bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl p-3 text-xs text-[#1A1A1A] focus:outline-none focus:bg-white focus:border-[#1DB954] transition"
 />
 </div>

 <div>
 <label className="block text-[#8A8A85] font-bold mb-1.5 uppercase tracking-wider text-[10px]">กำหนดชำระเงินทุกบิลไม่เกิน *</label>
 <input
 type="date"
 value={dueDate}
 onChange={(e) => setDueDate(e.target.value)}
 className="w-full bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl p-3 text-xs text-[#1A1A1A] focus:outline-none focus:bg-white focus:border-[#1DB954] transition"
 />
 </div>

 <div className="bg-[#1DB954]/10/50 rounded-xl p-3 border border-blue-100 text-xxs text-blue-700 leading-normal flex items-start gap-2">
 <Sparkles className="w-4 h-4 text-[#1DB954] flex-shrink-0 mt-0.5" />
 <p>
 <strong>โหมดจดเลขเร่งด่วน:</strong> เลขครั้งก่อนถูกดึงจากระบบอัตโนมัติ 
 เพียงระบุเลขมิเตอร์หลังสุดของทุกห้อง ระบบจะคำนวณเงินสุทธิแต่ละห้องและสร้างบิลพร้อมกันทันที!
 </p>
 </div>
 </div>

 {/* Bulk Rooms Entry List Table */}
 <div className="bg-white border border-[#E0E0DB] rounded-2xl overflow-hidden ">
 <div className="px-5 py-4 border-b border-[#E0E0DB] flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 bg-[#282828]/50">
 <h3 className="text-xs font-extrabold text-[#6B6B66] uppercase tracking-wider flex items-center gap-1.5">
 <Layers className="w-4 h-4 text-[#1DB954]" />
 <span>ตารางบันทึกมิเตอร์ด่วน ({occupiedRooms.length} ห้องพัก)</span>
 </h3>
 <span className="text-[10px] bg-slate-200 text-[#6B6B66] px-2.5 py-0.5 rounded-full font-bold">
 ค่าหน่วย: ไฟ {settings.defaultElecRate} บ. / น้ำ {settings.defaultWaterRate} บ.
 </span>
 </div>

 {occupiedRooms.length === 0 ? (
 <div className="p-12 text-center space-y-2">
 <User className="w-8 h-8 text-[#8A8A85] mx-auto" />
 <p className="text-xs font-bold text-[#6B6B66]">ไม่พบห้องพักที่มีผู้เช่า</p>
 <p className="text-xxs text-[#8A8A85]">กรุณาเพิ่มสัญญาเช่าหรือเข้าพักในเมนูห้องพักก่อนเพื่อเริ่มทำรายการค่ะ</p>
 </div>
 ) : (
 <div className="overflow-x-auto">
 <table className="w-full text-left border-collapse min-w-[800px]">
 <thead>
 <tr className="bg-[#F0F0EB] text-[10px] text-[#8A8A85] uppercase tracking-wider font-bold border-b border-[#E0E0DB]">
 <th className="py-3 px-4 w-20">ห้องพัก</th>
 <th className="py-3 px-4 w-32">ผู้เช่า</th>
 <th className="py-3 px-4 w-44 text-center bg-[#F59B23]/10/20">ค่าไฟฟ้า (ครั้งก่อน → หลัง)</th>
 <th className="py-3 px-4 w-44 text-center bg-[#1DB954]/10/20">ค่าน้ำ (ครั้งก่อน → หลัง)</th>
 <th className="py-3 px-4 w-32">ค่าใช้จ่ายเพิ่มเติม (บาท)</th>
 <th className="py-3 px-4 w-40">หมายเหตุค่าเพิ่ม</th>
 <th className="py-3 px-4 w-24 text-right">ค่าเช่าหลัก</th>
 <th className="py-3 px-4 w-28 text-right">คำนวณสุทธิ</th>
 </tr>
 </thead>
 <tbody className="divide-y divide-slate-100 text-xxs">
 {occupiedRooms.map(room => {
 const roomBills = bills
 .filter(b => b.roomId === room.id)
 .sort((a, b) => b.billMonth.localeCompare(a.billMonth));

 const pE = roomBills.length > 0 ? roomBills[0].currentElec : 0;
 const pW = roomBills.length > 0 ? roomBills[0].currentWater : 0;

 const inputs = bulkInputs[room.id] || {
 priorElec: pE.toString(),
 currentElec: pE.toString(),
 elecDeduct: '0',
 priorWater: pW.toString(),
 currentWater: pW.toString(),
 waterCost: '',
 otherCost: '0',
 otherDescription: 'ค่าส่วนกลาง/บริการ'
 };

 const finalPE = inputs.priorElec !== undefined ? (parseFloat(inputs.priorElec) || 0) : pE;
 const finalPW = inputs.priorWater !== undefined ? (parseFloat(inputs.priorWater) || 0) : pW;

 const curE = inputs.currentElec !== undefined ? (parseFloat(inputs.currentElec) || 0) : finalPE;
 const curW = inputs.currentWater !== undefined ? (parseFloat(inputs.currentWater) || 0) : finalPW;
 const deductE = parseFloat(inputs.elecDeduct) || 0;

 // Electricity usage & anomaly math
 const usedElec = Math.max(0, curE - finalPE - deductE);
 const costElec = Math.round(usedElec * settings.defaultElecRate);
 const avgE = get6MonthAverage(room.id, 'elec');
 const isElecAnomaly = avgE !== null && avgE > 0 && usedElec > avgE * 2;

 // Water usage & anomaly math
 const usedWater = Math.max(0, curW - finalPW);
 const autoWaterCost = usedWater > 0 ? Math.round(usedWater * settings.defaultWaterRate) : 0;
 const costWater = inputs.waterCost !== undefined && inputs.waterCost !== '' ? (parseFloat(inputs.waterCost) || 0) : autoWaterCost;
 const avgW = get6MonthAverage(room.id, 'water');
 const isWaterAnomaly = avgW !== null && avgW > 0 && usedWater > avgW * 2;

 const extra = parseFloat(inputs.otherCost) || 0;
 const recurringExtra = (bulkDueItems[room.id] || []).reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
 const totalCalculated = room.monthlyRent + costElec + costWater + extra + recurringExtra;

 const handleFieldChange = (field: string, value: string) => {
 setBulkInputs(prev => ({
 ...prev,
 [room.id]: {
 ...prev[room.id],
 [field]: value
 }
 }));
 };

 return (
 <tr key={room.id} className="hover:bg-[#282828]/55 transition items-center">
 {/* Room Number */}
 <td className="py-3 px-4 font-black text-[#1A1A1A] text-xs">
 ห้อง {room.roomNumber}
 </td>

 {/* Tenant Info */}
 <td className="py-3 px-4 text-[#8A8A85] max-w-[120px] truncate">
 <p className="font-semibold text-[#6B6B66]">{room.tenantName}</p>
 <p className="text-[9px] text-[#8A8A85]">ประวัติครั้งก่อน: ไฟ {pE} / น้ำ {pW}</p>
 </td>

 {/* Electricity Entry */}
 <td className="py-3 px-4 bg-[#F59B23]/10/10 text-center">
 <div className="flex items-center gap-1 justify-center">
 <div className="flex flex-col items-center">
 <span className="text-[8px] text-[#F59B23] font-bold mb-0.5">ครั้งก่อน</span>
 <input
 type="number"
 step="any"
 value={inputs.priorElec ?? ''}
 onChange={(e) => handleFieldChange('priorElec', e.target.value)}
 className="w-12 bg-white border border-[#E0E0DB] rounded-md p-1 text-center font-semibold focus:outline-none focus:border-amber-500 text-[10px]"
 />
 </div>
 <span className="text-[#8A8A85] self-end mb-1">→</span>
 <div className="flex flex-col items-center">
 <span className="text-[8px] text-[#F59B23] font-bold mb-0.5">ครั้งหลัง</span>
 <input
 type="number"
 step="any"
 placeholder={inputs.priorElec ?? ''}
 value={inputs.currentElec ?? ''}
 onChange={(e) => handleFieldChange('currentElec', e.target.value)}
 className={`w-12 bg-white border rounded-md p-1 text-center font-bold focus:outline-none focus:border-amber-500 text-[10px] ${
 isElecAnomaly ? 'border-amber-500 bg-[#F59B23]/10/30' : 'border-[#E0E0DB]'
 }`}
 />
 </div>
 <span className="text-[#8A8A85] self-end mb-1">-</span>
 <div className="flex flex-col items-center">
 <span className="text-[8px] text-[#E22134] font-bold mb-0.5">หักลบ</span>
 <input
 type="number"
 step="any"
 value={inputs.elecDeduct ?? '0'}
 onChange={(e) => handleFieldChange('elecDeduct', e.target.value)}
 className="w-10 bg-white border border-[#E0E0DB] rounded-md p-1 text-center font-semibold focus:outline-none focus:border-amber-500 text-[10px]"
 />
 </div>
 {isElecAnomaly && (
 <div className="relative group cursor-pointer" title={`ค่าไฟสูงผิดปกติ 100%+ ยอดใช้เฉลี่ย 6 เดือน: ${avgE?.toFixed(1)} หน่วย (เดือนนี้: ${usedElec} หน่วย)`}>
 <AlertTriangle className="w-4 h-4 text-[#F59B23]" />
 <span className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 p-2 bg-slate-900 text-[#1A1A1A] text-[9px] rounded-lg opacity-0 group-hover:opacity-100 transition whitespace-nowrap pointer-events-none z-30">
 ใช้ไฟสูงกว่าค่าเฉลี่ย 100%+ (เฉลี่ย: {avgE?.toFixed(1)} หน่วย)
 </span>
 </div>
 )}
 </div>
 <p className="text-[9px] text-[#8A8A85] mt-1">
 ใช้ {usedElec} หน่วย 
 {deductE > 0 && <span className="text-[#E22134] font-bold"> (หัก {deductE})</span>} ({costElec.toLocaleString()} บ.)
 </p>
 </td>

 {/* Water Entry */}
 <td className="py-3 px-4 bg-[#1DB954]/10/10 text-center">
 <div className="flex items-center gap-1 justify-center">
 <div className="flex flex-col items-center">
 <span className="text-[8px] text-[#1DB954] font-bold mb-0.5">ครั้งก่อน</span>
 <input
 type="number"
 step="any"
 value={inputs.priorWater ?? ''}
 onChange={(e) => handleFieldChange('priorWater', e.target.value)}
 className="w-12 bg-white border border-[#E0E0DB] rounded-md p-1 text-center font-semibold focus:outline-none focus:border-[#1DB954] text-[10px]"
 />
 </div>
 <span className="text-[#8A8A85] self-end mb-1">→</span>
 <div className="flex flex-col items-center">
 <span className="text-[8px] text-[#1DB954] font-bold mb-0.5">ครั้งหลัง</span>
 <input
 type="number"
 step="any"
 placeholder={inputs.priorWater}
 value={inputs.currentWater ?? ''}
 onChange={(e) => handleFieldChange('currentWater', e.target.value)}
 className={`w-12 bg-white border rounded-md p-1 text-center font-bold focus:outline-none focus:border-[#1DB954] text-[10px] ${
 isWaterAnomaly ? 'border-amber-500 bg-[#F59B23]/10/30' : 'border-[#E0E0DB]'
 }`}
 />
 </div>
 <span className="text-[#8A8A85] self-end mb-1">|</span>
 <div className="flex flex-col items-center">
 <span className="text-[8px] text-[#1DB954] font-bold mb-0.5">เงินค่าน้ำ (฿)</span>
 <input
 type="number"
 step="any"
 placeholder={autoWaterCost.toString()}
 value={inputs.waterCost ?? ''}
 onChange={(e) => handleFieldChange('waterCost', e.target.value)}
 className={`w-14 bg-white border rounded-md p-1 text-center font-bold focus:outline-none focus:border-[#1DB954] text-[10px] ${
 inputs.waterCost !== '' ? 'border-amber-400 bg-[#F59B23]/8 text-[#F59B23]' : 'border-[#E0E0DB] text-[#6B6B66]'
 }`}
 />
 </div>
 {isWaterAnomaly && (
 <div className="relative group cursor-pointer" title={`ค่าน้ำสูงผิดปกติ 100%+ ยอดใช้เฉลี่ย 6 เดือน: ${avgW?.toFixed(1)} หน่วย (เดือนนี้: ${usedWater} หน่วย)`}>
 <AlertTriangle className="w-4 h-4 text-[#F59B23]" />
 <span className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 p-2 bg-slate-900 text-[#1A1A1A] text-[9px] rounded-lg opacity-0 group-hover:opacity-100 transition whitespace-nowrap pointer-events-none z-30">
 ใช้น้ำสูงกว่าค่าเฉลี่ย 100%+ (เฉลี่ย: {avgW?.toFixed(1)} หน่วย)
 </span>
 </div>
 )}
 </div>
 <p className="text-[9px] text-[#8A8A85] mt-1">
 ใช้ {usedWater} หน่วย ({costWater.toLocaleString()} บ.) {inputs.waterCost !== '' && '(กำหนดเอง)'}
 </p>
 </td>

 {/* Other Costs */}
 <td className="py-3 px-4">
 <input
 type="number"
 value={inputs.otherCost ?? '0'}
 onChange={(e) => handleFieldChange('otherCost', e.target.value)}
 className="w-full bg-white border border-[#E0E0DB] rounded-lg p-1 text-center text-xxs"
 />
 </td>

 {/* Other Costs Description */}
 <td className="py-3 px-4">
 <input
 type="text"
 placeholder="เช่น ค่าส่วนกลาง"
 value={inputs.otherDescription ?? ''}
 onChange={(e) => handleFieldChange('otherDescription', e.target.value)}
 className="w-full bg-white border border-[#E0E0DB] rounded-lg p-1 text-xxs"
 />
 {(bulkDueItems[room.id] || []).length > 0 && <p className="mt-1 text-[8px] text-[#1DB954]">ประจำ: {(bulkDueItems[room.id] || []).map((item) => `${item.label} ${Number(item.amount).toLocaleString()}`).join(', ')}</p>}
 </td>

 {/* Rent Cost */}
 <td className="py-3 px-4 text-right text-[#6B6B66] font-bold">
 {room.monthlyRent.toLocaleString()} บาท
 </td>

 {/* Calculated Total */}
 <td className="py-3 px-4 text-right font-black text-[#1DB954] text-xs">
 {totalCalculated.toLocaleString()} บาท
 </td>
 </tr>
 );
 })}
 </tbody>
 </table>
 </div>
 )}
 </div>

 {/* Actions button */}
 {occupiedRooms.length > 0 && (
 <div className="flex items-center justify-end gap-3 pt-2">
 <button
 type="button"
 onClick={onNavigateToHistory}
 className="py-2.5 px-4 rounded-xl border border-[#E0E0DB] text-[#6B6B66] font-bold bg-white hover:bg-[#E8E8E3] transition cursor-pointer text-xs"
 >
 ยกเลิกทำรายการ
 </button>
 <button
 type="submit"
 disabled={submitting}
 className="py-3 px-6 rounded-xl bg-[#1DB954] hover:bg-[#1ED760] hover:scale-[1.04] text-white font-bold transition shadow-blue-200/50 cursor-pointer text-xs flex items-center gap-2 disabled:bg-slate-150 disabled:text-slate-400"
 >
 <PlusCircle className="w-5 h-5" />
 <span>{submitting ? 'กำลังจัดส่งและคำนวณบิล...' : 'คำนวณและบันทึกสร้างบิลด่วนพร้อมกันทั้งหมด'}</span>
 </button>
 </div>
 )}
 </motion.form>
 )}
 </AnimatePresence>

 </div>
 );
};
