import React, { useCallback, useEffect, useState } from 'react';
import { CalendarClock, Pencil, Plus, Save, Trash2, X } from 'lucide-react';
import type { RecurringChargeFrequency, RecurringChargeTemplate } from '../types.ts';
import { getApiErrorMessage, unwrapApiData } from '../utils/api.ts';

interface Props { idToken?: string | null }

const MONTHS = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
const emptyForm = { name: '', description: '', defaultAmount: '', frequency: 'monthly' as RecurringChargeFrequency, billingMonths: [] as number[], isActive: true };

export const RecurringChargesSettings: React.FC<Props> = ({ idToken }) => {
  const [templates, setTemplates] = useState<RecurringChargeTemplate[]>([]);
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const headers = useCallback(() => ({ 'Content-Type': 'application/json', Authorization: `Bearer ${idToken}` }), [idToken]);
  const load = useCallback(async () => {
    if (!idToken) return;
    const response = await fetch('/api/recurring-charges/templates', { headers: headers() });
    if (!response.ok) throw new Error(getApiErrorMessage(await response.json(), 'โหลดแม่แบบไม่สำเร็จ'));
    setTemplates(unwrapApiData<RecurringChargeTemplate[]>(await response.json()) || []);
  }, [headers, idToken]);

  useEffect(() => { load().catch((reason) => setError(reason.message)); }, [load]);

  const chooseFrequency = (frequency: RecurringChargeFrequency) => setForm((current) => ({ ...current, frequency, billingMonths: frequency === 'monthly' ? [] : current.billingMonths.slice(0, frequency === 'quarterly' ? 4 : 1) }));
  const toggleMonth = (month: number) => setForm((current) => ({ ...current, billingMonths: current.billingMonths.includes(month) ? current.billingMonths.filter((item) => item !== month) : [...current.billingMonths, month].sort((a, b) => a - b) }));
  const reset = () => { setForm(emptyForm); setEditingId(null); };

  const save = async (event: React.FormEvent) => {
    event.preventDefault(); setError(null); setMessage(null);
    const expected = form.frequency === 'quarterly' ? 4 : form.frequency === 'yearly' ? 1 : 0;
    if (form.frequency !== 'monthly' && form.billingMonths.length !== expected) { setError(`กรุณาเลือกเดือนเรียกเก็บ ${expected} เดือน`); return; }
    setBusy(true);
    try {
      const response = await fetch(editingId ? `/api/recurring-charges/templates/${editingId}` : '/api/recurring-charges/templates', { method: editingId ? 'PUT' : 'POST', headers: headers(), body: JSON.stringify({ ...form, defaultAmount: Number(form.defaultAmount) || 0 }) });
      const data = await response.json(); if (!response.ok) throw new Error(getApiErrorMessage(data, 'บันทึกแม่แบบไม่สำเร็จ'));
      setMessage(editingId ? 'อัปเดตแม่แบบแล้ว' : 'สร้างแม่แบบแล้ว'); reset(); await load();
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'บันทึกแม่แบบไม่สำเร็จ'); } finally { setBusy(false); }
  };

  const edit = (item: RecurringChargeTemplate) => { setEditingId(item.id); setForm({ name: item.name, description: item.description || '', defaultAmount: String(item.defaultAmount), frequency: item.frequency, billingMonths: item.billingMonths || [], isActive: item.isActive }); };
  const remove = async (id: number) => {
    if (!window.confirm('ปิดใช้งานแม่แบบนี้หรือไม่? ประวัติในบิลเดิมจะยังอยู่')) return;
    const response = await fetch(`/api/recurring-charges/templates/${id}`, { method: 'DELETE', headers: headers() });
    if (!response.ok) { setError(getApiErrorMessage(await response.json(), 'ลบแม่แบบไม่สำเร็จ')); return; }
    if (editingId === id) reset(); await load();
  };

  return <section className="rounded-2xl border border-[#E0E0DB] bg-white p-6 text-xs text-[#6B6B66] space-y-5">
    <div><h3 className="flex items-center gap-2 text-sm font-bold text-[#1A1A1A]"><CalendarClock className="h-4 w-4 text-[#1DB954]" />แม่แบบค่าบริการประจำ</h3><p className="mt-1 text-[11px] text-[#8A8A85]">กำหนดค่าบริการรายเดือน รายไตรมาส หรือรายปี แล้วนำไปเปิดใช้แยกรายห้อง</p></div>
    {error && <p className="rounded-xl border border-red-200 bg-red-50 p-3 text-red-700">{error}</p>}{message && <p className="rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-emerald-700">{message}</p>}
    <form onSubmit={save} className="space-y-3 rounded-xl border border-[#E0E0DB] bg-[#F0F0EB] p-4">
      <div className="grid gap-3 sm:grid-cols-2"><input required maxLength={120} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="ชื่อ เช่น อินเทอร์เน็ต" className="rounded-xl border border-[#E0E0DB] bg-white p-2.5" /><input min="0" type="number" value={form.defaultAmount} onChange={(e) => setForm({ ...form, defaultAmount: e.target.value })} placeholder="ราคาเริ่มต้น" className="rounded-xl border border-[#E0E0DB] bg-white p-2.5" /></div>
      <input maxLength={500} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="รายละเอียด (ไม่บังคับ)" className="w-full rounded-xl border border-[#E0E0DB] bg-white p-2.5" />
      <div className="flex flex-wrap gap-2">{(['monthly', 'quarterly', 'yearly'] as RecurringChargeFrequency[]).map((frequency) => <button type="button" key={frequency} onClick={() => chooseFrequency(frequency)} className={`rounded-lg border px-3 py-2 font-bold ${form.frequency === frequency ? 'border-[#1DB954] bg-[#1DB954]/10 text-[#168c43]' : 'border-[#E0E0DB] bg-white'}`}>{frequency === 'monthly' ? 'รายเดือน' : frequency === 'quarterly' ? 'รายไตรมาส' : 'รายปี'}</button>)}</div>
      {form.frequency !== 'monthly' && <div><p className="mb-2 font-bold">เลือกเดือนเรียกเก็บ ({form.frequency === 'quarterly' ? '4' : '1'} เดือน)</p><div className="grid grid-cols-4 gap-2 sm:grid-cols-6">{MONTHS.map((label, index) => <button type="button" key={label} onClick={() => toggleMonth(index + 1)} className={`rounded-lg border p-2 ${form.billingMonths.includes(index + 1) ? 'border-[#1DB954] bg-[#1DB954]/10 text-[#168c43]' : 'border-[#E0E0DB] bg-white'}`}>{label}</button>)}</div></div>}
      <label className="flex items-center gap-2"><input type="checkbox" checked={form.isActive} onChange={(e) => setForm({ ...form, isActive: e.target.checked })} /> เปิดใช้งาน</label>
      <div className="flex justify-end gap-2">{editingId && <button type="button" onClick={reset} className="flex items-center gap-1 rounded-xl border bg-white px-3 py-2"><X className="h-3.5 w-3.5" />ยกเลิก</button>}<button disabled={busy} className="flex items-center gap-1 rounded-xl bg-[#1DB954] px-4 py-2 font-bold text-white">{editingId ? <Save className="h-3.5 w-3.5" /> : <Plus className="h-3.5 w-3.5" />}{busy ? 'กำลังบันทึก...' : editingId ? 'บันทึก' : 'เพิ่มแม่แบบ'}</button></div>
    </form>
    <div className="space-y-2">{templates.length === 0 ? <p className="rounded-xl border border-dashed p-5 text-center text-[#8A8A85]">ยังไม่มีแม่แบบค่าบริการ</p> : templates.map((item) => <div key={item.id} className="flex items-center justify-between gap-3 rounded-xl border border-[#E0E0DB] p-3"><div><p className="font-bold text-[#1A1A1A]">{item.name} · {Number(item.defaultAmount).toLocaleString()} บาท</p><p className="text-[10px] text-[#8A8A85]">{item.frequency === 'monthly' ? 'ทุกเดือน' : `เดือน ${item.billingMonths.join(', ')}`} · {item.isActive ? 'เปิดใช้' : 'ปิดใช้'}</p></div><div className="flex gap-1"><button onClick={() => edit(item)} className="rounded-lg border p-2" title="แก้ไข"><Pencil className="h-3.5 w-3.5" /></button><button onClick={() => remove(item.id)} className="rounded-lg border p-2 text-red-600" title="ลบ"><Trash2 className="h-3.5 w-3.5" /></button></div></div>)}</div>
  </section>;
};
