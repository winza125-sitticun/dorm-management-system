import React, { useMemo, useState } from 'react';
import {
  CalendarClock,
  Edit3,
  Home,
  Loader2,
  NotebookPen,
  Pin,
  Plus,
  Search,
  Trash2,
  X,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { Note, NoteColor, Room } from '../types.ts';
import { getApiErrorMessage } from '../utils/api.ts';

interface NotesViewProps {
  notes: Note[];
  rooms: Room[];
  idToken: string | null;
  loading: boolean;
  hasMore: boolean;
  onRefresh: () => Promise<void> | void;
  onLoadMore: () => Promise<void> | void;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

const NOTE_COLORS: Array<{ value: NoteColor; label: string; swatch: string }> = [
  { value: 'yellow', label: 'เหลือง', swatch: 'bg-amber-300' },
  { value: 'green', label: 'เขียว', swatch: 'bg-emerald-300' },
  { value: 'blue', label: 'ฟ้า', swatch: 'bg-sky-300' },
  { value: 'pink', label: 'ชมพู', swatch: 'bg-rose-300' },
  { value: 'purple', label: 'ม่วง', swatch: 'bg-violet-300' },
  { value: 'gray', label: 'เทา', swatch: 'bg-zinc-300' },
];

const CARD_STYLES: Record<NoteColor, string> = {
  yellow: 'border-amber-200 bg-amber-50',
  green: 'border-emerald-200 bg-emerald-50',
  blue: 'border-sky-200 bg-sky-50',
  pink: 'border-rose-200 bg-rose-50',
  purple: 'border-violet-200 bg-violet-50',
  gray: 'border-zinc-200 bg-zinc-50',
};

const NOTE_TITLE_MAX_LENGTH = 120;
const NOTE_CONTENT_MAX_LENGTH = 5_000;

export const NotesView: React.FC<NotesViewProps> = ({
  notes,
  rooms,
  idToken,
  loading,
  hasMore,
  onRefresh,
  onLoadMore,
  showToast,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState<'all' | 'pinned' | 'room'>('all');
  const [filterRoomId, setFilterRoomId] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<Note | null>(null);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [roomId, setRoomId] = useState('');
  const [color, setColor] = useState<NoteColor>('yellow');
  const [isPinned, setIsPinned] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [busyNoteId, setBusyNoteId] = useState<number | null>(null);

  const headers = () => ({
    'Content-Type': 'application/json',
    Authorization: `Bearer ${idToken}`,
  });

  const sortedRooms = useMemo(
    () => [...rooms].sort((a, b) => a.roomNumber.localeCompare(b.roomNumber, 'th', { numeric: true })),
    [rooms]
  );

  const filteredNotes = useMemo(() => {
    const query = searchTerm.trim().toLocaleLowerCase('th');
    return notes.filter((note) => {
      const matchesSearch = !query || note.title.toLocaleLowerCase('th').includes(query) || note.content.toLocaleLowerCase('th').includes(query);
      const matchesFilter = filter === 'all'
        || (filter === 'pinned' && note.isPinned === 1)
        || (filter === 'room' && filterRoomId !== '' && note.roomId === Number(filterRoomId));
      return matchesSearch && matchesFilter;
    });
  }, [filter, filterRoomId, notes, searchTerm]);

  const resetForm = () => {
    setEditingNote(null);
    setTitle('');
    setContent('');
    setRoomId('');
    setColor('yellow');
    setIsPinned(false);
  };

  const openCreate = () => {
    resetForm();
    setIsModalOpen(true);
  };

  const openEdit = (note: Note) => {
    setEditingNote(note);
    setTitle(note.title);
    setContent(note.content);
    setRoomId(note.roomId ? String(note.roomId) : '');
    setColor(note.color);
    setIsPinned(note.isPinned === 1);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    if (submitting) return;
    setIsModalOpen(false);
    resetForm();
  };

  const submitNote = async (event: React.FormEvent) => {
    event.preventDefault();
    const cleanTitle = title.trim();
    const cleanContent = content.trim();
    if (!cleanTitle || !cleanContent) {
      showToast('กรุณากรอกหัวข้อและรายละเอียดโน้ต', 'error');
      return;
    }

    setSubmitting(true);
    try {
      const response = await fetch(editingNote ? `/api/notes/${editingNote.id}` : '/api/notes', {
        method: editingNote ? 'PUT' : 'POST',
        headers: headers(),
        body: JSON.stringify({
          title: cleanTitle,
          content: cleanContent,
          roomId: roomId ? Number(roomId) : null,
          color,
          isPinned,
        }),
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(getApiErrorMessage(payload, 'ไม่สามารถบันทึกโน้ตได้'));
      showToast(editingNote ? 'แก้ไขโน้ตเรียบร้อยแล้ว' : 'สร้างโน้ตเรียบร้อยแล้ว', 'success');
      setIsModalOpen(false);
      resetForm();
      await onRefresh();
    } catch (error) {
      showToast(error instanceof Error ? error.message : 'ไม่สามารถบันทึกโน้ตได้', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const togglePin = async (note: Note) => {
    setBusyNoteId(note.id);
    try {
      const response = await fetch(`/api/notes/${note.id}`, {
        method: 'PUT',
        headers: headers(),
        body: JSON.stringify({ isPinned: note.isPinned !== 1 }),
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(getApiErrorMessage(payload, 'ไม่สามารถเปลี่ยนสถานะปักหมุดได้'));
      await onRefresh();
    } catch (error) {
      showToast(error instanceof Error ? error.message : 'ไม่สามารถเปลี่ยนสถานะปักหมุดได้', 'error');
    } finally {
      setBusyNoteId(null);
    }
  };

  const deleteNote = async (note: Note) => {
    if (!window.confirm(`ต้องการลบโน้ต “${note.title}” ใช่หรือไม่?`)) return;
    setBusyNoteId(note.id);
    try {
      const response = await fetch(`/api/notes/${note.id}`, { method: 'DELETE', headers: headers() });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(getApiErrorMessage(payload, 'ไม่สามารถลบโน้ตได้'));
      showToast('ลบโน้ตเรียบร้อยแล้ว', 'success');
      await onRefresh();
    } catch (error) {
      showToast(error instanceof Error ? error.message : 'ไม่สามารถลบโน้ตได้', 'error');
    } finally {
      setBusyNoteId(null);
    }
  };

  const formatDate = (value: string) => {
    const date = new Date(value);
    return Number.isNaN(date.getTime())
      ? '-'
      : date.toLocaleString('th-TH', { dateStyle: 'medium', timeStyle: 'short' });
  };

  return (
    <div className="space-y-6 pb-12 font-sans">
      <section className="flex flex-col gap-4 rounded-2xl border border-[#E0E0DB] bg-white p-6 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <div className="rounded-xl bg-amber-100 p-3 text-amber-700">
            <NotebookPen className="h-7 w-7" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[#1A1A1A]">โน้ตภายในหอพัก</h1>
            <p className="text-sm text-[#8A8A85]">จดเรื่องที่ต้องติดตามและแชร์ข้อมูลกับผู้ดูแล โดยไม่แสดงแก่ผู้เช่า</p>
          </div>
        </div>
        <button onClick={openCreate} className="inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-500 px-4 py-3 text-sm font-bold text-white shadow-sm transition hover:bg-emerald-600">
          <Plus className="h-4 w-4" /> เพิ่มโน้ต
        </button>
      </section>

      <section className="grid gap-3 sm:grid-cols-3">
        <div className="rounded-2xl border border-[#E0E0DB] bg-white p-4">
          <p className="text-xs font-semibold text-[#8A8A85]">โน้ตทั้งหมด</p>
          <p className="mt-1 text-2xl font-extrabold text-[#1A1A1A]">{notes.length}</p>
        </div>
        <div className="rounded-2xl border border-[#E0E0DB] bg-white p-4">
          <p className="text-xs font-semibold text-[#8A8A85]">ปักหมุด</p>
          <p className="mt-1 text-2xl font-extrabold text-amber-600">{notes.filter((note) => note.isPinned === 1).length}</p>
        </div>
        <div className="rounded-2xl border border-[#E0E0DB] bg-white p-4">
          <p className="text-xs font-semibold text-[#8A8A85]">เชื่อมโยงห้องพัก</p>
          <p className="mt-1 text-2xl font-extrabold text-sky-600">{notes.filter((note) => note.roomId !== null).length}</p>
        </div>
      </section>

      <section className="flex flex-col gap-3 rounded-2xl border border-[#E0E0DB] bg-white p-4 lg:flex-row">
        <label className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#8A8A85]" />
          <input value={searchTerm} onChange={(event) => setSearchTerm(event.target.value)} placeholder="ค้นหาหัวข้อหรือรายละเอียด..." className="w-full rounded-xl border border-[#E0E0DB] bg-[#FAFAF7] py-2.5 pl-10 pr-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/10" />
        </label>
        <div className="flex flex-wrap gap-2">
          {(['all', 'pinned', 'room'] as const).map((value) => (
            <button key={value} onClick={() => setFilter(value)} className={`rounded-xl px-3 py-2 text-xs font-bold transition ${filter === value ? 'bg-[#1A1A1A] text-white' : 'bg-[#F0F0EB] text-[#6B6B66] hover:bg-[#E8E8E3]'}`}>
              {value === 'all' ? 'ทั้งหมด' : value === 'pinned' ? 'ปักหมุด' : 'ตามห้อง'}
            </button>
          ))}
        </div>
        {filter === 'room' && (
          <select value={filterRoomId} onChange={(event) => setFilterRoomId(event.target.value)} className="rounded-xl border border-[#E0E0DB] bg-white px-3 py-2 text-sm outline-none focus:border-emerald-500">
            <option value="">เลือกห้องพัก</option>
            {sortedRooms.map((room) => <option key={room.id} value={room.id}>ห้อง {room.roomNumber}</option>)}
          </select>
        )}
      </section>

      {loading && notes.length === 0 ? (
        <div className="flex min-h-52 items-center justify-center rounded-2xl border border-[#E0E0DB] bg-white">
          <Loader2 className="h-7 w-7 animate-spin text-emerald-500" />
        </div>
      ) : filteredNotes.length === 0 ? (
        <div className="flex min-h-52 flex-col items-center justify-center rounded-2xl border border-dashed border-[#D8D8D2] bg-white p-8 text-center">
          <NotebookPen className="mb-3 h-10 w-10 text-[#B0B0AA]" />
          <h2 className="font-bold text-[#6B6B66]">ยังไม่พบโน้ต</h2>
          <p className="mt-1 text-sm text-[#8A8A85]">เพิ่มโน้ตใหม่หรือปรับคำค้นหาและตัวกรอง</p>
        </div>
      ) : (
        <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {filteredNotes.map((note) => (
            <article key={note.id} className={`flex min-h-64 flex-col rounded-2xl border p-5 shadow-sm ${CARD_STYLES[note.color] || CARD_STYLES.yellow}`}>
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    {note.isPinned === 1 && <Pin className="h-4 w-4 shrink-0 fill-amber-500 text-amber-600" />}
                    <h2 className="break-words text-lg font-extrabold text-[#1A1A1A]">{note.title}</h2>
                  </div>
                  {note.roomNumber && (
                    <span className="mt-2 inline-flex items-center gap-1 rounded-full bg-white/70 px-2 py-1 text-[11px] font-bold text-[#6B6B66]">
                      <Home className="h-3 w-3" /> ห้อง {note.roomNumber}
                    </span>
                  )}
                </div>
                {busyNoteId === note.id && <Loader2 className="h-4 w-4 shrink-0 animate-spin text-[#6B6B66]" />}
              </div>
              <p className="mt-4 max-h-40 flex-1 overflow-hidden whitespace-pre-wrap break-words text-sm leading-6 text-[#42423E]">{note.content}</p>
              <div className="mt-5 border-t border-black/5 pt-3">
                <div className="flex items-center gap-1 text-[11px] text-[#777770]">
                  <CalendarClock className="h-3 w-3" /> แก้ไข {formatDate(note.updatedAt)}
                </div>
                <p className="mt-1 truncate text-[11px] text-[#8A8A85]">โดย {note.createdByEmail || 'ผู้ดูแลระบบ'}</p>
                <div className="mt-3 flex items-center justify-end gap-1">
                  <button disabled={busyNoteId === note.id} onClick={() => togglePin(note)} title={note.isPinned === 1 ? 'ยกเลิกปักหมุด' : 'ปักหมุด'} className="rounded-lg p-2 text-[#6B6B66] transition hover:bg-white/70 disabled:opacity-50">
                    <Pin className="h-4 w-4" />
                  </button>
                  <button disabled={busyNoteId === note.id} onClick={() => openEdit(note)} title="แก้ไขโน้ต" className="rounded-lg p-2 text-[#6B6B66] transition hover:bg-white/70 disabled:opacity-50">
                    <Edit3 className="h-4 w-4" />
                  </button>
                  <button disabled={busyNoteId === note.id} onClick={() => deleteNote(note)} title="ลบโน้ต" className="rounded-lg p-2 text-rose-600 transition hover:bg-white/70 disabled:opacity-50">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </article>
          ))}
        </section>
      )}

      {hasMore && !searchTerm.trim() && filter === 'all' && (
        <div className="flex justify-center">
          <button disabled={loading} onClick={() => onLoadMore()} className="inline-flex items-center gap-2 rounded-xl border border-[#D8D8D2] bg-white px-4 py-2.5 text-sm font-bold text-[#54544F] shadow-sm hover:bg-[#F5F5F0] disabled:cursor-not-allowed disabled:opacity-60">
            {loading && <Loader2 className="h-4 w-4 animate-spin" />}{loading ? 'กำลังโหลด...' : 'โหลดโน้ตเพิ่มเติม'}
          </button>
        </div>
      )}

      <AnimatePresence>
        {isModalOpen && (
          <motion.div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onMouseDown={(event) => event.target === event.currentTarget && closeModal()}>
            <motion.div role="dialog" aria-modal="true" aria-labelledby="note-modal-title" className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-2xl bg-white shadow-2xl" initial={{ opacity: 0, y: 18, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 12, scale: 0.98 }}>
              <div className="flex items-center justify-between border-b border-[#E0E0DB] px-6 py-4">
                <h2 id="note-modal-title" className="text-lg font-extrabold text-[#1A1A1A]">{editingNote ? 'แก้ไขโน้ต' : 'เพิ่มโน้ตใหม่'}</h2>
                <button type="button" onClick={closeModal} disabled={submitting} className="rounded-lg p-2 text-[#6B6B66] hover:bg-[#F0F0EB] disabled:opacity-50"><X className="h-5 w-5" /></button>
              </div>
              <form onSubmit={submitNote} className="space-y-5 p-6">
                <label className="block">
                  <span className="mb-1.5 block text-sm font-bold text-[#54544F]">หัวข้อ *</span>
                  <input required maxLength={NOTE_TITLE_MAX_LENGTH} value={title} onChange={(event) => setTitle(event.target.value)} className="w-full rounded-xl border border-[#D8D8D2] px-3 py-2.5 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/10" placeholder="เช่น ติดตามค่าเช่าห้อง 205" />
                  <span className="mt-1 block text-right text-[11px] text-[#8A8A85]">{title.length}/{NOTE_TITLE_MAX_LENGTH}</span>
                </label>
                <label className="block">
                  <span className="mb-1.5 block text-sm font-bold text-[#54544F]">รายละเอียด *</span>
                  <textarea required maxLength={NOTE_CONTENT_MAX_LENGTH} rows={8} value={content} onChange={(event) => setContent(event.target.value)} className="w-full resize-y rounded-xl border border-[#D8D8D2] px-3 py-2.5 text-sm leading-6 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/10" placeholder="บันทึกรายละเอียดที่ต้องติดตาม..." />
                  <span className="mt-1 block text-right text-[11px] text-[#8A8A85]">{content.length.toLocaleString()}/{NOTE_CONTENT_MAX_LENGTH.toLocaleString()}</span>
                </label>
                <div className="grid gap-4 sm:grid-cols-2">
                  <label className="block">
                    <span className="mb-1.5 block text-sm font-bold text-[#54544F]">ห้องพักที่เกี่ยวข้อง</span>
                    <select value={roomId} onChange={(event) => setRoomId(event.target.value)} className="w-full rounded-xl border border-[#D8D8D2] bg-white px-3 py-2.5 text-sm outline-none focus:border-emerald-500">
                      <option value="">ไม่ระบุห้อง</option>
                      {sortedRooms.map((room) => <option key={room.id} value={room.id}>ห้อง {room.roomNumber}</option>)}
                    </select>
                  </label>
                  <div>
                    <span className="mb-1.5 block text-sm font-bold text-[#54544F]">สีโน้ต</span>
                    <div className="flex flex-wrap gap-2">
                      {NOTE_COLORS.map((option) => (
                        <button key={option.value} type="button" onClick={() => setColor(option.value)} title={option.label} aria-label={`เลือกสี${option.label}`} aria-pressed={color === option.value} className={`h-9 w-9 rounded-full border-2 ${option.swatch} ${color === option.value ? 'border-[#1A1A1A] ring-2 ring-black/10' : 'border-white'}`} />
                      ))}
                    </div>
                  </div>
                </div>
                <label className="flex cursor-pointer items-center gap-3 rounded-xl border border-[#E0E0DB] bg-[#FAFAF7] p-3">
                  <input type="checkbox" checked={isPinned} onChange={(event) => setIsPinned(event.target.checked)} className="h-4 w-4 accent-emerald-500" />
                  <span className="flex items-center gap-2 text-sm font-bold text-[#54544F]"><Pin className="h-4 w-4" /> ปักหมุดโน้ตนี้ไว้ด้านบน</span>
                </label>
                <div className="flex justify-end gap-2 border-t border-[#E0E0DB] pt-5">
                  <button type="button" onClick={closeModal} disabled={submitting} className="rounded-xl border border-[#D8D8D2] px-4 py-2.5 text-sm font-bold text-[#6B6B66] hover:bg-[#F5F5F0] disabled:opacity-50">ยกเลิก</button>
                  <button type="submit" disabled={submitting} className="inline-flex min-w-32 items-center justify-center gap-2 rounded-xl bg-emerald-500 px-4 py-2.5 text-sm font-bold text-white hover:bg-emerald-600 disabled:cursor-not-allowed disabled:opacity-60">
                    {submitting && <Loader2 className="h-4 w-4 animate-spin" />}{submitting ? 'กำลังบันทึก...' : 'บันทึกโน้ต'}
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
