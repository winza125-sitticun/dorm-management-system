import React, { useEffect, useMemo, useState } from 'react';
import { CheckCircle2, ClipboardCheck, Loader2, Plus, RefreshCw, Sparkles } from 'lucide-react';
import { HousekeepingStatus, HousekeepingTask, Room, UserProfile } from '../types.ts';
import { getApiErrorMessage } from '../utils/api.ts';
import { canTransitionHousekeeping } from '../utils/housekeeping.ts';

interface Props {
  tasks: HousekeepingTask[];
  rooms: Room[];
  staff: UserProfile[];
  idToken: string | null;
  loading: boolean;
  canManage: boolean;
  onRefresh: () => Promise<void> | void;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

const statuses: Array<{ value: HousekeepingStatus; label: string; style: string }> = [
  { value: 'pending', label: 'รอดำเนินการ', style: 'bg-amber-50 text-amber-700 border-amber-200' },
  { value: 'in_progress', label: 'กำลังทำ', style: 'bg-blue-50 text-blue-700 border-blue-200' },
  { value: 'ready_for_inspection', label: 'พร้อมตรวจ', style: 'bg-violet-50 text-violet-700 border-violet-200' },
  { value: 'completed', label: 'เสร็จแล้ว', style: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
  { value: 'cancelled', label: 'ยกเลิก', style: 'bg-zinc-100 text-zinc-600 border-zinc-200' },
];

export const HousekeepingView: React.FC<Props> = ({ tasks, rooms, staff: initialStaff, idToken, loading, canManage, onRefresh, showToast }) => {
  const [filter, setFilter] = useState<'open' | 'all'>('open');
  const [staff, setStaff] = useState<UserProfile[]>(initialStaff);
  const [roomId, setRoomId] = useState('');
  const [assignedUserId, setAssignedUserId] = useState('');
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!idToken) return;
    fetch('/api/caretakers', { headers: { Authorization: `Bearer ${idToken}` } })
      .then((response) => response.ok ? response.json() : Promise.reject())
      .then((payload) => setStaff(Array.isArray(payload) ? payload : (payload.data || [])))
      .catch(() => setStaff(initialStaff));
  }, [idToken, initialStaff]);

  const housekeepers = staff.filter((person) => person.role === 'housekeeper');
  const visibleTasks = useMemo(() => filter === 'all' ? tasks : tasks.filter((task) => !['completed', 'cancelled'].includes(task.status)), [filter, tasks]);
  const headers = { 'Content-Type': 'application/json', Authorization: `Bearer ${idToken}` };

  const createTask = async (event: React.FormEvent) => {
    event.preventDefault(); if (!roomId) return;
    setSaving(true);
    try {
      const response = await fetch('/api/housekeeping', { method: 'POST', headers, body: JSON.stringify({ roomId: Number(roomId), assignedUserId: assignedUserId ? Number(assignedUserId) : null, note }) });
      const payload = await response.json().catch(() => ({})); if (!response.ok) throw new Error(getApiErrorMessage(payload, 'สร้างงานไม่สำเร็จ'));
      setRoomId(''); setAssignedUserId(''); setNote(''); await onRefresh(); showToast('สร้างงานแม่บ้านเรียบร้อยแล้ว', 'success');
    } catch (error) { showToast(error instanceof Error ? error.message : 'สร้างงานไม่สำเร็จ', 'error'); } finally { setSaving(false); }
  };

  const updateTask = async (task: HousekeepingTask, changes: Partial<HousekeepingTask>) => {
    setSaving(true);
    try {
      const response = await fetch(`/api/housekeeping/${task.id}`, { method: 'PUT', headers, body: JSON.stringify({ status: changes.status || task.status, assignedUserId: changes.assignedUserId === undefined ? task.assignedUserId : changes.assignedUserId, note: changes.note === undefined ? task.note : changes.note, inspectionNote: changes.inspectionNote === undefined ? task.inspectionNote : changes.inspectionNote }) });
      const payload = await response.json().catch(() => ({})); if (!response.ok) throw new Error(getApiErrorMessage(payload, 'อัปเดตงานไม่สำเร็จ'));
      await onRefresh(); showToast('อัปเดตงานแม่บ้านแล้ว', 'success');
    } catch (error) { showToast(error instanceof Error ? error.message : 'อัปเดตงานไม่สำเร็จ', 'error'); } finally { setSaving(false); }
  };

  return <div className="space-y-5 font-sans">
    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div><h2 className="flex items-center gap-2 text-xl font-bold text-[#1A1A1A]"><Sparkles className="h-5 w-5 text-rose-500" />งานแม่บ้าน</h2><p className="mt-1 text-xs text-[#8A8A85]">ติดตามการทำความสะอาดหลังย้ายออกและงานเพิ่มเติม</p></div>
      <button onClick={() => void onRefresh()} className="flex items-center justify-center gap-2 rounded-xl border border-[#E0E0DB] bg-white px-3 py-2 text-xs font-bold"><RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />รีเฟรช</button>
    </div>

    {canManage && <form onSubmit={createTask} className="grid gap-3 rounded-2xl border border-[#E0E0DB] bg-white p-4 sm:grid-cols-[1fr_1fr_2fr_auto]">
      <select value={roomId} onChange={(e) => setRoomId(e.target.value)} required className="rounded-xl border border-[#E0E0DB] bg-[#F8F8F5] p-2.5 text-xs"><option value="">เลือกห้อง</option>{rooms.map((room) => <option key={room.id} value={room.id}>ห้อง {room.roomNumber}</option>)}</select>
      <select value={assignedUserId} onChange={(e) => setAssignedUserId(e.target.value)} className="rounded-xl border border-[#E0E0DB] bg-[#F8F8F5] p-2.5 text-xs"><option value="">ยังไม่มอบหมาย</option>{housekeepers.map((person) => <option key={person.id} value={person.id}>{person.email}</option>)}</select>
      <input value={note} onChange={(e) => setNote(e.target.value)} maxLength={500} placeholder="หมายเหตุงานทำความสะอาด" className="rounded-xl border border-[#E0E0DB] bg-[#F8F8F5] p-2.5 text-xs" />
      <button disabled={saving} className="flex items-center justify-center gap-1.5 rounded-xl bg-rose-500 px-4 py-2.5 text-xs font-bold text-white disabled:opacity-50">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}เพิ่มงาน</button>
    </form>}

    <div className="flex gap-2">{(['open', 'all'] as const).map((value) => <button key={value} onClick={() => setFilter(value)} className={`rounded-full px-3 py-1.5 text-xs font-bold ${filter === value ? 'bg-[#1A1A1A] text-white' : 'bg-white text-[#6B6B66] border border-[#E0E0DB]'}`}>{value === 'open' ? 'งานที่ยังไม่เสร็จ' : 'ทั้งหมด'}</button>)}</div>
    <div className="grid gap-4 lg:grid-cols-2">
      {visibleTasks.map((task) => { const status = statuses.find((item) => item.value === task.status)!; return <article key={task.id} className="rounded-2xl border border-[#E0E0DB] bg-white p-4 shadow-sm">
        <div className="flex items-start justify-between gap-3"><div><p className="text-sm font-black text-[#1A1A1A]">ห้อง {task.roomNumber}</p><p className="text-[10px] text-[#8A8A85]">{task.source === 'checkout' ? 'สร้างอัตโนมัติหลังย้ายออก' : 'งานที่สร้างเอง'} • {new Date(task.createdAt).toLocaleString('th-TH')}</p></div><span className={`rounded-full border px-2.5 py-1 text-[10px] font-bold ${status.style}`}>{status.label}</span></div>
        {task.note && <p className="mt-3 rounded-xl bg-[#F8F8F5] p-3 text-xs text-[#6B6B66]">{task.note}</p>}
        <p className="mt-3 text-[10px] text-[#8A8A85]">ผู้รับผิดชอบ: {task.assignedUserEmail || 'ยังไม่มอบหมาย'}</p>
        {canManage && <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">{statuses.filter((item) => item.value !== task.status && canTransitionHousekeeping(task.status, item.value)).map((item) => <button key={item.value} disabled={saving} onClick={() => void updateTask(task, { status: item.value })} className="rounded-lg border border-[#E0E0DB] px-2 py-1.5 text-[10px] font-bold hover:bg-[#F0F0EB]">{item.label}</button>)}</div>}
      </article>; })}
      {!loading && visibleTasks.length === 0 && <div className="col-span-full flex flex-col items-center rounded-2xl border border-dashed border-[#D8D8D2] bg-white py-14 text-center"><CheckCircle2 className="mb-3 h-9 w-9 text-emerald-500" /><p className="text-sm font-bold">ไม่มีงานแม่บ้านค้างอยู่</p></div>}
    </div>
  </div>;
};
