import React, { useState, useMemo } from 'react';
import { useDebounce } from '../hooks/useDebounce.ts';
import { 
 Wrench, 
 Plus, 
 Search, 
 Filter, 
 Clock, 
 CheckCircle2, 
 AlertCircle, 
 XCircle, 
 Trash2, 
 Edit3, 
 Eye, 
 Image as ImageIcon, 
 User, 
 Phone, 
 Home, 
 DollarSign, 
 Tag, 
 AlertTriangle,
 X,
 FileText,
 Check
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Room, MaintenanceTicket, TicketCategory, TicketPriority, TicketStatus } from '../types.ts';

interface MaintenanceViewProps {
 tickets: MaintenanceTicket[];
 rooms: Room[];
 idToken: string | null;
 onRefresh: () => void;
 showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
 canManage?: boolean;
}

const CATEGORY_LABELS: Record<TicketCategory, { label: string; icon: string; color: string }> = {
 plumbing: { label: 'ระบบประปา/ห้องน้ำ', icon: '🚰', color: 'bg-[#1DB954]/8 text-blue-700 border-[#1DB954]/30' },
 electrical: { label: 'ระบบไฟฟ้า/หลอดไฟ', icon: '⚡', color: 'bg-[#F59B23]/8 text-amber-700 border-amber-200' },
 appliance: { label: 'เครื่องใช้ไฟฟ้า (แอร์/ตู้เย็น)', icon: '❄️', color: 'bg-cyan-50 text-cyan-700 border-cyan-200' },
 furniture: { label: 'เฟอร์นิเจอร์/เตียง/ตู้', icon: '🪑', color: 'bg-[#A855F7]/8 text-purple-700 border-purple-200' },
 structure: { label: 'ตัวห้อง/ประตู/หน้าต่าง', icon: '🚪', color: 'bg-[#1DB954]/8 text-[#1DB954] border-[#1DB954]/30' },
 other: { label: 'อื่นๆ', icon: '🔧', color: 'bg-[#F0F0EB] text-[#6B6B66] border-[#E0E0DB]' },
};

const PRIORITY_BADGES: Record<TicketPriority, { label: string; bg: string }> = {
 low: { label: 'ปกติ', bg: 'bg-[#F0F0EB] text-[#6B6B66]' },
 medium: { label: 'ปานกลาง', bg: 'bg-[#1DB954]/8 text-blue-800' },
 high: { label: 'สูง', bg: 'bg-orange-100 text-orange-800' },
 urgent: { label: 'ด่วนมาก ⚠️', bg: 'bg-[#E22134]/8 text-[#E22134] font-semibold' },
};

const STATUS_BADGES: Record<TicketStatus, { label: string; color: string; icon: any }> = {
 pending: { label: 'รอดำเนินการ', color: 'bg-[#F59B23]/8 text-[#F59B23] border-[#F59B23]/30', icon: Clock },
 in_progress: { label: 'กำลังซ่อมแซม', color: 'bg-[#1DB954]/8 text-blue-800 border-[#1DB954]/30', icon: Wrench },
 completed: { label: 'เสร็จสิ้นแล้ว', color: 'bg-[#1DB954]/8 text-[#1DB954] border-[#1DB954]/30', icon: CheckCircle2 },
 cancelled: { label: 'ยกเลิก', color: 'bg-[#F0F0EB] text-[#6B6B66] border-[#E0E0DB]', icon: XCircle },
};

export const MaintenanceView: React.FC<MaintenanceViewProps> = ({
 tickets,
 rooms,
 idToken,
 onRefresh,
 showToast,
 canManage = true,
}) => {
 const [searchTerm, setSearchTerm] = useState('');
 const [selectedStatus, setSelectedStatus] = useState<string>('all');
 const [selectedCategory, setSelectedCategory] = useState<string>('all');
 
 // Modals
 const [selectedTicket, setSelectedTicket] = useState<MaintenanceTicket | null>(null);
 const [isEditModalOpen, setIsEditModalOpen] = useState(false);
 const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

 // Edit form state
 const [editStatus, setEditStatus] = useState<TicketStatus>('pending');
 const [editPriority, setEditPriority] = useState<TicketPriority>('medium');
 const [editRepairCost, setEditRepairCost] = useState<number>(0);
 const [editTechnicianNote, setEditTechnicianNote] = useState<string>('');
 const [isSubmitting, setIsSubmitting] = useState(false);

 // Create form state
 const [newRoomId, setNewRoomId] = useState<string>('');
 const [newTitle, setNewTitle] = useState<string>('');
 const [newDescription, setNewDescription] = useState<string>('');
 const [newCategory, setNewCategory] = useState<TicketCategory>('other');
 const [newPriority, setNewPriority] = useState<TicketPriority>('medium');
 const [newImageUrl, setNewImageUrl] = useState<string>('');

 const getHeaders = () => ({
 'Content-Type': 'application/json',
 'Authorization': `Bearer ${idToken}`,
 });

 const debouncedSearchTerm = useDebounce(searchTerm, 300);

 // Filtered tickets with useMemo
 const filteredTickets = useMemo(() => {
   return tickets.filter((ticket) => {
     const matchesSearch = 
       ticket.roomNumber.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
       ticket.title.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
       (ticket.tenantName && ticket.tenantName.toLowerCase().includes(debouncedSearchTerm.toLowerCase()));

     const matchesStatus = selectedStatus === 'all' || ticket.status === selectedStatus;
     const matchesCategory = selectedCategory === 'all' || ticket.category === selectedCategory;

     return matchesSearch && matchesStatus && matchesCategory;
   });
 }, [tickets, debouncedSearchTerm, selectedStatus, selectedCategory]);

 // Stats
 const totalTickets = tickets.length;
 const pendingCount = tickets.filter(t => t.status === 'pending').length;
 const inProgressCount = tickets.filter(t => t.status === 'in_progress').length;
 const completedCount = tickets.filter(t => t.status === 'completed').length;
 const totalCost = tickets.reduce((acc, t) => acc + (t.repairCost || 0), 0);

 const openEditModal = (ticket: MaintenanceTicket) => {
 setSelectedTicket(ticket);
 setEditStatus(ticket.status);
 setEditPriority(ticket.priority);
 setEditRepairCost(ticket.repairCost || 0);
 setEditTechnicianNote(ticket.technicianNote || '');
 setIsEditModalOpen(true);
 };

 const handleUpdateTicket = async (e: React.FormEvent) => {
 e.preventDefault();
 if (!selectedTicket) return;

 setIsSubmitting(true);
 try {
 const res = await fetch(`/api/maintenance/${selectedTicket.id}`, {
 method: 'PUT',
 headers: getHeaders(),
 body: JSON.stringify({
 status: editStatus,
 priority: editPriority,
 repairCost: editRepairCost,
 technicianNote: editTechnicianNote,
 }),
 });

 if (!res.ok) {
 const err = await res.json();
 throw new Error(err.error || 'Failed to update ticket');
 }

 showToast('อัปเดตสถานะการแจ้งซ่อมเรียบร้อยแล้ว', 'success');
 setIsEditModalOpen(false);
 onRefresh();
 } catch (err: any) {
 showToast(err.message || 'เกิดข้อผิดพลาดในการอัปเดตข้อมูล', 'error');
 } finally {
 setIsSubmitting(false);
 }
 };

 const handleCreateTicket = async (e: React.FormEvent) => {
 e.preventDefault();
 if (!newRoomId || !newTitle.trim()) {
 showToast('กรุณาเลือกห้องพักและระบุหัวข้อที่แจ้งซ่อม', 'error');
 return;
 }

 const room = rooms.find(r => r.id === parseInt(newRoomId));

 setIsSubmitting(true);
 try {
 const res = await fetch('/api/maintenance', {
 method: 'POST',
 headers: getHeaders(),
 body: JSON.stringify({
 roomId: parseInt(newRoomId),
 roomNumber: room?.roomNumber,
 tenantName: room?.tenantName || 'ผู้ดูแลกรอกแทน',
 tenantPhone: room?.tenantPhone || '',
 title: newTitle,
 description: newDescription,
 category: newCategory,
 priority: newPriority,
 imageUrl: newImageUrl || null,
 }),
 });

 if (!res.ok) {
 const err = await res.json();
 throw new Error(err.error || 'Failed to create ticket');
 }

 showToast('บันทึกการแจ้งซ่อมใหม่เรียบร้อยแล้ว', 'success');
 setIsCreateModalOpen(false);
 // Reset form
 setNewRoomId('');
 setNewTitle('');
 setNewDescription('');
 setNewCategory('other');
 setNewPriority('medium');
 setNewImageUrl('');
 onRefresh();
 } catch (err: any) {
 showToast(err.message || 'เกิดข้อผิดพลาดในการบันทึก', 'error');
 } finally {
 setIsSubmitting(false);
 }
 };

 const handleDeleteTicket = async (id: number) => {
 if (!window.confirm('คุณต้องการลบรายการแจ้งซ่อมนี้ใช่หรือไม่?')) return;

 try {
 const res = await fetch(`/api/maintenance/${id}`, {
 method: 'DELETE',
 headers: getHeaders(),
 });

 if (!res.ok) {
 throw new Error('Failed to delete ticket');
 }

 showToast('ลบรายการแจ้งซ่อมสำเร็จ', 'success');
 if (isEditModalOpen) setIsEditModalOpen(false);
 onRefresh();
 } catch (err: any) {
 showToast('เกิดข้อผิดพลาดในการลบรายการ', 'error');
 }
 };

 return (
 <div className="space-y-6 pb-12">
 {/* Header */}
 <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-[#E0E0DB]">
 <div className="flex items-center gap-3">
 <div className="p-3 bg-[#F59B23]/8 rounded-xl text-[#F59B23]">
 <Wrench className="w-7 h-7" />
 </div>
 <div>
 <h1 className="text-2xl font-bold text-[#1A1A1A]">ระบบแจ้งซ่อมและติดตามงานช่าง</h1>
 <p className="text-sm text-[#8A8A85]">จัดการรายการแจ้งซ่อม ติดตามสถานะงาน และบันทึกค่าใช้จ่ายงานซ่อม</p>
 </div>
 </div>

 {canManage && <button
 onClick={() => setIsCreateModalOpen(true)}
 className="flex items-center justify-center gap-2 bg-amber-600 hover:bg-amber-700 text-[#1A1A1A] px-5 py-2.5 rounded-xl font-medium transition-all text-sm"
 >
 <Plus className="w-4 h-4" />
 <span>เพิ่มรายการแจ้งซ่อมใหม่</span>
 </button>}
 </div>

 {/* Stats Overview */}
 <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
 <div className="bg-white p-5 rounded-2xl border border-[#E0E0DB] flex items-center gap-4">
 <div className="p-3 rounded-xl bg-[#F59B23]/8 text-[#F59B23]">
 <Clock className="w-6 h-6" />
 </div>
 <div>
 <p className="text-xs font-medium text-[#8A8A85]">รอดำเนินการ</p>
 <p className="text-2xl font-bold text-[#F59B23]">{pendingCount}</p>
 </div>
 </div>

 <div className="bg-white p-5 rounded-2xl border border-[#E0E0DB] flex items-center gap-4">
 <div className="p-3 rounded-xl bg-[#1DB954]/8 text-[#1DB954]">
 <Wrench className="w-6 h-6" />
 </div>
 <div>
 <p className="text-xs font-medium text-[#8A8A85]">กำลังซ่อมแซม</p>
 <p className="text-2xl font-bold text-[#1DB954]">{inProgressCount}</p>
 </div>
 </div>

 <div className="bg-white p-5 rounded-2xl border border-[#E0E0DB] flex items-center gap-4">
 <div className="p-3 rounded-xl bg-[#1DB954]/8 text-[#1DB954]">
 <CheckCircle2 className="w-6 h-6" />
 </div>
 <div>
 <p className="text-xs font-medium text-[#8A8A85]">เสร็จสิ้นแล้ว</p>
 <p className="text-2xl font-bold text-[#1DB954]">{completedCount}</p>
 </div>
 </div>

 <div className="bg-white p-5 rounded-2xl border border-[#E0E0DB] flex items-center gap-4">
 <div className="p-3 rounded-xl bg-[#A855F7]/8 text-[#A855F7]">
 <DollarSign className="w-6 h-6" />
 </div>
 <div>
 <p className="text-xs font-medium text-[#8A8A85]">ค่าซ่อมรวมทั้งหมด</p>
 <p className="text-2xl font-bold text-[#A855F7]">฿{totalCost.toLocaleString()}</p>
 </div>
 </div>
 </div>

 {/* Filters & Search */}
 <div className="bg-white p-4 rounded-2xl border border-[#E0E0DB] space-y-4">
 <div className="flex flex-col md:flex-row gap-3 items-center justify-between">
 {/* Search bar */}
 <div className="relative w-full md:w-80">
 <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8A8A85]" />
 <input
 type="text"
 placeholder="ค้นหาห้อง, หัวข้อ, ชื่อผู้เช่า..."
 value={searchTerm}
 onChange={(e) => setSearchTerm(e.target.value)}
 className="w-full pl-10 pr-4 py-2 bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500"
 />
 {searchTerm && (
 <button 
 onClick={() => setSearchTerm('')} 
 className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8A8A85] hover:text-slate-600"
 >
 <X className="w-4 h-4" />
 </button>
 )}
 </div>

 {/* Filters */}
 <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
 {/* Status Filter */}
 <div className="flex items-center gap-1 bg-[#F0F0EB] p-1 rounded-xl text-xs font-medium">
 <button
 onClick={() => setSelectedStatus('all')}
 className={`px-3 py-1.5 rounded-lg transition-all ${
 selectedStatus === 'all' ? 'bg-white text-[#1A1A1A] ' : 'text-[#6B6B66] hover:text-slate-900'
 }`}
 >
 ทั้งหมด ({totalTickets})
 </button>
 <button
 onClick={() => setSelectedStatus('pending')}
 className={`px-3 py-1.5 rounded-lg transition-all ${
 selectedStatus === 'pending' ? 'bg-white text-amber-700 font-semibold' : 'text-[#6B6B66] hover:text-amber-700'
 }`}
 >
 รอดำเนินการ ({pendingCount})
 </button>
 <button
 onClick={() => setSelectedStatus('in_progress')}
 className={`px-3 py-1.5 rounded-lg transition-all ${
 selectedStatus === 'in_progress' ? 'bg-white text-blue-700 font-semibold' : 'text-[#6B6B66] hover:text-blue-700'
 }`}
 >
 กำลังซ่อม ({inProgressCount})
 </button>
 <button
 onClick={() => setSelectedStatus('completed')}
 className={`px-3 py-1.5 rounded-lg transition-all ${
 selectedStatus === 'completed' ? 'bg-white text-[#1DB954] font-semibold' : 'text-[#6B6B66] hover:text-emerald-700'
 }`}
 >
 เสร็จสิ้น ({completedCount})
 </button>
 </div>

 {/* Category Select */}
 <select
 value={selectedCategory}
 onChange={(e) => setSelectedCategory(e.target.value)}
 className="px-3 py-2 bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl text-xs font-medium text-[#6B6B66] focus:outline-none focus:ring-2 focus:ring-amber-500/20"
 >
 <option value="all">หมวดหมู่ทั้งหมด</option>
 {Object.entries(CATEGORY_LABELS).map(([catKey, catVal]) => (
 <option key={catKey} value={catKey}>
 {catVal.icon} {catVal.label}
 </option>
 ))}
 </select>
 </div>
 </div>
 </div>

 {/* Tickets List Grid */}
 {filteredTickets.length === 0 ? (
 <div className="bg-white p-12 rounded-2xl border border-[#E0E0DB] text-center">
 <div className="w-16 h-16 bg-[#F0F0EB] rounded-full flex items-center justify-center mx-auto mb-4 text-[#8A8A85]">
 <Wrench className="w-8 h-8" />
 </div>
 <h3 className="text-lg font-bold text-[#6B6B66] mb-1">ไม่พบรายการแจ้งซ่อม</h3>
 <p className="text-sm text-[#8A8A85]">
 {searchTerm || selectedStatus !== 'all' || selectedCategory !== 'all' 
 ? 'ลองปรับเปลี่ยนเงื่อนไขการค้นหาหรือตัวกรอง' 
 : 'ยังไม่มีการส่งรายการแจ้งซ่อมเข้ามาในขณะนี้'}
 </p>
 </div>
 ) : (
 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
 {filteredTickets.map((ticket) => {
 const StatusIcon = STATUS_BADGES[ticket.status].icon;
 const categoryInfo = CATEGORY_LABELS[ticket.category] || CATEGORY_LABELS.other;

 return (
 <motion.div
 key={ticket.id}
 layout
 initial={{ opacity: 0, y: 10 }}
 animate={{ opacity: 1, y: 0 }}
 exit={{ opacity: 0, scale: 0.95 }}
 className="bg-white rounded-2xl border border-[#E0E0DB] transition-all flex flex-col justify-between overflow-hidden"
 >
 <div>
 {/* Card Top Banner */}
 <div className="p-4 pb-3 border-b border-[#E0E0DB] flex items-center justify-between bg-[#282828]/50">
 <div className="flex items-center gap-2">
 <span className="font-bold text-lg text-[#1A1A1A] px-3 py-1 bg-white border border-[#E0E0DB] rounded-xl shadow-2xs">
 ห้อง {ticket.roomNumber}
 </span>
 <span className={`text-xs px-2.5 py-1 rounded-lg border font-medium ${categoryInfo.color}`}>
 {categoryInfo.icon} {categoryInfo.label.split('/')[0]}
 </span>
 </div>

 <span className={`text-xs px-2.5 py-1 rounded-full font-medium flex items-center gap-1 border ${STATUS_BADGES[ticket.status].color}`}>
 <StatusIcon className="w-3.5 h-3.5" />
 {STATUS_BADGES[ticket.status].label}
 </span>
 </div>

 {/* Card Content */}
 <div className="p-4 space-y-3">
 <div>
 <div className="flex items-center justify-between mb-1">
 <h3 className="font-bold text-[#1A1A1A] text-base line-clamp-1">{ticket.title}</h3>
 <span className={`text-[10px] px-2 py-0.5 rounded ${PRIORITY_BADGES[ticket.priority].bg}`}>
 {PRIORITY_BADGES[ticket.priority].label}
 </span>
 </div>
 {ticket.description && (
 <p className="text-xs text-[#6B6B66] line-clamp-2 leading-relaxed">
 {ticket.description}
 </p>
 )}
 </div>

 {/* Image Preview if present */}
 {ticket.imageUrl && (
 <div 
 onClick={() => openEditModal(ticket)}
 className="relative h-28 w-full rounded-xl overflow-hidden cursor-pointer group border border-[#E0E0DB] bg-[#F0F0EB]"
 >
 <img 
 src={ticket.imageUrl} 
 alt={ticket.title} 
 className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
 />
 <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-[#1A1A1A] text-xs font-medium">
 <Eye className="w-4 h-4 mr-1" /> ขยายรูป
 </div>
 </div>
 )}

 {/* Tenant Info */}
 <div className="text-xs text-[#8A8A85] space-y-1 bg-[#F0F0EB] p-2.5 rounded-xl border border-[#E0E0DB]">
 <div className="flex items-center justify-between">
 <span className="flex items-center gap-1 text-[#6B6B66] font-medium">
 <User className="w-3.5 h-3.5 text-[#8A8A85]" />
 {ticket.tenantName || 'ผู้เช่า'}
 </span>
 {ticket.tenantPhone && (
 <span className="flex items-center gap-1 text-[#8A8A85]">
 <Phone className="w-3 h-3 text-[#8A8A85]" />
 {ticket.tenantPhone}
 </span>
 )}
 </div>
 <div className="text-[11px] text-[#8A8A85] pt-1 flex justify-between">
 <span>แจ้งเมื่อ: {new Date(ticket.createdAt).toLocaleDateString('th-TH', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
 {ticket.repairCost > 0 && (
 <span className="font-semibold text-purple-700">ค่าซ่อม: ฿{ticket.repairCost.toLocaleString()}</span>
 )}
 </div>
 </div>

 {/* Technician Note if available */}
 {ticket.technicianNote && (
 <div className="text-xs bg-[#F59B23]/10/60 border border-[#F59B23]/30 p-2.5 rounded-xl text-amber-900">
 <span className="font-semibold">บันทึกช่าง: </span> {ticket.technicianNote}
 </div>
 )}
 </div>
 </div>

 {/* Card Actions */}
 {canManage && <div className="p-3 border-t border-[#E0E0DB] bg-[#282828]/30 flex items-center justify-between">
 <button
 onClick={() => handleDeleteTicket(ticket.id)}
 className="p-2 text-[#E22134] hover:bg-rose-50 rounded-xl transition-colors text-xs flex items-center gap-1"
 >
 <Trash2 className="w-4 h-4" />
 <span className="hidden sm:inline">ลบ</span>
 </button>

 <button
 onClick={() => openEditModal(ticket)}
 className="flex items-center gap-1.5 text-xs bg-amber-600 hover:bg-amber-700 text-[#1A1A1A] font-medium px-4 py-2 rounded-xl transition-all shadow-2xs"
 >
 <Edit3 className="w-3.5 h-3.5" />
 <span>จัดการ / เปลี่ยนสถานะ</span>
 </button>
 </div>}
 </motion.div>
 );
 })}
 </div>
 )}

 {/* Edit / Update Modal */}
 <AnimatePresence>
 {isEditModalOpen && selectedTicket && (
 <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
 <motion.div
 initial={{ opacity: 0, scale: 0.95 }}
 animate={{ opacity: 1, scale: 1 }}
 exit={{ opacity: 0, scale: 0.95 }}
 className="bg-white rounded-3xl shadow-xl border border-[#E0E0DB] max-w-lg w-full overflow-hidden max-h-[90vh] flex flex-col"
 >
 {/* Header */}
 <div className="p-5 border-b border-[#E0E0DB] flex items-center justify-between bg-[#F0F0EB]">
 <div className="flex items-center gap-2">
 <div className="p-2 bg-[#F59B23]/8 text-amber-700 rounded-xl">
 <Wrench className="w-5 h-5" />
 </div>
 <div>
 <h2 className="font-bold text-[#1A1A1A] text-lg">อัปเดตสถานะงานซ่อม</h2>
 <p className="text-xs text-[#8A8A85]">ห้อง {selectedTicket.roomNumber} - {selectedTicket.title}</p>
 </div>
 </div>
 <button
 onClick={() => setIsEditModalOpen(false)}
 className="p-2 text-[#8A8A85] hover:text-slate-600 rounded-full hover:bg-slate-200/50 transition-colors"
 >
 <X className="w-5 h-5" />
 </button>
 </div>

 {/* Body */}
 <form onSubmit={handleUpdateTicket} className="p-6 space-y-4 overflow-y-auto flex-1">
 {/* Details Overview */}
 <div className="bg-[#F0F0EB] p-4 rounded-2xl border border-[#E0E0DB] space-y-2 text-xs">
 <div className="flex justify-between">
 <span className="text-[#8A8A85]">ผู้แจ้ง:</span>
 <span className="font-medium text-[#1A1A1A]">{selectedTicket.tenantName} ({selectedTicket.tenantPhone || 'ไม่ระบุเบอร์'})</span>
 </div>
 <div className="flex justify-between">
 <span className="text-[#8A8A85]">รายละเอียด:</span>
 <span className="font-medium text-[#1A1A1A]">{selectedTicket.description || '-'}</span>
 </div>
 {selectedTicket.imageUrl && (
 <div className="pt-2">
 <p className="text-[#8A8A85] mb-1">รูปถ่ายอุปกรณ์ชำรุด:</p>
 <a href={selectedTicket.imageUrl} target="_blank" rel="noreferrer" className="inline-block">
 <img 
 src={selectedTicket.imageUrl} 
 alt="รูปถ่ายอุปกรณ์ชำรุด" 
 className="h-36 rounded-xl object-cover border border-[#E0E0DB]"
 />
 </a>
 </div>
 )}
 </div>

 {/* Status Selection */}
 <div>
 <label className="block text-xs font-semibold text-[#6B6B66] mb-2">สถานะงานซ่อม</label>
 <div className="grid grid-cols-2 gap-2">
 {(['pending', 'in_progress', 'completed', 'cancelled'] as TicketStatus[]).map((statusKey) => {
 const badge = STATUS_BADGES[statusKey];
 const Icon = badge.icon;
 const isSelected = editStatus === statusKey;

 return (
 <button
 type="button"
 key={statusKey}
 onClick={() => setEditStatus(statusKey)}
 className={`p-3 rounded-xl border text-xs font-medium flex items-center gap-2 transition-all ${
 isSelected
 ? 'border-amber-500 bg-[#F59B23]/10/50 text-amber-900 ring-2 ring-amber-500/20 font-bold'
 : 'border-[#E0E0DB] hover:border-slate-300 text-[#6B6B66] bg-white'
 }`}
 >
 <Icon className={`w-4 h-4 ${isSelected ? 'text-[#F59B23]' : 'text-[#8A8A85]'}`} />
 <span>{badge.label}</span>
 </button>
 );
 })}
 </div>
 </div>

 {/* Priority Selection */}
 <div>
 <label className="block text-xs font-semibold text-[#6B6B66] mb-1.5">ระดับความสำคัญ</label>
 <select
 value={editPriority}
 onChange={(e) => setEditPriority(e.target.value as TicketPriority)}
 className="w-full p-2.5 border border-[#E0E0DB] rounded-xl text-xs bg-[#F0F0EB] focus:outline-none focus:ring-2 focus:ring-amber-500/20"
 >
 <option value="low">ปกติ</option>
 <option value="medium">ปานกลาง</option>
 <option value="high">สูง</option>
 <option value="urgent">ด่วนมาก ⚠️</option>
 </select>
 </div>

 {/* Repair Cost */}
 <div>
 <label className="block text-xs font-semibold text-[#6B6B66] mb-1.5">ค่าใช้จ่ายงานซ่อม (บาท)</label>
 <div className="relative">
 <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#8A8A85] text-xs font-bold">฿</span>
 <input
 type="number"
 min="0"
 value={editRepairCost}
 onChange={(e) => setEditRepairCost(Number(e.target.value))}
 placeholder="0"
 className="w-full pl-8 pr-4 py-2.5 border border-[#E0E0DB] rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-amber-500/20 font-semibold text-purple-700"
 />
 </div>
 </div>

 {/* Technician Note */}
 <div>
 <label className="block text-xs font-semibold text-[#6B6B66] mb-1.5">บันทึกของช่าง / หมายเหตุเพิ่มเติม</label>
 <textarea
 rows={3}
 value={editTechnicianNote}
 onChange={(e) => setEditTechnicianNote(e.target.value)}
 placeholder="เช่น ซ่อมเปลี่ยนวาล์วน้ำแล้ว, ช่างนัดเข้ามาวันเสาร์..."
 className="w-full p-3 border border-[#E0E0DB] rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-amber-500/20"
 />
 </div>

 {/* Submit Actions */}
 <div className="pt-3 border-t border-[#E0E0DB] flex items-center justify-end gap-3">
 <button
 type="button"
 onClick={() => setIsEditModalOpen(false)}
 className="px-4 py-2.5 text-xs text-[#6B6B66] hover:bg-[#E8E8E3] rounded-xl transition-colors font-medium"
 >
 ยกเลิก
 </button>
 <button
 type="submit"
 disabled={isSubmitting}
 className="px-5 py-2.5 text-xs bg-amber-600 hover:bg-amber-700 text-[#1A1A1A] rounded-xl font-medium transition-all flex items-center gap-1.5"
 >
 {isSubmitting ? (
 <span>กำลังบันทึก...</span>
 ) : (
 <>
 <Check className="w-4 h-4" />
 <span>บันทึกการเปลี่ยนแปลง</span>
 </>
 )}
 </button>
 </div>
 </form>
 </motion.div>
 </div>
 )}
 </AnimatePresence>

 {/* Create New Ticket Modal */}
 <AnimatePresence>
 {isCreateModalOpen && (
 <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
 <motion.div
 initial={{ opacity: 0, scale: 0.95 }}
 animate={{ opacity: 1, scale: 1 }}
 exit={{ opacity: 0, scale: 0.95 }}
 className="bg-white rounded-3xl shadow-xl border border-[#E0E0DB] max-w-lg w-full overflow-hidden max-h-[90vh] flex flex-col"
 >
 {/* Header */}
 <div className="p-5 border-b border-[#E0E0DB] flex items-center justify-between bg-[#F0F0EB]">
 <div className="flex items-center gap-2">
 <div className="p-2 bg-[#F59B23]/8 text-amber-700 rounded-xl">
 <Plus className="w-5 h-5" />
 </div>
 <div>
 <h2 className="font-bold text-[#1A1A1A] text-lg">เพิ่มรายการแจ้งซ่อมใหม่</h2>
 <p className="text-xs text-[#8A8A85]">ลงบันทึกรายการแจ้งซ่อมแทนผู้เช่าหรือตรวจพบด้วยตนเอง</p>
 </div>
 </div>
 <button
 onClick={() => setIsCreateModalOpen(false)}
 className="p-2 text-[#8A8A85] hover:text-slate-600 rounded-full hover:bg-slate-200/50 transition-colors"
 >
 <X className="w-5 h-5" />
 </button>
 </div>

 {/* Body */}
 <form onSubmit={handleCreateTicket} className="p-6 space-y-4 overflow-y-auto flex-1">
 {/* Select Room */}
 <div>
 <label className="block text-xs font-semibold text-[#6B6B66] mb-1.5">เลือกห้องพัก *</label>
 <select
 value={newRoomId}
 onChange={(e) => setNewRoomId(e.target.value)}
 required
 className="w-full p-2.5 border border-[#E0E0DB] rounded-xl text-xs bg-[#F0F0EB] focus:outline-none focus:ring-2 focus:ring-amber-500/20 font-medium text-[#1A1A1A]"
 >
 <option value="">-- เลือกห้องพัก --</option>
 {rooms.map((r) => (
 <option key={r.id} value={r.id}>
 ห้อง {r.roomNumber} {r.tenantName ? `(${r.tenantName})` : '(ห้องว่าง)'}
 </option>
 ))}
 </select>
 </div>

 {/* Title */}
 <div>
 <label className="block text-xs font-semibold text-[#6B6B66] mb-1.5">หัวข้อ / อุปกรณ์ที่ชำรุด *</label>
 <input
 type="text"
 required
 placeholder="เช่น ก๊อกน้ำรั่วในห้องน้ำ, หลอดไฟระเบียงดับ"
 value={newTitle}
 onChange={(e) => setNewTitle(e.target.value)}
 className="w-full p-2.5 border border-[#E0E0DB] rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-amber-500/20"
 />
 </div>

 {/* Category & Priority Grid */}
 <div className="grid grid-cols-2 gap-3">
 <div>
 <label className="block text-xs font-semibold text-[#6B6B66] mb-1.5">หมวดหมู่ปัญหา</label>
 <select
 value={newCategory}
 onChange={(e) => setNewCategory(e.target.value as TicketCategory)}
 className="w-full p-2.5 border border-[#E0E0DB] rounded-xl text-xs bg-[#F0F0EB] focus:outline-none focus:ring-2 focus:ring-amber-500/20"
 >
 {Object.entries(CATEGORY_LABELS).map(([catKey, catVal]) => (
 <option key={catKey} value={catKey}>
 {catVal.icon} {catVal.label}
 </option>
 ))}
 </select>
 </div>

 <div>
 <label className="block text-xs font-semibold text-[#6B6B66] mb-1.5">ระดับความเร่งด่วน</label>
 <select
 value={newPriority}
 onChange={(e) => setNewPriority(e.target.value as TicketPriority)}
 className="w-full p-2.5 border border-[#E0E0DB] rounded-xl text-xs bg-[#F0F0EB] focus:outline-none focus:ring-2 focus:ring-amber-500/20"
 >
 <option value="low">ปกติ</option>
 <option value="medium">ปานกลาง</option>
 <option value="high">สูง</option>
 <option value="urgent">ด่วนมาก ⚠️</option>
 </select>
 </div>
 </div>

 {/* Description */}
 <div>
 <label className="block text-xs font-semibold text-[#6B6B66] mb-1.5">รายละเอียดเพิ่มเติม</label>
 <textarea
 rows={3}
 value={newDescription}
 onChange={(e) => setNewDescription(e.target.value)}
 placeholder="ระบุอาการชำรุด หรือตำแหน่งเพิ่มเติม..."
 className="w-full p-3 border border-[#E0E0DB] rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-amber-500/20"
 />
 </div>

 {/* Image URL / Link */}
 <div>
 <label className="block text-xs font-semibold text-[#6B6B66] mb-1.5">URL รูปภาพประกอบ (ถ้ามี)</label>
 <input
 type="url"
 placeholder="https://..."
 value={newImageUrl}
 onChange={(e) => setNewImageUrl(e.target.value)}
 className="w-full p-2.5 border border-[#E0E0DB] rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-amber-500/20"
 />
 </div>

 {/* Submit Actions */}
 <div className="pt-3 border-t border-[#E0E0DB] flex items-center justify-end gap-3">
 <button
 type="button"
 onClick={() => setIsCreateModalOpen(false)}
 className="px-4 py-2.5 text-xs text-[#6B6B66] hover:bg-[#E8E8E3] rounded-xl transition-colors font-medium"
 >
 ยกเลิก
 </button>
 <button
 type="submit"
 disabled={isSubmitting}
 className="px-5 py-2.5 text-xs bg-amber-600 hover:bg-amber-700 text-[#1A1A1A] rounded-xl font-medium transition-all flex items-center gap-1.5"
 >
 {isSubmitting ? (
 <span>กำลังบันทึก...</span>
 ) : (
 <>
 <Plus className="w-4 h-4" />
 <span>บันทึกรายการแจ้งซ่อม</span>
 </>
 )}
 </button>
 </div>
 </form>
 </motion.div>
 </div>
 )}
 </AnimatePresence>
 </div>
 );
};
