import React, { useState, useEffect } from 'react';
import { Room, Bill, Settings, BillChargeItem } from '../types.ts';
import { 
 Layers, 
 Calculator, 
 Zap, 
 Droplet, 
 DollarSign, 
 Calendar, 
 AlertTriangle, 
 CheckCircle2, 
 Sparkles, 
 HelpCircle, 
 ChevronRight, 
 RotateCcw,
 PlusCircle,
 FileSpreadsheet,
 Info
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { buildValidDueDate } from '../utils/settings.ts';

interface BulkMeterEntryViewProps {
 rooms: Room[];
 settings: Settings;
 bills: Bill[];
 loading: boolean;
 onCreateBulkBills: (bulkData: { billMonth: string; dueDate: string; bills: any[] }) => Promise<void>;
 onNavigateToHistory: () => void;
 idToken?: string | null;
}

export const BulkMeterEntryView: React.FC<BulkMeterEntryViewProps> = ({
 rooms,
 settings,
 bills,
 loading: parentLoading,
 onCreateBulkBills,
 onNavigateToHistory,
 idToken
}) => {
 const [billMonth, setBillMonth] = useState<string>('');
 const [dueDate, setDueDate] = useState<string>('');
 const [selectedRooms, setSelectedRooms] = useState<Record<number, boolean>>({});
 const [bulkInputs, setBulkInputs] = useState<Record<number, {
 priorElec: string;
 currentElec: string;
 elecDeduct: string;
 elecCost: string;
 priorWater: string;
 currentWater: string;
 waterCost: string;
 otherCost: string;
 otherDescription: string;
 }>>({});

 const [formError, setFormError] = useState<string | null>(null);
 const [submitting, setSubmitting] = useState(false);
 const [success, setSuccess] = useState(false);
 const [copiedNotification, setCopiedNotification] = useState<string | null>(null);
 const [dueItems, setDueItems] = useState<Record<number, BillChargeItem[]>>({});

 const occupiedRooms = rooms.filter(r => r.status === 'occupied');

 // Initialize month and due date (similar to CreateBillView)
 useEffect(() => {
 const today = new Date();
 const currentMonth = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;
 setBillMonth(currentMonth);

 setDueDate(buildValidDueDate(currentMonth, settings.defaultDueDateDay));
 }, [settings]);

 useEffect(() => {
 if (!billMonth || !idToken) return;
 const controller = new AbortController();
 fetch(`/api/recurring-charges/due?billMonth=${encodeURIComponent(billMonth)}`, { headers: { Authorization: `Bearer ${idToken}` }, signal: controller.signal })
 .then((response) => response.json()).then((payload) => { const grouped: Record<number, BillChargeItem[]> = {}; (payload?.data || []).forEach((item: any) => { (grouped[item.roomId] ||= []).push(item); }); setDueItems(grouped); })
 .catch((error) => { if (error.name !== 'AbortError') setFormError('โหลดค่าบริการประจำไม่สำเร็จ'); });
 return () => controller.abort();
 }, [billMonth, idToken]);

 // Initialize bulk input data from the last bills or set to 0
 useEffect(() => {
 const initial: Record<number, any> = {};
 const initialSelected: Record<number, boolean> = {};
 occupiedRooms.forEach(room => {
 initialSelected[room.id] = true;
 const roomBills = bills
 .filter(b => b.roomId === room.id)
 .sort((a, b) => b.billMonth.localeCompare(a.billMonth));

 let priorE = 0;
 let priorW = 0;
 if (roomBills.length > 0) {
 priorE = roomBills[0].currentElec;
 priorW = roomBills[0].currentWater;
 }

 initial[room.id] = {
 priorElec: priorE.toString(),
 currentElec: '', // start empty for manual entry
 elecDeduct: '0',
 elecCost: '',
 priorWater: priorW.toString(),
 currentWater: '', // start empty for manual entry
 waterCost: '',
 otherCost: '0',
 otherDescription: 'ค่าส่วนกลาง/บริการ',
 };
 });
 setBulkInputs(initial);
 setSelectedRooms(initialSelected);
 }, [rooms, bills]);

 // Format month selection to set dynamic due date based on settings
 const handleMonthChange = (e: React.ChangeEvent<HTMLInputElement>) => {
 const value = e.target.value;
 setBillMonth(value);
 if (value) {
 setDueDate(buildValidDueDate(value, settings.defaultDueDateDay));
 }
 };

 // Helper to calculate 6-month average for anomaly flagging
 const get6MonthAverage = (roomId: number, type: 'elec' | 'water') => {
 const roomBills = bills
 .filter(b => b.roomId === roomId)
 .sort((a, b) => b.billMonth.localeCompare(a.billMonth))
 .slice(0, 6);

 if (roomBills.length === 0) return null;

 let sum = 0;
 roomBills.forEach(b => {
 if (type === 'elec') {
 sum += Math.max(0, b.currentElec - b.priorElec);
 } else {
 sum += Math.max(0, b.currentWater - b.priorWater);
 }
 });

 return sum / roomBills.length;
 };

 // Quick Action: Autofill current readings with previous readings (to make manual adjustment fast)
 const handleAutofillWithPrevious = () => {
 setBulkInputs(prev => {
 const updated = { ...prev };
 occupiedRooms.forEach(room => {
 if (!updated[room.id]) return;
 updated[room.id] = {
 ...updated[room.id],
 currentElec: updated[room.id].priorElec,
 currentWater: updated[room.id].priorWater,
 elecDeduct: '0',
 waterCost: ''
 };
 });
 return updated;
 });
 triggerCopiedNotification('ดึงข้อมูลมิเตอร์ครั้งก่อนลงในช่องกรอกเรียบร้อยแล้ว');
 };

 // Quick Action: Auto-increment readings by custom amount
 const handleAutofillIncrement = (elecInc: number, waterInc: number) => {
 setBulkInputs(prev => {
 const updated = { ...prev };
 occupiedRooms.forEach(room => {
 if (!updated[room.id]) return;
 const pE = parseFloat(updated[room.id].priorElec) || 0;
 const pW = parseFloat(updated[room.id].priorWater) || 0;
 updated[room.id] = {
 ...updated[room.id],
 currentElec: (pE + elecInc).toString(),
 currentWater: (pW + waterInc).toString(),
 elecDeduct: '0',
 waterCost: ''
 };
 });
 return updated;
 });
 triggerCopiedNotification(`จำลองกรอกมิเตอร์ด้วยวิธีเพิ่ม (+ไฟ ${elecInc} หน่วย, +น้ำ ${waterInc} หน่วย)`);
 };

 // Helper for flash notification
 const triggerCopiedNotification = (msg: string) => {
 setCopiedNotification(msg);
 setTimeout(() => {
 setCopiedNotification(null);
 }, 3500);
 };

 const handleFieldChange = (roomId: number, field: string, value: string) => {
 setBulkInputs(prev => ({
 ...prev,
 [roomId]: {
 ...prev[roomId],
 [field]: value
 }
 }));
 };

 const toggleAllRooms = () => {
 const allSelected = occupiedRooms.every(r => selectedRooms[r.id]);
 const next: Record<number, boolean> = {};
 occupiedRooms.forEach(r => { next[r.id] = !allSelected; });
 setSelectedRooms(next);
 };

 const toggleRoom = (roomId: number) => {
 setSelectedRooms(prev => ({ ...prev, [roomId]: !prev[roomId] }));
 };

 // Total accumulation stats for the summary card
 const calculateTotals = () => {
 let roomsBilled = 0;
 let totalBaseRent = 0;
 let totalElecUnits = 0;
 let totalElecCost = 0;
 let totalWaterUnits = 0;
 let totalWaterCost = 0;
 let totalOtherCosts = 0;

 occupiedRooms.forEach(room => {
 if (!selectedRooms[room.id]) return;
 const roomBills = bills
 .filter(b => b.roomId === room.id)
 .sort((a, b) => b.billMonth.localeCompare(a.billMonth));

 const histE = roomBills.length > 0 ? roomBills[0].currentElec : 0;
 const histW = roomBills.length > 0 ? roomBills[0].currentWater : 0;

 const inputs = bulkInputs[room.id] || {
 priorElec: histE.toString(),
 currentElec: '',
 elecDeduct: '0',
 elecCost: '',
 priorWater: histW.toString(),
 currentWater: '',
 waterCost: '',
 otherCost: '0',
 otherDescription: 'ค่าส่วนกลาง/บริการ'
 };

 const pE = parseFloat(inputs.priorElec) || 0;
 const pW = parseFloat(inputs.priorWater) || 0;
 const cE = inputs.currentElec === '' ? pE : (parseFloat(inputs.currentElec) || 0);
 const cW = inputs.currentWater === '' ? pW : (parseFloat(inputs.currentWater) || 0);
 const deductE = parseFloat(inputs.elecDeduct) || 0;

 const elecUsed = Math.max(0, cE - pE - deductE);
 const autoElecCost = Math.round(elecUsed * settings.defaultElecRate);
 const elecCost = inputs.elecCost !== undefined && inputs.elecCost !== '' ? (parseFloat(inputs.elecCost) || 0) : autoElecCost;

 const waterUsed = Math.max(0, cW - pW);
 const autoWaterCost = waterUsed > 0 ? (Math.round(waterUsed * settings.defaultWaterRate)) : 0;
 const waterCost = inputs.waterCost !== undefined && inputs.waterCost !== '' ? (parseFloat(inputs.waterCost) || 0) : autoWaterCost;

 const other = (parseFloat(inputs.otherCost) || 0) + (dueItems[room.id] || []).reduce((sum, item) => sum + (Number(item.amount) || 0), 0);

 roomsBilled++;
 totalBaseRent += room.monthlyRent;
 totalElecUnits += elecUsed;
 totalElecCost += elecCost;
 totalWaterUnits += waterUsed;
 totalWaterCost += waterCost;
 totalOtherCosts += other;
 });

 const grandTotal = totalBaseRent + totalElecCost + totalWaterCost + totalOtherCosts;

 return {
 roomsBilled,
 totalBaseRent,
 totalElecUnits,
 totalElecCost,
 totalWaterUnits,
 totalWaterCost,
 totalOtherCosts,
 grandTotal
 };
 };

 const totals = calculateTotals();

 // Validate and submit bulk bills
 const handleSubmit = async (e: React.FormEvent) => {
 e.preventDefault();
 setFormError(null);
 setSuccess(false);

 if (!billMonth) {
 setFormError('กรุณาระบุรอบบิลประจำเดือน');
 return;
 }
 if (!dueDate) {
 setFormError('กรุณาระบุวันที่กำหนดชำระเงิน');
 return;
 }

 const payloadBills: any[] = [];

 for (const room of occupiedRooms) {
 if (!selectedRooms[room.id]) continue;
 const roomBills = bills
 .filter(b => b.roomId === room.id)
 .sort((a, b) => b.billMonth.localeCompare(a.billMonth));

 const histE = roomBills.length > 0 ? roomBills[0].currentElec : 0;
 const histW = roomBills.length > 0 ? roomBills[0].currentWater : 0;

 const inputs = bulkInputs[room.id] || {
 priorElec: histE.toString(),
 currentElec: '',
 elecDeduct: '0',
 elecCost: '',
 priorWater: histW.toString(),
 currentWater: '',
 waterCost: '',
 otherCost: '0',
 otherDescription: 'ค่าส่วนกลาง/บริการ'
 };

 const pE = parseFloat(inputs.priorElec) || 0;
 const pW = parseFloat(inputs.priorWater) || 0;
 const cE = inputs.currentElec === '' ? pE : (parseFloat(inputs.currentElec) || 0);
 const cW = inputs.currentWater === '' ? pW : (parseFloat(inputs.currentWater) || 0);
 const deductE = parseFloat(inputs.elecDeduct) || 0;

 // Simple validation checks
 if (cE < pE) {
 setFormError(`เกิดข้อผิดพลาด: เลขมิเตอร์ไฟฟ้าครั้งหลังของห้อง ${room.roomNumber} (${cE} หน่วย) น้อยกว่าครั้งก่อน (${pE} หน่วย)`);
 return;
 }
 if (cW < pW) {
 setFormError(`เกิดข้อผิดพลาด: เลขมิเตอร์น้ำครั้งหลังของห้อง ${room.roomNumber} (${cW} หน่วย) น้อยกว่าครั้งก่อน (${pW} หน่วย)`);
 return;
 }

 const elecUsed = Math.max(0, cE - pE - deductE);
 const autoElecCost = Math.round(elecUsed * settings.defaultElecRate);
 const finalElecCost = inputs.elecCost !== undefined && inputs.elecCost !== '' ? (parseFloat(inputs.elecCost) || 0) : autoElecCost;

 const waterUsed = Math.max(0, cW - pW);
 const autoWaterCost = waterUsed > 0 ? (Math.round(waterUsed * settings.defaultWaterRate)) : 0;
 const finalWaterCost = inputs.waterCost !== undefined && inputs.waterCost !== '' ? (parseFloat(inputs.waterCost) || 0) : autoWaterCost;

 payloadBills.push({
 roomId: room.id,
 priorElec: pE,
 currentElec: cE,
 elecDeduct: deductE,
 elecCost: finalElecCost,
 priorWater: pW,
 currentWater: cW,
 waterCost: finalWaterCost,
 rentCost: room.monthlyRent,
 depositCost: 0,
 otherCost: parseFloat(inputs.otherCost) || 0,
 otherDescription: inputs.otherDescription || "",
 chargeItems: [...(dueItems[room.id] || []), ...((parseFloat(inputs.otherCost) || 0) > 0 ? [{ label: inputs.otherDescription || 'ค่าใช้จ่ายอื่น', amount: parseFloat(inputs.otherCost) || 0, kind: 'manual', assignmentId: null }] : [])]
 });
 }

 if (payloadBills.length === 0) {
 setFormError('ไม่พบข้อมูลห้องพักที่ใช้งานเพื่อออกบิลในขณะนี้');
 return;
 }

 setSubmitting(true);

 try {
 await onCreateBulkBills({
 billMonth,
 dueDate,
 bills: payloadBills
 });
 setSuccess(true);
 window.scrollTo({ top: 0, behavior: 'smooth' });
 } catch (err: any) {
 setFormError(err.message || 'เกิดข้อผิดพลาดในการบันทึกบิลแบบกลุ่ม');
 } finally {
 setSubmitting(false);
 }
 };

 return (
 <div className="max-w-6xl mx-auto space-y-6 font-sans">
 
 {/* Header Banner */}
 <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-slate-900 text-[#1A1A1A] p-6 rounded-2xl shadow-xl border border-[#E0E0DB] relative overflow-hidden">
 <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-64 h-64 rounded-full bg-[#1DB954]/8 blur-3xl pointer-events-none" />
 <div className="absolute left-1/3 bottom-0 w-44 h-44 rounded-full bg-indigo-600/5 blur-3xl pointer-events-none" />
 
 <div className="space-y-1.5 relative z-10">
 <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1DB954]/8 text-[#1DB954] font-extrabold text-[10px] uppercase tracking-wider border border-[#1DB954]/30/20">
 <Layers className="w-3.5 h-3.5" />
 <span>Batch Billing System</span>
 </span>
 <h2 className="text-xl font-extrabold tracking-tight sm:text-2xl flex items-center gap-2 text-[#1A1A1A]">
 <span>บันทึกมิเตอร์น้ำ-ไฟแบบกลุ่ม (Bulk Meter Entry)</span>
 </h2>
 <p className="text-xs text-[#8A8A85] max-w-2xl leading-relaxed">
 กรอกตัวเลขมิเตอร์น้ำและมิเตอร์ไฟฟ้าของทุกห้องพักพร้อมกันในตารางเดียว ระบบจะดึงเลขครั้งล่าสุดมาให้และคำนวณเงินสุทธิรายห้อง พร้อมให้กดออกบิลด่วนส่งไปยัง LINE และบันทึกประวัติทันที!
 </p>
 </div>
 </div>

 {/* Quick Actions Panel */}
 <div className="bg-white border border-[#E0E0DB] rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-gradient-to-r from-slate-50 to-white">
 <div className="flex items-center gap-2 text-[#6B6B66]">
 <Sparkles className="w-4 h-4 text-[#F59B23] shrink-0" />
 <span className="text-xs font-bold">ฟังก์ชันกรอกรวดเร็ว (Quick Actions):</span>
 </div>
 <div className="flex flex-wrap gap-2">
 <button
 type="button"
 onClick={handleAutofillWithPrevious}
 className="px-3 py-1.5 bg-[#F0F0EB] hover:bg-slate-200 active:scale-[0.98] border border-[#E0E0DB] rounded-xl text-[10.5px] font-bold text-[#6B6B66] transition flex items-center gap-1.5 cursor-pointer"
 >
 <RotateCcw className="w-3.5 h-3.5 text-[#8A8A85]" />
 <span>ใช้เลขรอบก่อนเป็นค่าเริ่มต้นของรอบนี้</span>
 </button>
 <button
 type="button"
 onClick={() => handleAutofillIncrement(30, 2)}
 className="px-3 py-1.5 bg-[#1DB954]/8 hover:bg-blue-100 active:scale-[0.98] border border-[#1DB954]/30 rounded-xl text-[10.5px] font-bold text-blue-700 transition flex items-center gap-1.5 cursor-pointer"
 >
 <PlusCircle className="w-3.5 h-3.5 text-[#1DB954]" />
 <span>จำลองกรอก (+ไฟ 30, +น้ำ 2)</span>
 </button>
 </div>
 </div>

 {/* Floating Notifications */}
 <AnimatePresence>
 {copiedNotification && (
 <motion.div
 initial={{ opacity: 0, y: -20 }}
 animate={{ opacity: 1, y: 0 }}
 exit={{ opacity: 0, y: -20 }}
 className="p-3 bg-[#1DB954]/8 border border-[#1DB954]/30 text-[#1DB954] rounded-xl text-xxs font-bold flex items-center gap-2 "
 >
 <CheckCircle2 className="w-4 h-4 text-[#1DB954] shrink-0" />
 <span>{copiedNotification}</span>
 </motion.div>
 )}
 </AnimatePresence>

 {/* Main Submission Form */}
 <form onSubmit={handleSubmit} className="space-y-6">
 
 {/* Date and Month configuration card */}
 <div className="bg-white border border-[#E0E0DB] rounded-2xl p-5 grid grid-cols-1 md:grid-cols-2 gap-5">
 <div className="space-y-1">
 <label className="block text-[#6B6B66] font-extrabold text-xxs uppercase tracking-wider">
 1. รอบบิลประจำเดือนเรียกเก็บเงิน (Billing Month) *
 </label>
 <div className="relative">
 <Calendar className="absolute left-3.5 top-3.5 text-[#8A8A85] w-4 h-4" />
 <input
 type="month"
 value={billMonth}
 onChange={handleMonthChange}
 required
 className="w-full bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl p-3 pl-10 text-xs text-[#1A1A1A] font-bold focus:outline-none focus:bg-white focus:border-[#1DB954] transition"
 />
 </div>
 <p className="text-[10px] text-[#8A8A85] leading-normal">
 ระบุปีและเดือนที่จะเรียกเก็บ เช่น เดือนกรกฎาคม 2026
 </p>
 </div>

 <div className="space-y-1">
 <label className="block text-[#6B6B66] font-extrabold text-xxs uppercase tracking-wider">
 2. กำหนดชำrateชำระเงินไม่เกิน (Payment Due Date) *
 </label>
 <div className="relative">
 <Calendar className="absolute left-3.5 top-3.5 text-[#8A8A85] w-4 h-4" />
 <input
 type="date"
 value={dueDate}
 onChange={(e) => setDueDate(e.target.value)}
 required
 className="w-full bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl p-3 pl-10 text-xs text-[#1A1A1A] font-bold focus:outline-none focus:bg-white focus:border-[#1DB954] transition"
 />
 </div>
 <p className="text-[10px] text-[#8A8A85] leading-normal">
 ผู้เช่าต้องชำระภายในวันที่กำหนดนี้ (ค่าตั้งต้นดึงจากอัตราที่ตั้งค่าไว้คือทุกวันที่ {settings.defaultDueDateDay} ของรอบเดือน)
 </p>
 </div>
 </div>

 {/* Global Alert messages */}
 {formError && (
 <div className="p-4 bg-[#E22134]/8 border border-[#E22134]/30 rounded-2xl text-xs text-[#E22134] font-semibold flex items-center gap-2.5 animate-shake ">
 <AlertTriangle className="w-5 h-5 text-[#E22134] shrink-0" />
 <span className="whitespace-pre-line">{formError}</span>
 </div>
 )}

 {success && (
 <div className="p-6 bg-[#1DB954]/8 border border-[#1DB954]/30 rounded-2xl space-y-3 ">
 <div className="flex items-center gap-3">
 <CheckCircle2 className="w-7 h-7 text-[#1DB954] shrink-0" />
 <div>
 <h4 className="text-sm font-extrabold text-emerald-900">บันทึกและส่งบิลประจำรอบสำเร็จเรียบร้อยแล้วค่ะ!</h4>
 <p className="text-xs text-[#1DB954]">ระบบได้บันทึกประวัติและส่งการแจ้งเตือนยอดบิลไปยังผู้เช่าแต่ละห้องที่มีบัญชี LINE เชื่อมต่อสำเร็จแล้ว</p>
 </div>
 </div>
 <div className="flex gap-2 pt-1 pl-10">
 <button
 type="button"
 onClick={onNavigateToHistory}
 className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] text-[#1A1A1A] rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer"
 >
 <span>ไปที่ประวัติบิล</span>
 <ChevronRight className="w-4 h-4" />
 </button>
 <button
 type="button"
 onClick={() => setSuccess(false)}
 className="px-4 py-2 bg-white hover:bg-[#E8E8E3] border border-[#1DB954]/30 text-[#1DB954] rounded-xl text-xs font-bold transition cursor-pointer"
 >
 <span>กรอกรอบบิลถัดไป</span>
 </button>
 </div>
 </div>
 )}

 {/* Bulk Meter Entry Table Card */}
 <div className="bg-white border border-[#E0E0DB] rounded-2xl overflow-hidden ">
 <div className="px-5 py-4 border-b border-[#E0E0DB] flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 bg-[#282828]/50">
 <div>
 <h3 className="text-xs font-extrabold text-[#1A1A1A] uppercase tracking-wider flex items-center gap-2">
 <Layers className="w-4 h-4 text-[#1DB954]" />
 <span>ตารางกรอกมิเตอร์น้ำและไฟฟ้า ({occupiedRooms.length} ห้องพัก)</span>
 </h3>
 <p className="text-[10px] text-[#8A8A85] mt-0.5 font-medium">เฉพาะห้องพักที่มีสัญญาเช่า / มีผู้พักอาศัยอยู่ในปัจจุบัน</p>
 </div>
 <div className="flex items-center gap-2">
 <span className="text-[10px] bg-amber-500/10 text-[#F59B23] border border-amber-500/20 px-2.5 py-0.5 rounded-full font-bold">
 ไฟ {settings.defaultElecRate} บ. / หน่วย
 </span>
 <span className="text-[10px] bg-[#1DB954]/8 text-blue-800 border border-[#1DB954]/30/20 px-2.5 py-0.5 rounded-full font-bold">
 น้ำ {settings.defaultWaterRate} บ. / หน่วย 
 </span>
 </div>
 </div>

 {occupiedRooms.length === 0 ? (
 <div className="p-14 text-center space-y-3">
 <div className="w-12 h-12 rounded-full bg-[#F0F0EB] flex items-center justify-center mx-auto">
 <Layers className="w-6 h-6 text-[#8A8A85]" />
 </div>
 <div>
 <p className="text-xs font-bold text-[#6B6B66]">ยังไม่มีห้องพักที่มีสัญญาเช่าในขณะนี้</p>
 <p className="text-[11px] text-[#8A8A85] mt-0.5">กรุณาไปที่เมนู 'ห้องพัก' เพื่อทำการเพิ่มข้อมูลผู้เช่าและบันทึกสัญญาก่อนใช้งานค่ะ</p>
 </div>
 </div>
 ) : (
 <div className="overflow-x-auto">
 <table className="w-full text-left border-collapse min-w-[850px]">
 <thead>
 <tr className="bg-[#F0F0EB] text-[10px] text-[#8A8A85] uppercase tracking-wider font-extrabold border-b border-[#E0E0DB]">
 <th className="py-3.5 px-4 w-10 text-center">
 <input
 type="checkbox"
 checked={occupiedRooms.length > 0 && occupiedRooms.every(r => selectedRooms[r.id])}
 onChange={toggleAllRooms}
 className="w-3.5 h-3.5 rounded border-gray-300 text-[#1DB954] focus:ring-[#1DB954] cursor-pointer"
 />
 </th>
 <th className="py-3.5 px-4 w-24">ห้องพัก</th>
 <th className="py-3.5 px-4 w-36">ผู้เช่า / สถานะ LINE</th>
 <th className="py-3.5 px-4 text-center bg-[#F59B23]/10/20 w-48 border-x border-[#282828]/40">เลขมิเตอร์ไฟฟ้า (รอบก่อน → รอบล่าสุด)</th>
 <th className="py-3.5 px-4 text-center bg-[#1DB954]/10/20 w-48 border-r border-[#282828]/40">เลขมิเตอร์น้ำ (รอบก่อน → รอบล่าสุด)</th>
 <th className="py-3.5 px-4 w-32">ค่าใช้จ่ายอื่น ๆ (฿)</th>
 <th className="py-3.5 px-4 w-44">หมายเหตุค่าเพิ่ม</th>
 <th className="py-3.5 px-4 w-24 text-right">ค่าเช่าห้อง</th>
 <th className="py-3.5 px-4 w-28 text-right font-black bg-[#1DB954]/10/10">ยอดคำนวณสุทธิ</th>
 </tr>
 </thead>
 <tbody className="divide-y divide-slate-100 text-[11px]">
 {occupiedRooms.map(room => {
 const roomBills = bills
 .filter(b => b.roomId === room.id)
 .sort((a, b) => b.billMonth.localeCompare(a.billMonth));

 const pE = roomBills.length > 0 ? roomBills[0].currentElec : 0;
 const pW = roomBills.length > 0 ? roomBills[0].currentWater : 0;

 const inputs = bulkInputs[room.id] || {
 priorElec: pE.toString(),
 currentElec: '',
 elecDeduct: '0',
 elecCost: '',
 priorWater: pW.toString(),
 currentWater: '',
 waterCost: '',
 otherCost: '0',
 otherDescription: 'ค่าส่วนกลาง/บริการ'
 };

 const finalPE = inputs.priorElec !== undefined ? (parseFloat(inputs.priorElec) || 0) : pE;
 const finalPW = inputs.priorWater !== undefined ? (parseFloat(inputs.priorWater) || 0) : pW;

 const curEStr = inputs.currentElec;
 const curWStr = inputs.currentWater;

 const curE = curEStr === '' ? finalPE : (parseFloat(curEStr) || 0);
 const curW = curWStr === '' ? finalPW : (parseFloat(curWStr) || 0);
 const deductE = parseFloat(inputs.elecDeduct) || 0;

 // Electricity usage & anomaly math
 const usedElec = Math.max(0, curE - finalPE - deductE);
 const autoElecCost = Math.round(usedElec * settings.defaultElecRate);
 const costElec = inputs.elecCost !== undefined && inputs.elecCost !== '' ? (parseFloat(inputs.elecCost) || 0) : autoElecCost;
 const avgE = get6MonthAverage(room.id, 'elec');
 const isElecAnomaly = avgE !== null && avgE > 0 && usedElec > avgE * 1.8;

 // Water usage & anomaly math
 const usedWater = Math.max(0, curW - finalPW);
 const autoWaterCost = usedWater > 0 ? (Math.round(usedWater * settings.defaultWaterRate)) : 0;
 const costWater = inputs.waterCost !== undefined && inputs.waterCost !== '' ? (parseFloat(inputs.waterCost) || 0) : autoWaterCost;
 const avgW = get6MonthAverage(room.id, 'water');
 const isWaterAnomaly = avgW !== null && avgW > 0 && usedWater > avgW * 1.8;

 const extra = (parseFloat(inputs.otherCost) || 0) + (dueItems[room.id] || []).reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
 const totalCalculated = room.monthlyRent + costElec + costWater + extra;

 return (
 <tr key={room.id} className={`transition ${!selectedRooms[room.id] ? 'opacity-50 grayscale bg-gray-50' : 'hover:bg-[#282828]/40'}`}>
 {/* Checkbox */}
 <td className="py-3 px-4 text-center">
 <input
 type="checkbox"
 checked={!!selectedRooms[room.id]}
 onChange={() => toggleRoom(room.id)}
 className="w-3.5 h-3.5 rounded border-gray-300 text-[#1DB954] focus:ring-[#1DB954] cursor-pointer"
 />
 </td>

 {/* Room Number */}
 <td className="py-3 px-4 font-extrabold text-[#1A1A1A] text-xs">
 ห้อง {room.roomNumber}
 </td>

 {/* Tenant Name */}
 <td className="py-3 px-4 text-[#6B6B66]">
 <p className="font-bold text-[#1A1A1A] truncate max-w-[120px]">{room.tenantName}</p>
 <div className="flex items-center gap-1 mt-0.5 text-[9px]">
 {room.lineStatus === 'linked' ? (
 <span className="text-[#1DB954] bg-[#1DB954]/8 px-1 rounded font-bold border border-[#1DB954]/30">
 LINE: ต่อแล้ว
 </span>
 ) : (
 <span className="text-[#8A8A85] bg-[#F0F0EB] px-1 rounded font-bold border border-[#E0E0DB]">
 LINE: ยังไม่ต่อ
 </span>
 )}
 </div>
 </td>

 {/* Electricity Inputs */}
 <td className="py-3 px-3 bg-[#F59B23]/10/5 text-center border-x border-[#E0E0DB]">
 <div className="flex items-center gap-1 justify-center">
 <div className="flex flex-col items-center">
 <span className="text-[8px] text-[#8A8A85] font-bold mb-0.5">ก่อนหน้า</span>
 <input
 type="number"
 step="any"
 value={inputs.priorElec}
 onChange={(e) => handleFieldChange(room.id, 'priorElec', e.target.value)}
 className="w-12 bg-[#F0F0EB] hover:bg-white focus:bg-white border border-[#E0E0DB] rounded-md p-1 text-center font-bold text-[#6B6B66] text-xxs focus:outline-none"
 />
 </div>
 <span className="text-[#8A8A85] self-end mb-1">→</span>
 <div className="flex flex-col items-center">
 <span className="text-[8px] text-[#F59B23] font-bold mb-0.5">รอบล่าสุด *</span>
 <input
 type="number"
 step="any"
 placeholder={inputs.priorElec}
 value={inputs.currentElec}
 onChange={(e) => handleFieldChange(room.id, 'currentElec', e.target.value)}
 className={`w-12 bg-white border rounded-md p-1 text-center font-black text-xxs focus:outline-none focus:ring-1 focus:ring-amber-400 focus:border-amber-400 ${
 isElecAnomaly ? 'border-rose-400 bg-[#E22134]/10/10' : 'border-[#E0E0DB]'
 }`}
 />
 </div>
 <span className="text-[#8A8A85] self-end mb-1">-</span>
 <div className="flex flex-col items-center">
 <span className="text-[8px] text-[#E22134] font-bold mb-0.5">หักลบ</span>
 <input
 type="number"
 step="any"
 value={inputs.elecDeduct}
 onChange={(e) => handleFieldChange(room.id, 'elecDeduct', e.target.value)}
 className="w-10 bg-white border border-[#E0E0DB] rounded-md p-1 text-center font-semibold focus:outline-none focus:border-amber-500 text-xxs"
 />
 </div>
 <span className="text-[#8A8A85] self-end mb-1">|</span>
 <div className="flex flex-col items-center">
 <span className="text-[8px] text-[#F59B23] font-bold mb-0.5">เงินค่าไฟ (฿)</span>
 <input
 type="number"
 step="any"
 placeholder={autoElecCost.toString()}
 value={inputs.elecCost ?? ''}
 onChange={(e) => handleFieldChange(room.id, 'elecCost', e.target.value)}
 className={`w-14 bg-white border rounded-md p-1 text-center font-bold focus:outline-none focus:ring-1 focus:ring-amber-400 focus:border-amber-400 text-xxs ${
 inputs.elecCost !== '' ? 'border-amber-400 bg-[#F59B23]/10/30 text-[#F59B23]' : 'border-[#E0E0DB] text-[#6B6B66]'
 }`}
 title="พิมพ์จำนวนเงินค่าไฟเอง หรือปล่อยว่างเพื่อใช้คำนวณอัตโนมัติ"
 />
 </div>
 {isElecAnomaly && (
 <div className="relative group cursor-pointer shrink-0 ml-0.5 self-end mb-1" title={`ใช้ไฟฟ้าสูงกว่าปกติเฉลี่ย 6 เดือน: ${avgE?.toFixed(1)} หน่วย (เดือนนี้ใช้: ${usedElec} หน่วย)`}>
 <AlertTriangle className="w-3.5 h-3.5 text-[#F59B23] animate-pulse" />
 </div>
 )}
 </div>
 <div className="text-[9px] text-[#8A8A85] mt-1 font-semibold">
 ใช้: <span className="font-bold text-amber-700">{usedElec}</span> หน่วย 
 {deductE > 0 && <span className="text-[#E22134] font-bold"> (หัก {deductE})</span>}
 <span className="text-[#8A8A85] mx-1">|</span> 
 <span className={`font-bold ${inputs.elecCost !== '' ? 'text-amber-700' : 'text-[#6B6B66]'}`}>
 {costElec.toLocaleString()} บ. {inputs.elecCost !== '' && '(กำหนดเอง)'}
 </span>
 </div>
 </td>

 {/* Water Inputs */}
 <td className="py-3 px-3 bg-[#1DB954]/10/5 text-center border-r border-[#E0E0DB]">
 <div className="flex items-center gap-1 justify-center">
 <div className="flex flex-col items-center">
 <span className="text-[8px] text-[#8A8A85] font-bold mb-0.5">ก่อนหน้า</span>
 <input
 type="number"
 step="any"
 value={inputs.priorWater}
 onChange={(e) => handleFieldChange(room.id, 'priorWater', e.target.value)}
 className="w-12 bg-[#F0F0EB] hover:bg-white focus:bg-white border border-[#E0E0DB] rounded-md p-1 text-center font-bold text-[#6B6B66] text-xxs focus:outline-none"
 />
 </div>
 <span className="text-[#8A8A85] self-end mb-1">→</span>
 <div className="flex flex-col items-center">
 <span className="text-[8px] text-[#1DB954] font-bold mb-0.5">รอบล่าสุด *</span>
 <input
 type="number"
 step="any"
 placeholder={inputs.priorWater}
 value={inputs.currentWater}
 onChange={(e) => handleFieldChange(room.id, 'currentWater', e.target.value)}
 className={`w-12 bg-white border rounded-md p-1 text-center font-black text-xxs focus:outline-none focus:ring-1 focus:ring-blue-400 focus:border-blue-400 ${
 isWaterAnomaly ? 'border-rose-400 bg-[#E22134]/10/10' : 'border-[#E0E0DB]'
 }`}
 />
 </div>
 <span className="text-[#8A8A85] self-end mb-1">|</span>
 <div className="flex flex-col items-center">
 <span className="text-[8px] text-[#1DB954] font-bold mb-0.5">จำนวนเงิน (฿)</span>
 <input
 type="number"
 step="any"
 placeholder={autoWaterCost.toString()}
 value={inputs.waterCost}
 onChange={(e) => handleFieldChange(room.id, 'waterCost', e.target.value)}
 className={`w-14 bg-white border rounded-md p-1 text-center font-bold focus:outline-none focus:ring-1 focus:ring-blue-400 focus:border-blue-400 text-xxs ${
 inputs.waterCost !== '' ? 'border-amber-400 bg-[#F59B23]/10/30 text-[#F59B23]' : 'border-[#E0E0DB] text-[#6B6B66]'
 }`}
 title="พิมพ์จำนวนเงินค่าน้ำเอง หรือปล่อยว่างเพื่อใช้คำนวณอัตโนมัติ"
 />
 </div>
 {isWaterAnomaly && (
 <div className="relative group cursor-pointer shrink-0 ml-0.5 self-end mb-1" title={`ใช้น้ำสูงกว่าปกติเฉลี่ย 6 เดือน: ${avgW?.toFixed(1)} หน่วย (เดือนนี้ใช้: ${usedWater} หน่วย)`}>
 <AlertTriangle className="w-3.5 h-3.5 text-[#F59B23] animate-pulse" />
 </div>
 )}
 </div>
 <div className="text-[9px] text-[#8A8A85] mt-1 font-semibold">
 ใช้: <span className="font-bold text-blue-700">{usedWater}</span> หน่วย 
 <span className="text-[#8A8A85] mx-1">|</span> 
 <span className={`font-bold ${inputs.waterCost !== '' ? 'text-amber-700' : 'text-[#6B6B66]'}`}>
 {costWater.toLocaleString()} บ. {inputs.waterCost !== '' && '(กำหนดเอง)'}
 </span>
 </div>
 </td>

 {/* Other Cost */}
 <td className="py-3 px-4">
 <div className="relative">
 <span className="absolute left-2 top-1.5 text-[#8A8A85] text-[10px]">฿</span>
 <input
 type="number"
 value={inputs.otherCost}
 onChange={(e) => handleFieldChange(room.id, 'otherCost', e.target.value)}
 className="w-full bg-[#F0F0EB] hover:bg-white focus:bg-white border border-[#E0E0DB] rounded-lg py-1 pl-4 pr-1 text-center text-xxs font-bold text-[#6B6B66] focus:outline-none"
 />
 </div>
 </td>

 {/* Other Description */}
 <td className="py-3 px-4">
 <input
 type="text"
 placeholder="เช่น ค่าส่วนกลาง 100 บาท"
 value={inputs.otherDescription}
 onChange={(e) => handleFieldChange(room.id, 'otherDescription', e.target.value)}
 className="w-full bg-[#F0F0EB] hover:bg-white focus:bg-white border border-[#E0E0DB] rounded-lg py-1 px-2 text-xxs text-[#6B6B66] focus:outline-none"
 />
 </td>

 {/* Rent Main */}
 <td className="py-3 px-4 text-right text-[#8A8A85] font-extrabold text-xxs">
 {room.monthlyRent.toLocaleString()} บ.
 </td>

 {/* Net Total Calculated */}
 <td className="py-3 px-4 text-right font-black text-[#1DB954] text-xs bg-[#1DB954]/10/5">
 {totalCalculated.toLocaleString()} บาท
 </td>
 </tr>
 );
 })}
 </tbody>
 </table>
 </div>
 )}
 </div>

 {/* Aggregated Total & Batch Billing Confirmation */}
 {occupiedRooms.length > 0 && (
 <div className="bg-white border border-[#E0E0DB] rounded-2xl p-6 grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
 
 <div className="md:col-span-2 space-y-3">
 <h4 className="text-xs font-extrabold text-[#8A8A85] uppercase tracking-wider flex items-center gap-1.5">
 <Info className="w-4 h-4 text-[#1DB954]" />
 <span>สรุปยอดจำลองออกบิลแบบกลุ่มประจำรอบประจำเดือน</span>
 </h4>
 <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-1 text-xxs text-[#6B6B66] font-bold">
 <div className="bg-[#F0F0EB] p-2.5 rounded-xl border border-[#E0E0DB]">
 <p className="text-[#8A8A85] uppercase text-[8px] tracking-wide mb-0.5">ห้องพักที่จะคำนวณ</p>
 <p className="text-sm font-black text-[#1A1A1A]">{totals.roomsBilled} ห้อง</p>
 </div>
 <div className="bg-[#F0F0EB] p-2.5 rounded-xl border border-[#E0E0DB]">
 <p className="text-[#8A8A85] uppercase text-[8px] tracking-wide mb-0.5">รวมค่าไฟสุทธิ</p>
 <p className="text-sm font-black text-[#F59B23]">{totals.totalElecCost.toLocaleString()} บาท ({totals.totalElecUnits} หน่วย)</p>
 </div>
 <div className="bg-[#F0F0EB] p-2.5 rounded-xl border border-[#E0E0DB]">
 <p className="text-[#8A8A85] uppercase text-[8px] tracking-wide mb-0.5">รวมค่าน้ำสุทธิ</p>
 <p className="text-sm font-black text-[#1DB954]">{totals.totalWaterCost.toLocaleString()} บาท ({totals.totalWaterUnits} หน่วย)</p>
 </div>
 <div className="bg-[#F0F0EB] p-2.5 rounded-xl border border-[#E0E0DB]">
 <p className="text-[#8A8A85] uppercase text-[8px] tracking-wide mb-0.5">รวมค่าเช่าและอื่น ๆ</p>
 <p className="text-sm font-black text-[#1A1A1A]">{(totals.totalBaseRent + totals.totalOtherCosts).toLocaleString()} บาท</p>
 </div>
 </div>
 </div>

 <div className="bg-[#F0F0EB] border border-[#E0E0DB] rounded-2xl p-4 text-center md:text-right space-y-3.5">
 <div>
 <p className="text-[#8A8A85] text-[10px] font-extrabold uppercase tracking-wider">ยอดรวมค่าเช่าที่คาดว่าจะเก็บได้</p>
 <p className="text-2xl font-black text-[#1DB954]">{totals.grandTotal.toLocaleString()} <span className="text-xs font-semibold text-[#8A8A85]">บาท</span></p>
 </div>

 <div className="flex gap-2 justify-center md:justify-end">
 <button
 type="submit"
 disabled={submitting}
 className="w-full sm:w-auto py-3 px-5 rounded-xl bg-[#1DB954] hover:bg-[#1ED760] hover:scale-[1.04] active:scale-[0.98] text-[#1A1A1A] font-extrabold text-xs transition shadow-blue-200 cursor-pointer flex items-center justify-center gap-2 disabled:bg-slate-150 disabled:text-slate-400"
 >
 <FileSpreadsheet className="w-4 h-4" />
 <span>{submitting ? 'กำลังจัดเก็บและประมวลผล...' : 'บันทึกและคำนวณยอดออกบิลพร้อมกัน'}</span>
 </button>
 </div>
 </div>

 </div>
 )}

 </form>
 
 </div>
 );
};
