import React, { useRef } from 'react';
import { toJpeg } from 'html-to-image';
import { 
  Printer, 
  Copy, 
  Check, 
  MessageSquare, 
  X, 
  Home, 
  Zap, 
  Droplet, 
  Calculator, 
  AlertCircle, 
  Heart, 
  User, 
  Calendar, 
  Tag, 
  Info,
  Shield,
  Download,
  MapPin
} from 'lucide-react';
import { Bill, Settings } from '../types.ts';
import { PromptPayQR } from '../utils/promptpay.tsx';

const BILL_CANVAS_WIDTH = 528;

interface BillInvoiceProps {
  bill: Bill;
  settings: Settings;
  onClose: () => void;
}

export const BillInvoice: React.FC<BillInvoiceProps> = ({ bill, settings, onClose }) => {
  const [copied, setCopied] = React.useState(false);
  const [downloading, setDownloading] = React.useState(false);
  const printAreaRef = useRef<HTMLDivElement>(null);
  const previewHostRef = useRef<HTMLDivElement>(null);
  const [previewScale, setPreviewScale] = React.useState(1);
  const [previewHeight, setPreviewHeight] = React.useState<number | null>(null);

  const elecUnits = Math.max(0, bill.currentElec - bill.priorElec - (bill.elecDeduct ?? 0));
  const waterUnits = Math.max(0, bill.currentWater - bill.priorWater);
  const elecCost = (bill.elecCost !== undefined && bill.elecCost !== null) ? bill.elecCost : Math.round(elecUnits * bill.elecUnitCost);
  const waterCost = bill.waterCost !== undefined ? bill.waterCost : (waterUnits > 0 ? Math.round(waterUnits * bill.waterUnitCost) : 0);

  // Format month to Thai
  const formatThaiMonth = (monthStr: string) => {
    if (!monthStr) return '';
    const [year, month] = monthStr.split('-');
    const months = [
      'มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน',
      'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'
    ];
    const thYear = parseInt(year) + 543;
    return `${months[parseInt(month) - 1]} ${thYear}`;
  };

  const formatThaiFullDate = (dateStr: string) => {
    if (!dateStr) return '';
    const [year, month, day] = dateStr.split('-');
    const months = [
      'มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน',
      'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'
    ];
    const thYear = parseInt(year) + 543;
    return `${parseInt(day)} ${months[parseInt(month) - 1]} ${thYear}`;
  };

  const handlePrint = () => {
    const printContent = printAreaRef.current?.innerHTML;
    if (printContent) {
      // Create a style block for custom print settings
      const style = document.createElement('style');
      style.innerHTML = `
        @media print {
          body {
            background-color: white !important;
            color: black !important;
            padding: 0 !important;
            margin: 0 !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          .no-print {
            display: none !important;
          }
          .print-container {
            width: 100% !important;
            max-width: 600px !important;
            margin: 0 auto !important;
            box-shadow: none !important;
            border: 2.5px solid #0B419C !important;
            padding: 24px !important;
            border-radius: 2rem !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          /* Ensure wave graphics print correctly */
          svg, path {
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
        }
      `;
      document.head.appendChild(style);
      window.print();
      document.head.removeChild(style);
    }
  };

  const getBillText = () => {
    return `ใบแจ้งหนี้ ${settings.dormName || ''}
ห้อง ${bill.roomNumber} ประจำเดือน ${formatThaiMonth(bill.billMonth)}
ยอดรวมทั้งสิ้น: ${(bill.totalCost || 0).toLocaleString()} บาท
กำหนดชำระ: ${formatThaiFullDate(bill.dueDate)}`;
  };

  const handleCopyText = async () => {
    try {
      const textToCopy = getBillText();
      await navigator.clipboard.writeText(textToCopy);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  const handleShareLine = () => {
    const text = encodeURIComponent(getBillText());
    window.open(`https://line.me/R/share?text=${text}`, '_blank');
  };

  const handleDownloadImage = async () => {
    if (!printAreaRef.current) return;
    try {
      setDownloading(true);
      
      // Convert the container to JPEG using html-to-image
      const dataUrl = await toJpeg(printAreaRef.current, {
        quality: 0.95,
        backgroundColor: '#ffffff',
        pixelRatio: 2,
        cacheBust: true,
      });

      // Create a downloadable anchor tag
      const link = document.createElement('a');
      link.download = `bill-room-${bill.roomNumber}-${bill.billMonth}.jpg`;
      link.href = dataUrl;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error('Error generating image:', error);
      alert('ไม่สามารถเซฟรูปภาพได้ กรุณาลองใหม่อีกครั้ง');
    } finally {
      setDownloading(false);
    }
  };

  const billNumber = `INV-${(bill.billMonth || '').replace('-', '')}-${String(bill.id || 0).padStart(3, '0')}`;


  React.useLayoutEffect(() => {
    const updatePreview = () => {
      const host = previewHostRef.current;
      const invoice = printAreaRef.current;
      if (!host || !invoice) return;

      const nextScale = Math.min(1, host.clientWidth / BILL_CANVAS_WIDTH);
      setPreviewScale(nextScale);
      setPreviewHeight(Math.ceil(invoice.offsetHeight * nextScale));
    };

    updatePreview();

    const resizeObserver = typeof ResizeObserver !== 'undefined'
      ? new ResizeObserver(updatePreview)
      : null;

    if (resizeObserver) {
      if (previewHostRef.current) resizeObserver.observe(previewHostRef.current);
      if (printAreaRef.current) resizeObserver.observe(printAreaRef.current);
    }

    window.addEventListener('resize', updatePreview);
    return () => {
      resizeObserver?.disconnect();
      window.removeEventListener('resize', updatePreview);
    };
  }, [bill, settings.promptpayId]);

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto no-print">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-xl w-full flex flex-col my-8 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-blue-500"></span>
            <h3 className="font-semibold text-slate-200 text-lg">ใบแจ้งหนี้ / ใบแจ้งค่าใช้จ่าย</h3>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Area */}
        <div className="p-4 sm:p-6 overflow-y-auto max-h-[75vh] bg-slate-950">
          
          {/* Printable Invoice Card */}
          <div
            ref={previewHostRef}
            className="w-full flex justify-center overflow-hidden"
            style={{ height: previewHeight !== null ? `${previewHeight}px` : undefined }}
          >
            <div
              className="shrink-0"
              style={{
                width: `${BILL_CANVAS_WIDTH}px`,
                transform: `scale(${previewScale})`,
                transformOrigin: 'top center',
              }}
            >
              <div 
                ref={printAreaRef}
            className="print-container w-[528px] bg-white text-slate-900 p-5 rounded-[1.5rem] shadow-xl border border-slate-200 flex flex-col font-sans relative overflow-hidden"
            style={{ color: '#0f172a' }}
          >
            {/* Top Leaf Pattern Decoration (simulated with CSS) */}
            <div className="absolute top-0 left-0 w-full h-20 bg-gradient-to-b from-green-100/50 to-white opacity-80 pointer-events-none">
               {/* Faint leaf SVGs for top corners */}
               <svg className="absolute top-0 left-0 w-32 h-32 text-green-700 opacity-[0.04] -translate-x-4 -translate-y-4" viewBox="0 0 100 100" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                 <path d="M0,50 C20,10 80,10 100,50 C80,90 20,90 0,50 Z" transform="rotate(45 50 50)"/>
                 <path d="M10,20 C30,-10 90,-10 110,20 C90,60 30,60 10,20 Z" transform="rotate(15 50 50)"/>
               </svg>
               <svg className="absolute top-0 right-0 w-32 h-32 text-green-700 opacity-[0.04] translate-x-4 -translate-y-4" viewBox="0 0 100 100" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                 <path d="M0,50 C20,10 80,10 100,50 C80,90 20,90 0,50 Z" transform="rotate(-45 50 50)"/>
                 <path d="M-10,20 C10,-10 70,-10 90,20 C70,60 10,60 -10,20 Z" transform="rotate(-15 50 50)"/>
               </svg>
            </div>

            {/* Invoice Header */}
            <div className="relative flex flex-row items-center justify-between gap-3 mb-5 z-10">
              <div className="flex items-center gap-3">
                {/* Home/Building Icon */}
                <div className="w-16 h-16 bg-[#166534] rounded-full flex items-center justify-center text-white shrink-0 shadow-lg border-2 border-white">
                  <Home className="w-8 h-8 text-white fill-white" />
                </div>
                {/* Text Title */}
                <div className="text-left">
                  <h4 className="text-3xl font-black text-[#166534] leading-tight">
                    {settings.dormName || 'หอพักของฉัน'}
                  </h4>
                  <p className="text-xs font-bold text-slate-500 tracking-wide mt-0.5">
                    ใบแจ้งค่าใช้จ่าย
                  </p>
                  <p className="text-[10px] font-bold text-[#166534] mt-1 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-[#166534] fill-[#166534]" />
                    บริการหอพักสะอาด ปลอดภัย ใส่ใจทุกการดูแล
                  </p>
                </div>
              </div>

              {/* Billing Cycle Period Badge */}
              <div className="bg-[#166534] text-white rounded-xl py-2 px-4 text-center shadow-md flex flex-col justify-center shrink-0 border border-green-800">
                <p className="text-[10px] font-bold tracking-wide flex items-center justify-center gap-1.5 opacity-90">
                  <Calendar className="w-3 h-3" />
                  รอบบิลประจำเดือน
                </p>
                <p className="text-base font-black tracking-wide mt-1">
                  {formatThaiMonth(bill.billMonth)}
                </p>
              </div>
            </div>

            {/* Room Info and Bill Meta Grid */}
            <div className="grid grid-cols-2 gap-3 mb-5 z-10 relative">
              {/* Left Info: Room Details */}
              <div className="bg-white rounded-xl p-3 flex items-center gap-3 border border-slate-200 shadow-xs">
                <div className="w-11 h-11 bg-[#166534] text-white rounded-full flex items-center justify-center shadow-inner shrink-0 border border-green-800">
                  <User className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[#166534] text-[10px] font-extrabold tracking-wider">ผู้เช่า / ห้องพัก</p>
                  <p className="text-slate-800 text-xl font-black truncate leading-tight mt-0.5">
                    ห้อง {bill.roomNumber}
                  </p>
                </div>
              </div>

              {/* Right Info: Dates & Invoice Number */}
              <div className="bg-white rounded-xl border border-slate-200 overflow-hidden flex flex-col justify-center text-xs shadow-xs">
                {/* Row 1: Bill Date */}
                <div className="flex justify-between items-center px-4 py-2.5 bg-white">
                  <span className="flex items-center gap-1.5 text-[#166534] font-extrabold text-[11.5px]">
                    <Calendar className="w-4 h-4" />
                    วันที่ออกบิล
                  </span>
                  <span className="text-slate-700 font-bold text-right text-[11.5px]">
                    {formatThaiFullDate(bill.createdAt ? bill.createdAt.substring(0, 10) : '')}
                  </span>
                </div>
                {/* Divider Line */}
                <div className="border-t border-slate-100 mx-2"></div>
                {/* Row 2: Invoice No */}
                <div className="flex justify-between items-center px-4 py-2.5 bg-white">
                  <span className="flex items-center gap-1.5 text-[#166534] font-extrabold text-[11.5px]">
                    <Tag className="w-4 h-4" />
                    เลขที่บิล
                  </span>
                  <span className="text-slate-700 font-mono font-bold uppercase tracking-wide text-right text-[11.5px]">
                    {billNumber}
                  </span>
                </div>
              </div>
            </div>

            {/* Table of Details */}
            <div className="rounded-[1rem] overflow-hidden border border-slate-200 mb-4 shadow-xs z-10 relative">
              <table className="w-full text-xs">
                <thead>
                  <tr className="bg-[#166534] text-white text-[11.5px] font-bold tracking-wider text-center select-none border-b border-green-800">
                    <th className="py-3 px-3 text-left pl-5 w-[40%]">รายการ</th>
                    <th className="py-3 px-1 w-[15%]">มิเตอร์<br/>ก่อน</th>
                    <th className="py-3 px-1 w-[15%]">มิเตอร์<br/>หลัง</th>
                    <th className="py-3 px-1 w-[15%]">จำนวน<br/>หน่วย</th>
                    <th className="py-3 px-3 text-right pr-5 w-[15%]">จำนวนเงิน<br/>(บาท)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700 bg-white">
                  {/* Rent Row */}
                  <tr className="hover:bg-slate-50 transition">
                    <td className="py-3 px-3 pl-5 flex items-center gap-3 text-left">
                      <div className="w-8 h-8 bg-[#DCFCE7] rounded-full flex items-center justify-center shrink-0 border border-[#bbf7d0]">
                        <Home className="w-4 h-4 text-[#166534] fill-[#166534]" />
                      </div>
                      <div className="leading-tight">
                        <span className="text-[11.5px] font-extrabold text-slate-800 block">ค่าเช่าบ้าน / ค่าเช่าห้องพัก</span>
                        <span className="text-[9.5px] font-semibold text-slate-400 mt-0.5 block">ค่าใช้จ่ายประจำเดือน</span>
                      </div>
                    </td>
                    <td className="py-3 px-1 text-center text-slate-400 font-medium text-[11.5px]">-</td>
                    <td className="py-3 px-1 text-center text-slate-400 font-medium text-[11.5px]">-</td>
                    <td className="py-3 px-1 text-center text-slate-400 font-medium text-[11.5px]">-</td>
                    <td className="py-3 px-3 pr-5 text-right font-extrabold text-slate-800 text-[12px]">
                      {(bill.rentCost || 0).toLocaleString()}
                    </td>
                  </tr>

                  {/* Elec Row */}
                  <tr className="hover:bg-slate-50 transition">
                    <td className="py-3 px-3 pl-5 flex items-center gap-3 text-left">
                      <div className="w-8 h-8 bg-amber-50 rounded-full flex items-center justify-center shrink-0 border border-amber-100">
                        <Zap className="w-4 h-4 text-amber-500 fill-amber-500" />
                      </div>
                      <div className="leading-tight">
                        <span className="text-[11.5px] font-extrabold text-slate-800 block">ค่าไฟฟ้า</span>
                        <span className="text-[9.5px] font-semibold text-slate-400 mt-0.5 block">
                          อัตรา {bill.elecUnitCost} บ.
                          {(bill.elecDeduct ?? 0) > 0 && <span className="text-amber-600 ml-1">(หัก {bill.elecDeduct} น.)</span>}
                        </span>
                      </div>
                    </td>
                    <td className="py-3 px-1 text-center font-mono text-slate-600 text-[11.5px]">{bill.priorElec}</td>
                    <td className="py-3 px-1 text-center font-mono text-slate-600 text-[11.5px]">{bill.currentElec}</td>
                    <td className="py-3 px-1 text-center font-mono text-slate-800 font-bold text-[11.5px]">{elecUnits}</td>
                    <td className="py-3 px-3 pr-5 text-right font-extrabold text-slate-800 font-mono text-[12px]">
                      {(elecCost || 0).toLocaleString()}
                    </td>
                  </tr>

                  {/* Water Row */}
                  <tr className="hover:bg-slate-50 transition">
                    <td className="py-3 px-3 pl-5 flex items-center gap-3 text-left">
                      <div className="w-8 h-8 bg-blue-50 rounded-full flex items-center justify-center shrink-0 border border-blue-100">
                        <Droplet className="w-4 h-4 text-blue-500 fill-blue-500" />
                      </div>
                      <div className="leading-tight">
                        <span className="text-[11.5px] font-extrabold text-slate-800 block">ค่าน้ำประปา</span>
                        <span className="text-[9.5px] font-semibold text-slate-400 mt-0.5 block">
                          อัตรา {bill.waterUnitCost} บ.
                        </span>
                      </div>
                    </td>
                    <td className="py-3 px-1 text-center font-mono text-slate-600 text-[11.5px]">{bill.priorWater}</td>
                    <td className="py-3 px-1 text-center font-mono text-slate-600 text-[11.5px]">{bill.currentWater}</td>
                    <td className="py-3 px-1 text-center font-mono text-slate-800 font-bold text-[11.5px]">{waterUnits}</td>
                    <td className="py-3 px-3 pr-5 text-right font-extrabold text-slate-800 font-mono text-[12px]">
                      {(waterCost || 0).toLocaleString()}
                    </td>
                  </tr>

                  {/* Deposit Row (Optional) */}
                  {bill.depositCost > 0 && (
                    <tr className="hover:bg-slate-50 transition bg-slate-50/50">
                      <td className="py-3 px-3 pl-5 flex items-center gap-3 text-left">
                        <div className="w-8 h-8 bg-slate-100 rounded-full flex items-center justify-center shrink-0 border border-slate-200">
                          <Shield className="w-4 h-4 text-slate-500" />
                        </div>
                        <div className="leading-tight">
                          <span className="text-[11.5px] font-extrabold text-slate-800 block">ค่าประกัน / ล่วงหน้า</span>
                          <span className="text-[9.5px] font-semibold text-slate-400 mt-0.5 block">ค่าใช้จ่ายเพิ่มเติม</span>
                        </div>
                      </td>
                      <td colSpan={3} className="py-3 px-1 text-center text-slate-400 font-medium text-[11.5px]">-</td>
                      <td className="py-3 px-3 pr-5 text-right font-extrabold text-slate-800 font-mono text-[12px]">
                        {(bill.depositCost || 0).toLocaleString()}
                      </td>
                    </tr>
                  )}

                  {/* Snapshotted service charge rows; legacy bills fall back to otherCost. */}
                  {(bill.chargeItems?.length ? bill.chargeItems : (bill.otherCost > 0 ? [{ label: bill.otherDescription || 'ค่าใช้จ่ายอื่น ๆ', amount: bill.otherCost }] : [])).map((item, index) => (
                    <tr key={`${item.label}-${index}`} className="hover:bg-slate-50 transition">
                      <td className="py-3 px-3 pl-5 flex items-center gap-3 text-left">
                        <div className="w-8 h-8 bg-purple-50 rounded-full flex items-center justify-center shrink-0 border border-purple-100">
                          <Info className="w-4 h-4 text-purple-500" />
                        </div>
                        <div className="leading-tight">
                          <span className="text-[11.5px] font-extrabold text-slate-800 block">{item.label}</span>
                          <span className="text-[9.5px] font-semibold text-slate-400 mt-0.5 block">
                            ค่าบริการเพิ่มเติม
                          </span>
                        </div>
                      </td>
                      <td colSpan={3} className="py-3 px-1 text-center text-slate-400 font-medium text-[11.5px]">-</td>
                      <td className="py-3 px-3 pr-5 text-right font-extrabold text-slate-800 font-mono text-[12px]">
                        {(Number(item.amount) || 0).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Grand Total Accent Box */}
            <div className="bg-[#166534] rounded-[1rem] p-4 flex justify-between items-center mb-4 shadow-lg border-2 border-green-800 z-10 relative text-white">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 bg-white rounded-full flex items-center justify-center shadow-inner shrink-0 text-[#166534]">
                  <span className="font-black text-lg">฿</span>
                </div>
                <span className="font-black text-base tracking-wide">
                  ยอดรวมที่ต้องชำระ
                </span>
              </div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-4xl font-black font-mono tracking-tight text-white drop-shadow-md">
                  {(bill.totalCost || 0).toLocaleString()}
                </span>
                <span className="text-sm font-bold text-green-100">บาท</span>
              </div>
            </div>

            {/* Warning & QR Box Area */}
            <div className="flex flex-row gap-3 mb-4 z-10 relative">
              {/* Warning box */}
              <div className="flex-[1.1] bg-[#F0FDF4] border border-green-200 rounded-xl p-4 flex flex-col justify-center shadow-xs">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center shrink-0 border border-green-100 shadow-sm">
                    <Calendar className="w-5 h-5 text-[#166534]" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[11.5px] font-extrabold text-[#166534] leading-tight">
                      จ่ายไม่เกินวันที่ {settings.defaultDueDateDay || '5'} ของทุกเดือน
                    </span>
                    <span className="text-[11px] font-bold text-slate-600 mt-1">
                      ปรับวันละ {settings.defaultPenaltyRate ?? 100} บาท
                    </span>
                  </div>
                </div>
              </div>

              {/* PromptPay QR */}
              {settings.promptpayId && (
                <div className="flex-[1.5] bg-white border border-slate-200 rounded-xl p-3 flex flex-row items-center justify-center gap-4 shadow-xs">
                  <div className="p-1 bg-white border border-slate-200 rounded-lg shrink-0 shadow-sm">
                    <PromptPayQR 
                      target={settings.promptpayId} 
                      amount={bill.totalCost}
                      className="w-20 h-20 object-contain"
                    />
                  </div>
                  <div className="flex flex-col justify-center">
                    <span className="text-[12px] font-black text-[#166534] tracking-tight">สแกนเพื่อชำระเงิน</span>
                    <span className="text-[9.5px] font-bold text-slate-500 mt-0.5">ผ่าน Mobile Banking</span>
                    <div className="flex items-center gap-1 mt-1 opacity-90 text-[8px] font-extrabold text-white">
                       <div className="w-4 h-4 bg-green-500 rounded-full flex items-center justify-center border border-white shadow-xs"><Check className="w-2.5 h-2.5 text-white"/></div>
                       <div className="w-4 h-4 bg-blue-700 rounded-full flex items-center justify-center border border-white shadow-xs -ml-1">B</div>
                       <div className="w-4 h-4 bg-purple-600 rounded-full flex items-center justify-center border border-white shadow-xs -ml-1">S</div>
                       <div className="w-4 h-4 bg-cyan-500 rounded-full flex items-center justify-center border border-white shadow-xs -ml-1">K</div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Footer Area */}
            <div className="bg-[#F8FAFC] border-t border-slate-100 -mx-5 -mb-5 p-5 pt-4 pb-6 rounded-b-[1.4rem] relative overflow-hidden z-0 h-28">
              <div className="flex items-start gap-3 relative z-10 w-2/3">
                <div className="w-7 h-7 bg-[#166534] rounded-full flex items-center justify-center shrink-0 mt-0.5 shadow-sm border-2 border-white">
                  <Heart className="w-3.5 h-3.5 text-white fill-white" />
                </div>
                <div>
                  <p className="text-[11.5px] font-black text-[#166534]">ขอบคุณที่เลือกใช้บริการ</p>
                  <p className="text-[9.5px] font-bold text-slate-500 mt-1 leading-relaxed">เรามุ่งมั่นในการบริการที่ดีที่สุดสำหรับคุณ<br/>หากมีข้อสงสัย กรุณาติดต่อเบอร์โทรหอพัก</p>
                </div>
              </div>

              {/* Town SVG Graphic at bottom right */}
              <div className="absolute right-0 bottom-0 opacity-80 pointer-events-none" style={{ width: '180px', height: '100px' }}>
                <svg width="100%" height="100%" viewBox="0 0 180 100" xmlns="http://www.w3.org/2000/svg">
                  {/* Background Trees */}
                  <circle cx="30" cy="75" r="12" fill="#86efac" opacity="0.7" />
                  <rect x="28" y="80" width="4" height="15" fill="#166534" opacity="0.5" />
                  <circle cx="55" cy="80" r="9" fill="#bbf7d0" opacity="0.6" />
                  <rect x="53" y="85" width="4" height="15" fill="#166534" opacity="0.5" />
                  
                  {/* House 1 (Right) */}
                  <path d="M 100 65 L 130 40 L 160 65 Z" fill="#22c55e" />
                  <rect x="105" y="65" width="50" height="35" fill="#f0fdf4" />
                  <rect x="115" y="70" width="12" height="12" fill="#86efac" />
                  <rect x="135" y="70" width="12" height="12" fill="#86efac" />
                  <rect x="125" y="80" width="10" height="20" fill="#15803d" />

                  {/* House 2 (Left/Front) */}
                  <path d="M 70 75 L 95 55 L 120 75 Z" fill="#16a34a" />
                  <rect x="75" y="75" width="40" height="25" fill="#dcfce7" />
                  <rect x="80" y="80" width="10" height="10" fill="#86efac" />
                  <rect x="95" y="80" width="12" height="20" fill="#15803d" />
                  
                  {/* Small Bushes */}
                  <circle cx="70" cy="90" r="8" fill="#15803d" />
                  <circle cx="60" cy="92" r="5" fill="#166534" />
                  <circle cx="165" cy="88" r="9" fill="#16a34a" />
                  
                  {/* Base line */}
                  <rect x="0" y="95" width="180" height="5" fill="#166534" opacity="0.1" />
                </svg>
              </div>
            </div>

              </div>
            </div>
          </div>
        </div>

        {/* Action Controls Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 grid grid-cols-2 sm:grid-cols-5 gap-2">
          <button
            onClick={handlePrint}
            className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs sm:text-sm font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <Printer className="w-4 h-4 shrink-0" />
            <span>พิมพ์ / PDF</span>
          </button>

          <button
            onClick={handleDownloadImage}
            disabled={downloading}
            className="py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:bg-blue-800 disabled:opacity-75 text-[#1A1A1A] text-xs sm:text-sm font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            {downloading ? (
              <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin shrink-0"></span>
            ) : (
              <Download className="w-4 h-4 shrink-0" />
            )}
            <span>{downloading ? 'กำลังเซฟ...' : 'เซฟรูป JPG'}</span>
          </button>
          
          <button
            onClick={handleShareLine}
            className="py-2.5 px-3 rounded-xl bg-green-600 hover:bg-green-500 text-[#1A1A1A] text-xs sm:text-sm font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <MessageSquare className="w-4 h-4 shrink-0" />
            <span>ส่ง LINE</span>
          </button>

          <button
            onClick={handleCopyText}
            className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs sm:text-sm font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="text-emerald-400">คัดลอกแล้ว</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 shrink-0" />
                <span>คัดลอกข้อความ</span>
              </>
            )}
          </button>

          <button
            onClick={onClose}
            className="py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 text-xs sm:text-sm font-semibold border border-slate-800 transition col-span-2 sm:col-span-1 cursor-pointer"
          >
            ปิด
          </button>
        </div>

      </div>
    </div>
  );
};
