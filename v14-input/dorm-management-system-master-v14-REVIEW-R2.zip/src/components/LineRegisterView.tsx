import React, { useState, useEffect } from 'react';
import { PromptPayQR } from '../utils/promptpay.tsx';
import { APP_VERSION_LABEL } from '../generated/version.ts';
import { 
 Check, 
 AlertCircle, 
 MessageSquare, 
 QrCode, 
 User, 
 FileText, 
 CreditCard, 
 TrendingUp, 
 ChevronRight, 
 Smartphone,
 CheckCircle2,
 Lock,
 ArrowRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface LineRegisterViewProps {
 initialRoom?: string;
 initialPhone?: string;
 onBackToLogin?: () => void;
}

export function LineRegisterView({ initialRoom = '', initialPhone = '', onBackToLogin }: LineRegisterViewProps) {
 // Navigation & verification states
 const [roomNumber, setRoomNumber] = useState(initialRoom);
 const [tenantPhone, setTenantPhone] = useState(initialPhone);
 const [isVerified, setIsVerified] = useState(false);
 const [loading, setLoading] = useState(false);
 const [error, setError] = useState<string | null>(null);

 // Loaded tenant/room data
 const [roomData, setRoomData] = useState<any | null>(null);
 const [settings, setSettings] = useState<any | null>(null);
 const [unpaidBills, setUnpaidBills] = useState<any[]>([]);
 const [paidBills, setPaidBills] = useState<any[]>([]);
 const [tenantToken, setTenantToken] = useState<string | null>(null);

 // LINE connection simulation states
 const [showLineLoginModal, setShowLineLoginModal] = useState(false);
 const [simLineName, setSimLineName] = useState('');
 const [simLineAvatar, setSimLineAvatar] = useState('https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=faces');
 const [simLineId, setSimLineId] = useState('');

 // Selected bill for payment
 const [selectedBill, setSelectedBill] = useState<any | null>(null);
 const [isPaidSuccess, setIsPaidSuccess] = useState(false);

 // Pre-fill fields from URL params on load if present
 useEffect(() => {
 const params = new URLSearchParams(window.location.search);
 const urlRoom = params.get('room');
 const urlPhone = params.get('phone');
 if (urlRoom) setRoomNumber(urlRoom);
 if (urlPhone) setTenantPhone(urlPhone);
 }, []);

 const handleVerify = async (e?: React.FormEvent) => {
 if (e) e.preventDefault();
 if (!roomNumber.trim() || !tenantPhone.trim()) {
 setError('กรุณากรอกข้อมูลให้ครบถ้วน');
 return;
 }

 setLoading(true);
 setError(null);

 try {
 const res = await fetch('/api/public/line/verify', {
 method: 'POST',
 headers: { 'Content-Type': 'application/json' },
 body: JSON.stringify({ roomNumber: roomNumber.trim(), tenantPhone: tenantPhone.trim() })
 });

 const responseJson = await res.json();
 if (!res.ok) {
 const errMsg = typeof responseJson.error === 'string'
 ? responseJson.error
 : (responseJson.error?.message || responseJson.message || 'ตรวจสอบข้อมูลไม่สำเร็จ');
 throw new Error(errMsg);
 }

 // Cloudflare Pages API responses wrap successful payloads in `data`, while
 // the local Express backend returns the payload directly. Support both so the
 // tenant portal cannot enter the verified state with an undefined room.
 const data = responseJson.data || responseJson;
 if (!data.room) {
 throw new Error('เซิร์ฟเวอร์ไม่ส่งข้อมูลห้องพักกลับมา กรุณาลองใหม่อีกครั้ง');
 }

 setRoomData(data.room);
 setSettings(data.settings);
 setUnpaidBills(Array.isArray(data.unpaidBills) ? data.unpaidBills : []);
 setPaidBills(Array.isArray(data.paidBills) ? data.paidBills : []);
 setTenantToken(data.tenantToken);
 setIsVerified(true);

 // Pre-fill simulator ID
 setSimLineName(data.room.tenantName || 'ผู้ใช้ LINE');
 setSimLineId('usr_' + Math.random().toString(36).substring(2, 10));

 } catch (err: any) {
 const msg = typeof err === 'string' ? err : err?.message || String(err);
 setError(msg);
 } finally {
 setLoading(false);
 }
 };

 const triggerLineLink = () => {
 setShowLineLoginModal(true);
 };

 const handleCompleteLineLink = async () => {
 if (!simLineName.trim()) return;
 setLoading(true);
 setShowLineLoginModal(false);

 try {
 const res = await fetch('/api/public/line/register', {
 method: 'POST',
 headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tenantToken}` },
 body: JSON.stringify({
 roomId: roomData.id,
 lineUserId: simLineId,
 lineDisplayName: simLineName,
 linePictureUrl: simLineAvatar
 })
 });

 const data = await res.json();
 if (!res.ok) {
 const errMsg = typeof data.error === 'string' ? data.error : (data.error?.message || data.message || 'เชื่อมต่อล้มเหลว');
 throw new Error(errMsg);
 }

 // Refresh verification
 await handleVerify();
 } catch (err: any) {
 const msg = typeof err === 'string' ? err : (err?.message || String(err));
 alert(msg || 'เชื่อมต่อล้มเหลว');
 } finally {
 setLoading(false);
 }
 };

 const handleUnlink = async () => {
 if (!confirm('คุณแน่ใจหรือไม่ว่าต้องการยกเลิกการเชื่อมโยงกับบัญชี LINE นี้?')) return;
 setLoading(true);
 try {
 // Simulate unlink on client or hit server
 const res = await fetch(`/api/line/unlink/${roomData.id}`, {
 method: 'POST',
 headers: { 'Content-Type': 'application/json' }
 });
 if (res.ok) {
 await handleVerify();
 }
 } catch (err) {
 console.error(err);
 } finally {
 setLoading(false);
 }
 };

 const [slipImageBase64, setSlipImageBase64] = useState<string | null>(null);
 const [uploadingSlip, setUploadingSlip] = useState(false);
 const [uploadError, setUploadError] = useState<string | null>(null);

 const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
 const file = e.target.files?.[0];
 if (!file) return;
 const reader = new FileReader();
 reader.onload = (event) => {
 if (event.target?.result) {
 setSlipImageBase64(event.target.result as string);
 }
 };
 reader.readAsDataURL(file);
 };

 const handleUploadSlipSubmit = async () => {
 if (!slipImageBase64) {
 setUploadError('กรุณาเลือกไฟล์รูปภาพสลิปก่อนทำการส่งค่ะ');
 return;
 }

 setUploadingSlip(true);
 setUploadError(null);

 try {
 const res = await fetch(`/api/public/bills/${selectedBill.id}/upload-slip`, {
 method: 'POST',
 headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tenantToken}` },
 body: JSON.stringify({ slipImage: slipImageBase64 })
 });

 const data = await res.json();
 if (!res.ok) {
 const errMsg = typeof data.error === 'string' ? data.error : (data.error?.message || data.message || 'ไม่สามารถอัปโหลดข้อมูลรูปภาพได้');
 throw new Error(errMsg);
 }

 setIsPaidSuccess(true);
 setSlipImageBase64(null);
 setTimeout(() => {
 setIsPaidSuccess(false);
 setSelectedBill(null);
 handleVerify(); // Reload latest statuses
 }, 3000);

 } catch (err: any) {
 setUploadError(err.message || 'เกิดข้อผิดพลาดในการอัปโหลดสลิปโอนเงิน');
 } finally {
 setUploadingSlip(false);
 }
 };

 const avatars = [
 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=faces',
 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=faces',
 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=faces',
 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=faces',
 ];

 return (
 <div className="min-h-screen bg-slate-900 text-slate-100 font-sans flex flex-col justify-between selection:bg-green-600 selection:text-white">
 
 {/* Header */}
 <header className="border-b border-slate-800 bg-slate-950/80 backdrop-blur-md py-4 px-4 sticky top-0 z-20">
 <div className="max-w-md mx-auto flex items-center justify-between">
 <div className="flex items-center gap-2">
 <div className="p-1.5 rounded-lg bg-green-600 text-[#1A1A1A] shadow-green-900/20">
 <MessageSquare className="w-4 h-4" />
 </div>
 <div>
 <h1 className="font-extrabold text-xs tracking-wider text-slate-100 uppercase">
 {settings?.dormName || 'Greenville DORM'}
 </h1>
 <p className="text-[9px] text-green-400 font-bold uppercase tracking-widest">LINE Portal</p>
 </div>
 </div>
 {onBackToLogin && (
 <button 
 onClick={onBackToLogin}
 className="text-[10px] font-bold text-[#8A8A85] hover:text-white border border-slate-800 hover:border-slate-700 bg-slate-900 px-2.5 py-1.5 rounded-lg transition"
 >
 กลับสู่ระบบโฮสต์
 </button>
 )}
 </div>
 </header>

 {/* Main Container */}
 <main className="flex-1 max-w-md w-full mx-auto p-4 space-y-6">
 <AnimatePresence mode="wait">
 {!isVerified ? (
 /* PHASE 1: VERIFICATION FORM */
 <motion.div
 key="verify"
 initial={{ opacity: 0, y: 15 }}
 animate={{ opacity: 1, y: 0 }}
 exit={{ opacity: 0, y: -15 }}
 className="space-y-6 pt-4"
 >
 <div className="text-center space-y-2">
 <div className="inline-flex p-3 bg-green-500/10 text-green-400 rounded-full mb-1">
 <Smartphone className="w-8 h-8 animate-pulse" />
 </div>
 <h2 className="text-lg font-black tracking-tight text-[#1A1A1A]">ลงทะเบียนระบบแจ้งเตือน LINE</h2>
 <p className="text-xs text-[#8A8A85] leading-relaxed max-w-xs mx-auto">
 ตรวจสอบสิทธิ์ความเป็นผู้เช่าเพื่อทำการเชื่อมต่อ LINE รับใบแจ้งหนี้ และเช็คยอดค้างชำระอัตโนมัติ
 </p>
 </div>

 <form onSubmit={handleVerify} className="bg-slate-950 border border-[#E0E0DB] p-5 rounded-2xl shadow-xl space-y-4">
 <div>
 <label className="block text-[#8A8A85] font-bold mb-1.5 text-xs">หมายเลขห้องพัก (Room Number)</label>
 <input
 type="text"
 required
 placeholder="ตัวอย่าง: 101, A203"
 value={roomNumber}
 onChange={(e) => setRoomNumber(e.target.value)}
 className="w-full bg-slate-900 border border-slate-800 focus:border-green-500 rounded-xl p-3 text-slate-100 text-sm focus:outline-none transition font-semibold"
 />
 </div>

 <div>
 <label className="block text-[#8A8A85] font-bold mb-1.5 text-xs">เบอร์โทรศัพท์มือถือ (Phone Number)</label>
 <input
 type="tel"
 required
 placeholder="เบอร์โทรศัพท์ที่แจ้งทางหอพักไว้"
 value={tenantPhone}
 onChange={(e) => setTenantPhone(e.target.value)}
 className="w-full bg-slate-900 border border-slate-800 focus:border-green-500 rounded-xl p-3 text-slate-100 text-sm focus:outline-none transition font-semibold"
 />
 </div>

 {error && (
 <div className="p-3.5 rounded-xl bg-red-500/10 border border-red-900/30 text-red-400 text-xs flex items-start gap-2">
 <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
 <span>{error}</span>
 </div>
 )}

 <button
 type="submit"
 disabled={loading}
 className="w-full py-3 px-4 bg-green-600 hover:bg-green-500 text-[#1A1A1A] rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-green-900/20 disabled:bg-slate-800 disabled:text-slate-500"
 >
 {loading ? 'กำลังตรวจสอบ...' : 'ตรวจสอบและเข้าสู่ระบบ'}
 <ArrowRight className="w-4 h-4" />
 </button>
 </form>

 {/* Guide card */}
 <div className="bg-slate-950/40 border border-[#E0E0DB] p-4 rounded-xl text-[#8A8A85] space-y-2 text-xxs">
 <p className="font-bold text-[#8A8A85]">💡 วิธีการเชื่อมต่อ LINE Notify / Bot</p>
 <ol className="list-decimal list-inside space-y-1">
 <li>กรอกเลขห้องพัก และเบอร์โทรศัพท์ที่ตรงกับระบบของหอพัก</li>
 <li>กด "เชื่อมต่อ LINE" เพื่อจำลองหรือรับสิทธิ์ LINE ID</li>
 <li>พิมพ์ <span className="text-green-400 font-semibold">"บิล"</span> ในห้องแชท LINE เพื่อตรวจสอบค่าเช่าได้ทันทีตลอด 24 ชม.</li>
 </ol>
 </div>
 </motion.div>
 ) : (
 /* PHASE 2: TENANT CONSOLE & BILL LIST */
 <motion.div
 key="portal"
 initial={{ opacity: 0, scale: 0.98 }}
 animate={{ opacity: 1, scale: 1 }}
 exit={{ opacity: 0, scale: 0.98 }}
 className="space-y-6"
 >
 {/* Tenant Welcome Card */}
 <div className="bg-slate-950 border border-[#E0E0DB] rounded-2xl p-5 shadow-xl space-y-4">
 <div className="flex items-center justify-between">
 <div>
 <p className="text-[10px] text-[#8A8A85] font-bold uppercase tracking-wide">ห้องพักของคุณ</p>
 <h2 className="text-xl font-black text-[#1A1A1A]">ห้อง {roomData.roomNumber}</h2>
 <p className="text-xs text-[#8A8A85] font-semibold">{roomData.tenantName || 'ไม่ระบุชื่อ'}</p>
 </div>
 
 {roomData.lineStatus === 'linked' ? (
 <div className="flex items-center gap-2 bg-green-500/10 border border-green-900/30 px-3 py-1.5 rounded-full">
 <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
 <span className="text-[10px] font-bold text-green-400">เชื่อมโยง LINE แล้ว</span>
 </div>
 ) : (
 <div className="flex items-center gap-2 bg-amber-500/10 border border-amber-900/30 px-3 py-1.5 rounded-full">
 <div className="w-2 h-2 rounded-full bg-amber-400" />
 <span className="text-[10px] font-bold text-amber-400">ยังไม่เชื่อมโยง LINE</span>
 </div>
 )}
 </div>

 {/* LINE Info panel */}
 <div className="pt-4 border-t border-[#E0E0DB]">
 {roomData.lineStatus === 'linked' ? (
 <div className="flex items-center justify-between bg-slate-900 p-3 rounded-xl border border-slate-800">
 <div className="flex items-center gap-3">
 <img 
 src={roomData.linePictureUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=faces'} 
 alt="LINE Profile" 
 className="w-10 h-10 rounded-full border border-slate-700 object-cover"
 />
 <div>
 <p className="text-[10px] text-[#8A8A85] font-bold uppercase">บัญชี LINE ที่เชื่อมต่อ</p>
 <p className="text-xs font-black text-slate-200">{roomData.lineDisplayName}</p>
 </div>
 </div>
 <button
 onClick={handleUnlink}
 className="text-[10px] font-bold text-red-400 hover:text-red-300 px-2.5 py-1.5 rounded-lg hover:bg-red-500/5 transition cursor-pointer"
 >
 ยกเลิกเชื่อมโยง
 </button>
 </div>
 ) : (
 <div className="text-center py-2 space-y-3">
 <p className="text-xxs text-[#8A8A85]">
 คุณยังไม่ได้เชื่อมต่อ LINE บิลจะไม่แจ้งเตือนอัจฉริยะเข้าห้องแชทส่วนตัวของคุณ
 </p>
 <button
 onClick={triggerLineLink}
 className="w-full py-2.5 px-4 bg-green-600 hover:bg-green-500 text-[#1A1A1A] rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer shadow-green-950/20"
 >
 <MessageSquare className="w-4 h-4 fill-white text-green-600" />
 <span>เชื่อมต่อ LINE ของคุณเพื่อรับการแจ้งหนี้</span>
 </button>
 </div>
 )}
 </div>
 </div>

 {/* UNPAID BILLS SECTION */}
 <div className="space-y-3">
 <h3 className="text-xs font-black text-[#8A8A85] uppercase tracking-widest flex items-center gap-2">
 <FileText className="w-4 h-4 text-amber-400" />
 <span>ยอดค้างชำระ (Unpaid Bills)</span>
 </h3>

 {unpaidBills.length === 0 ? (
 <div className="bg-slate-950/40 border border-[#E0E0DB] p-6 rounded-2xl text-center space-y-2">
 <div className="inline-flex p-2 bg-green-500/10 text-green-400 rounded-full">
 <CheckCircle2 className="w-6 h-6" />
 </div>
 <p className="text-xs font-bold text-slate-200">ยอดค้างชำระเป็นศูนย์ 🎉</p>
 <p className="text-xxs text-[#8A8A85]">คุณไม่มีค้างชำระค่าห้องหรืองวดบริการใดๆ ค่ะ</p>
 </div>
 ) : (
 <div className="space-y-3">
 {unpaidBills.map((bill) => (
 <div 
 key={bill.id}
 className="bg-slate-950 border border-[#E0E0DB] hover:border-slate-800 rounded-2xl p-4 transition flex flex-col justify-between gap-4"
 >
 <div className="flex items-start justify-between">
 <div>
 <span className="text-[9px] bg-amber-500/10 text-amber-400 font-black tracking-widest px-2 py-0.5 rounded-full uppercase">ค้างชำระ</span>
 <h4 className="text-sm font-black text-[#1A1A1A] mt-1.5">รอบบิลเดือน {bill.billMonth}</h4>
 <p className="text-xxs text-[#8A8A85] font-semibold mt-1">กำหนดชำระ: {bill.dueDate}</p>
 </div>
 <div className="text-right">
 <p className="text-xxs text-[#8A8A85] font-semibold">ยอดสุทธิ</p>
 <p className="text-lg font-black text-amber-400 mt-0.5">{bill.totalCost.toLocaleString()} ฿</p>
 </div>
 </div>

 {/* Breakdown toggle link */}
 <div className="pt-3 border-t border-[#E0E0DB] grid grid-cols-2 gap-3 text-xxs">
 <button
 onClick={() => setSelectedBill(bill)}
 className="py-2.5 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-800 text-[#8A8A85] font-bold transition flex items-center justify-center gap-1.5 cursor-pointer"
 >
 <QrCode className="w-3.5 h-3.5 text-[#8A8A85]" />
 <span>สแกนคิวอาร์โค้ดจ่าย</span>
 </button>
 
 <div className="flex items-center justify-center text-[#8A8A85] font-bold">
 หรือโอนเข้า PromptPay หอพัก
 </div>
 </div>
 </div>
 ))}
 </div>
 )}
 </div>

 {/* PAYMENT HISTORY */}
 <div className="space-y-3">
 <h3 className="text-xs font-black text-[#8A8A85] uppercase tracking-widest flex items-center gap-2">
 <CheckCircle2 className="w-4 h-4 text-green-400" />
 <span>ประวัติชำระเงินล่าสุด (Paid History)</span>
 </h3>

 {paidBills.length === 0 ? (
 <p className="text-xxs text-[#8A8A85] italic">ไม่พบประวัติการชำระเงินย้อนหลัง</p>
 ) : (
 <div className="bg-slate-950 border border-[#E0E0DB] rounded-2xl divide-y divide-slate-900 overflow-hidden shadow-lg">
 {paidBills.map((bill) => (
 <div key={bill.id} className="p-3.5 flex items-center justify-between text-xxs">
 <div className="space-y-0.5">
 <p className="font-bold text-[#1A1A1A]">ประจำเดือน {bill.billMonth}</p>
 <p className="text-[#8A8A85]">ชำระเมื่อ: {bill.paidAt ? bill.paidAt.substring(0, 10) : '-'}</p>
 </div>
 <div className="text-right space-y-0.5">
 <p className="font-bold text-green-400">+{bill.totalCost.toLocaleString()} บาท</p>
 <span className="inline-flex px-1.5 py-0.5 bg-green-500/10 text-green-400 rounded-md font-black text-[8px] uppercase">สำเร็จ</span>
 </div>
 </div>
 ))}
 </div>
 )}
 </div>

 <div className="text-center">
 <button
 onClick={() => setIsVerified(false)}
 className="text-xxs text-[#8A8A85] hover:text-slate-400 font-bold underline transition"
 >
 สลับห้องพัก / ออกจากระบบผู้เช่า
 </button>
 </div>
 </motion.div>
 )}
 </AnimatePresence>
 </main>

 {/* LINE LOGIN FLOW SIMULATOR MODAL */}
 <AnimatePresence>
 {showLineLoginModal && (
 <div className="fixed inset-0 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 z-50">
 <motion.div 
 initial={{ opacity: 0, scale: 0.95, y: 10 }}
 animate={{ opacity: 1, scale: 1, y: 0 }}
 exit={{ opacity: 0, scale: 0.95, y: 10 }}
 className="bg-[#06C755] rounded-3xl max-w-sm w-full overflow-hidden shadow-2xl flex flex-col h-[520px]"
 >
 {/* Green Native Header */}
 <div className="p-5 text-center text-[#1A1A1A] space-y-3 relative flex-shrink-0">
 <button 
 onClick={() => setShowLineLoginModal(false)}
 className="absolute left-4 top-4 text-green-100 hover:text-white font-bold text-xs"
 >
 Cancel
 </button>
 <div className="w-12 h-12 bg-white rounded-2xl mx-auto flex items-center justify-center ">
 <span className="text-[#06C755] font-black text-xl tracking-tight">LINE</span>
 </div>
 <h3 className="font-extrabold text-sm tracking-wide">LINE LOGIN SIMULATOR</h3>
 <p className="text-[10px] text-green-100 leading-relaxed">
 เชื่อมโยงสิทธิ์ LINE ID ของคุณกับระบบหอพัก Greenville
 </p>
 </div>

 {/* White Form Panel */}
 <div className="flex-1 bg-white rounded-t-3xl p-5 text-[#1A1A1A] flex flex-col justify-between overflow-y-auto">
 <div className="space-y-4">
 <div className="p-3 bg-[#F0F0EB] border border-[#E0E0DB] rounded-xl space-y-1">
 <p className="text-[10px] text-[#8A8A85] font-bold uppercase">คำขอเข้าถึงสิทธิ์ (Permissions)</p>
 <p className="text-xs font-bold text-[#6B6B66]">✓ โปรไฟล์ LINE ของคุณ (ชื่อ และรูปภาพ)</p>
 <p className="text-xs font-bold text-[#6B6B66]">✓ รหัสประจำตัว (LINE User ID)</p>
 </div>

 <div>
 <label className="block text-[#8A8A85] font-bold mb-1.5 text-[10px] uppercase">ระบุชื่อ LINE ของคุณ</label>
 <input
 type="text"
 value={simLineName}
 onChange={(e) => setSimLineName(e.target.value)}
 placeholder="ใส่ชื่อแสดงผลบนไลน์"
 className="w-full bg-[#F0F0EB] border border-[#E0E0DB] focus:border-[#06C755] rounded-xl p-2.5 text-[#1A1A1A] text-xs focus:outline-none transition font-semibold"
 />
 </div>

 <div>
 <label className="block text-[#8A8A85] font-bold mb-1.5 text-[10px] uppercase">เลือกรูปโปรไฟล์จำลอง</label>
 <div className="flex items-center gap-2">
 {avatars.map((av, index) => (
 <button
 key={index}
 type="button"
 onClick={() => setSimLineAvatar(av)}
 className={`w-12 h-12 rounded-full overflow-hidden border-2 transition ${
 simLineAvatar === av ? 'border-[#06C755] scale-105' : 'border-transparent opacity-60'
 }`}
 >
 <img src={av} alt="Avatar option" className="w-full h-full object-cover" />
 </button>
 ))}
 </div>
 </div>

 <div className="bg-[#F0F0EB] rounded-xl p-3 text-[9px] text-[#8A8A85] leading-normal space-y-1">
 <p className="font-bold text-[#8A8A85]">🔐 ความปลอดภัยข้อมูลส่วนตัว</p>
 <p>ระบบ Greenville ขอเข้าถึงสิทธิ์นี้เพื่อใช้ในการส่ง Push Notification บิลรายเดือนเท่านั้น และจะไม่มีการนำข้อมูล LINE ไปเผยแพร่หรือใช้งานด้านอื่นๆ</p>
 </div>
 </div>

 <div className="pt-4 grid grid-cols-2 gap-3 text-xs">
 <button
 onClick={() => setShowLineLoginModal(false)}
 className="py-2.5 rounded-xl bg-[#F0F0EB] hover:bg-slate-200 text-[#6B6B66] font-bold text-center transition"
 >
 ปฏิเสธ (Decline)
 </button>
 <button
 onClick={handleCompleteLineLink}
 disabled={!simLineName.trim()}
 className="py-2.5 rounded-xl bg-[#06C755] hover:bg-[#05b34c] text-[#1A1A1A] font-bold text-center transition shadow-green-200/50 disabled:bg-slate-200 disabled:text-slate-400"
 >
 ตกลง (Agree)
 </button>
 </div>
 </div>
 </motion.div>
 </div>
 )}
 </AnimatePresence>

 {/* BILL PAYMENT DETAILED OVERLAY MODAL */}
 <AnimatePresence>
 {selectedBill && (
 <div className="fixed inset-0 bg-black/85 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
 <motion.div
 initial={{ opacity: 0, scale: 0.95 }}
 animate={{ opacity: 1, scale: 1 }}
 exit={{ opacity: 0, scale: 0.95 }}
 className="bg-slate-900 border border-slate-800 rounded-3xl max-w-sm w-full p-5 shadow-2xl relative space-y-4 my-8"
 >
 {isPaidSuccess ? (
 <div className="text-center py-10 space-y-4">
 <div className="inline-flex p-4 bg-green-500/10 text-green-400 rounded-full animate-bounce">
 <Check className="w-10 h-10" />
 </div>
 <h3 className="text-lg font-black text-[#1A1A1A]">ส่งสลิปสำเร็จ!</h3>
 <p className="text-xs text-[#8A8A85] leading-relaxed">
 อัปโหลดสลิปเรียบร้อยแล้วค่ะ ระบบได้ทำการแจ้งเตือนผู้ดูแลหอพักให้รับทราบแล้ว กรุณารอการตรวจสอบยอดเงินนะคะ
 </p>
 </div>
 ) : (
 <div className="space-y-4">
 <div className="text-center space-y-1">
 <h3 className="text-base font-black text-[#1A1A1A]">ใบแจ้งยอดชำระเงิน</h3>
 <p className="text-xxs text-[#8A8A85]">รอบบิลเดือน {selectedBill.billMonth} | ห้อง {roomData.roomNumber}</p>
 </div>

 {/* Breakdown table */}
 <div className="bg-slate-950 p-4 rounded-2xl border border-[#E0E0DB] text-xxs space-y-2 text-[#8A8A85]">
 <div className="flex justify-between items-center text-[#8A8A85] font-bold pb-2 border-b border-slate-900">
 <span>รายการค่าเช่า</span>
 <span>จำนวนเงิน</span>
 </div>
 <div className="flex justify-between">
 <span>ค่าเช่าห้อง</span>
 <span>{selectedBill.rentCost.toLocaleString()} บาท</span>
 </div>
 <div className="flex justify-between">
 <span>ค่าไฟฟ้า ({selectedBill.priorElec} ถึง {selectedBill.currentElec} หน่วย)</span>
 <span>{(selectedBill.elecCost ?? Math.round(Math.max(0, selectedBill.currentElec - selectedBill.priorElec - (selectedBill.elecDeduct ?? 0)) * selectedBill.elecUnitCost)).toLocaleString()} บาท</span>
 </div>
 <div className="flex justify-between">
 <span>ค่าน้ำ ({selectedBill.priorWater} ถึง {selectedBill.currentWater} หน่วย)</span>
 <span>{(selectedBill.waterCost !== undefined ? selectedBill.waterCost : (selectedBill.currentWater - selectedBill.priorWater > 0 ? Math.round((selectedBill.currentWater - selectedBill.priorWater) * selectedBill.waterUnitCost) : 0)).toLocaleString()} บาท</span>
 </div>
 {selectedBill.depositCost > 0 && (
 <div className="flex justify-between">
 <span>ค่าประกันเพิ่มเติม</span>
 <span>{selectedBill.depositCost.toLocaleString()} บาท</span>
 </div>
 )}
 {(selectedBill.chargeItems?.length ? selectedBill.chargeItems : (selectedBill.otherCost > 0 ? [{ label: selectedBill.otherDescription || 'ค่าใช้อื่นๆ', amount: selectedBill.otherCost }] : [])).map((item, index) => (
 <div key={`${item.label}-${index}`} className="flex justify-between">
 <span>{item.label}</span>
 <span>{Number(item.amount).toLocaleString()} บาท</span>
 </div>
 ))}
 <div className="flex justify-between font-black text-amber-400 pt-2 border-t border-slate-900 text-xs">
 <span>ยอดสุทธิรวมทั้งสิ้น</span>
 <span>{selectedBill.totalCost.toLocaleString()} บาท</span>
 </div>
 </div>

 {selectedBill.slipStatus === 'pending' ? (
 /* PENDING VERIFICATION STATE */
 <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-2xl text-center space-y-3">
 <div className="w-8 h-8 rounded-full bg-amber-500/10 text-amber-400 flex items-center justify-center mx-auto animate-pulse">
 <Lock className="w-4 h-4" />
 </div>
 <p className="text-xs font-bold text-amber-400">รอยืนยันสลิปโอนเงิน</p>
 <p className="text-[10px] text-[#8A8A85] leading-relaxed">
 คุณได้ส่งสลิปโอนเงินเรียบร้อยแล้วเมื่อ {selectedBill.slipUploadedAt ? new Date(selectedBill.slipUploadedAt).toLocaleDateString('th-TH') : 'ก่อนหน้านี้'} ขณะนี้ระบบผู้ดูแลอยู่ระหว่างตรวจทานยอดเงินค่ะ
 </p>
 {selectedBill.slipImage && (
 <div className="aspect-[3/4] max-w-[120px] mx-auto rounded-lg overflow-hidden border border-slate-800 bg-slate-950">
 <img src={selectedBill.slipImage} alt="Uploaded receipt" className="w-full h-full object-contain" />
 </div>
 )}
 <button
 type="button"
 onClick={() => setSelectedBill(null)}
 className="w-full py-2 bg-slate-950 hover:bg-slate-850 rounded-xl text-[#8A8A85] text-xxs font-bold transition border border-[#E0E0DB] cursor-pointer"
 >
 กลับสู่หน้าหลัก
 </button>
 </div>
 ) : (
 /* ACTIVE UPLOAD / PAYMENT FORM */
 <div className="space-y-4">
 {selectedBill.slipStatus === 'rejected' && (
 <div className="p-3 bg-red-500/10 border border-red-900/30 rounded-xl text-[10px] text-red-400 leading-relaxed font-semibold">
 ⚠️ สลิปก่อนหน้าไม่ผ่านการอนุมัติ: ข้อมูลไม่ตรงตามยอดโอนจริง กรุณาอัปโหลดสลิปใบใหม่อีกครั้งค่ะ
 </div>
 )}

 {/* PromptPay QR Code Display */}
 {settings?.promptpayId ? (
 <div className="bg-white p-4 rounded-2xl flex flex-col items-center justify-center space-y-3 border border-[#E0E0DB]">
 <div className="flex items-center gap-1.5 bg-[#003865] px-3 py-1 rounded-md text-[#1A1A1A] text-[9px] font-bold">
 <QrCode className="w-3 h-3 text-[#1A1A1A]" />
 <span>PromptPay QR</span>
 </div>
 <PromptPayQR 
 target={settings.promptpayId} 
 amount={selectedBill.totalCost} 
 className="w-36 h-36 object-contain"
 alt="PromptPay QR Code"
 />
 <p className="text-[9px] text-[#8A8A85] font-bold text-center">
 ชื่อบัญชี: {settings.promptpayName || 'ไม่ระบุชื่อ'}<br />
 PromptPay ID: {settings.promptpayId}
 </p>
 </div>
 ) : (
 <div className="p-3 bg-slate-950 border border-[#E0E0DB] rounded-xl text-center">
 <p className="text-xxs text-amber-400 font-bold">⚠️ ยังไม่มีช่องทางรับเงิน PromptPay</p>
 <p className="text-[9px] text-[#8A8A85] leading-normal mt-1">
 โปรดติดต่อโอนตรงเข้าบัญชีหอพัก หรือทักท้วงผู้ดูแลโดยตรงเพื่อความสะดวกในการรับยอดเงิน
 </p>
 </div>
 )}

 {/* Slip Selector / File Drop */}
 <div className="space-y-2">
 <label className="block text-[#8A8A85] font-extrabold text-[10px] uppercase tracking-wide">อัปโหลดสลิปโอนเงิน (Slip Receipt) *</label>
 
 {slipImageBase64 ? (
 <div className="relative rounded-xl overflow-hidden border border-green-500/40 bg-slate-950 p-2 flex items-center justify-between">
 <div className="flex items-center gap-2">
 <div className="w-10 h-14 rounded-md overflow-hidden bg-slate-900 flex-shrink-0 border border-[#E0E0DB]">
 <img src={slipImageBase64} alt="Preview" className="w-full h-full object-contain" />
 </div>
 <div>
 <p className="text-[10px] font-bold text-green-400 flex items-center gap-1">
 <Check className="w-3.5 h-3.5 text-green-400" />
 <span>เลือกรูปภาพแล้ว</span>
 </p>
 <p className="text-[8px] text-[#8A8A85]">ขนาดสลิปโอนเงินพร้อมส่ง</p>
 </div>
 </div>
 <button
 type="button"
 onClick={() => setSlipImageBase64(null)}
 className="text-[10px] text-red-400 hover:text-red-300 font-bold underline px-2 cursor-pointer"
 >
 ล้างรูป
 </button>
 </div>
 ) : (
 <div className="relative border-2 border-dashed border-slate-800 hover:border-slate-700 bg-slate-950/60 rounded-xl p-4 text-center hover:bg-slate-950 transition">
 <input
 type="file"
 accept="image/*"
 onChange={handleFileChange}
 className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
 />
 <p className="text-[10px] font-bold text-[#8A8A85]">📸 กดเพื่อถ่ายรูป หรือเลือกไฟล์สลิป</p>
 <p className="text-[9px] text-[#6B6B66] mt-1">รองรับไฟล์สลิปโอนเงินทุกรูปแบบ (JPG, PNG)</p>
 </div>
 )}
 </div>

 {uploadError && (
 <p className="text-red-400 text-[10px] font-semibold">{uploadError}</p>
 )}

 {/* Action buttons */}
 <div className="grid grid-cols-2 gap-3 text-xs pt-1.5">
 <button
 type="button"
 onClick={() => {
 setSelectedBill(null);
 setSlipImageBase64(null);
 setUploadError(null);
 }}
 className="py-2.5 rounded-xl bg-slate-950 hover:bg-slate-850 text-[#8A8A85] font-bold text-center border border-[#E0E0DB] transition cursor-pointer"
 >
 ปิดหน้าต่าง
 </button>
 <button
 type="button"
 disabled={uploadingSlip || !slipImageBase64}
 onClick={handleUploadSlipSubmit}
 className="py-2.5 rounded-xl bg-green-600 hover:bg-green-500 disabled:bg-slate-800 disabled:text-slate-500 text-[#1A1A1A] font-bold text-center transition cursor-pointer shadow-lg shadow-green-950/20"
 >
 {uploadingSlip ? 'กำลังส่งข้อมูล...' : 'อัปโหลดส่งสลิป'}
 </button>
 </div>
 </div>
 )}
 </div>
 )}
 </motion.div>
 </div>
 )}
 </AnimatePresence>

 {/* Footer */}
 <footer className="border-t border-[#E0E0DB] bg-slate-950/40 py-4 text-center text-[10px] text-[#8A8A85] font-semibold">
 <p>© 2026 {settings?.dormName || 'หอพักของฉัน'} | ระบบบิลอัจฉริยะแจ้งยอดผ่าน LINE | {APP_VERSION_LABEL}</p>
 </footer>

 </div>
 );
}
