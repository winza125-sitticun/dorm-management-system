import React, { useState } from 'react';
import { RefreshCw } from 'lucide-react';
import { DashboardData, Bill, Room, HousekeepingTask, LeaseContract, MaintenanceTicket } from '../types.ts';
import { DashboardHeader } from './Dashboard/DashboardHeader.tsx';
import { DashboardCards } from './Dashboard/DashboardCards.tsx';
import { DashboardChart } from './Dashboard/DashboardChart.tsx';
import { DashboardTable } from './Dashboard/DashboardTable.tsx';
import { DashboardSummary } from './Dashboard/DashboardSummary.tsx';
import { DashboardActionCenter } from './Dashboard/DashboardActionCenter.tsx';

interface DashboardViewProps {
  data: DashboardData | null;
  loading: boolean;
  onRefresh: () => void;
  onNavigateToBills: () => void;
  onViewBillById: (billId: number) => void;
  rooms: Room[];
  bills: Bill[];
  contracts: LeaseContract[];
  maintenanceTickets: MaintenanceTicket[];
  housekeepingTasks: HousekeepingTask[];
  onNavigate: (tab: 'history' | 'maintenance' | 'housekeeping' | 'contracts') => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  data,
  loading,
  onRefresh,
  onNavigateToBills,
  onViewBillById,
  rooms = [],
  bills = [],
  contracts = [],
  maintenanceTickets = [],
  housekeepingTasks = [],
  onNavigate,
}) => {
  const [activeDetailModal, setActiveDetailModal] = useState<'total_rooms' | 'occupied_rooms' | 'vacant_rooms' | 'collection_rate' | null>(null);

  const formatThaiMonthOnly = (monthStr: string) => {
    const [year, month] = monthStr.split('-');
    const monthsShort = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
    const thYear = (parseInt(year) + 543).toString().substring(2);
    return `${monthsShort[parseInt(month) - 1]} ${thYear}`;
  };

  const chartData = data?.revenueHistory?.map(h => ({
    name: formatThaiMonthOnly(h.month),
    'ชำระแล้ว': h.paid,
    'ค้างชำระ': h.unpaid,
    'ยอดรวม': h.total
  })) || [];

  if (loading && !data) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-[#8A8A85]">
        <RefreshCw className="w-8 h-8 animate-spin text-[#1DB954] mb-3" />
        <p className="text-sm font-semibold">กำลังโหลดข้อมูลแดชบอร์ด...</p>
      </div>
    );
  }

  const roomsStats = data?.rooms || { total: 0, occupied: 0, vacant: 0 };
  const revStats = data?.revenueThisMonth || { total: 0, paid: 0, unpaid: 0 };
  const unpaidRooms = data?.unpaidRooms || [];

  return (
    <div className="space-y-6 font-sans">
      {/* 1. Header */}
      <DashboardHeader loading={loading} onRefresh={onRefresh} />

      {/* 2. Metrics Cards */}
      <DashboardCards roomsStats={roomsStats} revStats={revStats} onCardClick={(type) => setActiveDetailModal(type)} />

      {/* 3. Operational action queue. */}
      <DashboardActionCenter
        bills={bills}
        contracts={contracts}
        maintenanceTickets={maintenanceTickets}
        housekeepingTasks={housekeepingTasks}
        onNavigate={onNavigate}
      />

      {/* 4. Recharts Revenue Trend */}
      <DashboardChart chartData={chartData} />

      {/* 5. Unpaid Rooms Table */}
      <DashboardTable unpaidRooms={unpaidRooms} onNavigateToBills={onNavigateToBills} onViewBillById={onViewBillById} />

      {/* 6. Summary Modal Drawer */}
      <DashboardSummary
        activeDetailModal={activeDetailModal}
        onClose={() => setActiveDetailModal(null)}
        rooms={rooms}
        revStats={revStats}
      />
    </div>
  );
};
