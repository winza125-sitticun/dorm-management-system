import React, { useEffect, useMemo, useState } from 'react';
import {
  Activity,
  ChevronDown,
  ChevronUp,
  Clock3,
  FileClock,
  Filter,
  Loader2,
  RefreshCw,
  Search,
  ShieldCheck,
  UserRound,
} from 'lucide-react';
import { AuditLog } from '../types.ts';
import { getApiErrorMessage } from '../utils/api.ts';

interface AuditLogViewProps {
  idToken: string | null;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

const ACTION_LABELS: Record<string, string> = {
  CREATE_NOTE: 'สร้างโน้ต',
  UPDATE_NOTE: 'แก้ไขโน้ต',
  DELETE_NOTE: 'ลบโน้ต',
  CREATE_ROOM: 'เพิ่มห้องพัก',
  EDIT_ROOM: 'แก้ไขห้องพัก',
  UPDATE_ROOM: 'แก้ไขห้องพัก',
  SOFT_DELETE_ROOM: 'ลบห้องพัก',
  DELETE_ROOM: 'ลบห้องพัก',
  CREATE_BILL: 'สร้างบิล',
  UPDATE_BILL: 'แก้ไขบิล',
  DELETE_BILL: 'ลบบิล',
  SOFT_DELETE_BILL: 'ลบบิล',
  UPDATE_SETTINGS: 'แก้ไขการตั้งค่า',
  CREATE_CONTRACT: 'สร้างสัญญา',
  UPDATE_CONTRACT: 'แก้ไขสัญญา',
  CHECKOUT_CONTRACT: 'ย้ายออก/คืนเงินประกัน',
  CREATE_MAINTENANCE: 'สร้างงานแจ้งซ่อม',
  UPDATE_MAINTENANCE: 'อัปเดตงานแจ้งซ่อม',
  VERIFY_SLIP: 'ยืนยันสลิป',
  REJECT_SLIP: 'ปฏิเสธสลิป',
  INITIAL_SETUP: 'ตั้งค่าระบบครั้งแรก',
  LOGIN: 'เข้าสู่ระบบ',
  CHANGE_PASSWORD: 'เปลี่ยนรหัสผ่าน',
  CREATE_CARETAKER: 'เพิ่มผู้ดูแลร่วม',
};

const TARGET_LABELS: Record<string, string> = {
  note: 'โน้ต',
  room: 'ห้องพัก',
  bill: 'บิล',
  setting: 'การตั้งค่า',
  settings: 'การตั้งค่า',
  contract: 'สัญญาเช่า',
  maintenance: 'งานแจ้งซ่อม',
  user: 'ผู้ใช้งาน',
  announcement: 'ประกาศ',
  system: 'ระบบ',
};

const formatValue = (value: string | null) => {
  if (!value) return null;
  try {
    return JSON.stringify(JSON.parse(value), null, 2);
  } catch {
    return value;
  }
};

export const AuditLogView: React.FC<AuditLogViewProps> = ({ idToken, showToast }) => {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [actionFilter, setActionFilter] = useState('all');
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const loadLogs = async () => {
    if (!idToken) return;
    setLoading(true);
    try {
      const response = await fetch('/api/audit-logs', {
        headers: { Authorization: `Bearer ${idToken}` },
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(getApiErrorMessage(payload, 'ไม่สามารถโหลดประวัติกิจกรรมได้'));
      setLogs(Array.isArray(payload) ? payload : (Array.isArray(payload.data) ? payload.data : []));
    } catch (error) {
      showToast(error instanceof Error ? error.message : 'ไม่สามารถโหลดประวัติกิจกรรมได้', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadLogs();
  }, [idToken]);

  const actionOptions = useMemo(
    () => Array.from(new Set(logs.map((log) => log.action))).sort(),
    [logs]
  );

  const filteredLogs = useMemo(() => {
    const query = searchTerm.trim().toLocaleLowerCase('th');
    return logs.filter((log) => {
      const actionLabel = ACTION_LABELS[log.action] || log.action;
      const targetLabel = TARGET_LABELS[log.targetType] || log.targetType;
      const matchesAction = actionFilter === 'all' || log.action === actionFilter;
      const matchesSearch = !query || [
        log.userEmail,
        actionLabel,
        targetLabel,
        log.targetId || '',
      ].some((value) => value.toLocaleLowerCase('th').includes(query));
      return matchesAction && matchesSearch;
    });
  }, [actionFilter, logs, searchTerm]);

  const todayCount = logs.filter((log) => {
    const created = new Date(log.createdAt);
    const now = new Date();
    return created.getFullYear() === now.getFullYear()
      && created.getMonth() === now.getMonth()
      && created.getDate() === now.getDate();
  }).length;
  const uniqueUsers = new Set(logs.map((log) => log.userEmail)).size;

  return (
    <div className="space-y-5 font-sans">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="flex items-center gap-2 text-xl font-bold text-[#1A1A1A]">
            <FileClock className="h-5 w-5 text-[#1DB954]" />
            ประวัติกิจกรรม
          </h2>
          <p className="mt-1 text-xs text-[#8A8A85]">ตรวจสอบว่าใครทำรายการอะไร และเกิดขึ้นเมื่อไร</p>
        </div>
        <button
          type="button"
          onClick={() => void loadLogs()}
          disabled={loading}
          className="flex items-center justify-center gap-2 rounded-xl border border-[#E0E0DB] bg-white px-3 py-2 text-xs font-bold text-[#6B6B66] transition hover:bg-[#F0F0EB] disabled:opacity-50"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
          รีเฟรช
        </button>
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        {[
          { label: 'กิจกรรมล่าสุด', value: logs.length, icon: Activity, color: 'text-[#1DB954]', bg: 'bg-[#1DB954]/10' },
          { label: 'รายการวันนี้', value: todayCount, icon: Clock3, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: 'ผู้ใช้งานที่เกี่ยวข้อง', value: uniqueUsers, icon: UserRound, color: 'text-violet-600', bg: 'bg-violet-50' },
        ].map((item) => (
          <div key={item.label} className="flex items-center gap-3 rounded-2xl border border-[#E0E0DB] bg-white p-4 shadow-sm">
            <div className={`rounded-xl p-2.5 ${item.bg} ${item.color}`}><item.icon className="h-5 w-5" /></div>
            <div>
              <p className="text-[10px] font-bold uppercase tracking-wider text-[#8A8A85]">{item.label}</p>
              <p className="text-xl font-black text-[#1A1A1A]">{item.value.toLocaleString()}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid gap-3 rounded-2xl border border-[#E0E0DB] bg-white p-4 sm:grid-cols-[1fr_220px]">
        <label className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#8A8A85]" />
          <input
            value={searchTerm}
            onChange={(event) => setSearchTerm(event.target.value)}
            placeholder="ค้นหาผู้ใช้ กิจกรรม หรือหมายเลขรายการ"
            className="w-full rounded-xl border border-[#E0E0DB] bg-[#F8F8F5] py-2.5 pl-9 pr-3 text-xs outline-none transition focus:border-[#1DB954] focus:ring-2 focus:ring-[#1DB954]/10"
          />
        </label>
        <label className="relative">
          <Filter className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#8A8A85]" />
          <select
            value={actionFilter}
            onChange={(event) => setActionFilter(event.target.value)}
            className="w-full appearance-none rounded-xl border border-[#E0E0DB] bg-[#F8F8F5] py-2.5 pl-9 pr-8 text-xs font-semibold outline-none focus:border-[#1DB954]"
          >
            <option value="all">กิจกรรมทั้งหมด</option>
            {actionOptions.map((action) => <option key={action} value={action}>{ACTION_LABELS[action] || action}</option>)}
          </select>
        </label>
      </div>

      <div className="overflow-hidden rounded-2xl border border-[#E0E0DB] bg-white shadow-sm">
        {loading ? (
          <div className="flex items-center justify-center gap-2 py-16 text-sm text-[#8A8A85]">
            <Loader2 className="h-5 w-5 animate-spin text-[#1DB954]" /> กำลังโหลดประวัติ...
          </div>
        ) : filteredLogs.length === 0 ? (
          <div className="flex flex-col items-center py-16 text-center">
            <ShieldCheck className="mb-3 h-9 w-9 text-[#1DB954]" />
            <p className="text-sm font-bold text-[#1A1A1A]">ไม่พบประวัติกิจกรรม</p>
            <p className="mt-1 text-xs text-[#8A8A85]">ลองเปลี่ยนคำค้นหาหรือตัวกรอง</p>
          </div>
        ) : (
          <div className="divide-y divide-[#E0E0DB]">
            {filteredLogs.map((log) => {
              const isExpanded = expandedId === log.id;
              const oldValue = formatValue(log.oldValue);
              const newValue = formatValue(log.newValue);
              const hasDetails = Boolean(oldValue || newValue);
              return (
                <article key={log.id} className="transition hover:bg-[#FAFAF7]">
                  <button
                    type="button"
                    onClick={() => hasDetails && setExpandedId(isExpanded ? null : log.id)}
                    className={`grid w-full gap-3 p-4 text-left sm:grid-cols-[160px_1fr_190px_auto] sm:items-center ${hasDetails ? 'cursor-pointer' : 'cursor-default'}`}
                  >
                    <time className="text-[11px] font-semibold text-[#8A8A85]">
                      {new Date(log.createdAt).toLocaleString('th-TH', { dateStyle: 'medium', timeStyle: 'short' })}
                    </time>
                    <div className="min-w-0">
                      <p className="truncate text-xs font-black text-[#1A1A1A]">{ACTION_LABELS[log.action] || log.action}</p>
                      <p className="mt-0.5 text-[10px] text-[#8A8A85]">
                        {TARGET_LABELS[log.targetType] || log.targetType}{log.targetId ? ` #${log.targetId}` : ''}
                      </p>
                    </div>
                    <div className="min-w-0">
                      <p className="truncate text-[11px] font-bold text-[#6B6B66]">{log.userEmail}</p>
                      <p className="text-[9px] uppercase tracking-wide text-[#8A8A85]">{log.userRole}</p>
                    </div>
                    {hasDetails && (isExpanded ? <ChevronUp className="h-4 w-4 text-[#8A8A85]" /> : <ChevronDown className="h-4 w-4 text-[#8A8A85]" />)}
                  </button>
                  {isExpanded && hasDetails && (
                    <div className="grid gap-3 border-t border-[#E0E0DB] bg-[#F8F8F5] px-4 py-3 lg:grid-cols-2">
                      {oldValue && <div><p className="mb-1 text-[10px] font-bold text-[#8A8A85]">ข้อมูลก่อนแก้ไข</p><pre className="max-h-56 overflow-auto rounded-xl bg-white p-3 text-[10px] text-[#6B6B66]">{oldValue}</pre></div>}
                      {newValue && <div><p className="mb-1 text-[10px] font-bold text-[#8A8A85]">ข้อมูลหลังทำรายการ</p><pre className="max-h-56 overflow-auto rounded-xl bg-white p-3 text-[10px] text-[#6B6B66]">{newValue}</pre></div>}
                    </div>
                  )}
                </article>
              );
            })}
          </div>
        )}
      </div>
      <p className="text-center text-[10px] text-[#8A8A85]">แสดงรายการล่าสุดสูงสุด 100 รายการ • ข้อมูลนี้เปิดให้เจ้าของหรือผู้ดูแลระบบเท่านั้น</p>
    </div>
  );
};
