import { drizzle } from 'drizzle-orm/sqlite-proxy';
import pkg from 'pg';
const { Pool } = pkg;
import * as schema from './schema.ts';

// Function to create a new connection pool with robust timeouts and fallback credentials.
export const createPool = () => {
  const host = process.env.SQL_HOST;
  const user = process.env.SQL_USER || process.env.SQL_ADMIN_USER;
  const password = process.env.SQL_PASSWORD || process.env.SQL_ADMIN_PASSWORD;
  const database = process.env.SQL_DB_NAME;
  const port = process.env.SQL_PORT ? parseInt(process.env.SQL_PORT, 10) : 5432;

  const poolConfig: any = {
    host,
    port,
    user,
    password,
    database,
    connectionTimeoutMillis: 15000,
    idleTimeoutMillis: 10000,
    max: 15,
    keepAlive: true,
  };

  if (host && !host.startsWith('/') && process.env.SQL_SSL === 'true') {
    poolConfig.ssl = { rejectUnauthorized: false };
  }

  return new Pool(poolConfig);
};

// Create a pool instance.
const pool = createPool();

// Prevent unhandled pool-level errors from crashing the application
pool.on('error', (err) => {
  // Silent or debug log for idle client disconnection from Cloud SQL
  if (err.message && (err.message.includes('terminated') || err.message.includes('closed') || err.message.includes('ECONNRESET'))) {
    return;
  }
  console.error('Unexpected error on idle SQL pool client:', err);
});

// Monkey-patch pool.query for seamless transparent reconnection
const origQuery = pool.query.bind(pool);
(pool as any).query = async function (...args: any[]) {
  let attempts = 0;
  const maxAttempts = 3;
  while (attempts < maxAttempts) {
    try {
      return await origQuery(...args);
    } catch (err: any) {
      attempts++;
      const msg = err?.message || '';
      const causeMsg = err?.cause?.message || '';
      const code = err?.code;
      const isConnErr =
        msg.includes('Connection terminated') ||
        msg.includes('ECONNRESET') ||
        msg.includes('closed') ||
        msg.includes('EOF') ||
        msg.includes('socket hung up') ||
        causeMsg.includes('Connection terminated') ||
        causeMsg.includes('ECONNRESET') ||
        code === '57P01' ||
        code === '08006' ||
        code === '08003';

      if (isConnErr && attempts < maxAttempts) {
        await new Promise((res) => setTimeout(res, 150 * attempts));
        continue;
      }
      throw err;
    }
  }
};

// Initialize Drizzle with sqlite-proxy driver and schema.
export const db = drizzle(async (sql, params, method) => {
  let paramIndex = 1;
  const pgSql = sql.replace(/\?/g, () => `$${paramIndex++}`);
  const res = await pool.query(pgSql, params);
  return { rows: res.rows };
}, { schema });

// Helper function to retry transient database connection errors
export async function withRetry<T>(fn: () => Promise<T>, retries = 2, delayMs = 200): Promise<T> {
  let lastError: any;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      return await fn();
    } catch (err: any) {
      lastError = err;
      const msg = err?.message || '';
      const causeMsg = err?.cause?.message || '';
      const isConnErr = 
        msg.includes('Connection terminated') ||
        msg.includes('ECONNRESET') ||
        msg.includes('closed') ||
        msg.includes('EOF') ||
        causeMsg.includes('Connection terminated') ||
        causeMsg.includes('ECONNRESET') ||
        err?.code === '57P01';

      if (isConnErr && attempt < retries) {
        await new Promise((res) => setTimeout(res, delayMs * (attempt + 1)));
        continue;
      }
      throw err;
    }
  }
  throw lastError;
}
