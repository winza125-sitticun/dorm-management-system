import { db, withRetry } from './index.ts';
import { users, settings } from './schema.ts';
import { eq } from 'drizzle-orm';

export async function getOrCreateUser(uid: string, email: string) {
  return withRetry(async () => {
    // 1. Try to find an existing user by the local account UID.
    let existingUser = await db.select().from(users).where(eq(users.uid, uid));
    
    if (existingUser.length > 0) {
      // If found, update email if needed and return
      if (existingUser[0].email !== email) {
        const updated = await db.update(users)
          .set({ email })
          .where(eq(users.uid, uid))
          .returning();
        return updated[0];
      }
      return existingUser[0];
    }

    // 2. If not found by UID, check if there is an invited user with the same email
    let userByEmail = await db.select().from(users).where(eq(users.email, email));
    if (userByEmail.length > 0) {
      // If found, this is an invited caretaker/user. Associate its local UID.
      const updated = await db.update(users)
        .set({ uid })
        .where(eq(users.id, userByEmail[0].id))
        .returning();
      return updated[0];
    }

    // 3. Brand new user, create as owner
    const result = await db.insert(users)
      .values({
        uid,
        email,
        role: 'owner'
      })
      .returning();

    const user = result[0];

    // Create default settings for user if they do not exist
    try {
      await db.insert(settings)
        .values({
          userId: user.id,
          dormName: 'หอพักของฉัน',
          defaultElecRate: 7,
          defaultWaterRate: 13,
          defaultDueDateDay: 5,
        })
        .onConflictDoNothing();
    } catch (err) {
      console.error('Error creating default settings for user:', err);
    }

    return user;
  });
}
