import { defineConfig } from "drizzle-kit";
import * as dotenv from "dotenv";

// Load environment variables from .env file.
dotenv.config();

export default defineConfig({
  schema: "./src/db/schema.ts",
  out: "./drizzle", // Output directory for migrations.
  dialect: "sqlite",
  dbCredentials: {
    url: process.env.SQL_HOST || "./dorm-db.sqlite",
  },
  verbose: true, // Enable verbose output.
});
