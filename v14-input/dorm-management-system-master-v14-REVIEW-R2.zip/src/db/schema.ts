import { relations, sql } from 'drizzle-orm';
import { integer, real, sqliteTable, text, unique, uniqueIndex } from 'drizzle-orm/sqlite-core';

// Define 'users' table
export const users = sqliteTable('users', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  uid: text('uid').notNull().unique(), // Auth UID / Username
  email: text('email').notNull(),
  role: text('role').default('owner').notNull(), // 'super_admin', 'owner', 'manager', 'staff', 'tenant', 'caretaker'
  parentId: integer('parent_id'), // links to users.id
  createdAt: text('created_at').default(sql`(CURRENT_TIMESTAMP)`),
  password: text('password').default('').notNull(),
  permissions: text('permissions').default('manage_rooms,manage_bills,edit_payments').notNull(),
  deletedAt: text('deleted_at'),
  deletedBy: integer('deleted_by'),
});

// Define 'rooms' table
export const rooms = sqliteTable('rooms', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  userId: integer('user_id')
    .references(() => users.id, { onDelete: 'cascade' })
    .notNull(),
  roomNumber: text('room_number').notNull(),
  monthlyRent: integer('monthly_rent').default(0).notNull(),
  status: text('status').default('vacant').notNull(), // 'vacant' or 'occupied'
  tenantName: text('tenant_name'),
  tenantPhone: text('tenant_phone'),
  lineUserId: text('line_user_id'),
  lineDisplayName: text('line_display_name'),
  linePictureUrl: text('line_picture_url'),
  lineStatus: text('line_status').default('unlinked'),
  lineNotifyToken: text('line_notify_token'),
  createdAt: text('created_at').default(sql`(CURRENT_TIMESTAMP)`),
  deletedAt: text('deleted_at'),
  deletedBy: integer('deleted_by'),
});

// Define 'bills' table
export const bills = sqliteTable('bills', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  userId: integer('user_id')
    .references(() => users.id, { onDelete: 'cascade' })
    .notNull(),
  roomId: integer('room_id')
    .references(() => rooms.id, { onDelete: 'cascade' })
    .notNull(),
  billMonth: text('bill_month').notNull(), // format 'YYYY-MM'
  priorElec: real('prior_elec').default(0).notNull(),
  currentElec: real('current_elec').default(0).notNull(),
  elecDeduct: real('elec_deduct').default(0).notNull(),
  elecUnitCost: real('elec_unit_cost').default(7).notNull(),
  elecCost: real('elec_cost').default(0).notNull(),
  priorWater: real('prior_water').default(0).notNull(),
  currentWater: real('current_water').default(0).notNull(),
  waterUnitCost: real('water_unit_cost').default(13).notNull(),
  waterCost: real('water_cost').default(0).notNull(),
  rentCost: integer('rent_cost').default(0).notNull(),
  depositCost: integer('deposit_cost').default(0).notNull(),
  otherCost: integer('other_cost').default(0).notNull(),
  otherDescription: text('other_description'),
  totalCost: integer('total_cost').default(0).notNull(),
  dueDate: text('due_date').notNull(), // format 'YYYY-MM-DD'
  status: text('status').default('unpaid').notNull(), // 'unpaid' or 'paid'
  paidAt: text('paid_at'),
  slipImage: text('slip_image'),
  slipUploadedAt: text('slip_uploaded_at'),
  slipStatus: text('slip_status').default('none').notNull(), // 'none' | 'pending' | 'verified' | 'rejected'
  createdAt: text('created_at').default(sql`(CURRENT_TIMESTAMP)`),
  deletedAt: text('deleted_at'),
  deletedBy: integer('deleted_by'),
}, (table) => [
  uniqueIndex('idx_bills_unique_active').on(table.userId, table.roomId, table.billMonth).where(sql`deleted_at IS NULL`),
]);

export const recurringChargeTemplates = sqliteTable('recurring_charge_templates', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  userId: integer('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  name: text('name').notNull(),
  description: text('description'),
  defaultAmount: integer('default_amount').default(0).notNull(),
  frequency: text('frequency').default('monthly').notNull(),
  billingMonths: text('billing_months').default('[1,2,3,4,5,6,7,8,9,10,11,12]').notNull(),
  isActive: integer('is_active').default(1).notNull(),
  createdAt: text('created_at').default(sql`(CURRENT_TIMESTAMP)`),
  updatedAt: text('updated_at').default(sql`(CURRENT_TIMESTAMP)`),
  deletedAt: text('deleted_at'),
});

export const roomRecurringCharges = sqliteTable('room_recurring_charges', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  userId: integer('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  roomId: integer('room_id').references(() => rooms.id, { onDelete: 'cascade' }).notNull(),
  templateId: integer('template_id').references(() => recurringChargeTemplates.id, { onDelete: 'cascade' }).notNull(),
  amountOverride: integer('amount_override'),
  isEnabled: integer('is_enabled').default(1).notNull(),
  createdAt: text('created_at').default(sql`(CURRENT_TIMESTAMP)`),
  updatedAt: text('updated_at').default(sql`(CURRENT_TIMESTAMP)`),
}, (table) => [unique('uq_room_recurring_template').on(table.roomId, table.templateId)]);

export const billChargeItems = sqliteTable('bill_charge_items', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  billId: integer('bill_id').references(() => bills.id, { onDelete: 'cascade' }).notNull(),
  assignmentId: integer('assignment_id').references(() => roomRecurringCharges.id, { onDelete: 'set null' }),
  label: text('label').notNull(),
  amount: integer('amount').default(0).notNull(),
  kind: text('kind').default('manual').notNull(),
  sortOrder: integer('sort_order').default(0).notNull(),
  createdAt: text('created_at').default(sql`(CURRENT_TIMESTAMP)`),
});

// Define 'settings' table
export const settings = sqliteTable('settings', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  userId: integer('user_id')
    .references(() => users.id, { onDelete: 'cascade' })
    .notNull()
    .unique(),
  dormName: text('dorm_name').default('หอพักของฉัน').notNull(),
  defaultElecRate: real('default_elec_rate').default(7).notNull(),
  defaultWaterRate: real('default_water_rate').default(13).notNull(),
  defaultDueDateDay: integer('default_due_date_day').default(5).notNull(),
  defaultPenaltyRate: real('default_penalty_rate').default(100).notNull(),
  promptpayId: text('promptpay_id'),
  promptpayName: text('promptpay_name'),
  lineChannelAccessToken: text('line_channel_access_token'),
  lineChannelSecret: text('line_channel_secret'),
  lineBotEnabled: integer('line_bot_enabled').default(0),
  googleSpreadsheetId: text('google_spreadsheet_id'),
  subscriptionPlan: text('subscription_plan', { enum: ['demo', 'basic', 'standard', 'pro'] }).default('pro').notNull(),
  subscriptionStatus: text('subscription_status').default('active').notNull(),
  subscriptionExpiresAt: text('subscription_expires_at'),
  fontScale: text('font_scale', { enum: ['small', 'medium', 'large'] }).default('medium').notNull(),
  updatedAt: text('updated_at').default(sql`(CURRENT_TIMESTAMP)`),
});

// Define 'maintenance_tickets' table
export const maintenanceTickets = sqliteTable('maintenance_tickets', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  userId: integer('user_id')
    .references(() => users.id, { onDelete: 'cascade' })
    .notNull(),
  roomId: integer('room_id')
    .references(() => rooms.id, { onDelete: 'cascade' })
    .notNull(),
  roomNumber: text('room_number').notNull(),
  tenantName: text('tenant_name'),
  tenantPhone: text('tenant_phone'),
  title: text('title').notNull(),
  description: text('description'),
  category: text('category').default('other').notNull(), // 'plumbing' | 'electrical' | 'appliance' | 'furniture' | 'structure' | 'other'
  priority: text('priority').default('medium').notNull(), // 'low' | 'medium' | 'high' | 'urgent'
  status: text('status').default('pending').notNull(), // 'pending' | 'in_progress' | 'completed' | 'cancelled'
  imageUrl: text('image_url'),
  repairCost: integer('repair_cost').default(0).notNull(),
  technicianNote: text('technician_note'),
  createdAt: text('created_at').default(sql`(CURRENT_TIMESTAMP)`),
  updatedAt: text('updated_at').default(sql`(CURRENT_TIMESTAMP)`),
  deletedAt: text('deleted_at'),
  deletedBy: integer('deleted_by'),
});

export const housekeepingTasks = sqliteTable('housekeeping_tasks', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  userId: integer('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  roomId: integer('room_id').references(() => rooms.id, { onDelete: 'cascade' }).notNull(),
  assignedUserId: integer('assigned_user_id').references(() => users.id, { onDelete: 'set null' }),
  contractId: integer('contract_id'),
  source: text('source').default('manual').notNull(),
  status: text('status').default('pending').notNull(),
  note: text('note'),
  inspectionNote: text('inspection_note'),
  createdBy: integer('created_by').references(() => users.id, { onDelete: 'set null' }),
  createdAt: text('created_at').default(sql`(CURRENT_TIMESTAMP)`),
  updatedAt: text('updated_at').default(sql`(CURRENT_TIMESTAMP)`),
  completedAt: text('completed_at'),
});

// Define 'lease_contracts' table
export const leaseContracts = sqliteTable('lease_contracts', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  userId: integer('user_id')
    .references(() => users.id, { onDelete: 'cascade' })
    .notNull(),
  roomId: integer('room_id')
    .references(() => rooms.id, { onDelete: 'cascade' })
    .notNull(),
  roomNumber: text('room_number').notNull(),
  tenantName: text('tenant_name').notNull(),
  tenantPhone: text('tenant_phone'),
  idCardNumber: text('id_card_number'),
  startDate: text('start_date').notNull(), // format 'YYYY-MM-DD'
  endDate: text('end_date').notNull(),   // format 'YYYY-MM-DD'
  monthlyRent: integer('monthly_rent').default(0).notNull(),
  depositAmount: integer('deposit_amount').default(0).notNull(),
  advanceRentAmount: integer('advance_rent_amount').default(0).notNull(),
  contractDocumentUrl: text('contract_document_url'),
  status: text('status').default('active').notNull(), // 'active' | 'expiring_soon' | 'expired' | 'terminated'
  note: text('note'),
  createdAt: text('created_at').default(sql`(CURRENT_TIMESTAMP)`),
  updatedAt: text('updated_at').default(sql`(CURRENT_TIMESTAMP)`),
  deletedAt: text('deleted_at'),
  deletedBy: integer('deleted_by'),
});

// Define 'announcements' table
export const announcements = sqliteTable('announcements', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  userId: integer('user_id')
    .references(() => users.id, { onDelete: 'cascade' })
    .notNull(),
  title: text('title').notNull(),
  content: text('content').notNull(),
  category: text('category').default('general').notNull(), // 'general' | 'maintenance' | 'billing' | 'urgent'
  isPinned: integer('is_pinned').default(0).notNull(), // 1 = pinned, 0 = normal
  targetRoomIds: text('target_room_ids'), // comma-separated room ids or null for all
  imageUrl: text('image_url'),
  createdAt: text('created_at').default(sql`(CURRENT_TIMESTAMP)`),
  updatedAt: text('updated_at').default(sql`(CURRENT_TIMESTAMP)`),
  deletedAt: text('deleted_at'),
  deletedBy: integer('deleted_by'),
});

// Internal notes shared by authenticated staff in the same dormitory.
export const notes = sqliteTable('notes', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  userId: integer('user_id')
    .references(() => users.id, { onDelete: 'cascade' })
    .notNull(),
  createdBy: integer('created_by')
    .references(() => users.id)
    .notNull(),
  roomId: integer('room_id')
    .references(() => rooms.id, { onDelete: 'set null' }),
  title: text('title').notNull(),
  content: text('content').notNull(),
  color: text('color').default('yellow').notNull(),
  isPinned: integer('is_pinned').default(0).notNull(),
  createdAt: text('created_at').default(sql`(CURRENT_TIMESTAMP)`),
  updatedAt: text('updated_at').default(sql`(CURRENT_TIMESTAMP)`),
  deletedAt: text('deleted_at'),
  deletedBy: integer('deleted_by'),
});

// Define 'audit_logs' table
export const auditLogs = sqliteTable('audit_logs', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  userId: integer('user_id'),
  userEmail: text('user_email').notNull(),
  userRole: text('user_role').default('owner').notNull(),
  action: text('action').notNull(),
  targetType: text('target_type').notNull(),
  targetId: text('target_id'),
  oldValue: text('old_value'),
  newValue: text('new_value'),
  ipAddress: text('ip_address'),
  userAgent: text('user_agent'),
  createdAt: text('created_at').default(sql`(CURRENT_TIMESTAMP)`),
});

// Define relations
export const usersRelations = relations(users, ({ many, one }) => ({
  rooms: many(rooms),
  bills: many(bills),
  maintenanceTickets: many(maintenanceTickets),
  leaseContracts: many(leaseContracts),
  announcements: many(announcements),
  notes: many(notes, { relationName: 'notesOwner' }),
  createdNotes: many(notes, { relationName: 'notesCreator' }),
  settings: one(settings, {
    fields: [users.id],
    references: [settings.userId],
  }),
}));

export const roomsRelations = relations(rooms, ({ one, many }) => ({
  user: one(users, {
    fields: [rooms.userId],
    references: [users.id],
  }),
  bills: many(bills),
  maintenanceTickets: many(maintenanceTickets),
  leaseContracts: many(leaseContracts),
  notes: many(notes),
}));

export const billsRelations = relations(bills, ({ one }) => ({
  user: one(users, {
    fields: [bills.userId],
    references: [users.id],
  }),
  room: one(rooms, {
    fields: [bills.roomId],
    references: [rooms.id],
  }),
}));

export const settingsRelations = relations(settings, ({ one }) => ({
  user: one(users, {
    fields: [settings.userId],
    references: [users.id],
  }),
}));

export const maintenanceTicketsRelations = relations(maintenanceTickets, ({ one }) => ({
  user: one(users, {
    fields: [maintenanceTickets.userId],
    references: [users.id],
  }),
  room: one(rooms, {
    fields: [maintenanceTickets.roomId],
    references: [rooms.id],
  }),
}));

export const leaseContractsRelations = relations(leaseContracts, ({ one }) => ({
  user: one(users, {
    fields: [leaseContracts.userId],
    references: [users.id],
  }),
  room: one(rooms, {
    fields: [leaseContracts.roomId],
    references: [rooms.id],
  }),
}));

export const announcementsRelations = relations(announcements, ({ one }) => ({
  user: one(users, {
    fields: [announcements.userId],
    references: [users.id],
  }),
}));

export const notesRelations = relations(notes, ({ one }) => ({
  owner: one(users, {
    fields: [notes.userId],
    references: [users.id],
    relationName: 'notesOwner',
  }),
  creator: one(users, {
    fields: [notes.createdBy],
    references: [users.id],
    relationName: 'notesCreator',
  }),
  room: one(rooms, {
    fields: [notes.roomId],
    references: [rooms.id],
  }),
}));
