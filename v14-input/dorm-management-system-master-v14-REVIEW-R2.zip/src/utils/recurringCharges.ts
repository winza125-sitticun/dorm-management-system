import { BillChargeItem, RecurringChargeAssignment, RecurringChargeTemplate } from '../types.ts';

export function normalizeBillingMonths(frequency: RecurringChargeTemplate['frequency'], months: number[]): number[] {
  if (frequency === 'monthly') return Array.from({ length: 12 }, (_, index) => index + 1);
  const expected = frequency === 'quarterly' ? 4 : 1;
  const normalized = Array.from(new Set(months.map(Number).filter((month) => Number.isInteger(month) && month >= 1 && month <= 12))).sort((a, b) => a - b);
  if (normalized.length !== expected) throw new Error(frequency === 'quarterly' ? 'รายไตรมาสต้องเลือก 4 เดือน' : 'รายปีต้องเลือก 1 เดือน');
  return normalized;
}

export function isChargeDue(template: Pick<RecurringChargeTemplate, 'frequency' | 'billingMonths' | 'isActive'>, billMonth: string): boolean {
  if (!template.isActive || !/^\d{4}-\d{2}$/.test(billMonth)) return false;
  const month = Number(billMonth.slice(5, 7));
  if (template.frequency === 'monthly') return true;
  return template.billingMonths.includes(month);
}

export function resolveChargeAmount(assignment: Pick<RecurringChargeAssignment, 'amountOverride'>, template: Pick<RecurringChargeTemplate, 'defaultAmount'>): number {
  const amount = assignment.amountOverride === null || assignment.amountOverride === undefined
    ? template.defaultAmount
    : assignment.amountOverride;
  return Math.max(0, Math.round(Number(amount) || 0));
}

export function sumChargeItems(items: Array<Pick<BillChargeItem, 'amount'>>): number {
  return items.reduce((sum, item) => sum + Math.max(0, Math.round(Number(item.amount) || 0)), 0);
}

