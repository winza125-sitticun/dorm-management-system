export function buildValidDueDate(billMonth: string, preferredDay: number): string {
  const match = /^(\d{4})-(\d{2})$/.exec(billMonth);
  if (!match) return '';

  const year = Number(match[1]);
  const month = Number(match[2]);
  if (!Number.isInteger(year) || month < 1 || month > 12) return '';

  const requestedDay = Number.isFinite(preferredDay) ? Math.trunc(preferredDay) : 1;
  const lastDay = new Date(Date.UTC(year, month, 0)).getUTCDate();
  const day = Math.min(Math.max(requestedDay, 1), lastDay);
  return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
}

export function parseNumberOrFallback(value: string | number, fallback: number): number {
  const parsed = typeof value === 'number' ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

export function extractSpreadsheetId(input: string): string {
  const trimmed = (input || '').trim();
  const match = trimmed.match(/\/d\/([a-zA-Z0-9-_]+)/);
  return match?.[1] || trimmed;
}

export function isValidSpreadsheetId(input: string): boolean {
  return /^[a-zA-Z0-9-_]{20,}$/.test(extractSpreadsheetId(input));
}

export type FontScale = 'small' | 'medium' | 'large';

export function normalizeFontScale(value: unknown): FontScale {
  return value === 'small' || value === 'large' ? value : 'medium';
}

export function fontScalePercent(value: unknown): number {
  const normalized = normalizeFontScale(value);
  if (normalized === 'small') return 90;
  if (normalized === 'large') return 112.5;
  return 100;
}
