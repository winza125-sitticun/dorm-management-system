import { PERMISSIONS, hasAppPermission, type Permission } from '../constants/permissions.ts';

export type AppTab =
  | 'dashboard' | 'announcements' | 'notes' | 'rooms' | 'contracts'
  | 'maintenance' | 'housekeeping' | 'create_bill' | 'bulk_meter'
  | 'history' | 'report' | 'settings' | 'audit_logs';

export type AppSurface = 'main_app' | 'tenant_portal' | 'line_registration';

export interface AppHistoryEventTarget {
  addEventListener(type: 'popstate', listener: () => void): void;
  removeEventListener(type: 'popstate', listener: () => void): void;
}

export interface AppHistoryLocation {
  pathname: string;
  search: string;
}

export interface AppHistoryListenerOptions {
  eventTarget: AppHistoryEventTarget;
  location: AppHistoryLocation;
  onLocation?: (location: string) => void;
  onMainPath?: (pathname: string) => void;
  syncImmediately?: boolean;
}

export function listenToAppHistory(options: AppHistoryListenerOptions): () => void {
  const handleLocationChange = () => {
    const location = `${options.location.pathname}${options.location.search}`;
    options.onLocation?.(location);
    if (appSurfaceForLocation(location) === 'main_app') {
      options.onMainPath?.(options.location.pathname);
    }
  };

  if (options.syncImmediately) handleLocationChange();
  options.eventTarget.addEventListener('popstate', handleLocationChange);
  return () => options.eventTarget.removeEventListener('popstate', handleLocationChange);
}

export function appSurfaceForLocation(location: string): AppSurface {
  const queryIndex = location.indexOf('?');
  const pathname = normalizeAppPath(queryIndex === -1 ? location : location.slice(0, queryIndex));
  const search = queryIndex === -1 ? '' : location.slice(queryIndex + 1);
  const params = new URLSearchParams(search);

  if (
    pathname === '/tenant-portal'
    || pathname.startsWith('/tenant-portal/')
    || params.has('roomId')
    || params.get('portal') === 'tenant'
    || params.has('tenant')
  ) {
    return 'tenant_portal';
  }
  if (
    pathname === '/line-register'
    || pathname.startsWith('/line-register/')
    || params.has('room')
  ) {
    return 'line_registration';
  }
  return 'main_app';
}

export const APP_TAB_PATHS: Record<AppTab, string> = {
  dashboard: '/', announcements: '/announcements', notes: '/notes',
  rooms: '/rooms', contracts: '/contracts', maintenance: '/maintenance',
  housekeeping: '/housekeeping', create_bill: '/bills/create',
  bulk_meter: '/bills/meters', history: '/bills/history', report: '/reports',
  settings: '/settings', audit_logs: '/audit-logs',
};

export type HistoryAction = 'none' | 'push' | 'replace';

export interface RouteDecision {
  tab: AppTab;
  path: string;
  history: HistoryAction;
}

export function normalizeAppPath(pathname: string): string {
  const collapsed = `/${pathname.split('/').filter(Boolean).join('/')}`;
  return collapsed === '/' ? '/' : collapsed.replace(/\/+$/, '');
}

export function pathForTab(tab: AppTab): string {
  return APP_TAB_PATHS[tab];
}

export function tabForPath(pathname: string): AppTab | null {
  const normalized = normalizeAppPath(pathname);
  return (Object.entries(APP_TAB_PATHS).find(([, path]) => path === normalized)?.[0] as AppTab | undefined) ?? null;
}

export function canAccessAppTab(tab: AppTab, role: string, permissions: string | null | undefined): boolean {
  if (['dashboard', 'announcements', 'notes'].includes(tab)) return true;
  if (tab === 'audit_logs') return role === 'owner' || role === 'super_admin';
  const allowed = (permission: Permission) => hasAppPermission(role, permissions, permission);
  if (tab === 'rooms') return allowed(PERMISSIONS.VIEW_ROOMS);
  if (tab === 'contracts') return allowed(PERMISSIONS.VIEW_CONTRACTS);
  if (tab === 'maintenance') return allowed(PERMISSIONS.VIEW_MAINTENANCE);
  if (tab === 'housekeeping') return allowed(PERMISSIONS.VIEW_HOUSEKEEPING);
  if (tab === 'create_bill' || tab === 'bulk_meter') return allowed(PERMISSIONS.MANAGE_BILLS);
  if (tab === 'history') return allowed(PERMISSIONS.VIEW_BILLS) || allowed(PERMISSIONS.EDIT_PAYMENTS);
  if (tab === 'report') return allowed(PERMISSIONS.VIEW_REPORTS);
  return allowed(PERMISSIONS.MANAGE_SETTINGS) || allowed(PERMISSIONS.MANAGE_RECURRING_CHARGES);
}

export function resolveAppPath(pathname: string, canAccess: (tab: AppTab) => boolean): RouteDecision {
  const tab = tabForPath(pathname);
  if (!tab || !canAccess(tab)) return { tab: 'dashboard', path: '/', history: 'replace' };
  return { tab, path: pathForTab(tab), history: 'none' };
}

export interface NavigationEffects {
  setTab(tab: AppTab): void;
  closeMobileMenu(): void;
  pushPath(path: string): void;
  replacePath(path: string): void;
}

export interface AppNavigationAccess {
  role: string;
  permissions: string | null | undefined;
}

export type DashboardHistoryEntry = 'base' | 'guard';

interface AppNavigationHistoryState {
  appTab: true;
  dashboardEntry?: DashboardHistoryEntry;
  navigationPosition: number;
}

export interface DashboardExitEffects {
  isMobileMenuOpen(): boolean;
  showExitWarning(): void;
  hideExitWarning(): void;
  exitApp(): void;
  scheduleTimeout(callback: () => void, delayMs: number): unknown;
  cancelTimeout(handle: unknown): void;
}

export interface AppNavigationHistory {
  readonly state: unknown;
  pushState(state: unknown, title: string, path: string): void;
  replaceState(state: unknown, title: string, path: string): void;
  forward(): void;
}

export interface AppNavigationSessionOptions {
  eventTarget: AppHistoryEventTarget;
  location: AppHistoryLocation;
  history: AppNavigationHistory;
  initialAccess: AppNavigationAccess | null;
  setTab(tab: AppTab): void;
  closeMobileMenu(): void;
  dashboardExit: DashboardExitEffects;
}

export interface AppNavigationSession {
  navigateTo(tab: AppTab): RouteDecision | null;
  updateAccess(access: AppNavigationAccess | null): RouteDecision | null;
  stop(): void;
}

export function applyPathFromHistory(
  pathname: string,
  canAccess: (tab: AppTab) => boolean,
  effects: NavigationEffects,
): RouteDecision {
  const decision = resolveAppPath(pathname, canAccess);
  if (decision.history === 'replace') effects.replacePath(decision.path);
  effects.setTab(decision.tab);
  effects.closeMobileMenu();
  return decision;
}

export function navigateToAppTab(
  currentTab: AppTab,
  requestedTab: AppTab,
  canAccess: (tab: AppTab) => boolean,
  effects: NavigationEffects,
): RouteDecision {
  if (!canAccess(requestedTab)) {
    const decision = { tab: 'dashboard', path: '/', history: 'replace' } as const;
    effects.replacePath(decision.path);
    effects.setTab(decision.tab);
    effects.closeMobileMenu();
    return decision;
  }
  if (currentTab === requestedTab) {
    effects.closeMobileMenu();
    return { tab: requestedTab, path: pathForTab(requestedTab), history: 'none' };
  }
  const path = pathForTab(requestedTab);
  effects.pushPath(path);
  effects.setTab(requestedTab);
  effects.closeMobileMenu();
  return { tab: requestedTab, path, history: 'push' };
}

export function createAppNavigationSession(options: AppNavigationSessionOptions): AppNavigationSession {
  let access = options.initialAccess;
  let currentTab = tabForPath(options.location.pathname) ?? 'dashboard';
  let stopped = false;
  let awaitingSecondBack = false;
  let exitTimeout: unknown = null;
  let restoringTraversal = false;
  let nextNavigationPosition = 0;
  let activeNavigationPosition: number | null = null;

  const currentLocation = () => `${options.location.pathname}${options.location.search}`;
  const normalState = (): AppNavigationHistoryState => ({
    appTab: true,
    navigationPosition: ++nextNavigationPosition,
  });
  const dashboardState = (dashboardEntry: DashboardHistoryEntry): AppNavigationHistoryState => ({
    appTab: true,
    dashboardEntry,
    navigationPosition: ++nextNavigationPosition,
  });
  const readDashboardEntry = (state: unknown): DashboardHistoryEntry | null => {
    if (
      typeof state !== 'object'
      || state === null
      || (state as Partial<AppNavigationHistoryState>).appTab !== true
    ) return null;
    const dashboardEntry = (state as Partial<AppNavigationHistoryState>).dashboardEntry;
    return dashboardEntry === 'base' || dashboardEntry === 'guard' ? dashboardEntry : null;
  };
  const readNavigationPosition = (state: unknown): number | null => {
    if (
      typeof state !== 'object'
      || state === null
      || (state as Partial<AppNavigationHistoryState>).appTab !== true
    ) return null;
    const navigationPosition = (state as Partial<AppNavigationHistoryState>).navigationPosition;
    return Number.isSafeInteger(navigationPosition) ? navigationPosition : null;
  };
  const rememberActiveNavigationPosition = () => {
    activeNavigationPosition = readNavigationPosition(options.history.state);
  };
  const persistedNavigationPosition = readNavigationPosition(options.history.state);
  if (persistedNavigationPosition !== null) {
    nextNavigationPosition = persistedNavigationPosition;
    activeNavigationPosition = persistedNavigationPosition;
  }
  const establishDashboardBoundary = (replaceCurrent: boolean) => {
    if (replaceCurrent) {
      options.history.replaceState(dashboardState('base'), '', '/');
    } else {
      options.history.pushState(dashboardState('base'), '', '/');
    }
    options.history.pushState(dashboardState('guard'), '', '/');
    rememberActiveNavigationPosition();
  };
  const restoreForward = () => {
    restoringTraversal = true;
    options.history.forward();
  };
  const disarmExit = () => {
    awaitingSecondBack = false;
    if (exitTimeout !== null) options.dashboardExit.cancelTimeout(exitTimeout);
    exitTimeout = null;
    options.dashboardExit.hideExitWarning();
  };
  const effects: NavigationEffects = {
    setTab: (tab) => {
      currentTab = tab;
      options.setTab(tab);
    },
    closeMobileMenu: options.closeMobileMenu,
    pushPath: (path) => {
      if (path === '/') {
        establishDashboardBoundary(false);
        return;
      }
      disarmExit();
      options.history.pushState(normalState(), '', path);
      rememberActiveNavigationPosition();
    },
    replacePath: (path) => {
      if (path === '/') {
        if (readDashboardEntry(options.history.state) === 'guard') return;
        establishDashboardBoundary(true);
        return;
      }
      options.history.replaceState(normalState(), '', path);
      rememberActiveNavigationPosition();
    },
  };

  const synchronizeFromLocation = (): RouteDecision | null => {
    if (appSurfaceForLocation(currentLocation()) !== 'main_app' || !access) return null;
    if (options.location.pathname === '/' && readDashboardEntry(options.history.state) !== 'guard') {
      establishDashboardBoundary(true);
    } else if (readNavigationPosition(options.history.state) === null) {
      const tab = tabForPath(options.location.pathname);
      if (tab && canAccessAppTab(tab, access.role, access.permissions)) {
        options.history.replaceState(normalState(), '', currentLocation());
        rememberActiveNavigationPosition();
      }
    }
    return applyPathFromHistory(
      options.location.pathname,
      (tab) => canAccessAppTab(tab, access!.role, access!.permissions),
      effects,
    );
  };

  const applyGoogleSheetsCallback = () => {
    if (appSurfaceForLocation(currentLocation()) !== 'main_app') return;
    const params = new URLSearchParams(options.location.search);
    if (params.get('googleSheets') !== 'connected') return;

    const settingsLocation = `/settings${options.location.search}`;
    if (currentLocation() !== settingsLocation) {
      options.history.replaceState(normalState(), '', settingsLocation);
      rememberActiveNavigationPosition();
    }
    currentTab = 'settings';
    options.setTab('settings');
  };

  const handlePopState = () => {
    if (appSurfaceForLocation(currentLocation()) !== 'main_app' || !access) return;
    const navigationPosition = readNavigationPosition(options.history.state);
    if (restoringTraversal) {
      activeNavigationPosition = navigationPosition;
      restoringTraversal = false;
      return;
    }
    const isBackTraversal = (
      activeNavigationPosition === null
      || navigationPosition === null
      || navigationPosition < activeNavigationPosition
    );
    activeNavigationPosition = navigationPosition;
    if (options.dashboardExit.isMobileMenuOpen()) {
      options.closeMobileMenu();
      if (isBackTraversal) restoreForward();
      else synchronizeFromLocation();
      return;
    }

    const dashboardEntry = readDashboardEntry(options.history.state);
    if (dashboardEntry === 'base') {
      if (awaitingSecondBack) {
        disarmExit();
        options.dashboardExit.exitApp();
        return;
      }
      awaitingSecondBack = true;
      options.dashboardExit.showExitWarning();
      exitTimeout = options.dashboardExit.scheduleTimeout(disarmExit, 2_000);
      restoreForward();
      return;
    }

    if (awaitingSecondBack && options.location.pathname !== '/') disarmExit();
    synchronizeFromLocation();
  };

  applyGoogleSheetsCallback();
  synchronizeFromLocation();
  options.eventTarget.addEventListener('popstate', handlePopState);

  return {
    navigateTo(tab) {
      if (appSurfaceForLocation(currentLocation()) !== 'main_app' || !access) {
        options.closeMobileMenu();
        return null;
      }
      return navigateToAppTab(
        currentTab,
        tab,
        (candidate) => canAccessAppTab(candidate, access!.role, access!.permissions),
        effects,
      );
    },
    updateAccess(nextAccess) {
      access = nextAccess;
      if (!access) {
        disarmExit();
        restoringTraversal = false;
      }
      return synchronizeFromLocation();
    },
    stop() {
      if (stopped) return;
      stopped = true;
      disarmExit();
      options.eventTarget.removeEventListener('popstate', handlePopState);
    },
  };
}
