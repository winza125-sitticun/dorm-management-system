export const BACKUP_FORMAT = 'dorm-backup' as const;
export const BACKUP_FORMAT_VERSION = 1 as const;
export const BACKUP_SCHEMA_VERSION = 6 as const;
export const BACKUP_ARCHIVE_MAX_BYTES = 10 * 1024 * 1024;
export const BACKUP_REQUEST_MAX_BYTES = 20 * 1024 * 1024;
export const BACKUP_MAX_TOTAL_RECORDS = 60_000;

export const BACKUP_TABLES = [
  'rooms','bills','recurringChargeTemplates','roomRecurringCharges','billChargeItems',
  'maintenanceTickets','housekeepingTasks','leaseContracts','announcements','notes',
] as const;
export type BackupTableName = typeof BACKUP_TABLES[number];
export type BackupCounts = Record<BackupTableName, number> & { settings: 1 };

export interface BackupSafeSettingsV1 {
  dormName: string;
  defaultElecRate: number;
  defaultWaterRate: number;
  defaultDueDateDay: number;
  defaultPenaltyRate: number;
  promptpayId: string | null;
  promptpayName: string | null;
  fontScale: 'small' | 'medium' | 'large';
}

export interface BackupManifestV1 {
  format: typeof BACKUP_FORMAT;
  formatVersion: typeof BACKUP_FORMAT_VERSION;
  appVersion: string;
  schemaVersion: typeof BACKUP_SCHEMA_VERSION;
  createdAt: string;
  ownerScope: string;
  dormName: string;
  counts: BackupCounts;
  excluded: string[];
  dataSha256: string;
}

export interface BackupDataV1 {
  rooms: Record<string, unknown>[];
  bills: Record<string, unknown>[];
  recurringChargeTemplates: Record<string, unknown>[];
  roomRecurringCharges: Record<string, unknown>[];
  billChargeItems: Record<string, unknown>[];
  maintenanceTickets: Record<string, unknown>[];
  housekeepingTasks: Record<string, unknown>[];
  leaseContracts: Record<string, unknown>[];
  announcements: Record<string, unknown>[];
  notes: Record<string, unknown>[];
  settings: BackupSafeSettingsV1;
}

function canonicalize(value: unknown, seen: Set<object>): unknown {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return value;
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) throw new TypeError('BACKUP_CANONICAL_INVALID_NUMBER');
    return value;
  }
  if (typeof value === 'undefined' || typeof value === 'bigint' || typeof value === 'function' || typeof value === 'symbol') {
    throw new TypeError('BACKUP_CANONICAL_UNSUPPORTED_VALUE');
  }
  if (typeof value !== 'object') throw new TypeError('BACKUP_CANONICAL_UNSUPPORTED_VALUE');
  if (seen.has(value)) throw new TypeError('BACKUP_CANONICAL_CYCLE');
  seen.add(value);
  try {
    if (Array.isArray(value)) {
      for (let i = 0; i < value.length; i += 1) {
        if (!Object.prototype.hasOwnProperty.call(value, i)) throw new TypeError('BACKUP_CANONICAL_SPARSE_ARRAY');
      }
      return value.map((item) => canonicalize(item, seen));
    }
    if (Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null) {
      throw new TypeError('BACKUP_CANONICAL_NON_PLAIN_OBJECT');
    }
    if (Object.getOwnPropertySymbols(value).length > 0) throw new TypeError('BACKUP_CANONICAL_SYMBOL_KEY');
    const input = value as Record<string, unknown>;
    const output: Record<string, unknown> = {};
    for (const key of Object.keys(input).sort()) output[key] = canonicalize(input[key], seen);
    return output;
  } finally {
    seen.delete(value);
  }
}

export function stableStringify(value: unknown): string {
  return JSON.stringify(canonicalize(value, new Set<object>()));
}

export async function sha256Hex(value: string | Uint8Array): Promise<string> {
  const bytes = typeof value === 'string' ? new TextEncoder().encode(value) : value;
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, '0')).join('');
}

export function computeBackupCounts(data: BackupDataV1): BackupCounts {
  return {
    rooms: data.rooms.length,
    bills: data.bills.length,
    recurringChargeTemplates: data.recurringChargeTemplates.length,
    roomRecurringCharges: data.roomRecurringCharges.length,
    billChargeItems: data.billChargeItems.length,
    maintenanceTickets: data.maintenanceTickets.length,
    housekeepingTasks: data.housekeepingTasks.length,
    leaseContracts: data.leaseContracts.length,
    announcements: data.announcements.length,
    notes: data.notes.length,
    settings: 1,
  };
}
