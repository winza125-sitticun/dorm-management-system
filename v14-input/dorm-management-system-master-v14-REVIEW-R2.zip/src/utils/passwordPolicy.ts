export interface PasswordPolicyResult {
  isValid: boolean;
  error?: string;
}

export function validatePasswordPolicy(password: string): PasswordPolicyResult {
  if (!password || password.length < 8) return { isValid: false, error: 'รหัสผ่านต้องมีความยาวอย่างน้อย 8 ตัวอักษร' };
  if (!/[A-Z]/.test(password)) return { isValid: false, error: 'รหัสผ่านต้องมีตัวอักษรภาษาอังกฤษตัวพิมพ์ใหญ่ (A-Z) อย่างน้อย 1 ตัว' };
  if (!/[a-z]/.test(password)) return { isValid: false, error: 'รหัสผ่านต้องมีตัวอักษรภาษาอังกฤษตัวพิมพ์เล็ก (a-z) อย่างน้อย 1 ตัว' };
  if (!/[0-9]/.test(password)) return { isValid: false, error: 'รหัสผ่านต้องมีตัวเลข (0-9) อย่างน้อย 1 ตัว' };
  if (!/[!@#$%^&*(),.?":{}|<>\-_=+]/.test(password)) return { isValid: false, error: 'รหัสผ่านต้องมีอักขระพิเศษ (!@#$%^&*...) อย่างน้อย 1 ตัว' };
  return { isValid: true };
}
