import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';

/**
 * Formats a PromptPay target ID (mobile phone, tax ID/national ID, or e-wallet ID).
 * - Mobile: 10 digits starting with '0' -> converted to 13 digits '00668xxxxxxxx' (subtag '01').
 * - Tax ID: 13 digits (subtag '02').
 * - E-Wallet ID: 15 digits (subtag '03').
 */
export function formatPromptPayTarget(target: string): { subtag: string; targetId: string } {
  const sanitized = (target || '').replace(/[^0-9]/g, '');
  if (!sanitized) {
    throw new Error('PromptPay target ID cannot be empty');
  }

  if (sanitized.length === 10 && sanitized.startsWith('0')) {
    // 10-digit Thai Mobile Number e.g. 0812345678 -> 0066812345678
    return {
      subtag: '01',
      targetId: '0066' + sanitized.substring(1),
    };
  }

  if (sanitized.length === 13 && sanitized.startsWith('0066')) {
    // 13-digit Mobile number already in 0066 format
    return {
      subtag: '01',
      targetId: sanitized,
    };
  }

  if (sanitized.length === 13) {
    // 13-digit National ID / Tax ID
    return {
      subtag: '02',
      targetId: sanitized,
    };
  }

  if (sanitized.length === 15) {
    // 15-digit E-Wallet ID
    return {
      subtag: '03',
      targetId: sanitized,
    };
  }

  if (sanitized.length === 9) {
    // Mobile number without leading 0
    return {
      subtag: '01',
      targetId: '0066' + sanitized,
    };
  }

  return {
    subtag: sanitized.length > 13 ? '03' : '02',
    targetId: sanitized,
  };
}

/**
 * Formats Tag-Length-Value (TLV) string according to EMVCo QR specification.
 */
function formatTLV(tag: string, value: string): string {
  const length = value.length.toString().padStart(2, '0');
  return `${tag}${length}${value}`;
}

/**
 * Computes CRC16-CCITT checksum over Tag 63 with polynomial 0x1021 and initial value 0xFFFF.
 */
export function crc16(data: string): string {
  let crc = 0xffff;
  for (let i = 0; i < data.length; i++) {
    crc ^= data.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) {
      if ((crc & 0x8000) !== 0) {
        crc = ((crc << 1) ^ 0x1021) & 0xffff;
      } else {
        crc = (crc << 1) & 0xffff;
      }
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, '0');
}

/**
 * Generates an EMVCo-compliant PromptPay QR Code payload string.
 */
export function generatePromptPayPayload(target: string, amount?: number): string {
  const { subtag, targetId } = formatPromptPayTarget(target);

  // Tag 00: Payload Format Indicator ('01')
  const tag00 = formatTLV('00', '01');

  // Tag 01: Point of Initiation Method ('11' for static, '12' for dynamic)
  const isDynamic = typeof amount === 'number' && amount > 0;
  const tag01 = formatTLV('01', isDynamic ? '12' : '11');

  // Tag 29: Merchant Account Info (PromptPay AID 'A000000677010111')
  const aidSubtag = formatTLV('00', 'A000000677010111');
  const targetSubtag = formatTLV(subtag, targetId);
  const tag29Value = aidSubtag + targetSubtag;
  const tag29 = formatTLV('29', tag29Value);

  // Tag 53: Transaction Currency (764 = THB)
  const tag53 = formatTLV('53', '764');

  // Tag 54: Transaction Amount (formatted to 2 decimal places e.g., '100.00')
  let tag54 = '';
  if (isDynamic && amount !== undefined) {
    const amountStr = amount.toFixed(2);
    tag54 = formatTLV('54', amountStr);
  }

  // Tag 58: Country Code ('TH')
  const tag58 = formatTLV('58', 'TH');

  // Tag 63: Checksum
  const rawPayload = `${tag00}${tag01}${tag29}${tag53}${tag54}${tag58}6304`;
  const checksum = crc16(rawPayload);

  return `${rawPayload}${checksum}`;
}

/**
 * Generates a local QR code Data URL (PNG base64) for the given PromptPay target & amount.
 */
export async function generatePromptPayQRDataURL(target: string, amount?: number): Promise<string> {
  const payload = generatePromptPayPayload(target, amount);
  return await QRCode.toDataURL(payload, {
    margin: 2,
    width: 300,
    color: {
      dark: '#000000',
      light: '#ffffff',
    },
  });
}

interface PromptPayQRProps {
  target: string;
  amount?: number;
  className?: string;
  alt?: string;
}

/**
 * React Component for rendering PromptPay QR Code offline locally without external HTTP calls.
 */
export const PromptPayQR: React.FC<PromptPayQRProps> = ({
  target,
  amount,
  className = 'w-24 h-24 object-contain',
  alt = 'PromptPay QR Code',
}) => {
  const [dataUrl, setDataUrl] = useState<string>('');
  const [error, setError] = useState<boolean>(false);

  useEffect(() => {
    let isMounted = true;
    if (target) {
      setError(false);
      try {
        const payload = generatePromptPayPayload(target, amount);
        QRCode.toDataURL(payload, {
          margin: 2,
          width: 300,
          color: {
            dark: '#000000',
            light: '#ffffff',
          },
        })
          .then((url) => {
            if (isMounted) setDataUrl(url);
          })
          .catch((err) => {
            console.error('Failed to generate local PromptPay QR code:', err);
            if (isMounted) setError(true);
          });
      } catch (err) {
        console.error('Invalid PromptPay target ID:', err);
        if (isMounted) setError(true);
      }
    }
    return () => {
      isMounted = false;
    };
  }, [target, amount]);

  if (error) {
    return (
      <div className={`flex items-center justify-center bg-slate-100 text-slate-400 text-xs font-semibold rounded-lg p-2 ${className}`}>
        <span>QR Error</span>
      </div>
    );
  }

  if (!dataUrl) {
    return <div className={`animate-pulse bg-slate-200 rounded-lg ${className}`} />;
  }

  return <img src={dataUrl} alt={alt} className={className} />;
};
