import { canAccessAppTab, type AppTab } from './appNavigation.ts';
import {
  hasPlanFeature,
  type PlanFeature,
  type SubscriptionPlan,
} from '../constants/planEntitlements.ts';

const TAB_PLAN_FEATURES: Partial<Record<AppTab, PlanFeature>> = {
  announcements: 'announcements',
  notes: 'notes',
  contracts: 'contracts',
  maintenance: 'maintenance',
  housekeeping: 'housekeeping',
  bulk_meter: 'bulkMeter',
  report: 'reports',
  settings: 'settings',
  audit_logs: 'auditLogs',
};

const TAB_PAID_PLAN: Partial<Record<AppTab, 'basic' | 'standard' | 'pro'>> = {
  settings: 'basic',
  notes: 'basic',
  bulk_meter: 'standard',
  report: 'standard',
  contracts: 'pro',
  maintenance: 'pro',
  housekeeping: 'pro',
  announcements: 'pro',
  audit_logs: 'pro',
};

export function requiredPlanFeatureForTab(tab: AppTab): PlanFeature | null {
  return TAB_PLAN_FEATURES[tab] ?? null;
}

export function requiredPaidPlanForTab(tab: AppTab): 'basic' | 'standard' | 'pro' | null {
  return TAB_PAID_PLAN[tab] ?? null;
}

export function canAccessTabForPlan(
  tab: AppTab,
  role: string,
  permissions: string | null | undefined,
  plan: SubscriptionPlan,
): boolean {
  if (!canAccessAppTab(tab, role, permissions)) return false;
  if (tab === 'settings') return hasPlanFeature(plan, 'settings') || hasPlanFeature(plan, 'backupExport');
  const feature = requiredPlanFeatureForTab(tab);
  return feature ? hasPlanFeature(plan, feature) : true;
}
