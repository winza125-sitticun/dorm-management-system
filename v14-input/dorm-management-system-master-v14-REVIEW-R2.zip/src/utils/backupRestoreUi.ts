export interface RestoreStartGate {
  validated: boolean;
  confirmed: boolean;
  typed: string;
  allowed?: boolean;
  busy?: boolean;
}

export function canStartRestore(input: RestoreStartGate): boolean {
  return input.validated === true
    && input.confirmed === true
    && input.typed === 'RESTORE'
    && input.allowed !== false
    && input.busy !== true;
}

export function backupFilename(prefix = 'dorm-backup', date = new Date()): string {
  const pad = (value: number) => String(value).padStart(2, '0');
  return `${prefix}-${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}-${pad(date.getHours())}${pad(date.getMinutes())}.dormbackup`;
}
