export function unwrapApiData<T>(payload: any): T {
  return (payload && Object.prototype.hasOwnProperty.call(payload, 'data') ? payload.data : payload) as T;
}

export function getApiErrorMessage(payload: any, fallback: string): string {
  if (typeof payload?.error === 'string' && payload.error.trim()) return payload.error;
  if (typeof payload?.error?.message === 'string' && payload.error.message.trim()) return payload.error.message;
  if (typeof payload?.message === 'string' && payload.message.trim()) return payload.message;
  return fallback;
}

export async function readApiError(response: Response, fallback: string): Promise<string> {
  try {
    return getApiErrorMessage(await response.json(), fallback);
  } catch {
    return fallback;
  }
}
