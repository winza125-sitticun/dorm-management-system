import { strFromU8, strToU8, unzipSync, zipSync } from 'fflate';
import {
  BACKUP_ARCHIVE_MAX_BYTES,
  BACKUP_REQUEST_MAX_BYTES,
  stableStringify,
  type BackupDataV1,
  type BackupManifestV1,
} from './backupFormat.ts';

export const DORM_BACKUP_ENTRIES = ['manifest.json', 'data.json'] as const;

export class DormBackupArchiveError extends Error {
  constructor(public code: string, message = code) { super(message); }
}

export function createDormBackupArchive(manifest: BackupManifestV1, data: BackupDataV1): Uint8Array {
  const bytes = zipSync({
    'manifest.json': strToU8(stableStringify(manifest)),
    'data.json': strToU8(stableStringify(data)),
  }, { level: 6 });
  if (bytes.byteLength > BACKUP_ARCHIVE_MAX_BYTES) throw new DormBackupArchiveError('BACKUP_ARCHIVE_TOO_LARGE');
  return bytes;
}

function findEndOfCentralDirectory(bytes: Uint8Array): number {
  const min = Math.max(0, bytes.length - 65_557);
  for (let i = bytes.length - 22; i >= min; i -= 1) {
    if (bytes[i] === 0x50 && bytes[i + 1] === 0x4b && bytes[i + 2] === 0x05 && bytes[i + 3] === 0x06) return i;
  }
  return -1;
}

function read16(view: DataView, offset: number) { return view.getUint16(offset, true); }
function read32(view: DataView, offset: number) { return view.getUint32(offset, true); }

function preflightZip(bytes: Uint8Array): void {
  if (bytes.byteLength > BACKUP_ARCHIVE_MAX_BYTES) throw new DormBackupArchiveError('BACKUP_ARCHIVE_TOO_LARGE');
  const eocd = findEndOfCentralDirectory(bytes);
  if (eocd < 0) throw new DormBackupArchiveError('BACKUP_ZIP_INVALID');
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const disk = read16(view, eocd + 4);
  const centralDisk = read16(view, eocd + 6);
  const diskEntries = read16(view, eocd + 8);
  const entries = read16(view, eocd + 10);
  const centralSize = read32(view, eocd + 12);
  const centralOffset = read32(view, eocd + 16);
  if (disk !== 0 || centralDisk !== 0 || entries !== diskEntries || entries !== 2) throw new DormBackupArchiveError('BACKUP_ZIP_ENTRY_COUNT');
  if (centralOffset + centralSize > bytes.length || centralOffset > eocd) throw new DormBackupArchiveError('BACKUP_ZIP_INVALID');

  const decoder = new TextDecoder();
  const names = new Set<string>();
  let cursor = centralOffset;
  let uncompressedTotal = 0;
  for (let index = 0; index < entries; index += 1) {
    if (cursor + 46 > bytes.length || read32(view, cursor) !== 0x02014b50) throw new DormBackupArchiveError('BACKUP_ZIP_INVALID');
    const flags = read16(view, cursor + 8);
    const method = read16(view, cursor + 10);
    const uncompressed = read32(view, cursor + 24);
    const nameLength = read16(view, cursor + 28);
    const extraLength = read16(view, cursor + 30);
    const commentLength = read16(view, cursor + 32);
    if ((flags & 0x1) !== 0) throw new DormBackupArchiveError('BACKUP_ZIP_ENCRYPTED');
    if (method !== 0 && method !== 8) throw new DormBackupArchiveError('BACKUP_ZIP_METHOD_UNSUPPORTED');
    const nameStart = cursor + 46;
    const nameEnd = nameStart + nameLength;
    if (nameEnd > bytes.length) throw new DormBackupArchiveError('BACKUP_ZIP_INVALID');
    const name = decoder.decode(bytes.subarray(nameStart, nameEnd));
    if (!DORM_BACKUP_ENTRIES.includes(name as any) || name.includes('/') || name.includes('\\')) throw new DormBackupArchiveError('BACKUP_ZIP_ENTRY_INVALID');
    if (names.has(name)) throw new DormBackupArchiveError('BACKUP_ZIP_DUPLICATE_ENTRY');
    names.add(name);
    uncompressedTotal += uncompressed;
    if (uncompressedTotal > BACKUP_REQUEST_MAX_BYTES) throw new DormBackupArchiveError('BACKUP_UNCOMPRESSED_TOO_LARGE');
    cursor = nameEnd + extraLength + commentLength;
  }
  for (const required of DORM_BACKUP_ENTRIES) if (!names.has(required)) throw new DormBackupArchiveError('BACKUP_ZIP_ENTRY_MISSING');
}

export function parseDormBackupArchive(bytes: Uint8Array): { manifest: BackupManifestV1; data: BackupDataV1 } {
  preflightZip(bytes);
  let files: Record<string, Uint8Array>;
  try { files = unzipSync(bytes); } catch { throw new DormBackupArchiveError('BACKUP_ZIP_INVALID'); }
  const keys = Object.keys(files).sort();
  if (keys.length !== 2 || keys[0] !== 'data.json' || keys[1] !== 'manifest.json') throw new DormBackupArchiveError('BACKUP_ZIP_ENTRY_INVALID');
  try {
    const manifest = JSON.parse(strFromU8(files['manifest.json'])) as BackupManifestV1;
    const data = JSON.parse(strFromU8(files['data.json'])) as BackupDataV1;
    return { manifest, data };
  } catch {
    throw new DormBackupArchiveError('BACKUP_JSON_INVALID');
  }
}
