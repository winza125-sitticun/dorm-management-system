import type { HousekeepingStatus } from '../types.ts';

export const HOUSEKEEPING_TRANSITIONS: Record<HousekeepingStatus, HousekeepingStatus[]> = {
  pending: ['pending', 'in_progress', 'cancelled'],
  in_progress: ['in_progress', 'ready_for_inspection', 'cancelled'],
  ready_for_inspection: ['ready_for_inspection', 'in_progress', 'completed', 'cancelled'],
  completed: ['completed'],
  cancelled: ['cancelled'],
};

export function canTransitionHousekeeping(from: string, to: string): boolean {
  return Boolean(HOUSEKEEPING_TRANSITIONS[from as HousekeepingStatus]?.includes(to as HousekeepingStatus));
}
