/**
 * Rate Limiter Service
 * D1 database-backed fixed-window limiter protecting sensitive routes.
 */

export type RateLimitCategory = 'auth' | 'api' | 'upload' | 'notes_read' | 'notes_write' | 'backup_restore';

export class RateLimiterService {
  private static readonly memoryLimits = new Map<string, { count: number; resetAt: number }>();
  private static memoryChecks = 0;
  private static readonly MAX_MEMORY_KEYS = 10_000;

  /**
   * Checks whether an IP request exceeds rate limits
   * @param db D1 Database binding
   * @param ip Client IP address
   * @param category Limit category, including stricter note read/write buckets
   * @returns boolean (true if allowed, false if limit exceeded)
   */
  static async checkRateLimit(db: any, ip: string, category: RateLimitCategory = 'api'): Promise<{ allowed: boolean; retryAfterSeconds: number }> {
    // The development server does not use D1.  Keep a process-local limiter so
    // authentication endpoints are protected there as well.
    if (!db) {
      return this.checkMemoryRateLimit(ip, category);
    }

    const now = Date.now();
    const safeIdentifier = String(ip || '127.0.0.1').trim().slice(0, 256);
    const key = `${category}:${safeIdentifier}`;

    let maxRequests = 100;
    let windowMs = 60 * 1000; // 1 minute

    if (category === 'auth') {
      maxRequests = 30;
      windowMs = 3 * 60 * 1000; // 3 minutes
    } else if (category === 'upload') {
      maxRequests = 10;
      windowMs = 60 * 1000; // 1 minute
    } else if (category === 'notes_read') {
      maxRequests = 60;
      windowMs = 60 * 1000;
    } else if (category === 'notes_write') {
      maxRequests = 20;
      windowMs = 60 * 1000;
    } else if (category === 'backup_restore') {
      maxRequests = 3;
      windowMs = 10 * 60 * 1000;
    }

    try {
      // One atomic UPSERT avoids lost increments when many requests arrive at once.
      const nextResetAt = now + windowMs;
      const record = await db.prepare(
        `INSERT INTO rate_limits (key, count, reset_at) VALUES (?, 1, ?)
         ON CONFLICT(key) DO UPDATE SET
           count = CASE WHEN rate_limits.reset_at <= ? THEN 1 ELSE rate_limits.count + 1 END,
           reset_at = CASE WHEN rate_limits.reset_at <= ? THEN ? ELSE rate_limits.reset_at END
         RETURNING count, reset_at`
      ).bind(key, nextResetAt, now, now, nextResetAt).first();

      const count = Number(record?.count || 0);
      const resetAt = Number(record?.reset_at || nextResetAt);
      if (count > maxRequests) {
        // Opportunistically prune expired keys only on the first blocked
        // request in a window, avoiding an extra database write per request.
        if (count === maxRequests + 1) {
          try {
            await db.prepare("DELETE FROM rate_limits WHERE reset_at < ?").bind(now).run();
          } catch (cleanupError) {
            console.warn("RateLimiter cleanup warning:", cleanupError);
          }
        }
        return { allowed: false, retryAfterSeconds: Math.max(1, Math.ceil((resetAt - now) / 1000)) };
      }
      return { allowed: true, retryAfterSeconds: 0 };
    } catch (error) {
      console.warn("RateLimiter error (failing open):", error);
      return { allowed: true, retryAfterSeconds: 0 };
    }
  }

  private static checkMemoryRateLimit(ip: string, category: RateLimitCategory) {
    const now = Date.now();
    const safeIdentifier = String(ip || '127.0.0.1').trim().slice(0, 256);
    const key = `${category}:${safeIdentifier}`;
    const maxRequests = category === 'auth' ? 30 : category === 'upload' ? 10 : category === 'notes_read' ? 60 : category === 'notes_write' ? 20 : category === 'backup_restore' ? 3 : 100;
    const windowMs = category === 'auth' ? 3 * 60 * 1000 : category === 'backup_restore' ? 10 * 60 * 1000 : 60 * 1000;
    this.pruneMemoryLimits(now);
    const record = this.memoryLimits.get(key);

    if (!record || now > record.resetAt) {
      this.memoryLimits.set(key, { count: 1, resetAt: now + windowMs });
      return { allowed: true, retryAfterSeconds: 0 };
    }
    if (record.count >= maxRequests) {
      return { allowed: false, retryAfterSeconds: Math.ceil((record.resetAt - now) / 1000) };
    }
    record.count += 1;
    return { allowed: true, retryAfterSeconds: 0 };
  }

  private static pruneMemoryLimits(now: number) {
    this.memoryChecks += 1;
    if (this.memoryChecks % 128 !== 0 && this.memoryLimits.size < this.MAX_MEMORY_KEYS) return;

    for (const [key, value] of this.memoryLimits) {
      if (value.resetAt <= now) this.memoryLimits.delete(key);
    }

    while (this.memoryLimits.size >= this.MAX_MEMORY_KEYS) {
      const oldestKey = this.memoryLimits.keys().next().value as string | undefined;
      if (!oldestKey) break;
      this.memoryLimits.delete(oldestKey);
    }
  }
}
