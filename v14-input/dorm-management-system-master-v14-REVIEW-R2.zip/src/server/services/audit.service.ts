/**
 * Enhanced Audit Logging Service
 * Records system activities for security compliance, user tracking, and data history (Who, When, IP, User Agent, Old/New Values).
 */

export interface DetailedAuditLogEntry {
  userId?: number | string | null;
  userEmail: string;
  userRole?: string;
  action: string; // e.g. 'LOGIN', 'LOGOUT', 'CREATE_BILL', 'EDIT_ROOM', 'SOFT_DELETE_ROOM'
  targetType: string; // e.g. 'room', 'bill', 'user', 'setting', 'contract'
  targetId?: string | number | null;
  oldValue?: object | string | null;
  newValue?: object | string | null;
  ipAddress?: string | null;
  userAgent?: string | null;
}

export async function logAuditAction(db: any, entry: DetailedAuditLogEntry) {
  if (!db) return;
  try {
    const oldValStr = typeof entry.oldValue === 'object' ? JSON.stringify(entry.oldValue) : entry.oldValue;
    const newValStr = typeof entry.newValue === 'object' ? JSON.stringify(entry.newValue) : entry.newValue;

    if (db.prepare) {
      // Cloudflare D1 (SQLite) API
      await db.prepare(
        `INSERT INTO audit_logs (user_id, user_email, user_role, action, target_type, target_id, old_value, new_value, ip_address, user_agent)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      ).bind(
        entry.userId || null,
        entry.userEmail || 'system',
        entry.userRole || 'owner',
        entry.action,
        entry.targetType,
        entry.targetId ? String(entry.targetId) : null,
        oldValStr || null,
        newValStr || null,
        entry.ipAddress || '127.0.0.1',
        entry.userAgent || 'Unknown'
      ).run();
    }
  } catch (e) {
    console.warn("Audit Log Record Warning:", e);
  }
}

/**
 * Strict variant for security-sensitive operations whose release criteria require
 * an audit record. Unlike logAuditAction, database failures are propagated.
 */
export async function logAuditActionStrict(db: any, entry: DetailedAuditLogEntry) {
  if (!db?.prepare) throw new Error('AUDIT_DATABASE_REQUIRED');
  const oldValStr = typeof entry.oldValue === 'object' ? JSON.stringify(entry.oldValue) : entry.oldValue;
  const newValStr = typeof entry.newValue === 'object' ? JSON.stringify(entry.newValue) : entry.newValue;
  const result = await db.prepare(
    `INSERT INTO audit_logs (user_id, user_email, user_role, action, target_type, target_id, old_value, new_value, ip_address, user_agent)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).bind(
    entry.userId || null,
    entry.userEmail || 'system',
    entry.userRole || 'owner',
    entry.action,
    entry.targetType,
    entry.targetId ? String(entry.targetId) : null,
    oldValStr || null,
    newValStr || null,
    entry.ipAddress || '127.0.0.1',
    entry.userAgent || 'Unknown'
  ).run();
  if (result && result.success === false) throw new Error(result.error || 'AUDIT_WRITE_FAILED');
}
