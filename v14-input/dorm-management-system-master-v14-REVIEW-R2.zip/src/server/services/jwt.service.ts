/**
 * Lightweight JWT Service using Web Crypto API
 * Compatible with Cloudflare Edge Workers and Node.js
 */

const base64UrlEncode = (buffer: ArrayBuffer | Uint8Array | string) => {
  let str = '';
  if (typeof buffer === 'string') {
    str = buffer;
  } else {
    const bytes = new Uint8Array(buffer);
    for (let i = 0; i < bytes.byteLength; i++) {
      str += String.fromCharCode(bytes[i]);
    }
  }
  return btoa(str)
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
};

const base64UrlDecode = (str: string) => {
  let base64 = str.replace(/-/g, '+').replace(/_/g, '/');
  while (base64.length % 4) {
    base64 += '=';
  }
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
};

const utf8Encoder = new TextEncoder();
const utf8Decoder = new TextDecoder();

export async function generateToken(payload: any, secret: string, expiresInHours = 24 * 7): Promise<string> {
  const header = { alg: 'HS256', typ: 'JWT' };
  const iat = Math.floor(Date.now() / 1000);
  const exp = iat + expiresInHours * 3600;
  const tokenPayload = { ...payload, iat, exp };

  const encodedHeader = base64UrlEncode(utf8Encoder.encode(JSON.stringify(header)));
  const encodedPayload = base64UrlEncode(utf8Encoder.encode(JSON.stringify(tokenPayload)));
  const dataToSign = `${encodedHeader}.${encodedPayload}`;

  const key = await crypto.subtle.importKey(
    'raw',
    utf8Encoder.encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );

  const signatureBuffer = await crypto.subtle.sign(
    'HMAC',
    key,
    utf8Encoder.encode(dataToSign)
  );

  const signature = base64UrlEncode(signatureBuffer);
  return `${dataToSign}.${signature}`;
}

export async function verifyToken(token: string, secret: string): Promise<any> {
  if (!token || typeof token !== 'string') {
    return null;
  }

  const parts = token.split('.');
  if (parts.length !== 3) {
    return null;
  }

  const [encodedHeader, encodedPayload, signature] = parts;
  const dataToSign = `${encodedHeader}.${encodedPayload}`;

  try {
    const key = await crypto.subtle.importKey(
      'raw',
      utf8Encoder.encode(secret),
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['verify']
    );

    const signatureBytes = base64UrlDecode(signature);
    const isValid = await crypto.subtle.verify(
      'HMAC',
      key,
      signatureBytes,
      utf8Encoder.encode(dataToSign)
    );

    if (!isValid) {
      return null;
    }

    const payloadString = utf8Decoder.decode(base64UrlDecode(encodedPayload));
    const payload = JSON.parse(payloadString);

    const now = Math.floor(Date.now() / 1000);
    if (payload.exp && payload.exp < now) {
      return null;
    }

    return payload;
  } catch (e) {
    console.error("JWT Verify Error:", e);
    return null;
  }
}
