import {
  exportBusinessBackup,
  snapshotCurrentIntegrationState,
  type CurrentIntegrationState,
  type D1DatabaseLike as BackupD1DatabaseLike,
} from './backup.service.ts';
import { sha256Hex, stableStringify, type BackupDataV1 } from '../../utils/backupFormat.ts';

export const RESTORE_DELETE_ORDER = [
  'bill_charge_items','room_recurring_charges','housekeeping_tasks','notes','maintenance_tickets',
  'lease_contracts','bills','announcements','recurring_charge_templates','rooms',
] as const;
export const RESTORE_INSERT_ORDER = [
  'rooms','recurring_charge_templates','bills','lease_contracts','maintenance_tickets','announcements',
  'room_recurring_charges','housekeeping_tasks','notes','bill_charge_items',
] as const;
export const RESTORE_BATCH_SIZE = 50;

type Row = Record<string, any>;
export interface RestoreStatementLike {
  bind(...values: unknown[]): RestoreStatementLike;
  first<T = Row>(): Promise<T | null>;
  all<T = Row>(): Promise<{ results?: T[] }>;
  run?(): Promise<{ success?: boolean; error?: string }>;
}
export interface RestoreD1DatabaseLike extends BackupD1DatabaseLike {
  prepare(sql: string): RestoreStatementLike;
  batch(statements: RestoreStatementLike[]): Promise<Array<{ success?: boolean; error?: string }> | unknown[]>;
}

export interface RestoreCurrentState {
  integrations: CurrentIntegrationState;
  existingUserIds: Set<number>;
  childUserIds: Set<number>;
}

export interface PreparedRestoreData {
  rooms: Row[]; bills: Row[]; recurringChargeTemplates: Row[]; roomRecurringCharges: Row[];
  billChargeItems: Row[]; maintenanceTickets: Row[]; housekeepingTasks: Row[]; leaseContracts: Row[];
  announcements: Row[]; notes: Row[]; settings: Record<string, unknown>;
  backupData: BackupDataV1;
  expectedIntegrations: CurrentIntegrationState;
}

export class RestorePartialFailure extends Error {
  code = 'RESTORE_PARTIAL_FAILURE' as const;
  recoveryRequired = true as const;
  constructor(public preRestoreDataSha256: string, cause?: unknown) {
    super('กู้คืนไม่สมบูรณ์ ให้ใช้ไฟล์ pre-restore ที่ดาวน์โหลดก่อนเริ่มรายการ');
    if (cause !== undefined) (this as any).cause = cause;
  }
}

export async function loadRestoreCurrentState(db: RestoreD1DatabaseLike, ownerId: number): Promise<RestoreCurrentState> {
  const integrations = await snapshotCurrentIntegrationState(db, ownerId);
  const userRows = await db.prepare('SELECT id, parent_id FROM users WHERE id = ? OR parent_id = ?').bind(ownerId, ownerId).all<{ id: number; parent_id?: number | null }>();
  const existingUserIds = new Set<number>([ownerId]);
  const childUserIds = new Set<number>();
  for (const row of userRows.results ?? []) {
    const id = Number(row.id);
    if (!Number.isInteger(id)) continue;
    existingUserIds.add(id);
    if (id !== ownerId && Number(row.parent_id) === ownerId) childUserIds.add(id);
  }
  return { integrations, existingUserIds, childUserIds };
}

function validActor(value: unknown, state: RestoreCurrentState, ownerId: number): number {
  const n = Number(value);
  return Number.isInteger(n) && state.existingUserIds.has(n) ? n : ownerId;
}
function validChild(value: unknown, state: RestoreCurrentState): number | null {
  if (value == null) return null;
  const n = Number(value);
  return Number.isInteger(n) && state.childUserIds.has(n) ? n : null;
}
function validDeletedBy(value: unknown, state: RestoreCurrentState, ownerId: number): number | null {
  if (value == null) return null;
  return validActor(value, state, ownerId);
}

export function prepareRestoreData(data: BackupDataV1, currentState: RestoreCurrentState, ownerId: number): PreparedRestoreData {
  const sortById = (rows: Record<string, unknown>[]) => [...rows].sort((a: any, b: any) => Number(a.id) - Number(b.id));
  const normalizedData = {
    ...data,
    rooms: sortById(data.rooms),
    bills: sortById(data.bills),
    recurringChargeTemplates: sortById(data.recurringChargeTemplates),
    roomRecurringCharges: sortById(data.roomRecurringCharges),
    billChargeItems: sortById(data.billChargeItems),
    maintenanceTickets: sortById(data.maintenanceTickets),
    housekeepingTasks: sortById(data.housekeepingTasks),
    leaseContracts: sortById(data.leaseContracts),
    announcements: sortById(data.announcements),
    notes: sortById(data.notes),
  };
  const lineByRoom = new Map(currentState.integrations.rooms.map((room) => [room.id, room]));
  const rooms = normalizedData.rooms.map((source: any) => {
    const line = lineByRoom.get(Number(source.id));
    return {
      ...source, userId: ownerId,
      deletedBy: validDeletedBy(source.deletedBy, currentState, ownerId),
      lineUserId: line?.lineUserId ?? null,
      lineDisplayName: line?.lineDisplayName ?? null,
      linePictureUrl: line?.linePictureUrl ?? null,
      lineStatus: line?.lineStatus ?? 'unlinked',
      lineNotifyToken: line?.lineNotifyToken ?? null,
    };
  });
  const bills = normalizedData.bills.map((source: any) => ({ ...source, userId: ownerId, deletedBy: validDeletedBy(source.deletedBy, currentState, ownerId) }));
  const recurringChargeTemplates = normalizedData.recurringChargeTemplates.map((source: any) => ({ ...source, userId: ownerId }));
  const roomRecurringCharges = normalizedData.roomRecurringCharges.map((source: any) => ({ ...source, userId: ownerId }));
  const billChargeItems = normalizedData.billChargeItems.map((source: any) => ({ ...source }));
  const maintenanceTickets = normalizedData.maintenanceTickets.map((source: any) => ({ ...source, userId: ownerId, deletedBy: validDeletedBy(source.deletedBy, currentState, ownerId) }));
  const leaseContracts = normalizedData.leaseContracts.map((source: any) => ({ ...source, userId: ownerId, deletedBy: validDeletedBy(source.deletedBy, currentState, ownerId) }));
  const announcements = normalizedData.announcements.map((source: any) => ({ ...source, userId: ownerId, deletedBy: validDeletedBy(source.deletedBy, currentState, ownerId) }));
  const notes = normalizedData.notes.map((source: any) => ({ ...source, userId: ownerId, createdBy: validActor(source.createdBy, currentState, ownerId), deletedBy: validDeletedBy(source.deletedBy, currentState, ownerId) }));
  const housekeepingTasks = normalizedData.housekeepingTasks.map((source: any) => ({ ...source, userId: ownerId, assignedUserId: validChild(source.assignedUserId, currentState), createdBy: validActor(source.createdBy, currentState, ownerId) }));

  const expectedIntegrations: CurrentIntegrationState = {
    rooms: rooms.map((room) => ({
      id: Number(room.id), lineUserId: room.lineUserId, lineDisplayName: room.lineDisplayName,
      linePictureUrl: room.linePictureUrl, lineStatus: room.lineStatus, lineNotifyToken: room.lineNotifyToken,
    })),
    settings: { ...currentState.integrations.settings },
  };

  const backupData: BackupDataV1 = {
    rooms: rooms.map(({ userId, lineUserId, lineDisplayName, linePictureUrl, lineStatus, lineNotifyToken, ...row }) => row),
    bills: bills.map(({ userId, ...row }) => row),
    recurringChargeTemplates: recurringChargeTemplates.map(({ userId, ...row }) => row),
    roomRecurringCharges: roomRecurringCharges.map(({ userId, ...row }) => row),
    billChargeItems: billChargeItems.map((row) => ({ ...row })),
    maintenanceTickets: maintenanceTickets.map(({ userId, ...row }) => row),
    housekeepingTasks: housekeepingTasks.map(({ userId, ...row }) => row),
    leaseContracts: leaseContracts.map(({ userId, ...row }) => row),
    announcements: announcements.map(({ userId, ...row }) => row),
    notes: notes.map(({ userId, ...row }) => row),
    settings: { ...data.settings },
  };

  return { rooms, bills, recurringChargeTemplates, roomRecurringCharges, billChargeItems, maintenanceTickets, housekeepingTasks, leaseContracts, announcements, notes, settings: { ...data.settings }, backupData, expectedIntegrations };
}

const DELETE_SQL = [
  'DELETE FROM bill_charge_items WHERE bill_id IN (SELECT id FROM bills WHERE user_id = ?)',
  'DELETE FROM room_recurring_charges WHERE user_id = ?',
  'DELETE FROM housekeeping_tasks WHERE user_id = ?',
  'DELETE FROM notes WHERE user_id = ?',
  'DELETE FROM maintenance_tickets WHERE user_id = ?',
  'DELETE FROM lease_contracts WHERE user_id = ?',
  'DELETE FROM bills WHERE user_id = ?',
  'DELETE FROM announcements WHERE user_id = ?',
  'DELETE FROM recurring_charge_templates WHERE user_id = ?',
  'DELETE FROM rooms WHERE user_id = ?',
] as const;

function insertSpec(table: typeof RESTORE_INSERT_ORDER[number], row: Row, ownerId: number): { sql: string; values: unknown[] } {
  switch (table) {
    case 'rooms': return { sql: `INSERT INTO rooms (id,user_id,room_number,monthly_rent,status,tenant_name,tenant_phone,line_user_id,line_display_name,line_picture_url,line_status,line_notify_token,created_at,deleted_at,deleted_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, values: [row.id,ownerId,row.roomNumber,row.monthlyRent,row.status,row.tenantName,row.tenantPhone,row.lineUserId,row.lineDisplayName,row.linePictureUrl,row.lineStatus,row.lineNotifyToken,row.createdAt,row.deletedAt,row.deletedBy] };
    case 'recurring_charge_templates': return { sql: `INSERT INTO recurring_charge_templates (id,user_id,name,description,default_amount,frequency,billing_months,is_active,created_at,updated_at,deleted_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)`, values: [row.id,ownerId,row.name,row.description,row.defaultAmount,row.frequency,row.billingMonths,row.isActive,row.createdAt,row.updatedAt,row.deletedAt] };
    case 'bills': return { sql: `INSERT INTO bills (id,user_id,room_id,bill_month,prior_elec,current_elec,elec_deduct,elec_unit_cost,elec_cost,prior_water,current_water,water_unit_cost,water_cost,rent_cost,deposit_cost,other_cost,other_description,total_cost,due_date,status,paid_at,slip_image,slip_uploaded_at,slip_status,created_at,deleted_at,deleted_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, values: [row.id,ownerId,row.roomId,row.billMonth,row.priorElec,row.currentElec,row.elecDeduct,row.elecUnitCost,row.elecCost,row.priorWater,row.currentWater,row.waterUnitCost,row.waterCost,row.rentCost,row.depositCost,row.otherCost,row.otherDescription,row.totalCost,row.dueDate,row.status,row.paidAt,row.slipImage,row.slipUploadedAt,row.slipStatus,row.createdAt,row.deletedAt,row.deletedBy] };
    case 'lease_contracts': return { sql: `INSERT INTO lease_contracts (id,user_id,room_id,room_number,tenant_name,tenant_phone,id_card_number,start_date,end_date,monthly_rent,deposit_amount,advance_rent_amount,contract_document_url,status,note,created_at,updated_at,deleted_at,deleted_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, values: [row.id,ownerId,row.roomId,row.roomNumber,row.tenantName,row.tenantPhone,row.idCardNumber,row.startDate,row.endDate,row.monthlyRent,row.depositAmount,row.advanceRentAmount,row.contractDocumentUrl,row.status,row.note,row.createdAt,row.updatedAt,row.deletedAt,row.deletedBy] };
    case 'maintenance_tickets': return { sql: `INSERT INTO maintenance_tickets (id,user_id,room_id,room_number,tenant_name,tenant_phone,title,description,category,priority,status,image_url,repair_cost,technician_note,created_at,updated_at,deleted_at,deleted_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, values: [row.id,ownerId,row.roomId,row.roomNumber,row.tenantName,row.tenantPhone,row.title,row.description,row.category,row.priority,row.status,row.imageUrl,row.repairCost,row.technicianNote,row.createdAt,row.updatedAt,row.deletedAt,row.deletedBy] };
    case 'announcements': return { sql: `INSERT INTO announcements (id,user_id,title,content,category,is_pinned,target_room_ids,image_url,created_at,updated_at,deleted_at,deleted_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`, values: [row.id,ownerId,row.title,row.content,row.category,row.isPinned,row.targetRoomIds,row.imageUrl,row.createdAt,row.updatedAt,row.deletedAt,row.deletedBy] };
    case 'room_recurring_charges': return { sql: `INSERT INTO room_recurring_charges (id,user_id,room_id,template_id,amount_override,is_enabled,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)`, values: [row.id,ownerId,row.roomId,row.templateId,row.amountOverride,row.isEnabled,row.createdAt,row.updatedAt] };
    case 'housekeeping_tasks': return { sql: `INSERT INTO housekeeping_tasks (id,user_id,room_id,assigned_user_id,contract_id,source,status,note,inspection_note,created_by,created_at,updated_at,completed_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`, values: [row.id,ownerId,row.roomId,row.assignedUserId,row.contractId,row.source,row.status,row.note,row.inspectionNote,row.createdBy,row.createdAt,row.updatedAt,row.completedAt] };
    case 'notes': return { sql: `INSERT INTO notes (id,user_id,created_by,room_id,title,content,color,is_pinned,created_at,updated_at,deleted_at,deleted_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`, values: [row.id,ownerId,row.createdBy,row.roomId,row.title,row.content,row.color,row.isPinned,row.createdAt,row.updatedAt,row.deletedAt,row.deletedBy] };
    case 'bill_charge_items': return { sql: `INSERT INTO bill_charge_items (id,bill_id,assignment_id,label,amount,kind,sort_order,created_at) VALUES (?,?,?,?,?,?,?,?)`, values: [row.id,row.billId,row.assignmentId,row.label,row.amount,row.kind,row.sortOrder,row.createdAt] };
  }
}

function rowsForTable(data: PreparedRestoreData, table: typeof RESTORE_INSERT_ORDER[number]): Row[] {
  const map: Record<typeof RESTORE_INSERT_ORDER[number], keyof PreparedRestoreData> = {
    rooms:'rooms', recurring_charge_templates:'recurringChargeTemplates', bills:'bills', lease_contracts:'leaseContracts', maintenance_tickets:'maintenanceTickets', announcements:'announcements', room_recurring_charges:'roomRecurringCharges', housekeeping_tasks:'housekeepingTasks', notes:'notes', bill_charge_items:'billChargeItems',
  };
  return data[map[table]] as Row[];
}

function ensureBatchSuccess(results: unknown[], label: string): void {
  for (const result of results as Array<{ success?: boolean; error?: string }>) {
    if (result && result.success === false) throw new Error(`${label}:${result.error ?? 'D1_BATCH_FAILED'}`);
  }
}

export async function restoreBusinessBackup(db: RestoreD1DatabaseLike, ownerId: number, preparedData: PreparedRestoreData): Promise<{ preRestoreDataSha256: string }> {
  const pre = await exportBusinessBackup(db, ownerId, 'pre-restore');
  const preRestoreDataSha256 = await sha256Hex(stableStringify(pre.data));
  try {
    const deletes = DELETE_SQL.map((sql) => db.prepare(sql).bind(ownerId));
    ensureBatchSuccess(await db.batch(deletes), 'DELETE');
    for (const table of RESTORE_INSERT_ORDER) {
      const rows = rowsForTable(preparedData, table);
      for (let index = 0; index < rows.length; index += RESTORE_BATCH_SIZE) {
        const chunk = rows.slice(index, index + RESTORE_BATCH_SIZE).map((row) => {
          const spec = insertSpec(table, row, ownerId);
          return db.prepare(spec.sql).bind(...spec.values);
        });
        if (chunk.length) ensureBatchSuccess(await db.batch(chunk), `INSERT:${table}`);
      }
    }
    const s: any = preparedData.settings;
    const settingsStmt = db.prepare(`UPDATE settings SET dorm_name=?,default_elec_rate=?,default_water_rate=?,default_due_date_day=?,default_penalty_rate=?,promptpay_id=?,promptpay_name=?,font_scale=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(s.dormName,s.defaultElecRate,s.defaultWaterRate,s.defaultDueDateDay,s.defaultPenaltyRate,s.promptpayId,s.promptpayName,s.fontScale,ownerId);
    ensureBatchSuccess(await db.batch([settingsStmt]), 'SETTINGS');
    return { preRestoreDataSha256 };
  } catch (error) {
    throw new RestorePartialFailure(preRestoreDataSha256, error);
  }
}

export async function verifyRestoredBackup(db: RestoreD1DatabaseLike, ownerId: number, expected: PreparedRestoreData): Promise<void> {
  const owner = await db.prepare('SELECT id FROM users WHERE id = ? LIMIT 1').bind(ownerId).first<{ id: number }>();
  if (Number(owner?.id) !== ownerId) throw new Error('RESTORE_OWNER_MISSING');
  const after = await exportBusinessBackup(db, ownerId, 'verify');
  if (stableStringify(after.data) !== stableStringify(expected.backupData)) throw new Error('RESTORE_BUSINESS_DATA_MISMATCH');
  const integrations = await snapshotCurrentIntegrationState(db, ownerId);
  if (stableStringify(integrations) !== stableStringify(expected.expectedIntegrations)) throw new Error('RESTORE_INTEGRATION_STATE_CHANGED');
}
