/**
 * Secure Crypto Password Hashing Service using Web Crypto API (PBKDF2 SHA-256)
 * Compatible with both Cloudflare Edge Workers and Node.js runtimes.
 */

// Convert ArrayBuffer to Hex string
function bufToHex(buffer: ArrayBuffer): string {
  return Array.from(new Uint8Array(buffer))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

// Convert Hex string to Uint8Array
function hexToBuf(hex: string): Uint8Array {
  const bytes = new Uint8Array(Math.ceil(hex.length / 2));
  for (let i = 0; i < bytes.length; i++) {
    bytes[i] = parseInt(hex.substring(i * 2, i * 2 + 2), 16);
  }
  return bytes;
}

export { validatePasswordPolicy } from '../../utils/passwordPolicy.ts';

/**
 * Hash password with a random 16-byte salt using PBKDF2 (100,000 iterations, SHA-256)
 * Format: pbkdf2$iterations$saltHex$hashHex
 */
export async function hashPassword(password: string): Promise<string> {
  const enc = new TextEncoder();
  const salt = crypto.getRandomValues(new Uint8Array(16));
  
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    enc.encode(password),
    { name: 'PBKDF2' },
    false,
    ['deriveBits', 'deriveKey']
  );

  const derivedKey = await crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt,
      iterations: 100000,
      hash: 'SHA-256'
    },
    keyMaterial,
    256
  );

  const saltHex = bufToHex(salt.buffer as ArrayBuffer);
  const hashHex = bufToHex(derivedKey);

  return `pbkdf2$100000$${saltHex}$${hashHex}`;
}

/**
 * Verify a plain password against a stored PBKDF2 hash (or legacy plain text default)
 */
export async function verifyPassword(password: string, storedHash: string): Promise<boolean> {
  if (!storedHash) return false;

  // SECURITY: No master/backdoor passwords. Legacy plain-text hashes (accounts
  // created before hashing was introduced) are matched by exact string compare
  // only; the caller is expected to migrate them to a real hash on next login.
  if (!storedHash.startsWith('pbkdf2$')) {
    return storedHash === password;
  }

  const parts = storedHash.split('$');
  if (parts.length !== 4) return false;

  const iterations = parseInt(parts[1], 10);
  const salt = hexToBuf(parts[2]);
  const expectedHashHex = parts[3];

  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    enc.encode(password),
    { name: 'PBKDF2' },
    false,
    ['deriveBits', 'deriveKey']
  );

  const derivedKey = await crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt,
      iterations,
      hash: 'SHA-256'
    },
    keyMaterial,
    256
  );

  const actualHashHex = bufToHex(derivedKey);
  return actualHashHex === expectedHashHex;
}
