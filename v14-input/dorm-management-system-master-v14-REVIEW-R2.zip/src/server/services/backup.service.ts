import {
  BACKUP_FORMAT,
  BACKUP_FORMAT_VERSION,
  BACKUP_SCHEMA_VERSION,
  computeBackupCounts,
  sha256Hex,
  stableStringify,
  type BackupDataV1,
  type BackupManifestV1,
  type BackupSafeSettingsV1,
} from '../../utils/backupFormat.ts';

type D1Row = Record<string, unknown>;

export interface D1StatementLike {
  bind(...values: unknown[]): D1StatementLike;
  first<T = D1Row>(): Promise<T | null>;
  all<T = D1Row>(): Promise<{ results?: T[] }>;
}

export interface D1DatabaseLike {
  prepare(sql: string): D1StatementLike;
}

export const BACKUP_EXCLUDED = [
  'users',
  'audit_logs',
  'rate_limits',
  'google_oauth_states',
  'google_oauth_tokens',
  'line_event_logs',
  'integration_secrets',
  'room_line_linkage',
  'subscription_metadata',
] as const;

export interface CurrentIntegrationState {
  rooms: Array<{
    id: number;
    lineUserId?: string | null;
    lineDisplayName?: string | null;
    linePictureUrl?: string | null;
    lineStatus?: string | null;
    lineNotifyToken?: string | null;
  }>;
  settings: {
    lineChannelAccessToken?: string | null;
    lineChannelSecret?: string | null;
    lineBotEnabled?: number | null;
    googleSpreadsheetId?: string | null;
    subscriptionPlan?: string | null;
    subscriptionStatus?: string | null;
    subscriptionExpiresAt?: string | null;
  };
}

export async function computeOwnerScope(ownerUid: string): Promise<string> {
  const normalized = String(ownerUid);
  if (!normalized) throw new Error('BACKUP_OWNER_UID_REQUIRED');
  return sha256Hex(normalized);
}

function camelRow(row: D1Row, mapping: Record<string, string>): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [dbKey, dtoKey] of Object.entries(mapping)) out[dtoKey] = row[dbKey];
  return out;
}

async function allRows(db: D1DatabaseLike, sql: string, ownerId: number): Promise<D1Row[]> {
  const result = await db.prepare(sql).bind(ownerId).all<D1Row>();
  return Array.isArray(result.results) ? result.results : [];
}

async function firstRow(db: D1DatabaseLike, sql: string, ownerId: number): Promise<D1Row | null> {
  return db.prepare(sql).bind(ownerId).first<D1Row>();
}

const ROOM_MAP = {
  id: 'id', room_number: 'roomNumber', monthly_rent: 'monthlyRent', status: 'status',
  tenant_name: 'tenantName', tenant_phone: 'tenantPhone', created_at: 'createdAt',
  deleted_at: 'deletedAt', deleted_by: 'deletedBy',
};
const BILL_MAP = {
  id: 'id', room_id: 'roomId', bill_month: 'billMonth', prior_elec: 'priorElec',
  current_elec: 'currentElec', elec_deduct: 'elecDeduct', elec_unit_cost: 'elecUnitCost',
  elec_cost: 'elecCost', prior_water: 'priorWater', current_water: 'currentWater',
  water_unit_cost: 'waterUnitCost', water_cost: 'waterCost', rent_cost: 'rentCost',
  deposit_cost: 'depositCost', other_cost: 'otherCost', other_description: 'otherDescription',
  total_cost: 'totalCost', due_date: 'dueDate', status: 'status', paid_at: 'paidAt',
  slip_image: 'slipImage', slip_uploaded_at: 'slipUploadedAt', slip_status: 'slipStatus',
  created_at: 'createdAt', deleted_at: 'deletedAt', deleted_by: 'deletedBy',
};
const TEMPLATE_MAP = {
  id: 'id', name: 'name', description: 'description', default_amount: 'defaultAmount',
  frequency: 'frequency', billing_months: 'billingMonths', is_active: 'isActive',
  created_at: 'createdAt', updated_at: 'updatedAt', deleted_at: 'deletedAt',
};
const ASSIGNMENT_MAP = {
  id: 'id', room_id: 'roomId', template_id: 'templateId', amount_override: 'amountOverride',
  is_enabled: 'isEnabled', created_at: 'createdAt', updated_at: 'updatedAt',
};
const CHARGE_ITEM_MAP = {
  id: 'id', bill_id: 'billId', assignment_id: 'assignmentId', label: 'label', amount: 'amount',
  kind: 'kind', sort_order: 'sortOrder', created_at: 'createdAt',
};
const MAINTENANCE_MAP = {
  id: 'id', room_id: 'roomId', room_number: 'roomNumber', tenant_name: 'tenantName',
  tenant_phone: 'tenantPhone', title: 'title', description: 'description', category: 'category',
  priority: 'priority', status: 'status', image_url: 'imageUrl', repair_cost: 'repairCost',
  technician_note: 'technicianNote', created_at: 'createdAt', updated_at: 'updatedAt',
  deleted_at: 'deletedAt', deleted_by: 'deletedBy',
};
const HOUSEKEEPING_MAP = {
  id: 'id', room_id: 'roomId', assigned_user_id: 'assignedUserId', contract_id: 'contractId',
  source: 'source', status: 'status', note: 'note', inspection_note: 'inspectionNote',
  created_by: 'createdBy', created_at: 'createdAt', updated_at: 'updatedAt', completed_at: 'completedAt',
};
const CONTRACT_MAP = {
  id: 'id', room_id: 'roomId', room_number: 'roomNumber', tenant_name: 'tenantName',
  tenant_phone: 'tenantPhone', id_card_number: 'idCardNumber', start_date: 'startDate', end_date: 'endDate',
  monthly_rent: 'monthlyRent', deposit_amount: 'depositAmount', advance_rent_amount: 'advanceRentAmount',
  contract_document_url: 'contractDocumentUrl', status: 'status', note: 'note', created_at: 'createdAt',
  updated_at: 'updatedAt', deleted_at: 'deletedAt', deleted_by: 'deletedBy',
};
const ANNOUNCEMENT_MAP = {
  id: 'id', title: 'title', content: 'content', category: 'category', is_pinned: 'isPinned',
  target_room_ids: 'targetRoomIds', image_url: 'imageUrl', created_at: 'createdAt',
  updated_at: 'updatedAt', deleted_at: 'deletedAt', deleted_by: 'deletedBy',
};
const NOTE_MAP = {
  id: 'id', created_by: 'createdBy', room_id: 'roomId', title: 'title', content: 'content',
  color: 'color', is_pinned: 'isPinned', created_at: 'createdAt', updated_at: 'updatedAt',
  deleted_at: 'deletedAt', deleted_by: 'deletedBy',
};

function safeSettings(row: D1Row): BackupSafeSettingsV1 {
  return {
    dormName: String(row.dorm_name ?? 'หอพักของฉัน'),
    defaultElecRate: Number(row.default_elec_rate ?? 7),
    defaultWaterRate: Number(row.default_water_rate ?? 13),
    defaultDueDateDay: Number(row.default_due_date_day ?? 5),
    defaultPenaltyRate: Number(row.default_penalty_rate ?? 100),
    promptpayId: row.promptpay_id == null ? null : String(row.promptpay_id),
    promptpayName: row.promptpay_name == null ? null : String(row.promptpay_name),
    fontScale: row.font_scale === 'small' || row.font_scale === 'large' ? row.font_scale : 'medium',
  };
}

export async function exportBusinessBackup(
  db: D1DatabaseLike,
  ownerId: number,
  appVersion: string,
): Promise<{ manifest: BackupManifestV1; data: BackupDataV1 }> {
  const owner = await firstRow(db, 'SELECT uid FROM users WHERE id = ? LIMIT 1', ownerId);
  if (!owner?.uid) throw new Error('BACKUP_OWNER_NOT_FOUND');

  const [
    roomsRaw, billsRaw, templatesRaw, assignmentsRaw, chargeItemsRaw,
    maintenanceRaw, housekeepingRaw, contractsRaw, announcementsRaw, notesRaw,
  ] = await Promise.all([
    allRows(db, `SELECT id, room_number, monthly_rent, status, tenant_name, tenant_phone,
      created_at, deleted_at, deleted_by FROM rooms WHERE user_id = ? ORDER BY id`, ownerId),
    allRows(db, `SELECT id, room_id, bill_month, prior_elec, current_elec, elec_deduct, elec_unit_cost,
      elec_cost, prior_water, current_water, water_unit_cost, water_cost, rent_cost, deposit_cost,
      other_cost, other_description, total_cost, due_date, status, paid_at, slip_image,
      slip_uploaded_at, slip_status, created_at, deleted_at, deleted_by
      FROM bills WHERE user_id = ? ORDER BY id`, ownerId),
    allRows(db, `SELECT id, name, description, default_amount, frequency, billing_months, is_active,
      created_at, updated_at, deleted_at FROM recurring_charge_templates WHERE user_id = ? ORDER BY id`, ownerId),
    allRows(db, `SELECT id, room_id, template_id, amount_override, is_enabled, created_at, updated_at
      FROM room_recurring_charges WHERE user_id = ? ORDER BY id`, ownerId),
    allRows(db, `SELECT bci.id, bci.bill_id, bci.assignment_id, bci.label, bci.amount, bci.kind,
      bci.sort_order, bci.created_at FROM bill_charge_items bci
      JOIN bills b ON b.id = bci.bill_id WHERE b.user_id = ? ORDER BY bci.id`, ownerId),
    allRows(db, `SELECT id, room_id, room_number, tenant_name, tenant_phone, title, description,
      category, priority, status, image_url, repair_cost, technician_note, created_at, updated_at,
      deleted_at, deleted_by FROM maintenance_tickets WHERE user_id = ? ORDER BY id`, ownerId),
    allRows(db, `SELECT id, room_id, assigned_user_id, contract_id, source, status, note,
      inspection_note, created_by, created_at, updated_at, completed_at
      FROM housekeeping_tasks WHERE user_id = ? ORDER BY id`, ownerId),
    allRows(db, `SELECT id, room_id, room_number, tenant_name, tenant_phone, id_card_number,
      start_date, end_date, monthly_rent, deposit_amount, advance_rent_amount, contract_document_url,
      status, note, created_at, updated_at, deleted_at, deleted_by
      FROM lease_contracts WHERE user_id = ? ORDER BY id`, ownerId),
    allRows(db, `SELECT id, title, content, category, is_pinned, target_room_ids, image_url,
      created_at, updated_at, deleted_at, deleted_by FROM announcements WHERE user_id = ? ORDER BY id`, ownerId),
    allRows(db, `SELECT id, created_by, room_id, title, content, color, is_pinned, created_at,
      updated_at, deleted_at, deleted_by FROM notes WHERE user_id = ? ORDER BY id`, ownerId),
  ]);

  const settingsRaw = await firstRow(db, `SELECT dorm_name, default_elec_rate, default_water_rate,
    default_due_date_day, default_penalty_rate, promptpay_id, promptpay_name, font_scale
    FROM settings WHERE user_id = ? LIMIT 1`, ownerId);
  if (!settingsRaw) throw new Error('BACKUP_SETTINGS_NOT_FOUND');

  const data: BackupDataV1 = {
    rooms: roomsRaw.map((row) => camelRow(row, ROOM_MAP)),
    bills: billsRaw.map((row) => camelRow(row, BILL_MAP)),
    recurringChargeTemplates: templatesRaw.map((row) => camelRow(row, TEMPLATE_MAP)),
    roomRecurringCharges: assignmentsRaw.map((row) => camelRow(row, ASSIGNMENT_MAP)),
    billChargeItems: chargeItemsRaw.map((row) => camelRow(row, CHARGE_ITEM_MAP)),
    maintenanceTickets: maintenanceRaw.map((row) => camelRow(row, MAINTENANCE_MAP)),
    housekeepingTasks: housekeepingRaw.map((row) => camelRow(row, HOUSEKEEPING_MAP)),
    leaseContracts: contractsRaw.map((row) => camelRow(row, CONTRACT_MAP)),
    announcements: announcementsRaw.map((row) => camelRow(row, ANNOUNCEMENT_MAP)),
    notes: notesRaw.map((row) => camelRow(row, NOTE_MAP)),
    settings: safeSettings(settingsRaw),
  };

  const ownerScope = await computeOwnerScope(String(owner.uid));
  const manifest: BackupManifestV1 = {
    format: BACKUP_FORMAT,
    formatVersion: BACKUP_FORMAT_VERSION,
    appVersion,
    schemaVersion: BACKUP_SCHEMA_VERSION,
    createdAt: new Date().toISOString(),
    ownerScope,
    dormName: data.settings.dormName,
    counts: computeBackupCounts(data),
    excluded: [...BACKUP_EXCLUDED],
    dataSha256: await sha256Hex(stableStringify(data)),
  };

  return { manifest, data };
}

export async function snapshotCurrentIntegrationState(
  db: D1DatabaseLike,
  ownerId: number,
): Promise<CurrentIntegrationState> {
  const rooms = await allRows(db, `SELECT id, line_user_id, line_display_name, line_picture_url,
    line_status, line_notify_token FROM rooms WHERE user_id = ? ORDER BY id`, ownerId);
  const settings = await firstRow(db, `SELECT line_channel_access_token, line_channel_secret,
    line_bot_enabled, google_spreadsheet_id, subscription_plan, subscription_status,
    subscription_expires_at FROM settings WHERE user_id = ? LIMIT 1`, ownerId);

  return {
    rooms: rooms.map((row) => ({
      id: Number(row.id),
      lineUserId: row.line_user_id as string | null | undefined,
      lineDisplayName: row.line_display_name as string | null | undefined,
      linePictureUrl: row.line_picture_url as string | null | undefined,
      lineStatus: row.line_status as string | null | undefined,
      lineNotifyToken: row.line_notify_token as string | null | undefined,
    })),
    settings: {
      lineChannelAccessToken: settings?.line_channel_access_token as string | null | undefined,
      lineChannelSecret: settings?.line_channel_secret as string | null | undefined,
      lineBotEnabled: settings?.line_bot_enabled as number | null | undefined,
      googleSpreadsheetId: settings?.google_spreadsheet_id as string | null | undefined,
      subscriptionPlan: settings?.subscription_plan as string | null | undefined,
      subscriptionStatus: settings?.subscription_status as string | null | undefined,
      subscriptionExpiresAt: settings?.subscription_expires_at as string | null | undefined,
    },
  };
}

import { generateToken, verifyToken } from './jwt.service.ts';
import { BackupRestoreRequestSchema, BackupValidationError, validateBackupReferences } from '../validators/backup.ts';

export const RESTORE_TOKEN_TTL_SECONDS = 600;

export interface RestoreTokenBinding {
  ownerId: number;
  ownerScope: string;
  dataSha256: string;
  formatVersion?: number;
}

export interface RestorePreviewRow { current: number; backup: number; }
export type RestorePreview = Record<keyof BackupManifestV1['counts'], RestorePreviewRow>;

export interface BackupValidationResult {
  valid: true;
  restoreToken: string;
  expiresInSeconds: typeof RESTORE_TOKEN_TTL_SECONDS;
  preview: RestorePreview;
  warnings: string[];
}

export async function createRestoreToken(binding: RestoreTokenBinding, secret: string): Promise<string> {
  if (!secret || secret.length < 32) throw new BackupValidationError('JWT_SECRET_INVALID', 500);
  return generateToken({
    purpose: 'dorm-backup-restore',
    ownerId: binding.ownerId,
    ownerScope: binding.ownerScope,
    dataSha256: binding.dataSha256,
    formatVersion: binding.formatVersion ?? BACKUP_FORMAT_VERSION,
  }, secret, 1 / 6);
}

export async function verifyRestoreToken(
  token: string,
  secret: string,
  expected: RestoreTokenBinding,
): Promise<{ ok: true; payload: Record<string, unknown> } | { ok: false }> {
  const payload = await verifyToken(token, secret);
  if (!payload || typeof payload !== 'object') return { ok: false };
  const iat = Number(payload.iat ?? 0);
  const exp = Number(payload.exp ?? 0);
  const lifetime = exp - iat;
  const now = Math.floor(Date.now() / 1000);
  if (!Number.isFinite(iat) || !Number.isFinite(exp) || lifetime <= 0 || lifetime > RESTORE_TOKEN_TTL_SECONDS || exp < now) return { ok: false };
  if (payload.purpose !== 'dorm-backup-restore') return { ok: false };
  if (Number(payload.ownerId) !== expected.ownerId) return { ok: false };
  if (String(payload.ownerScope ?? '') !== expected.ownerScope) return { ok: false };
  if (String(payload.dataSha256 ?? '') !== expected.dataSha256) return { ok: false };
  if (Number(payload.formatVersion) !== (expected.formatVersion ?? BACKUP_FORMAT_VERSION)) return { ok: false };
  return { ok: true, payload };
}

const CURRENT_COUNT_QUERIES: Record<keyof BackupManifestV1['counts'], string | null> = {
  rooms: 'SELECT COUNT(*) AS count FROM rooms WHERE user_id = ?',
  bills: 'SELECT COUNT(*) AS count FROM bills WHERE user_id = ?',
  recurringChargeTemplates: 'SELECT COUNT(*) AS count FROM recurring_charge_templates WHERE user_id = ?',
  roomRecurringCharges: 'SELECT COUNT(*) AS count FROM room_recurring_charges WHERE user_id = ?',
  billChargeItems: `SELECT COUNT(*) AS count FROM bill_charge_items bci JOIN bills b ON b.id = bci.bill_id WHERE b.user_id = ?`,
  maintenanceTickets: 'SELECT COUNT(*) AS count FROM maintenance_tickets WHERE user_id = ?',
  housekeepingTasks: 'SELECT COUNT(*) AS count FROM housekeeping_tasks WHERE user_id = ?',
  leaseContracts: 'SELECT COUNT(*) AS count FROM lease_contracts WHERE user_id = ?',
  announcements: 'SELECT COUNT(*) AS count FROM announcements WHERE user_id = ?',
  notes: 'SELECT COUNT(*) AS count FROM notes WHERE user_id = ?',
  settings: null,
};

async function countCurrentBackupRows(db: D1DatabaseLike, ownerId: number): Promise<Record<keyof BackupManifestV1['counts'], number>> {
  const out = {} as Record<keyof BackupManifestV1['counts'], number>;
  for (const [key, sql] of Object.entries(CURRENT_COUNT_QUERIES) as Array<[keyof BackupManifestV1['counts'], string | null]>) {
    if (!sql) { out[key] = 1; continue; }
    const row = await db.prepare(sql).bind(ownerId).first<{ count?: number | string }>();
    out[key] = Number(row?.count ?? 0);
  }
  return out;
}

async function currentUserSets(db: D1DatabaseLike, ownerId: number): Promise<{ existingUserIds: Set<number>; childUserIds: Set<number> }> {
  const users = await db.prepare('SELECT id, parent_id, role FROM users WHERE id = ? OR parent_id = ?').bind(ownerId, ownerId).all<{ id: number; parent_id?: number | null; role?: string }>();
  const rows = users.results ?? [];
  const existingUserIds = new Set<number>([ownerId]);
  const childUserIds = new Set<number>();
  for (const row of rows) {
    const id = Number(row.id);
    if (!Number.isInteger(id)) continue;
    existingUserIds.add(id);
    if (id !== ownerId && Number(row.parent_id) === ownerId) childUserIds.add(id);
  }
  return { existingUserIds, childUserIds };
}

export async function validateBackupForRestore(
  db: D1DatabaseLike,
  ownerId: number,
  jwtSecret: string,
  input: { manifest: unknown; data: unknown },
): Promise<BackupValidationResult> {
  let parsed: { manifest: BackupManifestV1; data: BackupDataV1 };
  try {
    parsed = BackupRestoreRequestSchema.parse(input) as { manifest: BackupManifestV1; data: BackupDataV1 };
  } catch {
    throw new BackupValidationError('BACKUP_SCHEMA_INVALID', 400);
  }

  const { manifest, data } = parsed;
  const actualHash = await sha256Hex(stableStringify(data));
  if (actualHash !== manifest.dataSha256) throw new BackupValidationError('BACKUP_HASH_MISMATCH', 400);
  const actualCounts = computeBackupCounts(data);
  for (const key of Object.keys(actualCounts) as Array<keyof typeof actualCounts>) {
    if (actualCounts[key] !== manifest.counts[key]) throw new BackupValidationError('BACKUP_COUNT_MISMATCH', 400, `BACKUP_COUNT_MISMATCH:${String(key)}`);
  }

  const owner = await db.prepare('SELECT uid FROM users WHERE id = ? LIMIT 1').bind(ownerId).first<{ uid?: string }>();
  if (!owner?.uid) throw new BackupValidationError('BACKUP_OWNER_NOT_FOUND', 403);
  const ownerScope = await computeOwnerScope(String(owner.uid));
  if (ownerScope !== manifest.ownerScope) throw new BackupValidationError('BACKUP_OWNER_SCOPE_MISMATCH', 403);

  const users = await currentUserSets(db, ownerId);
  const referenceResult = validateBackupReferences(data, { ownerId, ...users });
  const currentCounts = await countCurrentBackupRows(db, ownerId);
  const preview = {} as RestorePreview;
  for (const key of Object.keys(manifest.counts) as Array<keyof BackupManifestV1['counts']>) {
    preview[key] = { current: currentCounts[key], backup: manifest.counts[key] };
  }

  const restoreToken = await createRestoreToken({ ownerId, ownerScope, dataSha256: actualHash, formatVersion: manifest.formatVersion }, jwtSecret);
  return {
    valid: true,
    restoreToken,
    expiresInSeconds: RESTORE_TOKEN_TTL_SECONDS,
    preview,
    warnings: [
      ...referenceResult.warnings,
      'ข้อมูลผู้ใช้และรหัสผ่านจะไม่เปลี่ยน',
      'LINE/Google credentials และการผูก LINE ปัจจุบันจะไม่เปลี่ยน',
      'Audit history เดิมจะไม่ถูกย้อนกลับ',
    ],
  };
}
