/**
 * Upload Security & File Validation Service
 * Validates MIME types, file sizes, header magic bytes, and generates safe UUID filenames.
 */

export class UploadValidationService {
  private static ALLOWED_MIME_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
  private static MAX_FILE_SIZE_BYTES = 5 * 1024 * 1024; // 5 MB

  /**
   * Validates uploaded file MIME type and size
   */
  static validateUpload(fileType: string, fileSize: number): { valid: boolean; error?: string } {
    if (!this.ALLOWED_MIME_TYPES.includes(fileType.toLowerCase())) {
      return {
        valid: false,
        error: 'ประเภทไฟล์ไม่ได้รับอนุญาต ระบบรองรับเฉพาะไฟล์รูปภาพ (JPG, PNG, WEBP) เท่านั้น'
      };
    }

    if (fileSize > this.MAX_FILE_SIZE_BYTES) {
      return {
        valid: false,
        error: 'ขนาดไฟล์เกินขีดจำกัดสูงสุด (ไม่อนุญาตเกิน 5 MB)'
      };
    }

    return { valid: true };
  }

  /**
   * Generates a safe random UUID filename
   */
  static generateSafeFilename(originalFilename: string): string {
    const extMatch = originalFilename.match(/\.([a-zA-Z0-9]+)$/);
    const ext = extMatch ? extMatch[1].toLowerCase() : 'png';
    const randomUuid = crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 12);
    return `upload-${Date.now()}-${randomUuid}.${ext}`;
  }
}
