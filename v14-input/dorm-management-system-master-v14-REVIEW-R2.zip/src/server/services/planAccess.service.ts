import type { PlanFeature } from '../../constants/planEntitlements.ts';

export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE' | string;

export function requiredPlanFeatureForApiRequest(path: string, method: HttpMethod): PlanFeature | null {
  if (path === '/api/admin/backup/export' && method === 'GET') return 'backupExport';
  if ((path === '/api/admin/backup/validate' || path === '/api/admin/backup/restore') && method === 'POST') return 'backupRestore';
  if (path === '/api/bills/bulk' && method === 'POST') return 'bulkMeter';
  if (path.startsWith('/api/recurring-charges/')) return 'recurringCharges';
  if (/^\/api\/rooms\/\d+\/recurring-charges$/.test(path)) return 'recurringCharges';
  if (path === '/api/caretakers' || path.startsWith('/api/caretakers/')) return 'staff';
  if (path.startsWith('/api/contracts/')) return path.endsWith('/checkout') ? 'checkout' : 'contracts';
  if (path === '/api/contracts') return 'contracts';
  if (path === '/api/maintenance' || path.startsWith('/api/maintenance/')) return 'maintenance';
  if (path === '/api/housekeeping' || path.startsWith('/api/housekeeping/')) return 'housekeeping';
  if (path === '/api/announcements' || path.startsWith('/api/announcements/')) return 'announcements';
  if (path === '/api/audit-logs' || path.startsWith('/api/audit-logs/')) return 'auditLogs';
  if (path.startsWith('/api/google-sheets/')) return path.endsWith('/callback') ? null : 'googleSheets';
  if (path.startsWith('/api/line/') && !path.endsWith('/webhook')) return 'lineIntegration';
  if (path === '/api/notes' || path.startsWith('/api/notes/')) return 'notes';
  return null;
}

export function minimumPaidPlanForFeature(feature: PlanFeature): 'basic' | 'standard' | 'pro' {
  if (feature === 'settings' || feature === 'notes' || feature === 'backupExport' || feature === 'backupRestore') return 'basic';
  if (feature === 'promptPay' || feature === 'bulkMeter' || feature === 'reports' || feature === 'recurringCharges' || feature === 'staff') {
    return 'standard';
  }
  return 'pro';
}

export function isDemoMutationRestricted(path: string, method: HttpMethod): boolean {
  if (method === 'DELETE') return true;
  if (path === '/api/settings' && method === 'PUT') return true;
  if ((path === '/api/caretakers' || path.startsWith('/api/caretakers/')) && method !== 'GET') return true;
  if (path.startsWith('/api/google-sheets/') && method !== 'GET') return true;
  if (path.startsWith('/api/line/') && !path.endsWith('/webhook')) return true;
  return false;
}


export function requiredPlanFeaturesForSettingsUpdate(input: Record<string, unknown>): PlanFeature[] {
  const features: PlanFeature[] = [];
  const hasNonEmpty = (key: string) => key in input && input[key] !== undefined && input[key] !== null && input[key] !== '';

  if (hasNonEmpty('promptpayId') || hasNonEmpty('promptpayName')) features.push('promptPay');
  if (hasNonEmpty('lineChannelAccessToken') || hasNonEmpty('lineChannelSecret') || input.lineBotEnabled === true) features.push('lineIntegration');
  if (hasNonEmpty('googleSpreadsheetId')) features.push('googleSheets');
  return features;
}
