import { z } from 'zod';

export const NOTE_TITLE_MAX_LENGTH = 120;
export const NOTE_CONTENT_MAX_LENGTH = 5_000;
export const NOTE_REQUEST_MAX_BYTES = 16 * 1024;
export const NOTE_LIST_MAX_LIMIT = 100;

export const NoteColorSchema = z.enum(['yellow', 'green', 'blue', 'pink', 'purple', 'gray']);

const optionalRoomId = z.preprocess(
  (value) => {
    if (value === '' || value === undefined) return null;
    if (typeof value === 'string' && /^\d+$/.test(value)) return Number(value);
    return value;
  },
  z.number().int().positive().nullable()
);

const pinnedValue = z.preprocess(
  (value) => value === 1 || value === '1' ? true : value === 0 || value === '0' ? false : value,
  z.boolean()
);

const noteTitle = z.string().trim().min(1, 'กรุณาระบุหัวข้อโน้ต').max(NOTE_TITLE_MAX_LENGTH, `หัวข้อโน้ตต้องไม่เกิน ${NOTE_TITLE_MAX_LENGTH} ตัวอักษร`);
const noteContent = z.string().trim().min(1, 'กรุณาระบุรายละเอียดโน้ต').max(NOTE_CONTENT_MAX_LENGTH, `รายละเอียดโน้ตต้องไม่เกิน ${NOTE_CONTENT_MAX_LENGTH.toLocaleString()} ตัวอักษร`);

export const NoteCreateSchema = z.object({
  title: noteTitle,
  content: noteContent,
  roomId: optionalRoomId.optional().default(null),
  color: NoteColorSchema.optional().default('yellow'),
  isPinned: pinnedValue.optional().default(false),
}).strict();

export const NoteUpdateSchema = z.object({
  title: noteTitle.optional(),
  content: noteContent.optional(),
  roomId: optionalRoomId.optional(),
  color: NoteColorSchema.optional(),
  isPinned: pinnedValue.optional(),
}).strict().refine(
  (value) => Object.keys(value).length > 0,
  { message: 'กรุณาระบุข้อมูลที่ต้องการแก้ไข' }
);

export function getNoteValidationDetails(error: z.ZodError) {
  return error.issues.map((issue) => ({
    field: issue.path.join('.'),
    message: issue.message,
  }));
}
