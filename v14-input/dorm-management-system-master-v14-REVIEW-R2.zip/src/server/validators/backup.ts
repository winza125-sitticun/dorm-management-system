import { z } from 'zod';
import { BACKUP_FORMAT, BACKUP_FORMAT_VERSION, BACKUP_MAX_TOTAL_RECORDS, BACKUP_SCHEMA_VERSION, BACKUP_TABLES, type BackupDataV1 } from '../../utils/backupFormat.ts';

const nullableString = z.string().nullable();
const nullableNumber = z.number().nullable();
const id = z.number().int().nonnegative();
const maybeUserId = z.number().int().nonnegative().nullable();

const RoomSchema = z.object({ id, roomNumber: z.string(), monthlyRent: z.number(), status: z.string(), tenantName: nullableString, tenantPhone: nullableString, createdAt: nullableString, deletedAt: nullableString, deletedBy: nullableNumber }).strict();
const BillSchema = z.object({ id, roomId: id, billMonth: z.string(), priorElec: z.number(), currentElec: z.number(), elecDeduct: z.number(), elecUnitCost: z.number(), elecCost: z.number(), priorWater: z.number(), currentWater: z.number(), waterUnitCost: z.number(), waterCost: z.number(), rentCost: z.number(), depositCost: z.number(), otherCost: z.number(), otherDescription: nullableString, totalCost: z.number(), dueDate: z.string(), status: z.string(), paidAt: nullableString, slipImage: nullableString, slipUploadedAt: nullableString, slipStatus: z.string(), createdAt: nullableString, deletedAt: nullableString, deletedBy: nullableNumber }).strict();
const RecurringTemplateSchema = z.object({ id, name: z.string(), description: nullableString, defaultAmount: z.number(), frequency: z.string(), billingMonths: z.string(), isActive: z.number(), createdAt: nullableString, updatedAt: nullableString, deletedAt: nullableString }).strict();
const RoomRecurringSchema = z.object({ id, roomId: id, templateId: id, amountOverride: nullableNumber, isEnabled: z.number(), createdAt: nullableString, updatedAt: nullableString }).strict();
const BillChargeItemSchema = z.object({ id, billId: id, assignmentId: maybeUserId, label: z.string(), amount: z.number(), kind: z.string(), sortOrder: z.number(), createdAt: nullableString }).strict();
const MaintenanceSchema = z.object({ id, roomId: id, roomNumber: z.string(), tenantName: nullableString, tenantPhone: nullableString, title: z.string(), description: nullableString, category: z.string(), priority: z.string(), status: z.string(), imageUrl: nullableString, repairCost: z.number(), technicianNote: nullableString, createdAt: nullableString, updatedAt: nullableString, deletedAt: nullableString, deletedBy: nullableNumber }).strict();
const HousekeepingSchema = z.object({ id, roomId: id, assignedUserId: maybeUserId, contractId: maybeUserId, source: z.string(), status: z.string(), note: nullableString, inspectionNote: nullableString, createdBy: maybeUserId, createdAt: nullableString, updatedAt: nullableString, completedAt: nullableString }).strict();
const ContractSchema = z.object({ id, roomId: id, roomNumber: z.string(), tenantName: z.string(), tenantPhone: nullableString, idCardNumber: nullableString, startDate: z.string(), endDate: z.string(), monthlyRent: z.number(), depositAmount: z.number(), advanceRentAmount: z.number(), contractDocumentUrl: nullableString, status: z.string(), note: nullableString, createdAt: nullableString, updatedAt: nullableString, deletedAt: nullableString, deletedBy: nullableNumber }).strict();
const AnnouncementSchema = z.object({ id, title: z.string(), content: z.string(), category: z.string(), isPinned: z.number(), targetRoomIds: nullableString, imageUrl: nullableString, createdAt: nullableString, updatedAt: nullableString, deletedAt: nullableString, deletedBy: nullableNumber }).strict();
const NoteSchema = z.object({ id, createdBy: id, roomId: maybeUserId, title: z.string(), content: z.string(), color: z.string(), isPinned: z.number(), createdAt: nullableString, updatedAt: nullableString, deletedAt: nullableString, deletedBy: nullableNumber }).strict();
const SafeSettingsSchema = z.object({ dormName: z.string(), defaultElecRate: z.number(), defaultWaterRate: z.number(), defaultDueDateDay: z.number().int(), defaultPenaltyRate: z.number(), promptpayId: nullableString, promptpayName: nullableString, fontScale: z.enum(['small', 'medium', 'large']) }).strict();

export const BackupManifestSchema = z.object({
  format: z.literal(BACKUP_FORMAT), formatVersion: z.literal(BACKUP_FORMAT_VERSION), appVersion: z.string(),
  schemaVersion: z.literal(BACKUP_SCHEMA_VERSION), createdAt: z.string(), ownerScope: z.string().length(64), dormName: z.string(),
  counts: z.object({ rooms: z.number().int().nonnegative(), bills: z.number().int().nonnegative(), recurringChargeTemplates: z.number().int().nonnegative(), roomRecurringCharges: z.number().int().nonnegative(), billChargeItems: z.number().int().nonnegative(), maintenanceTickets: z.number().int().nonnegative(), housekeepingTasks: z.number().int().nonnegative(), leaseContracts: z.number().int().nonnegative(), announcements: z.number().int().nonnegative(), notes: z.number().int().nonnegative(), settings: z.literal(1) }).strict(),
  excluded: z.array(z.string()), dataSha256: z.string().regex(/^[0-9a-f]{64}$/),
}).strict();

export const BackupDataSchema = z.object({
  rooms: z.array(RoomSchema), bills: z.array(BillSchema), recurringChargeTemplates: z.array(RecurringTemplateSchema),
  roomRecurringCharges: z.array(RoomRecurringSchema), billChargeItems: z.array(BillChargeItemSchema), maintenanceTickets: z.array(MaintenanceSchema),
  housekeepingTasks: z.array(HousekeepingSchema), leaseContracts: z.array(ContractSchema), announcements: z.array(AnnouncementSchema), notes: z.array(NoteSchema),
  settings: SafeSettingsSchema,
}).strict();

export const BackupRestoreRequestSchema = z.object({ manifest: BackupManifestSchema, data: BackupDataSchema }).strict();

export class BackupValidationError extends Error {
  constructor(public code: string, public status = 400, message = code) { super(message); }
}

export interface BackupReferenceContext { ownerId: number; existingUserIds: ReadonlySet<number>; childUserIds: ReadonlySet<number>; }
export interface BackupValidationWarnings { warnings: string[]; }

function assertUniqueIds(name: string, rows: Array<{ id: number }>) {
  const seen = new Set<number>();
  for (const row of rows) {
    if (seen.has(row.id)) throw new BackupValidationError('BACKUP_DUPLICATE_ID', 400, `BACKUP_DUPLICATE_ID:${name}:${row.id}`);
    seen.add(row.id);
  }
}

function requireRef(ok: boolean, relation: string) {
  if (!ok) throw new BackupValidationError('BACKUP_REFERENCE_INVALID', 400, `BACKUP_REFERENCE_INVALID:${relation}`);
}

export function validateBackupReferences(data: BackupDataV1, context: BackupReferenceContext): BackupValidationWarnings {
  const total = BACKUP_TABLES.reduce((sum, key) => sum + data[key].length, 0);
  if (total > BACKUP_MAX_TOTAL_RECORDS) throw new BackupValidationError('BACKUP_RECORD_LIMIT', 413);

  for (const key of BACKUP_TABLES) assertUniqueIds(key, data[key] as Array<{ id: number }>);
  const rooms = new Set(data.rooms.map((row: any) => row.id));
  const bills = new Set(data.bills.map((row: any) => row.id));
  const templates = new Set(data.recurringChargeTemplates.map((row: any) => row.id));
  const assignments = new Set(data.roomRecurringCharges.map((row: any) => row.id));
  const contracts = new Set(data.leaseContracts.map((row: any) => row.id));

  for (const row of data.bills as any[]) requireRef(rooms.has(row.roomId), `bills.roomId:${row.id}`);
  for (const row of data.maintenanceTickets as any[]) requireRef(rooms.has(row.roomId), `maintenanceTickets.roomId:${row.id}`);
  for (const row of data.leaseContracts as any[]) requireRef(rooms.has(row.roomId), `leaseContracts.roomId:${row.id}`);
  for (const row of data.housekeepingTasks as any[]) {
    requireRef(rooms.has(row.roomId), `housekeepingTasks.roomId:${row.id}`);
    if (row.contractId != null) requireRef(contracts.has(row.contractId), `housekeepingTasks.contractId:${row.id}`);
  }
  for (const row of data.notes as any[]) if (row.roomId != null) requireRef(rooms.has(row.roomId), `notes.roomId:${row.id}`);
  for (const row of data.roomRecurringCharges as any[]) {
    requireRef(rooms.has(row.roomId), `roomRecurringCharges.roomId:${row.id}`);
    requireRef(templates.has(row.templateId), `roomRecurringCharges.templateId:${row.id}`);
  }
  for (const row of data.billChargeItems as any[]) {
    requireRef(bills.has(row.billId), `billChargeItems.billId:${row.id}`);
    if (row.assignmentId != null) requireRef(assignments.has(row.assignmentId), `billChargeItems.assignmentId:${row.id}`);
  }
  for (const row of data.announcements as any[]) {
    if (!row.targetRoomIds) continue;
    for (const token of String(row.targetRoomIds).split(',').map((v) => v.trim()).filter(Boolean)) {
      const roomId = Number(token);
      requireRef(Number.isInteger(roomId) && rooms.has(roomId), `announcements.targetRoomIds:${row.id}:${token}`);
    }
  }

  // Mirror D1 CHECK/UNIQUE constraints before any destructive restore write.
  const activeRoomNumbers = new Set<string>();
  for (const row of data.rooms as any[]) {
    if (row.deletedAt != null) continue;
    const key = String(row.roomNumber).trim().toLocaleLowerCase('en-US');
    if (activeRoomNumbers.has(key)) throw new BackupValidationError('BACKUP_CONSTRAINT_INVALID', 400, `BACKUP_DUPLICATE_ACTIVE_ROOM:${row.roomNumber}`);
    activeRoomNumbers.add(key);
  }
  const activeBills = new Set<string>();
  for (const row of data.bills as any[]) {
    if (row.deletedAt != null) continue;
    const key = `${row.roomId}:${row.billMonth}`;
    if (activeBills.has(key)) throw new BackupValidationError('BACKUP_CONSTRAINT_INVALID', 400, `BACKUP_DUPLICATE_ACTIVE_BILL:${key}`);
    activeBills.add(key);
  }
  const roomTemplates = new Set<string>();
  for (const row of data.roomRecurringCharges as any[]) {
    const key = `${row.roomId}:${row.templateId}`;
    if (roomTemplates.has(key)) throw new BackupValidationError('BACKUP_CONSTRAINT_INVALID', 400, `BACKUP_DUPLICATE_ROOM_TEMPLATE:${key}`);
    roomTemplates.add(key);
    if (row.amountOverride != null && row.amountOverride < 0) throw new BackupValidationError('BACKUP_CONSTRAINT_INVALID', 400, `BACKUP_NEGATIVE_AMOUNT_OVERRIDE:${row.id}`);
  }
  for (const row of data.recurringChargeTemplates as any[]) {
    if (row.defaultAmount < 0 || !['monthly','quarterly','yearly'].includes(row.frequency)) throw new BackupValidationError('BACKUP_CONSTRAINT_INVALID', 400, `BACKUP_RECURRING_TEMPLATE_INVALID:${row.id}`);
  }
  for (const row of data.billChargeItems as any[]) {
    if (row.amount < 0 || !['recurring','manual','legacy'].includes(row.kind)) throw new BackupValidationError('BACKUP_CONSTRAINT_INVALID', 400, `BACKUP_BILL_CHARGE_INVALID:${row.id}`);
  }
  const checkoutContracts = new Set<number>();
  for (const row of data.housekeepingTasks as any[]) {
    if (!['manual','checkout'].includes(row.source) || !['pending','in_progress','ready_for_inspection','completed','cancelled'].includes(row.status)) throw new BackupValidationError('BACKUP_CONSTRAINT_INVALID', 400, `BACKUP_HOUSEKEEPING_INVALID:${row.id}`);
    if (row.source === 'checkout' && row.contractId != null) {
      if (checkoutContracts.has(row.contractId)) throw new BackupValidationError('BACKUP_CONSTRAINT_INVALID', 400, `BACKUP_DUPLICATE_CHECKOUT:${row.contractId}`);
      checkoutContracts.add(row.contractId);
    }
  }
  for (const row of data.notes as any[]) {
    if (row.title.length < 1 || row.title.length > 120 || row.content.length < 1 || row.content.length > 5000 || !['yellow','green','blue','pink','purple','gray'].includes(row.color) || ![0,1].includes(row.isPinned)) throw new BackupValidationError('BACKUP_CONSTRAINT_INVALID', 400, `BACKUP_NOTE_INVALID:${row.id}`);
  }

  const warnings: string[] = [];
  const currentUsers = context.existingUserIds;
  for (const row of data.notes as any[]) if (row.createdBy !== context.ownerId && !currentUsers.has(row.createdBy)) warnings.push(`REMAP_CREATED_BY:notes:${row.id}`);
  for (const row of data.housekeepingTasks as any[]) {
    if (row.createdBy != null && row.createdBy !== context.ownerId && !currentUsers.has(row.createdBy)) warnings.push(`REMAP_CREATED_BY:housekeepingTasks:${row.id}`);
    if (row.assignedUserId != null && !context.childUserIds.has(row.assignedUserId)) warnings.push(`CLEAR_ASSIGNED_USER:housekeepingTasks:${row.id}`);
  }
  return { warnings };
}
