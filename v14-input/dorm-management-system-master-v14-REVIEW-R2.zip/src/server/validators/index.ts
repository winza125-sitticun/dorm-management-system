import { z } from 'zod';
import { ValidationError } from '../errors.ts';
export {
  NOTE_CONTENT_MAX_LENGTH,
  NOTE_LIST_MAX_LIMIT,
  NOTE_REQUEST_MAX_BYTES,
  NOTE_TITLE_MAX_LENGTH,
  NoteColorSchema,
  NoteCreateSchema,
  NoteUpdateSchema,
  getNoteValidationDetails,
} from './notes.validator.ts';

export const SetupSchema = z.object({
  email: z.string().min(3, { message: 'กรุณาระบุ Username / Email' }),
  password: z.string().min(8, { message: 'รหัสผ่านต้องมีความยาวอย่างน้อย 8 ตัวอักษร' }),
  displayName: z.string().optional(),
  dormName: z.string().optional(),
});

export const LoginSchema = z.object({
  username: z.string().min(1, { message: 'กรุณาระบุชื่อผู้ใช้งาน หรือ อีเมล' }),
  password: z.string().min(1, { message: 'กรุณาระบุรหัสผ่าน' }),
});

export const ChangePasswordSchema = z.object({
  currentPassword: z.string().min(1, { message: 'กรุณาระบุรหัสผ่านเดิม' }),
  newPassword: z.string().min(8, { message: 'รหัสผ่านใหม่ต้องมีความยาวอย่างน้อย 8 ตัวอักษร' }),
});

export const CaretakerSchema = z.object({
  email: z.string().min(3, { message: 'กรุณาระบุ User ID / Email' }),
  password: z.string().min(4, { message: 'รหัสผ่านต้องมีความยาวอย่างน้อย 4 ตัวอักษร' }).optional().or(z.literal('')),
  role: z.enum(['super_admin', 'owner', 'manager', 'staff', 'tenant', 'caretaker']).default('staff'),
  permissions: z.string().optional(),
});

export const RoomSchema = z.object({
  roomNumber: z.string().min(1, { message: 'กรุณาระบุเลขห้องพัก' }),
  monthlyRent: z.coerce.number().min(0, { message: 'ค่าเช่าห้องต้องไม่ติดลบ' }),
  status: z.enum(['vacant', 'occupied']).default('vacant'),
  tenantName: z.string().nullable().optional(),
  tenantPhone: z.string().nullable().optional(),
});

export const BillSchema = z.object({
  roomId: z.coerce.number().min(1, { message: 'กรุณาระบุห้องพัก' }),
  billMonth: z.string().min(4, { message: 'กรุณาระบุเดือนประจำบิล (YYYY-MM)' }),
  priorElec: z.coerce.number().min(0),
  currentElec: z.coerce.number().min(0),
  elecDeduct: z.coerce.number().min(0).default(0),
  elecUnitCost: z.coerce.number().min(0).default(7),
  elecCost: z.coerce.number().optional(),
  priorWater: z.coerce.number().min(0),
  currentWater: z.coerce.number().min(0),
  waterUnitCost: z.coerce.number().min(0).default(13),
  waterCost: z.coerce.number().optional(),
  rentCost: z.coerce.number().min(0),
  depositCost: z.coerce.number().min(0).default(0),
  otherCost: z.coerce.number().min(0).default(0),
  otherDescription: z.string().nullable().optional(),
  dueDate: z.string().min(1, { message: 'กรุณาระบุวันครบกำหนดชำระ' }),
  status: z.enum(['paid', 'unpaid']).default('unpaid'),
});

export const SettingsSchema = z.object({
  dormName: z.string().min(1, { message: 'กรุณาระบุชื่อหอพัก' }),
  defaultElecRate: z.coerce.number().min(0),
  defaultWaterRate: z.coerce.number().min(0),
  defaultDueDateDay: z.coerce.number().min(1).max(31),
  defaultPenaltyRate: z.coerce.number().min(0),
  promptpayId: z.string().nullable().optional(),
  promptpayName: z.string().nullable().optional(),
  lineChannelAccessToken: z.string().nullable().optional(),
  lineChannelSecret: z.string().nullable().optional(),
  lineBotEnabled: z.coerce.number().optional(),
  googleSpreadsheetId: z.string().nullable().optional(),
  fontScale: z.enum(['small', 'medium', 'large']).optional(),
});

export function validateZod<T>(schema: z.ZodSchema<T>, data: any): T {
  const result = schema.safeParse(data);
  if (!result.success) {
    const details = result.error.issues.map(err => ({
      field: err.path.join('.'),
      message: err.message
    }));
    throw new ValidationError(details[0]?.message || 'ข้อมูลที่ส่งมาไม่ถูกต้อง', details);
  }
  return result.data;
}
