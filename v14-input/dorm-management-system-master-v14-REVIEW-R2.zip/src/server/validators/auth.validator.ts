import { z } from 'zod';

export const LoginSchema = z.object({
  email: z.string().min(1, { message: 'กรุณาระบุระบุอีเมล หรือ User ID' }),
  password: z.string().min(1, { message: 'กรุณาระบุรหัสผ่าน' }),
});

export const ChangePasswordSchema = z.object({
  currentPassword: z.string().optional(),
  newPassword: z.string().min(6, { message: 'รหัสผ่านใหม่ต้องมีความยาวอย่างน้อย 6 ตัวอักษร' }),
});

export const CreateCaretakerSchema = z.object({
  email: z.string().min(3, { message: 'กรุณาระบุ User ID / Email' }),
  password: z.string().min(6, { message: 'รหัสผ่านต้องมีความยาวอย่างน้อย 6 ตัวอักษร' }),
  permissions: z.array(z.string()).default(['manage_rooms', 'manage_bills', 'edit_payments']),
});

export const UpdateCaretakerSchema = z.object({
  password: z.string().min(6, { message: 'รหัสผ่านต้องมีความยาวอย่างน้อย 6 ตัวอักษร' }).optional().or(z.literal('')),
  permissions: z.array(z.string()).optional(),
});
