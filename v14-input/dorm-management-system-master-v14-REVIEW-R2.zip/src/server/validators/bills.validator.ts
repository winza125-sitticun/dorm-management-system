import { z } from 'zod';

export const BillSchema = z.object({
  roomId: z.coerce.number().min(1, { message: 'กรุณาระบุห้องพัก' }),
  billMonth: z.string().min(4, { message: 'กรุณาระบุเดือนประจำบิล (YYYY-MM)' }),
  priorElec: z.coerce.number().min(0),
  currentElec: z.coerce.number().min(0),
  elecUnitCost: z.coerce.number().min(0).default(7),
  priorWater: z.coerce.number().min(0),
  currentWater: z.coerce.number().min(0),
  waterUnitCost: z.coerce.number().min(0).default(13),
  rentCost: z.coerce.number().min(0),
  depositCost: z.coerce.number().min(0).default(0),
  otherCost: z.coerce.number().min(0).default(0),
  otherDescription: z.string().nullable().optional(),
  dueDate: z.string().min(1, { message: 'กรุณาระบุวันครบกำหนดชำระ' }),
  status: z.enum(['paid', 'unpaid']).default('unpaid'),
});
