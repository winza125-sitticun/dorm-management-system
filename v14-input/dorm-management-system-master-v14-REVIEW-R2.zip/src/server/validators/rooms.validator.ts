import { z } from 'zod';

export const RoomSchema = z.object({
  roomNumber: z.string().min(1, { message: 'กรุณาระบุเลขห้องพัก' }),
  monthlyRent: z.coerce.number().min(0, { message: 'ค่าเช่าห้องต้องไม่ติดลบ' }),
  status: z.enum(['vacant', 'occupied']).default('vacant'),
  tenantName: z.string().nullable().optional(),
  tenantPhone: z.string().nullable().optional(),
});
