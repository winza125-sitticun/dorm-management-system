/**
 * Standardized Custom API Error Classes
 */

export class ApiError extends Error {
  public statusCode: number;
  public code: string;
  public details?: any[];

  constructor(statusCode: number, code: string, message: string, details?: any[]) {
    super(message);
    this.name = 'ApiError';
    this.statusCode = statusCode;
    this.code = code;
    this.details = details;
    Object.setPrototypeOf(this, new.target.prototype);
  }
}

export class ValidationError extends ApiError {
  constructor(message: string = 'ข้อมูลที่ส่งมาไม่ถูกต้อง', details?: any[]) {
    super(400, 'VALIDATION_ERROR', message, details);
    this.name = 'ValidationError';
  }
}

export class AuthError extends ApiError {
  constructor(code: 'UNAUTHORIZED' | 'FORBIDDEN' = 'UNAUTHORIZED', message: string = 'ไม่มีสิทธิ์เข้าถึงข้อมูลนี้') {
    const status = code === 'UNAUTHORIZED' ? 401 : 403;
    super(status, code, message);
    this.name = 'AuthError';
  }
}

export class NotFoundError extends ApiError {
  constructor(resource: string = 'ข้อมูล') {
    super(404, 'NOT_FOUND', `ไม่พบ${resource}ในระบบ`);
    this.name = 'NotFoundError';
  }
}

export class DatabaseError extends ApiError {
  constructor(message: string = 'เกิดข้อผิดพลาดในการเชื่อมต่อหรือจัดการฐานข้อมูล') {
    super(500, 'DATABASE_ERROR', message);
    this.name = 'DatabaseError';
  }
}

export class ConflictError extends ApiError {
  constructor(message: string = 'ข้อมูลนี้มีอยู่ในระบบแล้ว') {
    super(409, 'CONFLICT_ERROR', message);
    this.name = 'ConflictError';
  }
}
