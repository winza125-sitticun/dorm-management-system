import { Request, Response, NextFunction } from 'express';
import { eq, and, inArray, isNull, sql } from 'drizzle-orm';
import type { UserRole } from '../types.ts';
import { AuthError, ApiError } from '../server/errors.ts';
import { db } from '../db/index.ts';
import { rooms, settings, users } from '../db/schema.ts';
import { verifyToken } from '../server/services/jwt.service.ts';
import { getPlanLimit, hasPlanFeature, isDemoPlan, normalizeSubscriptionPlan } from '../constants/planEntitlements.ts';
import { isDemoMutationRestricted, minimumPaidPlanForFeature, requiredPlanFeatureForApiRequest, requiredPlanFeaturesForSettingsUpdate } from '../server/services/planAccess.service.ts';

export interface AuthRequest extends Request {
  user?: {
    id: number;
    uid: string;
    email: string;
    role: UserRole;
    parentId: number | null;
    permissions?: string;
    password?: string;
  };
  // Backward compatibility alias
  dbUser?: {
    id: number;
    uid: string;
    email: string;
    role: string;
    parentId: number | null;
    permissions?: string;
    password?: string;
  };
}

/**
 * Fine-grained RBAC Permission Checker
 */
export function hasPermission(userRole: UserRole | string, permission: string): boolean {
  if (userRole === 'super_admin' || userRole === 'owner') return true;
  
  if (userRole === 'manager') {
    // Managers can manage rooms, bills, maintenance, lease contracts, and view reports, but cannot touch system settings or delete resources
    const allowed = [
      'room:create', 'room:read', 'room:update',
      'bill:create', 'bill:read', 'bill:approve', 'bill:cancel',
      'maintenance:read', 'maintenance:update',
      'contract:read', 'contract:create', 'contract:update',
      'report:read', 'announcement:read', 'announcement:create'
    ];
    return allowed.includes(permission);
  }

  if (userRole === 'staff') {
    // Staff can record meter readings, view rooms/bills, create draft bills/tickets
    const allowed = [
      'room:read', 'bill:read', 'bill:create',
      'maintenance:read', 'maintenance:create', 'maintenance:update',
      'announcement:read'
    ];
    return allowed.includes(permission);
  }

  if (userRole === 'tenant') {
    // Tenants can read own room/bills, create maintenance tickets
    const allowed = [
      'room:read_self', 'bill:read_self', 'maintenance:create_self', 'announcement:read'
    ];
    return allowed.includes(permission);
  }

  // Caretaker fallback string match
  if (userRole === 'caretaker') {
    const permMap: Record<string, string> = {
      'room:create': 'manage_rooms',
      'room:read': 'manage_rooms',
      'room:update': 'manage_rooms',
      'bill:create': 'manage_bills',
      'bill:read': 'manage_bills',
      'bill:approve': 'edit_payments',
      'setting:update': 'manage_settings'
    };
    const mapped = permMap[permission];
    return mapped ? true : false;
  }

  return false;
}

export const requireRole = (allowedRoles: (UserRole | string)[]) => {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    const role = req.user?.role || req.dbUser?.role;
    if (!role || !allowedRoles.includes(role)) {
      return next(new AuthError('FORBIDDEN', 'คุณไม่มีสิทธิ์การเข้าถึงในบทบาทนี้'));
    }
    next();
  };
};

export const requirePermission = (permission: string) => {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    const role = req.user?.role || req.dbUser?.role || 'tenant';
    if (!hasPermission(role, permission)) {
      return next(new AuthError('FORBIDDEN', `คุณไม่มีสิทธิ์ดำเนินการ (${permission})`));
    }
    next();
  };
};

export const requireAuth = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return next(new AuthError('UNAUTHORIZED', 'กรุณาล็อกอินเข้าสู่ระบบก่อนใช้งาน'));
  }

  const token = authHeader.split('Bearer ')[1];
  const secret = process.env.JWT_SECRET;
  if (!secret || secret.length < 32) {
    return next(new ApiError(500, 'INTERNAL_ERROR', 'JWT_SECRET environment variable is not configured on server'));
  }

  try {
    const payload = await verifyToken(token, secret);
    if (!payload || !payload.id) {
      return next(new AuthError('UNAUTHORIZED', 'โทเค็นยืนยันตัวตนไม่ถูกต้องหรือหมดอายุ'));
    }

    const [dbUser] = await db.select()
      .from(users)
      .where(and(eq(users.id, payload.id), isNull(users.deletedAt)))
      .limit(1);

    if (!dbUser) {
      return next(new AuthError('UNAUTHORIZED', 'ไม่พบบัญชีผู้ใช้งาน กรุณาเข้าสู่ระบบใหม่'));
    }

    const userObj: AuthRequest['user'] = {
      id: dbUser.id,
      uid: dbUser.uid,
      email: dbUser.email,
      role: dbUser.role as UserRole,
      parentId: dbUser.parentId ?? null,
      permissions: dbUser.permissions ?? undefined,
      password: dbUser.password ?? undefined,
    };

    const staffRoles = ['caretaker', 'accountant', 'technician', 'housekeeper', 'staff'];
    const ownerId = staffRoles.includes(String(dbUser.role)) && dbUser.parentId ? dbUser.parentId : dbUser.id;
    const [subscriptionRow] = await db.select({ subscriptionPlan: settings.subscriptionPlan })
      .from(settings)
      .where(eq(settings.userId, ownerId))
      .limit(1);
    const subscriptionPlan = normalizeSubscriptionPlan(subscriptionRow?.subscriptionPlan);
    const requestPath = String(req.originalUrl || req.path || '').split('?')[0];
    const requiredFeature = requiredPlanFeatureForApiRequest(requestPath, req.method);

    if (isDemoPlan(subscriptionPlan) && isDemoMutationRestricted(requestPath, req.method)) {
      return next(new ApiError(403, 'PLAN_REQUIRED', 'บัญชี Demo ไม่อนุญาตให้แก้ไขการตั้งค่า ลบข้อมูล หรือจัดการ Integration'));
    }

    if (requiredFeature && !hasPlanFeature(subscriptionPlan, requiredFeature)) {
      const requiredPlan = minimumPaidPlanForFeature(requiredFeature);
      return next(new ApiError(403, 'PLAN_REQUIRED', `ฟีเจอร์นี้อยู่ในแพ็กเกจ ${requiredPlan[0].toUpperCase() + requiredPlan.slice(1)} หรือสูงกว่า`));
    }

    if (req.method === 'PUT' && requestPath === '/api/settings') {
      const settingsFeatures = requiredPlanFeaturesForSettingsUpdate((req.body && typeof req.body === 'object') ? req.body : {});
      for (const feature of settingsFeatures) {
        if (!hasPlanFeature(subscriptionPlan, feature)) {
          const requiredPlan = minimumPaidPlanForFeature(feature);
          return next(new ApiError(403, 'PLAN_REQUIRED', `การตั้งค่านี้อยู่ในแพ็กเกจ ${requiredPlan[0].toUpperCase() + requiredPlan.slice(1)} หรือสูงกว่า`));
        }
      }
    }

    if (req.method === 'POST' && requestPath === '/api/rooms') {
      const [countRow] = await db.select({ count: sql<number>`count(*)` }).from(rooms)
        .where(and(eq(rooms.userId, ownerId), isNull(rooms.deletedAt)));
      if (Number(countRow?.count || 0) >= getPlanLimit(subscriptionPlan, 'maxRooms')) {
        return next(new ApiError(403, 'PLAN_LIMIT_REACHED', `แพ็กเกจ ${subscriptionPlan} รองรับห้องพักสูงสุด ${getPlanLimit(subscriptionPlan, 'maxRooms')} ห้อง`));
      }
    }

    if (req.method === 'POST' && requestPath === '/api/caretakers') {
      const [countRow] = await db.select({ count: sql<number>`count(*)` }).from(users)
        .where(and(eq(users.parentId, ownerId), inArray(users.role, staffRoles), isNull(users.deletedAt)));
      if (Number(countRow?.count || 0) >= getPlanLimit(subscriptionPlan, 'maxStaff')) {
        return next(new ApiError(403, 'PLAN_LIMIT_REACHED', `แพ็กเกจ ${subscriptionPlan} รองรับผู้ดูแลร่วมสูงสุด ${getPlanLimit(subscriptionPlan, 'maxStaff')} คน`));
      }
    }

    req.user = userObj;
    req.dbUser = userObj;
    next();
  } catch (error) {
    return next(new AuthError('UNAUTHORIZED', 'โทเค็นยืนยันตัวตนไม่ถูกต้องหรือหมดอายุ'));
  }
};
