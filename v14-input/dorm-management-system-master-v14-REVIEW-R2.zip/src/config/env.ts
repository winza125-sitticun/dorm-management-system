import { z } from 'zod';

const EnvSchema = z.object({
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  PORT: z.coerce.number().default(3000),
  DATABASE_URL: z.string().optional(),
  LINE_CHANNEL_ACCESS_TOKEN: z.string().optional(),
  LINE_CHANNEL_SECRET: z.string().optional(),
  GEMINI_API_KEY: z.string().optional(),
});

export function validateEnv() {
  const result = EnvSchema.safeParse(process.env);
  if (!result.success) {
    console.warn("⚙️ Environment Validation Notice:", result.error.format());
    return EnvSchema.parse({});
  }
  return result.data;
}

export const envConfig = validateEnv();
