import { envConfig } from './env.ts';

export const lineConfig = {
  channelAccessToken: envConfig.LINE_CHANNEL_ACCESS_TOKEN || '',
  channelSecret: envConfig.LINE_CHANNEL_SECRET || '',
};
