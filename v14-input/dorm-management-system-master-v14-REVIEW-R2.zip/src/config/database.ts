import { envConfig } from './env.ts';

export const databaseConfig = {
  url: envConfig.DATABASE_URL || '',
  retryAttempts: 3,
  retryDelayMs: 1000,
  maxConnections: 10,
};
