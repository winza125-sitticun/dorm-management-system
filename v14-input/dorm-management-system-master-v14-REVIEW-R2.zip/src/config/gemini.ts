import { envConfig } from './env.ts';

export const geminiConfig = {
  apiKey: envConfig.GEMINI_API_KEY || '',
  modelName: 'gemini-2.5-flash',
};
