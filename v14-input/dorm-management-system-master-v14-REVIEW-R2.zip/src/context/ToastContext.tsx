import React, { createContext, useContext, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, AlertCircle, Info, AlertTriangle, X } from 'lucide-react';

export type ToastType = 'success' | 'error' | 'info' | 'warning';

export interface ToastItem {
  id: string;
  message: string;
  type: ToastType;
  title?: string;
  duration?: number;
}

interface ToastContextType {
  toast: (message: string, type?: ToastType, title?: string, duration?: number) => void;
  success: (message: string, title?: string, duration?: number) => void;
  error: (message: string, title?: string, duration?: number) => void;
  info: (message: string, title?: string, duration?: number) => void;
  warning: (message: string, title?: string, duration?: number) => void;
}

const ToastContext = createContext<ToastContextType | undefined>(undefined);

export const ToastProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const toast = useCallback((message: any, type: ToastType = 'info', title?: string, duration = 6000) => {
    const id = Math.random().toString(36).substring(2, 9);
    
    // Ensure message is a string
    const messageStr = typeof message === 'object' && message !== null
      ? (message.message || message.error || JSON.stringify(message))
      : String(message || '');

    // Set a fallback title if not provided
    const fallbackTitle = title || (
      type === 'success' ? 'สำเร็จ' :
      type === 'error' ? 'เกิดข้อผิดพลาด' :
      type === 'warning' ? 'คำแจ้งเตือน' : 'ข้อมูล'
    );

    setToasts((prev) => [...prev, { id, message: messageStr, type, title: fallbackTitle, duration }]);

    setTimeout(() => {
      removeToast(id);
    }, duration);
  }, [removeToast]);

  const success = useCallback((message: string, title?: string, duration?: number) => {
    toast(message, 'success', title, duration);
  }, [toast]);

  const error = useCallback((message: string, title?: string, duration?: number) => {
    toast(message, 'error', title, duration);
  }, [toast]);

  const info = useCallback((message: string, title?: string, duration?: number) => {
    toast(message, 'info', title, duration);
  }, [toast]);

  const warning = useCallback((message: string, title?: string, duration?: number) => {
    toast(message, 'warning', title, duration);
  }, [toast]);

  return (
    <ToastContext.Provider value={{ toast, success, error, info, warning }}>
      {children}
      
      {/* Toast container */}
      <div className="fixed top-4 right-4 z-[9999] flex flex-col gap-3 w-full max-w-sm sm:max-w-md pointer-events-none px-4 sm:px-0">
        <AnimatePresence>
          {toasts.map((t) => {
            let icon = <Info className="w-5 h-5 text-[#1DB954]" />;
            let bgClass = 'bg-[#F0F0EB] border-[#D5D5D0] text-[#1A1A1A]';
            let iconBg = 'bg-[#1DB954]/8';
            
            if (t.type === 'success') {
              icon = <CheckCircle2 className="w-5 h-5 text-[#1DB954]" />;
              bgClass = 'bg-[#F0F0EB] border-[#D5D5D0] text-[#1A1A1A]';
              iconBg = 'bg-[#1DB954]/8';
            } else if (t.type === 'error') {
              icon = <AlertCircle className="w-5 h-5 text-[#E22134]" />;
              bgClass = 'bg-[#F0F0EB] border-[#E22134]/30 text-[#1A1A1A]';
              iconBg = 'bg-[#E22134]/8';
            } else if (t.type === 'warning') {
              icon = <AlertTriangle className="w-5 h-5 text-[#F59B23]" />;
              bgClass = 'bg-[#F0F0EB] border-[#F59B23]/30 text-[#1A1A1A]';
              iconBg = 'bg-[#F59B23]/8';
            }

            return (
              <motion.div
                key={t.id}
                layout
                initial={{ opacity: 0, y: -20, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -10, scale: 0.95 }}
                transition={{ duration: 0.2 }}
                className={`w-full pointer-events-auto border rounded-2xl p-4 shadow-lg flex gap-3.5 items-start ${bgClass} backdrop-blur-md`}
              >
                <div className={`p-2 rounded-xl shrink-0 ${iconBg}`}>
                  {icon}
                </div>
                
                <div className="flex-1 min-w-0 space-y-1">
                  {t.title && (
                    <h4 className="font-extrabold text-xs sm:text-sm tracking-tight text-[#1A1A1A]">
                      {t.title}
                    </h4>
                  )}
                  
                  {/* Message body with whitespace-pre-line to respect line breaks */}
                  <div className="text-[11px] sm:text-xs leading-relaxed opacity-90 font-medium whitespace-pre-line text-[#6B6B66]">
                    {t.message}
                  </div>
                </div>

                <button
                  onClick={() => removeToast(t.id)}
                  className="p-1 rounded-lg text-[#8A8A85] hover:text-white hover:bg-[#333333] transition shrink-0 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </ToastContext.Provider>
  );
};

export const useToast = () => {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error('useToast must be used within a ToastProvider');
  }
  return context;
};
