import React, { createContext, useContext, useEffect, useState } from 'react';

interface AuthContextType {
  user: any;
  idToken: string | null;
  googleAccessToken: string | null;
  /** True only during the initial localStorage session-restore check on mount. */
  loading: boolean;
  /** True while a loginWithCredentials fetch is in flight. */
  loginPending: boolean;
  loginWithGoogle: () => Promise<void>;
  loginWithCredentials: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  getIdToken: () => Promise<string | null>;
  getGoogleAccessToken: () => Promise<string | null>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<any>(null);
  const [idToken, setIdToken] = useState<string | null>(null);
  const [googleAccessToken, setGoogleAccessToken] = useState<string | null>(null);
  // 'loading' = initial session-restore check (blocks App render with spinner)
  const [loading, setLoading] = useState(true);
  // 'loginPending' = active loginWithCredentials fetch in flight (only disables button)
  const [loginPending, setLoginPending] = useState(false);

  useEffect(() => {
    // Check Cloudflare D1 native local credentials session
    const localUser = localStorage.getItem('local_user');
    const localToken = localStorage.getItem('local_token');
    
    if (localUser && localToken) {
      try {
        setUser(JSON.parse(localUser));
        setIdToken(localToken);
      } catch (e) {
        localStorage.removeItem('local_user');
        localStorage.removeItem('local_token');
      }
    }
    
    setLoading(false);
  }, []);

  const loginWithGoogle = async () => {
    // Cloudflare native mode fallback
    await loginWithCredentials('admin', 'admin');
  };

  const loginWithCredentials = async (username: string, password: string) => {
    // Use loginPending (not loading) so App.tsx does NOT unmount <Login /> during
    // the request — otherwise any error state set in Login.tsx's catch block would
    // be discarded when the fresh Login instance is mounted after loading → false.
    setLoginPending(true);
    try {
      // 1. Attempt the fetch — may throw on network failure (DNS, offline, CORS, etc.)
      let res: Response;
      try {
        res = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, password }),
        });
      } catch (fetchErr: any) {
        // fetch() itself rejected — this is a network-level failure, not an HTTP error.
        console.error('[AuthContext] Network fetch failed:', fetchErr);
        throw new Error(
          'ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์ได้ กรุณาตรวจสอบการเชื่อมต่ออินเทอร์เน็ต'
        );
      }

      // 2. HTTP-level errors (4xx / 5xx)
      if (!res.ok) {
        let errorMessage = 'การเข้าสู่ระบบล้มเหลว';
        try {
          const errData = await res.json();
          if (errData && errData.error) {
            errorMessage = typeof errData.error === 'string'
              ? errData.error
              : (errData.error.message || errData.error.code || 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง');
          }
        } catch {
          // Response body wasn't JSON — build a descriptive fallback
          errorMessage = `ไม่สามารถเชื่อมต่อระบบหลังบ้านได้ (HTTP ${res.status})`;
        }
        throw new Error(errorMessage);
      }

      // 3. Success — persist session
      const resJson = await res.json();
      const payloadData = resJson.data || resJson;
      const userObj = payloadData.user || resJson.user;
      const tokenObj = payloadData.token || resJson.token;
      if (!tokenObj) throw new Error('ไม่ได้รับโทเค็นการยืนยันตัวตนจากเซิร์ฟเวอร์');

      if (!userObj) {
        throw new Error('โครงสร้างข้อมูลผู้ใช้งานไม่ถูกต้อง');
      }

      localStorage.setItem('local_user', JSON.stringify(userObj));
      localStorage.setItem('local_token', tokenObj);
      
      setUser(userObj);
      setIdToken(tokenObj);
    } catch (error) {
      console.error('[AuthContext] loginWithCredentials error:', error);
      // Always re-throw so the Login component can display the error
      throw error;
    } finally {
      setLoginPending(false);
    }
  };

  const logout = async () => {
    setLoading(true);
    try {
      localStorage.removeItem('local_user');
      localStorage.removeItem('local_token');
      setGoogleAccessToken(null);
      setUser(null);
      setIdToken(null);
    } catch (error) {
      console.error("Error logging out:", error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const getIdToken = async () => {
    const token = localStorage.getItem('local_token') || idToken;
    return token;
  };

  const getGoogleAccessToken = async (): Promise<string | null> => {
    if (!idToken) return null;
    const response = await fetch('/api/google-sheets/token', {
      headers: { Authorization: `Bearer ${idToken}` }
    });
    if (!response.ok) return null;
    const payload = await response.json();
    return payload?.data?.accessToken || null;
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      idToken, 
      googleAccessToken, 
      loading, 
      loginPending,
      loginWithGoogle, 
      loginWithCredentials,
      logout, 
      getIdToken,
      getGoogleAccessToken
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
