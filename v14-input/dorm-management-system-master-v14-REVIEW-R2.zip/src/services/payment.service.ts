/**
 * Payment & PromptPay Service
 * Sanitizes PromptPay ID / Mobile numbers and formats payload for QR Code generation.
 */

export class PaymentService {
  /**
   * Sanitizes PromptPay ID to numeric format
   * e.g., "089-123-4567" -> "0891234567"
   */
  static formatPromptPayId(rawId: string): string {
    if (!rawId) return '';
    return rawId.replace(/[^0-9]/g, '');
  }

  /**
   * Evaluates payment collection rate percentage
   */
  static calculateCollectionRate(totalRevenue: number, paidRevenue: number): number {
    if (totalRevenue <= 0) return 0;
    return Math.round((paidRevenue / totalRevenue) * 100);
  }
}
