/**
 * Billing Business Logic Service
 * Contains core calculations for utility units, costs, late fees, and total bill calculations.
 */

export interface BillingCalculationInput {
  rentCost: number;
  priorElec: number;
  currentElec: number;
  elecDeduct?: number;
  elecUnitCost: number;
  priorWater: number;
  currentWater: number;
  waterUnitCost: number;
  depositCost?: number;
  otherCost?: number;
}

export interface BillingCalculationResult {
  elecUnits: number;
  elecCost: number;
  waterUnits: number;
  waterCost: number;
  totalCost: number;
}

export class BillingService {
  /**
   * Calculates utility usage units and total bill cost
   */
  static calculateBillTotal(input: BillingCalculationInput): BillingCalculationResult {
    const elecUnits = Math.max(0, input.currentElec - input.priorElec - (input.elecDeduct || 0));
    const elecCost = Math.round(elecUnits * input.elecUnitCost);

    const waterUnits = Math.max(0, input.currentWater - input.priorWater);
    const waterCost = waterUnits > 0 ? Math.round(waterUnits * input.waterUnitCost) : 0;

    const rentCost = input.rentCost || 0;
    const depositCost = input.depositCost || 0;
    const otherCost = input.otherCost || 0;

    const totalCost = rentCost + elecCost + waterCost + depositCost + otherCost;

    return {
      elecUnits,
      elecCost,
      waterUnits,
      waterCost,
      totalCost,
    };
  }

  /**
   * Calculates overdue penalty based on due date and daily penalty rate
   */
  static calculateLateFee(dueDateStr: string, penaltyRatePerDay: number): number {
    if (!dueDateStr || penaltyRatePerDay <= 0) return 0;
    const dueDate = new Date(dueDateStr);
    const today = new Date();

    // Reset hours to compare dates cleanly
    dueDate.setHours(0, 0, 0, 0);
    today.setHours(0, 0, 0, 0);

    const diffTime = today.getTime() - dueDate.getTime();
    if (diffTime <= 0) return 0;

    const overdueDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return overdueDays * penaltyRatePerDay;
  }
}
