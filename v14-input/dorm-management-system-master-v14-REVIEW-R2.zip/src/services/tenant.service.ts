/**
 * Tenant & Lease Business Service
 */

export interface RoomOccupancyInfo {
  id: number;
  status: string;
  roomNumber?: string;
  tenantName?: string | null;
}

export interface ContractOccupancyInfo {
  roomId: number;
  status: string;
}

export class TenantService {
  /**
   * Evaluates lease contract status based on start/end dates.
   * Threshold set to 60 days for 'expiring_soon' status.
   */
  static getContractStatus(startDateStr: string, endDateStr: string): 'active' | 'expiring_soon' | 'expired' {
    if (!endDateStr) return 'active';
    const endDate = new Date(endDateStr);
    const today = new Date();

    const diffDays = Math.ceil((endDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    if (diffDays < 0) return 'expired';
    if (diffDays <= 60) return 'expiring_soon';
    return 'active';
  }

  /**
   * Validates whether a room is currently occupied or has an active lease contract.
   * Returns validation result indicating if creation of a new active contract is allowed.
   */
  static validateRoomOccupancy(
    roomId: number,
    rooms: RoomOccupancyInfo[],
    existingContracts?: ContractOccupancyInfo[]
  ): { isOccupied: boolean; message?: string } {
    const room = rooms.find((r) => r.id === roomId);
    if (!room) {
      return { isOccupied: false, message: 'ไม่พบข้อมูลห้องพักที่เลือก' };
    }

    const isRoomOccupied = room.status === 'occupied';
    const hasActiveContract = existingContracts
      ? existingContracts.some(
          (c) => c.roomId === roomId && (c.status === 'active' || c.status === 'expiring_soon')
        )
      : false;

    if (isRoomOccupied || hasActiveContract) {
      const occupantDetail = room.tenantName ? ` (${room.tenantName})` : '';
      const roomLabel = room.roomNumber ? `ห้อง ${room.roomNumber}` : `ห้อง ID ${roomId}`;
      return {
        isOccupied: true,
        message: `${roomLabel} มีผู้เช่าอยู่แล้ว${occupantDetail} ไม่สามารถทำสัญญาเช่าใหม่ซ้ำซ้อนได้`,
      };
    }

    return { isOccupied: false };
  }
}
