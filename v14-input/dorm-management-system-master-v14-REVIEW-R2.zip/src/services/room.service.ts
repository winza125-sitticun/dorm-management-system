/**
 * Room Business Logic Service
 * Handles building/floor resolution, occupancy status, and room metadata normalization.
 */

export interface RoomMeta {
  building: string;
  floor: string;
}

export class RoomService {
  /**
   * Normalizes room numbers to extract building and floor
   * e.g., "A101" -> building "A", floor "1"
   * e.g., "102" -> building "อาคารหลัก", floor "1"
   */
  static extractRoomMeta(roomNumber: string): RoomMeta {
    if (!roomNumber) return { building: 'อาคารหลัก', floor: '1' };

    const clean = roomNumber.trim().toUpperCase();
    const match = clean.match(/^([A-Z]+)?\s*(\d+)(.*)$/);

    if (match) {
      const building = match[1] || 'อาคารหลัก';
      const digits = match[2];
      const floor = digits.length >= 3 ? digits.substring(0, digits.length - 2) : '1';
      return { building, floor };
    }

    return { building: 'อาคารหลัก', floor: '1' };
  }

  /**
   * Evaluates occupancy rate percentage
   */
  static calculateOccupancyRate(totalRooms: number, occupiedRooms: number): number {
    if (totalRooms <= 0) return 0;
    return Math.round((occupiedRooms / totalRooms) * 100);
  }
}
