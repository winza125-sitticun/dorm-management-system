import type { SubscriptionPlan } from './constants/planEntitlements.ts';

export type UserRole = 'super_admin' | 'owner' | 'manager' | 'staff' | 'tenant' | 'caretaker' | 'accountant' | 'technician' | 'housekeeper';

export interface Room {
  id: number;
  roomNumber: string;
  monthlyRent: number;
  status: 'vacant' | 'occupied';
  tenantName: string | null;
  tenantPhone: string | null;
  lineUserId?: string | null;
  lineDisplayName?: string | null;
  linePictureUrl?: string | null;
  lineStatus?: 'linked' | 'unlinked' | null;
  lineNotifyToken?: string | null;
  deletedAt?: string | null;
  deletedBy?: number | null;
}

export interface Bill {
  id: number;
  roomId: number;
  roomNumber: string;
  billMonth: string; // YYYY-MM
  priorElec: number;
  currentElec: number;
  elecDeduct: number;
  elecUnitCost: number;
  elecCost?: number;
  priorWater: number;
  currentWater: number;
  waterUnitCost: number;
  waterCost: number;
  rentCost: number;
  depositCost: number;
  otherCost: number;
  otherDescription: string | null;
  totalCost: number;
  dueDate: string; // YYYY-MM-DD
  status: 'unpaid' | 'paid';
  paidAt: string | null;
  slipImage?: string | null;
  slipUploadedAt?: string | null;
  slipStatus?: 'none' | 'pending' | 'verified' | 'rejected';
  tenantName: string | null;
  tenantPhone: string | null;
  deletedAt?: string | null;
  deletedBy?: number | null;
  chargeItems?: BillChargeItem[];
}

export type RecurringChargeFrequency = 'monthly' | 'quarterly' | 'yearly';

export interface RecurringChargeTemplate {
  id: number;
  userId: number;
  name: string;
  description: string | null;
  defaultAmount: number;
  frequency: RecurringChargeFrequency;
  billingMonths: number[];
  isActive: boolean;
  createdAt?: string;
  updatedAt?: string;
  deletedAt?: string | null;
}

export interface RecurringChargeAssignment {
  id: number;
  userId: number;
  roomId: number;
  templateId: number;
  amountOverride: number | null;
  isEnabled: boolean;
  template?: RecurringChargeTemplate;
}

export interface BillChargeItem {
  id?: number;
  billId?: number;
  assignmentId?: number | null;
  label: string;
  amount: number;
  kind: 'recurring' | 'manual' | 'legacy';
  sortOrder?: number;
}

export interface Settings {
  id: number;
  dormName: string;
  defaultElecRate: number;
  defaultWaterRate: number;
  defaultDueDateDay: number;
  defaultPenaltyRate: number;
  promptpayId: string | null;
  promptpayName: string | null;
  lineChannelAccessToken?: string | null;
  lineChannelSecret?: string | null;
  lineTokenConfigured?: boolean;
  lineSecretConfigured?: boolean;
  lineBotEnabled?: boolean | null;
    googleSpreadsheetId?: string | null;
    subscriptionPlan?: SubscriptionPlan;
    subscriptionStatus?: string;
    subscriptionExpiresAt?: string | null;
    fontScale?: 'small' | 'medium' | 'large';
  }

export interface UserProfile {
  id: number;
  uid: string;
  email: string;
  role: UserRole;
  parentId: number | null;
  permissions?: string;
  subscriptionPlan?: SubscriptionPlan;
  subscriptionStatus?: string;
  subscriptionExpiresAt?: string | null;
  password?: string;
  deletedAt?: string | null;
  deletedBy?: number | null;
}

export interface DashboardData {
  rooms: {
    total: number;
    occupied: number;
    vacant: number;
  };
  revenueThisMonth: {
    total: number;
    paid: number;
    unpaid: number;
  };
  unpaidRooms: Array<{
    billId: number;
    roomId: number;
    roomNumber: string;
    tenantName: string;
    amount: number;
    month: string;
  }>;
  revenueHistory: Array<{
    month: string;
    paid: number;
    unpaid: number;
    total: number;
  }>;
}

export type TicketCategory = 'plumbing' | 'electrical' | 'appliance' | 'furniture' | 'structure' | 'other';
export type TicketPriority = 'low' | 'medium' | 'high' | 'urgent';
export type TicketStatus = 'pending' | 'in_progress' | 'completed' | 'cancelled';

export interface MaintenanceTicket {
  id: number;
  roomId: number;
  roomNumber: string;
  tenantName: string | null;
  tenantPhone: string | null;
  title: string;
  description: string | null;
  category: TicketCategory;
  priority: TicketPriority;
  status: TicketStatus;
  imageUrl: string | null;
  repairCost: number;
  technicianNote: string | null;
  createdAt: string;
  updatedAt: string;
  deletedAt?: string | null;
  deletedBy?: number | null;
}

export type HousekeepingStatus = 'pending' | 'in_progress' | 'ready_for_inspection' | 'completed' | 'cancelled';

export interface HousekeepingTask {
  id: number;
  userId: number;
  roomId: number;
  roomNumber: string;
  assignedUserId: number | null;
  assignedUserEmail?: string | null;
  contractId: number | null;
  source: 'manual' | 'checkout';
  status: HousekeepingStatus;
  note: string | null;
  inspectionNote: string | null;
  createdBy: number;
  createdAt: string;
  updatedAt: string;
  completedAt: string | null;
}

export type ContractStatus = 'active' | 'expiring_soon' | 'expired' | 'terminated';

export interface LeaseContract {
  id: number;
  roomId: number;
  roomNumber: string;
  tenantName: string;
  tenantPhone: string | null;
  idCardNumber: string | null;
  startDate: string;
  endDate: string;
  monthlyRent: number;
  depositAmount: number;
  advanceRentAmount: number;
  contractDocumentUrl: string | null;
  status: ContractStatus;
  note: string | null;
  createdAt: string;
  updatedAt: string;
  deletedAt?: string | null;
  deletedBy?: number | null;
}

export type AnnouncementCategory = 'general' | 'maintenance' | 'billing' | 'urgent';

export interface Announcement {
  id: number;
  userId: number;
  title: string;
  content: string;
  category: AnnouncementCategory;
  isPinned: number; // 1 or 0
  targetRoomIds: string | null;
  imageUrl: string | null;
  createdAt: string;
  updatedAt: string;
  deletedAt?: string | null;
  deletedBy?: number | null;
}

export type NoteColor = 'yellow' | 'green' | 'blue' | 'pink' | 'purple' | 'gray';

export interface Note {
  id: number;
  userId: number;
  createdBy: number;
  createdByEmail: string | null;
  roomId: number | null;
  roomNumber: string | null;
  title: string;
  content: string;
  color: NoteColor;
  isPinned: number;
  createdAt: string;
  updatedAt: string;
  deletedAt?: string | null;
  deletedBy?: number | null;
}

export interface AuditLog {
  id: number;
  userId: number | null;
  userEmail: string;
  userRole: string;
  action: string;
  targetType: string;
  targetId: string | null;
  oldValue: string | null;
  newValue: string | null;
  ipAddress: string | null;
  userAgent: string | null;
  createdAt: string;
}

export interface ApiResponseSuccess<T = any> {
  success: true;
  data: T;
  message?: string;
}

export interface ApiErrorDetail {
  field?: string;
  message: string;
}

export interface ApiResponseError {
  success: false;
  error: {
    code: string;
    message: string;
    details?: ApiErrorDetail[];
  };
}

export type ApiResponse<T = any> = ApiResponseSuccess<T> | ApiResponseError;
