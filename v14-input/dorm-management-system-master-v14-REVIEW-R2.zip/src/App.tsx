import React, { useState, useEffect, useRef, lazy, Suspense } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { ToastProvider, useToast } from './context/ToastContext.tsx';
import { Login } from './components/Login.tsx';
import { BillInvoice } from './components/BillInvoice.tsx';
import { FirstSetupWizard } from './components/FirstSetupWizard.tsx';
import { PageSkeletonLoader } from './components/common/PageSkeletonLoader.tsx';

import { LineRegisterView } from './components/LineRegisterView.tsx';
import { TenantPortalView } from './components/TenantPortalView.tsx';

// Code Splitting - Dynamic Lazy Imports
const DashboardView = lazy(() => import('./components/DashboardView.tsx').then(m => ({ default: m.DashboardView })));
const RoomsView = lazy(() => import('./components/RoomsView.tsx').then(m => ({ default: m.RoomsView })));
const CreateBillView = lazy(() => import('./components/CreateBillView.tsx').then(m => ({ default: m.CreateBillView })));
const BulkMeterEntryView = lazy(() => import('./components/BulkMeterEntryView.tsx').then(m => ({ default: m.BulkMeterEntryView })));
const HistoryView = lazy(() => import('./components/HistoryView.tsx').then(m => ({ default: m.HistoryView })));
const ReportView = lazy(() => import('./components/ReportView.tsx').then(m => ({ default: m.ReportView })));
const SettingsView = lazy(() => import('./components/SettingsView.tsx').then(m => ({ default: m.SettingsView })));
const MaintenanceView = lazy(() => import('./components/MaintenanceView.tsx').then(m => ({ default: m.MaintenanceView })));
const ContractsView = lazy(() => import('./components/ContractsView.tsx').then(m => ({ default: m.ContractsView })));
const AnnouncementsView = lazy(() => import('./components/AnnouncementsView.tsx').then(m => ({ default: m.AnnouncementsView })));
const NotesView = lazy(() => import('./components/NotesView.tsx').then(m => ({ default: m.NotesView })));
const AuditLogView = lazy(() => import('./components/AuditLogView.tsx').then(m => ({ default: m.AuditLogView })));
const HousekeepingView = lazy(() => import('./components/HousekeepingView.tsx').then(m => ({ default: m.HousekeepingView })));
import { Room, Bill, Settings, DashboardData, UserProfile, MaintenanceTicket, LeaseContract, Announcement, Note, HousekeepingTask } from './types.ts';
import { PERMISSIONS, hasAppPermission } from './constants/permissions.ts';
import { normalizeSubscriptionPlan } from './constants/planEntitlements.ts';
import { canAccessTabForPlan, requiredPaidPlanForTab } from './utils/planNavigation.ts';
import { ThemeProvider, useTheme } from './context/ThemeContext.tsx';
import { 
  Building2, 
  TrendingUp, 
  Home as HomeIcon, 
  Calculator, 
  FileText, 
  Settings as SettingsIcon, 
  LogOut, 
  Menu, 
  X,
  User,
  RefreshCw,
  FileSpreadsheet,
  Layers,
  Wrench,
  FileSignature,
  Megaphone,
  NotebookPen,
  FileClock,
  Sparkles,
  Sun,
  Moon,
  Lock
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { readApiError, unwrapApiData } from './utils/api.ts';
import { normalizeFontScale } from './utils/settings.ts';
import { APP_VERSION_LABEL } from './generated/version.ts';
import {
  appSurfaceForLocation,
  canAccessAppTab,
  createAppNavigationSession,
  listenToAppHistory,
  tabForPath,
  type AppTab,
  type AppNavigationSession,
  type AppNavigationSessionOptions,
} from './utils/appNavigation.ts';

export const createMainAppNavigationSession = (options: AppNavigationSessionOptions) => (
  createAppNavigationSession(options)
);

interface RestoredAuthUser {
  uid?: string;
  email?: string;
}

export async function loadAuthenticatedUserProfile(
  request: (input: string, init: { headers: Record<string, string> }) => Promise<Response>,
  headers: Record<string, string>,
  restoredUser: RestoredAuthUser | null | undefined,
): Promise<UserProfile | null> {
  try {
    const response = await request('/api/profile', { headers });
    if (!response.ok) throw new Error('Failed to fetch profile');
    const responseJson = await response.json();
    return responseJson.data || responseJson;
  } catch (error) {
    console.error('Error fetching user profile:', error);
    return null;
  }
}

function MainAppContent() {
  const { user, idToken, logout, loading: authLoading } = useAuth();
  const { toast } = useToast();
  const { theme, toggleTheme } = useTheme();
  
  const [activeTab, setActiveTab] = useState<AppTab>(() => tabForPath(window.location.pathname) ?? 'dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showExitWarning, setShowExitWarning] = useState(false);
  const mobileMenuOpenRef = useRef(isMobileMenuOpen);
  mobileMenuOpenRef.current = isMobileMenuOpen;

  // Core App State
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [profileResolved, setProfileResolved] = useState(false);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [bills, setBills] = useState<Bill[]>([]);
  const [settings, setSettings] = useState<Settings | null>(null);
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const [maintenanceTickets, setMaintenanceTickets] = useState<MaintenanceTicket[]>([]);
  const [contracts, setContracts] = useState<LeaseContract[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [housekeepingTasks, setHousekeepingTasks] = useState<HousekeepingTask[]>([]);

  useEffect(() => {
    document.documentElement.dataset.fontScale = normalizeFontScale(settings?.fontScale);
  }, [settings?.fontScale]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [notesHasMore, setNotesHasMore] = useState(false);

  // Loaders
  const [roomsLoading, setRoomsLoading] = useState(false);
  const [billsLoading, setBillsLoading] = useState(false);
  const [settingsLoading, setSettingsLoading] = useState(false);
  const [dashboardLoading, setDashboardLoading] = useState(false);
  const [maintenanceLoading, setMaintenanceLoading] = useState(false);
  const [contractsLoading, setContractsLoading] = useState(false);
  const [announcementsLoading, setAnnouncementsLoading] = useState(false);
  const [housekeepingLoading, setHousekeepingLoading] = useState(false);
  const [notesLoading, setNotesLoading] = useState(false);

  // Selected Bill for invoice viewing modal
  const [selectedInvoice, setSelectedInvoice] = useState<Bill | null>(null);

  // Global Refresh trigger helper
  const triggerRefreshData = async () => {
    if (!idToken) return;
    setDashboardLoading(true);
    setRoomsLoading(true);
    setBillsLoading(true);
    setSettingsLoading(true);
    setMaintenanceLoading(true);
    setContractsLoading(true);
    setAnnouncementsLoading(true);
    setHousekeepingLoading(true);
    setNotesLoading(true);
    
    try {
      await Promise.all([
        fetchProfile(),
        fetchSettings(),
        fetchRooms(),
        fetchBills(),
        fetchDashboard(),
        fetchMaintenanceTickets(),
        fetchContracts(),
        fetchAnnouncements(),
        fetchHousekeeping(),
        fetchNotes()
      ]);
    } catch (err) {
      console.error("Error refreshing global data:", err);
    } finally {
      setDashboardLoading(false);
      setRoomsLoading(false);
      setBillsLoading(false);
      setSettingsLoading(false);
      setMaintenanceLoading(false);
      setContractsLoading(false);
      setAnnouncementsLoading(false);
      setHousekeepingLoading(false);
      setNotesLoading(false);
    }
  };

  // Fetch initial data once user is authenticated
  useEffect(() => {
    if (idToken) {
      setProfileResolved(false);
      triggerRefreshData();
    } else {
      setUserProfile(null);
      setProfileResolved(false);
    }
  }, [idToken]);

  // --- API Handlers ---

  const getHeaders = () => {
    return {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${idToken}`
    };
  };

  const fetchProfile = async () => {
    try {
      setUserProfile(await loadAuthenticatedUserProfile(fetch, getHeaders(), user));
    } finally {
      setProfileResolved(true);
    }
  };

  const fetchHousekeeping = async () => {
    if (!idToken) return;
    try {
      const res = await fetch('/api/housekeeping', { headers: getHeaders() });
      if (res.status === 403) { setHousekeepingTasks([]); return; }
      if (!res.ok) throw new Error('Failed to fetch housekeeping tasks');
      const payload = await res.json();
      setHousekeepingTasks(Array.isArray(payload) ? payload : (Array.isArray(payload.data) ? payload.data : []));
    } catch (error) { console.error(error); }
  };

  // 1. Settings
  const fetchSettings = async () => {
    try {
      const res = await fetch('/api/settings', { headers: getHeaders() });
      if (!res.ok) throw new Error('Failed to fetch settings');
      setSettings(unwrapApiData<Settings>(await res.json()));
    } catch (err) {
      console.error(err);
    }
  };

  const updateSettings = async (settingsData: Omit<Settings, 'id'>) => {
    try {
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: getHeaders(),
        body: JSON.stringify(settingsData)
      });
      if (!res.ok) throw new Error(await readApiError(res, 'ไม่สามารถบันทึกการตั้งค่าได้'));
      setSettings(unwrapApiData<Settings>(await res.json()));
      fetchDashboard();
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  // 2. Rooms
  const fetchRooms = async () => {
    try {
      const res = await fetch('/api/rooms', { headers: getHeaders() });
      if (!res.ok) throw new Error('Failed to fetch rooms');
      const data = await res.json();
      const list = Array.isArray(data) ? data : (Array.isArray(data.data) ? data.data : []);
      setRooms(list);
    } catch (err) {
      console.error(err);
    }
  };

  const createRoom = async (roomData: Omit<Room, 'id'>) => {
    try {
      const res = await fetch('/api/rooms', {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify(roomData)
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || data.message || 'ไม่สามารถเพิ่มห้องพักได้');
      }
      await fetchRooms();
      await fetchDashboard();
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  const updateRoom = async (roomId: number, roomData: Omit<Room, 'id'>) => {
    try {
      const res = await fetch(`/api/rooms/${roomId}`, {
        method: 'PUT',
        headers: getHeaders(),
        body: JSON.stringify(roomData)
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || data.message || 'ไม่สามารถแก้ไขห้องพักได้');
      }
      await fetchRooms();
      await fetchDashboard();
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  const deleteRoom = async (roomId: number) => {
    try {
      const res = await fetch(`/api/rooms/${roomId}`, {
        method: 'DELETE',
        headers: getHeaders()
      });
      if (!res.ok) throw new Error('Failed to delete room');
      await fetchRooms();
      await fetchBills();
      await fetchDashboard();
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  // 3. Bills
  const fetchBills = async () => {
    try {
      const res = await fetch('/api/bills', { headers: getHeaders() });
      if (!res.ok) throw new Error('Failed to fetch bills');
      const data = await res.json();
      const list = Array.isArray(data) ? data : (Array.isArray(data.data) ? data.data : []);
      setBills(list);
    } catch (err) {
      console.error(err);
    }
  };

  const createBill = async (billData: Omit<Bill, 'id' | 'roomNumber' | 'tenantName' | 'tenantPhone'>) => {
    try {
      const res = await fetch('/api/bills', {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify(billData)
      });
      if (!res.ok) throw new Error('Failed to create bill');
      await fetchBills();
      await fetchDashboard();
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  const createBulkBills = async (bulkData: { billMonth: string; dueDate: string; bills: any[] }) => {
    try {
      const res = await fetch('/api/bills/bulk', {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify(bulkData)
      });
      if (!res.ok) {
        let errorMsg = 'Failed to create bulk bills';
        try {
          const errorData = await res.json();
          errorMsg = errorData.error?.message || errorData.message || errorMsg;
        } catch(e) {}
        throw new Error(errorMsg);
      }
      await fetchBills();
      await fetchDashboard();
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  const updateBill = async (billId: number, billData: Partial<Bill>) => {
    try {
      const res = await fetch(`/api/bills/${billId}`, {
        method: 'PUT',
        headers: getHeaders(),
        body: JSON.stringify(billData)
      });
      if (!res.ok) {
        let errorMsg = 'Failed to update bill';
        try {
          const errorData = await res.json();
          errorMsg = errorData.error?.message || errorData.message || errorMsg;
        } catch(e) {}
        throw new Error(errorMsg);
      }
      await fetchBills();
      await fetchDashboard();

      if (selectedInvoice && selectedInvoice.id === billId) {
        const freshBill = bills.find(b => b.id === billId);
        if (freshBill) {
          const resJson = await res.json();
          const updatedBill = resJson.data || resJson;
          const room = rooms.find(r => r.id === updatedBill.roomId);
          setSelectedInvoice({
            ...updatedBill,
            roomNumber: room?.roomNumber || selectedInvoice.roomNumber,
            tenantName: room?.tenantName || selectedInvoice.tenantName,
            tenantPhone: room?.tenantPhone || selectedInvoice.tenantPhone
          });
        }
      }
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  const deleteBill = async (billId: number) => {
    try {
      const res = await fetch(`/api/bills/${billId}`, {
        method: 'DELETE',
        headers: getHeaders()
      });
      if (!res.ok) throw new Error('Failed to delete bill');
      await fetchBills();
      await fetchDashboard();
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  // 4. Dashboard
  const fetchDashboard = async () => {
    try {
      const res = await fetch('/api/dashboard', { headers: getHeaders() });
      if (!res.ok) throw new Error('Failed to fetch dashboard');
      const data = await res.json();
      setDashboardData(data.data || data);
    } catch (err) {
      console.error(err);
    }
  };

  // 5. Maintenance Tickets
  const fetchMaintenanceTickets = async () => {
    try {
      const res = await fetch('/api/maintenance', { headers: getHeaders() });
      if (!res.ok) throw new Error('Failed to fetch maintenance tickets');
      const data = await res.json();
      const list = Array.isArray(data) ? data : (Array.isArray(data.data) ? data.data : []);
      setMaintenanceTickets(list);
    } catch (err) {
      console.error("Error fetching maintenance tickets:", err);
    }
  };

  // 6. Lease Contracts
  const fetchContracts = async () => {
    try {
      const res = await fetch('/api/contracts', { headers: getHeaders() });
      if (!res.ok) throw new Error('Failed to fetch contracts');
      const data = await res.json();
      const list = Array.isArray(data) ? data : (Array.isArray(data.data) ? data.data : []);
      setContracts(list);
    } catch (err) {
      console.error("Error fetching contracts:", err);
    }
  };

  // 7. Announcements
  const fetchAnnouncements = async () => {
    try {
      const res = await fetch('/api/announcements', { headers: getHeaders() });
      if (!res.ok) throw new Error('Failed to fetch announcements');
      const data = await res.json();
      const list = Array.isArray(data) ? data : (Array.isArray(data.data) ? data.data : []);
      setAnnouncements(list);
    } catch (err) {
      console.error("Error fetching announcements:", err);
    }
  };

  // 8. Internal Notes (bounded to the latest 100 records per request)
  const fetchNotes = async (offset = 0, append = false) => {
    setNotesLoading(true);
    try {
      const res = await fetch(`/api/notes?limit=100&offset=${Math.max(0, offset)}`, { headers: getHeaders() });
      if (!res.ok) throw new Error(await readApiError(res, 'ไม่สามารถดึงข้อมูลโน้ตได้'));
      const data = await res.json();
      const list = Array.isArray(data) ? data : (Array.isArray(data.data) ? data.data : []);
      setNotes((current) => append ? [...current, ...list] : list);
      setNotesHasMore(list.length === 100);
    } catch (err) {
      console.error('Error fetching notes:', err);
    } finally {
      setNotesLoading(false);
    }
  };

  // View bill helper for clicking from dashboard lists
  const onViewBillById = (billId: number) => {
    const bill = bills.find(b => b.id === billId);
    if (bill) {
      setSelectedInvoice(bill);
    } else {
      // If bills not loaded or found, do a quick fetch
      fetch(`/api/bills`, { headers: getHeaders() })
        .then(res => res.json())
        .then(data => {
          const found = data.find((b: any) => b.id === billId);
          if (found) setSelectedInvoice(found);
        });
    }
  };

  const [isSetupRequired, setIsSetupRequired] = useState(false);
  const [setupChecked, setSetupChecked] = useState(false);

  useEffect(() => {
    fetch('/api/setup/status')
      .then(res => res.json())
      .then(data => {
        const required = data?.data?.isSetupRequired || data?.isSetupRequired || false;
        setIsSetupRequired(required);
        setSetupChecked(true);
      })
      .catch(() => setSetupChecked(true));
  }, []);

  const profileRole = String(userProfile?.role || user?.role || 'super_admin').toLowerCase();
  const currentSubscriptionPlan = normalizeSubscriptionPlan(userProfile?.subscriptionPlan ?? settings?.subscriptionPlan);
  const rbacCanAccessTab = (tab: AppTab) => canAccessAppTab(tab, profileRole, userProfile?.permissions);
  const canAccessTab = (tab: AppTab) => canAccessTabForPlan(tab, profileRole, userProfile?.permissions, currentSubscriptionPlan);
  const navigationSessionRef = useRef<AppNavigationSession | null>(null);
  const navigateToTab = (tab: AppTab) => {
    if (!canAccessTab(tab)) {
      if (rbacCanAccessTab(tab)) {
        const requiredPlan = requiredPaidPlanForTab(tab);
        toast(`ฟีเจอร์นี้อยู่ในแพ็กเกจ ${requiredPlan ? requiredPlan[0].toUpperCase() + requiredPlan.slice(1) : 'ที่สูงกว่า'} — ติดต่อเพื่ออัปเกรด`, 'warning', 'แพ็กเกจปัจจุบันยังไม่รองรับ');
      }
      return;
    }
    navigationSessionRef.current?.navigateTo(tab);
  };

  useEffect(() => {
    const session = createMainAppNavigationSession({
      eventTarget: window,
      location: window.location,
      history: window.history,
      initialAccess: null,
      setTab: setActiveTab,
      closeMobileMenu: () => setIsMobileMenuOpen(false),
      dashboardExit: {
        isMobileMenuOpen: () => mobileMenuOpenRef.current,
        showExitWarning: () => setShowExitWarning(true),
        hideExitWarning: () => setShowExitWarning(false),
        exitApp: () => { window.close(); },
        scheduleTimeout: (callback, delayMs) => window.setTimeout(callback, delayMs),
        cancelTimeout: (handle) => window.clearTimeout(handle as number),
      },
    });
    navigationSessionRef.current = session;
    return () => {
      session.stop();
      if (navigationSessionRef.current === session) navigationSessionRef.current = null;
    };
  }, []);

  useEffect(() => {
    navigationSessionRef.current?.updateAccess(
      profileResolved
        ? { role: profileRole, permissions: userProfile?.permissions }
        : null,
    );
  }, [profileResolved, profileRole, userProfile?.permissions]);


  useEffect(() => {
    if (!profileResolved || canAccessTab(activeTab)) return;
    setActiveTab('dashboard');
    window.history.replaceState(window.history.state, '', '/');
  }, [activeTab, profileResolved, profileRole, userProfile?.permissions, currentSubscriptionPlan]);

  if (authLoading || !setupChecked) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex flex-col items-center justify-center text-[#6B6B66] font-sans">
        <RefreshCw className="w-8 h-8 animate-spin text-[#1DB954] mb-3" />
        <p className="text-sm font-semibold">กำลังตรวจสอบระบบ...</p>
      </div>
    );
  }

  if (isSetupRequired) {
    return (
      <FirstSetupWizard onSetupComplete={() => {
        setIsSetupRequired(false);
        window.location.reload();
      }} />
    );
  }

  if (!user) {
    return <Login />;
  }

  const isOwnerOrAdmin = profileRole === 'owner' || profileRole === 'super_admin';
  const hasPerm = (perm: any) => hasAppPermission(profileRole, userProfile?.permissions, perm);

  const menuItems = [
    { id: 'dashboard', label: 'ภาพรวม', icon: TrendingUp, group: 'overview' },
    { 
      id: 'rooms', 
      label: 'ห้องพัก', 
      icon: HomeIcon,
      group: 'property',
      show: rbacCanAccessTab('rooms')
    },
    { 
      id: 'contracts', 
      label: 'สัญญาเช่า & เงินประกัน', 
      icon: FileSignature,
      group: 'property',
      show: rbacCanAccessTab('contracts')
    },
    { 
      id: 'announcements', 
      label: 'ข่าวสาร & ประกาศ', 
      icon: Megaphone,
      group: 'overview',
      show: rbacCanAccessTab('announcements')
    },
    {
      id: 'notes',
      label: 'โน้ต',
      icon: NotebookPen,
      group: 'overview',
      show: rbacCanAccessTab('notes'),
    },
    { 
      id: 'create_bill', 
      label: 'สร้างบิล', 
      icon: Calculator,
      group: 'billing',
      show: rbacCanAccessTab('create_bill')
    },
    { 
      id: 'bulk_meter', 
      label: 'บันทึกมิเตอร์แบบกลุ่ม', 
      icon: Layers,
      group: 'billing',
      show: rbacCanAccessTab('bulk_meter')
    },
    { 
      id: 'history', 
      label: 'ประวัติบิล', 
      icon: FileText,
      group: 'billing',
      show: rbacCanAccessTab('history')
    },
    { id: 'maintenance', label: 'แจ้งซ่อม', icon: Wrench, group: 'property', show: rbacCanAccessTab('maintenance') },
    { id: 'housekeeping', label: 'งานแม่บ้าน', icon: Sparkles, group: 'property', show: rbacCanAccessTab('housekeeping') },
    { 
      id: 'report', 
      label: 'รายงานรวม & มิเตอร์', 
      icon: FileSpreadsheet,
      group: 'billing',
      show: rbacCanAccessTab('report')
    },
    { 
      id: 'settings', 
      label: 'ตั้งค่าระบบ', 
      icon: SettingsIcon,
      group: 'system',
      show: rbacCanAccessTab('settings')
    },
    {
      id: 'audit_logs',
      label: 'ประวัติกิจกรรม',
      icon: FileClock,
      group: 'system',
      show: rbacCanAccessTab('audit_logs'),
    },
  ]
    .filter(item => item.show === undefined || item.show === true)
    .map(item => ({
      ...item,
      planLocked: rbacCanAccessTab(item.id as AppTab) && !canAccessTab(item.id as AppTab),
      requiredPlan: requiredPaidPlanForTab(item.id as AppTab),
    }));

  const menuGroups = [
    { id: 'overview', label: 'ภาพรวม' },
    { id: 'property', label: 'จัดการห้องพัก' },
    { id: 'billing', label: 'การเงินและบิล' },
    { id: 'system', label: 'ระบบ' },
  ]
    .map(group => ({
      ...group,
      items: menuItems.filter(item => item.group === group.id),
    }))
    .filter(group => group.items.length > 0);

  return (
    <div className="min-h-screen bg-[#F5F5F0] text-[#1A1A1A] font-sans flex flex-col md:flex-row relative">
      
      {/* Sidebar for Desktop */}
      <aside className="hidden md:flex flex-col w-72 bg-black border-r border-white/10 p-5 flex-shrink-0 justify-between h-screen sticky top-0 no-print">
        <div className="space-y-6 overflow-y-auto flex-1 pr-2 pb-4 custom-scrollbar">
          {/* Logo */}
          <button
            onClick={() => navigateToTab('dashboard')}
            className="flex items-center gap-3 pb-4 border-b border-[#E0E0DB] text-left w-full hover:opacity-90 transition cursor-pointer"
          >
            <div className="p-2 rounded-xl bg-[#1DB954] text-[#1A1A1A] shadow-md">
              <Building2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-extrabold text-sm text-white tracking-wide uppercase">
                {settings?.dormName || 'Greenville'}
              </h1>
              <p className="text-[10px] text-[#1DB954] font-bold uppercase tracking-wider">ระบบบิลอัจฉริยะ</p>
            </div>
          </button>

          {/* Nav list */}
          <nav className="space-y-5" aria-label="เมนูหลัก">
            {menuGroups.map((group) => (
              <section key={group.id} aria-labelledby={`desktop-menu-${group.id}`}>
                <h2
                  id={`desktop-menu-${group.id}`}
                  className="mb-1.5 px-3 text-[10px] font-bold uppercase tracking-[0.14em] text-zinc-500"
                >
                  {group.label}
                </h2>
                <div className="space-y-1">
                  {group.items.map((item) => {
                    const Icon = item.icon;
                    const isActive = activeTab === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => navigateToTab(item.id as AppTab)}
                        aria-current={isActive ? 'page' : undefined}
                        className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold text-left transition cursor-pointer ${
                          isActive
                            ? 'bg-emerald-500 text-white shadow-md shadow-emerald-950/20'
                            : 'text-zinc-300 hover:text-white hover:bg-white/10'
                        }`}
                      >
                        <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-zinc-500'}`} />
                        <span className="leading-snug">{item.label}</span>
                        {item.planLocked && (
                          <span className="ml-auto inline-flex items-center gap-1 rounded-full bg-amber-400/15 px-2 py-0.5 text-[9px] font-extrabold uppercase text-amber-300">
                            <Lock className="h-3 w-3" />
                            {item.requiredPlan || 'upgrade'}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </section>
            ))}
          </nav>
        </div>

        {/* User Info, Theme Toggle & Logout */}
        <div className="pt-4 border-t border-[#E0E0DB] space-y-3 text-xs shrink-0">
          <button
            onClick={toggleTheme}
            className="w-full py-2 px-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold flex items-center justify-between transition cursor-pointer"
          >
            <div className="flex items-center gap-2">
              {theme === 'dark' ? <Moon className="w-4 h-4 text-purple-400" /> : <Sun className="w-4 h-4 text-amber-400" />}
              <span>{theme === 'dark' ? 'โหมดมืด (Dark Mode)' : 'โหมดสว่าง (Light Mode)'}</span>
            </div>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-700 font-mono text-zinc-400">
              {theme.toUpperCase()}
            </span>
          </button>

          <div className="flex items-center gap-2.5 px-1">
            <div className="w-8 h-8 rounded-full bg-[#F0F0EB] flex items-center justify-center text-[#8A8A85] overflow-hidden border border-[#E0E0DB]">
              {user.photoURL ? (
                <img src={user.photoURL} alt="User Avatar" referrerPolicy="no-referrer" />
              ) : (
                <User className="w-4 h-4" />
              )}
            </div>
            <div className="truncate max-w-[140px]">
              <p className="font-bold text-white text-xxs truncate">{user.displayName || 'Landlord'}</p>
              <p className="text-[9px] text-zinc-400 truncate">{user.email}</p>
            </div>
          </div>

          <div className="flex items-center justify-between rounded-lg bg-zinc-900 px-2.5 py-1.5 text-[9px] font-bold text-zinc-400">
            <span>แพ็กเกจ</span>
            <span className="uppercase text-emerald-400">{currentSubscriptionPlan}</span>
          </div>
          <p className="text-center text-[9px] font-mono text-zinc-500" title="Application version">
            {APP_VERSION_LABEL}
          </p>

          <button
            onClick={logout}
            className="w-full py-2 px-3 rounded-xl bg-white hover:bg-red-950/20 text-[#8A8A85] hover:text-red-400 border border-[#E0E0DB] hover:border-red-900/30 font-bold flex items-center justify-center gap-2 transition cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>ออกจากระบบ</span>
          </button>
        </div>
      </aside>

      {/* Top navbar for Mobile */}
      <header
        className="md:hidden border-b border-emerald-200/30 bg-cover bg-center p-4 sticky top-0 z-30 flex items-center justify-between shadow-lg no-print"
        style={{
          backgroundImage:
            "linear-gradient(90deg, rgba(6, 78, 59, 0.94), rgba(15, 23, 42, 0.96)), url('/header-nav-background-v1.png')",
        }}
      >
        <button
          onClick={() => navigateToTab('dashboard')}
          className="flex items-center gap-2.5 text-left hover:opacity-90 transition cursor-pointer"
        >
          <div className="p-1.5 rounded-lg bg-[#1DB954] text-[#1A1A1A] shadow-sm">
            <Building2 className="w-4 h-4 text-white" />
          </div>
          <div>
            <h1 className="font-extrabold text-xs text-white">
              {settings?.dormName || 'Greenville'}
            </h1>
            <p className="text-[8px] text-emerald-200 font-bold uppercase">ระบบคิดค่าเช่า</p>
          </div>
        </button>

        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="p-1.5 rounded-lg text-white hover:bg-white/15 transition"
        >
          {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </header>

      {/* Mobile Drawer Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <div 
            onClick={() => setIsMobileMenuOpen(false)}
            className="md:hidden fixed inset-0 bg-black/40 backdrop-blur-xs z-40 no-print cursor-pointer"
          >
            <motion.div 
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              onClick={(e) => e.stopPropagation()}
              className="w-64 h-full bg-cover bg-center p-5 border-r border-emerald-200/30 flex flex-col justify-between cursor-default"
              style={{
                backgroundImage:
                  "linear-gradient(180deg, rgba(6, 78, 59, 0.98), rgba(15, 23, 42, 0.99)), url('/header-nav-background-v1.png')",
              }}
            >
              <div className="space-y-6 overflow-y-auto flex-1 pr-2 pb-4 custom-scrollbar">
                <button
                  onClick={() => navigateToTab('dashboard')}
                  className="flex items-center gap-3 pb-4 border-b border-[#E0E0DB] text-left w-full hover:opacity-90 transition cursor-pointer"
                >
                  <div className="p-2 rounded-xl bg-[#1DB954] text-[#1A1A1A] shadow-md">
                    <Building2 className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h1 className="font-extrabold text-xs text-white uppercase">{settings?.dormName || 'Greenville'}</h1>
                    <p className="text-[9px] text-[#1DB954] font-semibold uppercase">Menu</p>
                  </div>
                </button>

                <nav className="space-y-5" aria-label="เมนูหลักบนมือถือ">
                  {menuGroups.map((group) => (
                    <section key={group.id} aria-labelledby={`mobile-menu-${group.id}`}>
                      <h2
                        id={`mobile-menu-${group.id}`}
                        className="mb-1.5 px-3 text-[10px] font-bold uppercase tracking-[0.14em] text-emerald-200/60"
                      >
                        {group.label}
                      </h2>
                      <div className="space-y-1">
                        {group.items.map((item) => {
                          const Icon = item.icon;
                          const isActive = activeTab === item.id;
                          return (
                            <button
                              key={item.id}
                              onClick={() => navigateToTab(item.id as AppTab)}
                              aria-current={isActive ? 'page' : undefined}
                              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold text-left transition cursor-pointer ${
                                isActive
                                  ? 'bg-emerald-500 text-white shadow-md shadow-emerald-950/20'
                                  : 'text-slate-100 hover:text-white hover:bg-white/12'
                              }`}
                            >
                              <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-emerald-200'}`} />
                              <span className="leading-snug">{item.label}</span>
                              {item.planLocked && (
                                <span className="ml-auto inline-flex items-center gap-1 rounded-full bg-amber-300/20 px-2 py-0.5 text-[9px] font-extrabold uppercase text-amber-200">
                                  <Lock className="h-3 w-3" />
                                  {item.requiredPlan || 'upgrade'}
                                </span>
                              )}
                            </button>
                          );
                        })}
                      </div>
                    </section>
                  ))}
                </nav>
              </div>

              {/* User Info & Logout */}
              <div className="pt-4 border-t border-[#E0E0DB] space-y-3 text-xs shrink-0">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-full bg-[#F0F0EB] flex items-center justify-center text-[#8A8A85] overflow-hidden border border-[#E0E0DB]">
                    {user.photoURL ? (
                      <img src={user.photoURL} alt="User Avatar" referrerPolicy="no-referrer" />
                    ) : (
                      <User className="w-4 h-4" />
                    )}
                  </div>
                  <div>
                    <p className="font-bold text-white text-xxs">{user.displayName}</p>
                    <p className="text-[9px] text-slate-200">{user.email}</p>
                  </div>
                </div>

                <div className="flex items-center justify-between rounded-lg bg-emerald-950/60 px-2.5 py-1.5 text-[9px] font-bold text-emerald-100">
                  <span>แพ็กเกจ</span>
                  <span className="uppercase text-emerald-300">{currentSubscriptionPlan}</span>
                </div>
                <p className="text-center text-[9px] font-mono text-zinc-500" title="Application version">
                  {APP_VERSION_LABEL}
                </p>

                <button
                  onClick={logout}
                  className="w-full py-2.5 px-3 rounded-xl bg-white hover:bg-red-950/20 text-[#8A8A85] hover:text-red-400 border border-[#E0E0DB] font-bold flex items-center justify-center gap-2 transition cursor-pointer"
                >
                  <LogOut className="w-4 h-4" />
                  <span>ออกจากระบบ</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Main Content Area */}
      <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto w-full max-w-7xl mx-auto">
        <Suspense fallback={<PageSkeletonLoader />}>
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.15 }}
            >
            {activeTab === 'dashboard' && (
              <DashboardView 
                data={dashboardData}
                loading={dashboardLoading}
                onRefresh={triggerRefreshData}
                onNavigateToBills={() => navigateToTab('history')}
                onViewBillById={onViewBillById}
                rooms={rooms}
                bills={bills}
                contracts={contracts}
                maintenanceTickets={maintenanceTickets}
                housekeepingTasks={housekeepingTasks}
                onNavigate={(tab) => navigateToTab(tab)}
              />
            )}

            {activeTab === 'rooms' && (
              <RoomsView 
                rooms={rooms}
                loading={roomsLoading}
                onCreateRoom={createRoom}
                onUpdateRoom={updateRoom}
                onDeleteRoom={deleteRoom}
                idToken={idToken}
                onRefreshRooms={fetchRooms}
                userProfile={userProfile}
                settings={settings}
              />
            )}

            {activeTab === 'create_bill' && (
              <CreateBillView 
                rooms={rooms}
                settings={settings || { id: 0, dormName: 'หอพักของฉัน', defaultElecRate: 7, defaultWaterRate: 13, defaultDueDateDay: 5, promptpayId: null, promptpayName: null }}
                bills={bills}
                onCreateBill={createBill}
                onCreateBulkBills={createBulkBills}
                onNavigateToHistory={() => navigateToTab('history')}
                idToken={idToken}
              />
            )}

            {activeTab === 'bulk_meter' && (
              <BulkMeterEntryView 
                rooms={rooms}
                settings={settings || { id: 0, dormName: 'หอพักของฉัน', defaultElecRate: 7, defaultWaterRate: 13, defaultDueDateDay: 5, promptpayId: null, promptpayName: null, defaultPenaltyRate: 0 }}
                bills={bills}
                loading={billsLoading}
                onCreateBulkBills={createBulkBills}
                onNavigateToHistory={() => navigateToTab('history')}
                idToken={idToken}
              />
            )}

            {activeTab === 'history' && (
              <HistoryView 
                bills={bills}
                rooms={rooms}
                settings={settings || { id: 0, dormName: 'หอพักของฉัน', defaultElecRate: 7, defaultWaterRate: 13, defaultDueDateDay: 5, promptpayId: null, promptpayName: null }}
                loading={billsLoading}
                onUpdateBill={updateBill}
                onDeleteBill={deleteBill}
                onViewBillDetails={(bill) => setSelectedInvoice(bill)}
                idToken={idToken}
                userProfile={userProfile}
              />
            )}

            {activeTab === 'report' && (
              <ReportView 
                bills={bills}
                rooms={rooms}
                settings={settings || { id: 0, dormName: 'หอพักของฉัน', defaultElecRate: 7, defaultWaterRate: 13, defaultDueDateDay: 5, promptpayId: null, promptpayName: null }}
                loading={billsLoading}
                onUpdateBill={updateBill}
                onViewBillDetails={(bill) => setSelectedInvoice(bill)}
                idToken={idToken}
                userProfile={userProfile}
              />
            )}

            {activeTab === 'maintenance' && (
              <MaintenanceView 
                tickets={maintenanceTickets}
                rooms={rooms}
                idToken={idToken}
                onRefresh={fetchMaintenanceTickets}
                showToast={(msg, type) => toast(msg, type || 'info')}
                canManage={hasPerm(PERMISSIONS.MANAGE_MAINTENANCE)}
              />
            )}

            {activeTab === 'housekeeping' && (
              <HousekeepingView
                tasks={housekeepingTasks}
                rooms={rooms}
                staff={[]}
                idToken={idToken}
                loading={housekeepingLoading}
                canManage={hasPerm(PERMISSIONS.MANAGE_HOUSEKEEPING)}
                onRefresh={fetchHousekeeping}
                showToast={(msg, type) => toast(msg, type || 'info')}
              />
            )}

            {activeTab === 'contracts' && (
              <ContractsView 
                contracts={contracts}
                rooms={rooms}
                idToken={idToken}
                onRefresh={() => {
                  fetchContracts();
                  fetchRooms();
                }}
                showToast={(msg, type) => toast(msg, type || 'info')}
                canManage={hasPerm(PERMISSIONS.MANAGE_CONTRACTS)}
                canCheckout={hasPerm(PERMISSIONS.PROCESS_CHECKOUT)}
              />
            )}

            {activeTab === 'announcements' && (
              <AnnouncementsView 
                announcements={announcements}
                rooms={rooms}
                idToken={idToken}
                onRefresh={fetchAnnouncements}
                showToast={(msg, type) => toast(msg, type || 'info')}
              />
            )}

            {activeTab === 'notes' && (
              <NotesView
                notes={notes}
                rooms={rooms}
                idToken={idToken}
                loading={notesLoading}
                hasMore={notesHasMore}
                onRefresh={() => fetchNotes()}
                onLoadMore={() => fetchNotes(notes.length, true)}
                showToast={(msg, type) => toast(msg, type || 'info')}
              />
            )}

            {activeTab === 'settings' && (
              <SettingsView 
                settings={settings}
                loading={settingsLoading}
                onUpdateSettings={updateSettings}
                idToken={idToken}
                userProfile={userProfile}
                onRestoreSuccess={triggerRefreshData}
                showToast={(msg, type) => toast(msg, type || 'info')}
              />
            )}

            {activeTab === 'audit_logs' && isOwnerOrAdmin && (
              <AuditLogView
                idToken={idToken}
                showToast={(msg, type) => toast(msg, type || 'info')}
              />
            )}
          </motion.div>
        </AnimatePresence>
        </Suspense>
      </main>

      {/* Shared Invoice Modal overlay */}
      {selectedInvoice && settings && (
        <BillInvoice 
          bill={selectedInvoice}
          settings={settings}
          onClose={() => setSelectedInvoice(null)}
        />
      )}

      <AnimatePresence>
        {showExitWarning && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
            className="fixed bottom-10 left-1/2 -translate-x-1/2 z-[9999] px-5 py-3 bg-[#1A1A1A]/90 text-white rounded-full shadow-2xl border border-[#333333]/50 backdrop-blur-md flex items-center gap-3 max-w-sm w-[calc(100%-2rem)] text-center justify-center font-bold text-xs sm:text-sm tracking-wide"
            role="status"
            aria-live="polite"
          >
            <div className="w-2 h-2 rounded-full bg-[#1DB954] animate-pulse shrink-0" />
            <span>กดปุ่มกลับ (Back) อีกครั้งเพื่อออกจากเว็บแอป</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function App() {
  const [currentLocation, setCurrentLocation] = useState(
    () => `${window.location.pathname}${window.location.search}`,
  );

  useEffect(() => {
    return listenToAppHistory({
      eventTarget: window,
      location: window.location,
      onLocation: setCurrentLocation,
    });
  }, []);

  const appSurface = appSurfaceForLocation(currentLocation);

  if (appSurface === 'tenant_portal') {
    return (
      <TenantPortalView />
    );
  }

  if (appSurface === 'line_registration') {
    return (
      <LineRegisterView 
        onBackToLogin={() => {
          window.history.pushState({}, '', '/');
          setCurrentLocation('/');
        }}
      />
    );
  }

  return (
    <ThemeProvider>
      <AuthProvider>
        <ToastProvider>
          <MainAppContent />
        </ToastProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
