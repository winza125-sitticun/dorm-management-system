import { db } from '../db/index.ts';
import { leaseContracts } from '../db/schema.ts';
import { eq, isNull } from 'drizzle-orm';

export class TenantRepository {
  static async findAllContracts(dbClient: any = db): Promise<any[]> {
    if (dbClient.prepare) {
      const { results } = await dbClient.prepare("SELECT * FROM lease_contracts WHERE deleted_at IS NULL ORDER BY id DESC").all();
      return results || [];
    }
    return dbClient.select().from(leaseContracts).where(isNull(leaseContracts.deletedAt));
  }

  static async findContractById(id: number, dbClient: any = db): Promise<any | null> {
    if (dbClient.prepare) {
      return dbClient.prepare("SELECT * FROM lease_contracts WHERE id = ? AND deleted_at IS NULL").bind(id).first();
    }
    const result = await dbClient.select().from(leaseContracts).where(eq(leaseContracts.id, id));
    return result[0] || null;
  }
}
