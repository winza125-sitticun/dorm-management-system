import { db } from '../db/index.ts';
import { bills } from '../db/schema.ts';
import { eq, isNull, and } from 'drizzle-orm';
import { Bill } from '../types.ts';

export class BillRepository {
  static async findAll(userId: number, dbClient: any = db): Promise<any[]> {
    if (dbClient.prepare) {
      const { results } = await dbClient.prepare(
        `SELECT b.*, r.room_number, r.tenant_name, r.tenant_phone 
         FROM bills b 
         JOIN rooms r ON b.room_id = r.id 
         WHERE b.user_id = ? AND b.deleted_at IS NULL AND r.deleted_at IS NULL 
         ORDER BY b.id DESC`
      ).bind(userId).all();
      return results || [];
    }
    return dbClient.select().from(bills).where(and(eq(bills.userId, userId), isNull(bills.deletedAt)));
  }

  static async findById(id: number, userId: number, dbClient: any = db): Promise<any | null> {
    if (dbClient.prepare) {
      return dbClient.prepare("SELECT * FROM bills WHERE id = ? AND user_id = ? AND deleted_at IS NULL").bind(id, userId).first();
    }
    const result = await dbClient.select().from(bills).where(and(eq(bills.id, id), eq(bills.userId, userId), isNull(bills.deletedAt)));
    return result[0] || null;
  }

  static async create(billData: Partial<Bill>, userId: number, dbClient: any = db): Promise<any> {
    if (dbClient.prepare) {
      return dbClient.prepare(
        `INSERT INTO bills (
          user_id, room_id, bill_month, prior_elec, current_elec, elec_deduct, elec_unit_cost, elec_cost,
          prior_water, current_water, water_unit_cost, water_cost, rent_cost, deposit_cost, other_cost,
          other_description, total_cost, due_date, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING *`
      ).bind(
        userId, billData.roomId, billData.billMonth, billData.priorElec, billData.currentElec,
        billData.elecDeduct || 0, billData.elecUnitCost, billData.elecCost || 0, billData.priorWater, billData.currentWater,
        billData.waterUnitCost, billData.waterCost || 0, billData.rentCost, billData.depositCost || 0, billData.otherCost || 0,
        billData.otherDescription || null, billData.totalCost, billData.dueDate, billData.status || 'unpaid'
      ).first();
    }
    const inserted = await dbClient.insert(bills).values({
      userId,
      roomId: billData.roomId!,
      billMonth: billData.billMonth!,
      priorElec: billData.priorElec || 0,
      currentElec: billData.currentElec || 0,
      elecDeduct: billData.elecDeduct || 0,
      elecUnitCost: billData.elecUnitCost || 7,
      elecCost: billData.elecCost || 0,
      priorWater: billData.priorWater || 0,
      currentWater: billData.currentWater || 0,
      waterUnitCost: billData.waterUnitCost || 13,
      waterCost: billData.waterCost || 0,
      rentCost: billData.rentCost || 0,
      depositCost: billData.depositCost || 0,
      otherCost: billData.otherCost || 0,
      otherDescription: billData.otherDescription || null,
      totalCost: billData.totalCost || 0,
      dueDate: billData.dueDate!,
      status: billData.status || 'unpaid',
    }).returning();
    return inserted[0];
  }

  static async softDelete(id: number, userId: number, dbClient: any = db): Promise<void> {
    if (dbClient.prepare) {
      await dbClient.prepare("UPDATE bills SET deleted_at = CURRENT_TIMESTAMP, deleted_by = ? WHERE id = ? AND user_id = ?").bind(userId, id, userId).run();
      return;
    }
    await dbClient.update(bills)
      .set({ deletedAt: new Date(), deletedBy: userId })
      .where(and(eq(bills.id, id), eq(bills.userId, userId)));
  }
}
