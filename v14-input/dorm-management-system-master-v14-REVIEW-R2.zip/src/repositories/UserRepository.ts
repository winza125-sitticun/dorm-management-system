import { db } from '../db/index.ts';
import { users } from '../db/schema.ts';
import { eq, isNull, and } from 'drizzle-orm';

export class UserRepository {
  static async findAll(dbClient: any = db): Promise<any[]> {
    if (dbClient.prepare) {
      const { results } = await dbClient.prepare("SELECT * FROM users WHERE deleted_at IS NULL ORDER BY id DESC").all();
      return results || [];
    }
    return dbClient.select().from(users).where(isNull(users.deletedAt));
  }

  static async findByUid(uid: string, dbClient: any = db): Promise<any | null> {
    if (dbClient.prepare) {
      return dbClient.prepare("SELECT * FROM users WHERE uid = ? AND deleted_at IS NULL").bind(uid).first();
    }
    const result = await dbClient.select().from(users).where(and(eq(users.uid, uid), isNull(users.deletedAt)));
    return result[0] || null;
  }

  static async countActiveUsers(dbClient: any = db): Promise<number> {
    if (dbClient.prepare) {
      const res = await dbClient.prepare("SELECT COUNT(*) as count FROM users WHERE deleted_at IS NULL").first();
      return res?.count || 0;
    }
    const results = await dbClient.select().from(users).where(isNull(users.deletedAt));
    return results.length;
  }
}
