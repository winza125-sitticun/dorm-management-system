import { db } from '../db/index.ts';
import { rooms } from '../db/schema.ts';
import { eq, isNull, and } from 'drizzle-orm';
import { Room } from '../types.ts';

export class RoomRepository {
  static async findAll(userId: number, dbClient: any = db): Promise<any[]> {
    if (dbClient.prepare) {
      // Cloudflare D1
      const { results } = await dbClient.prepare("SELECT * FROM rooms WHERE user_id = ? AND deleted_at IS NULL ORDER BY room_number ASC").bind(userId).all();
      return results || [];
    }
    return dbClient.select().from(rooms).where(and(eq(rooms.userId, userId), isNull(rooms.deletedAt)));
  }

  static async findById(id: number, userId: number, dbClient: any = db): Promise<any | null> {
    if (dbClient.prepare) {
      return dbClient.prepare("SELECT * FROM rooms WHERE id = ? AND user_id = ? AND deleted_at IS NULL").bind(id, userId).first();
    }
    const result = await dbClient.select().from(rooms).where(and(eq(rooms.id, id), eq(rooms.userId, userId), isNull(rooms.deletedAt)));
    return result[0] || null;
  }

  static async create(roomData: Partial<Room>, userId: number, dbClient: any = db): Promise<any> {
    if (dbClient.prepare) {
      return dbClient.prepare(
        "INSERT INTO rooms (user_id, room_number, monthly_rent, status, tenant_name, tenant_phone) VALUES (?, ?, ?, ?, ?, ?) RETURNING *"
      ).bind(
        userId, roomData.roomNumber, roomData.monthlyRent || 0, roomData.status || 'vacant', roomData.tenantName || null, roomData.tenantPhone || null
      ).first();
    }
    const inserted = await dbClient.insert(rooms).values({
      userId,
      roomNumber: roomData.roomNumber!,
      monthlyRent: roomData.monthlyRent || 0,
      status: roomData.status || 'vacant',
      tenantName: roomData.tenantName || null,
      tenantPhone: roomData.tenantPhone || null,
    }).returning();
    return inserted[0];
  }

  static async update(id: number, roomData: Partial<Room>, userId: number, dbClient: any = db): Promise<void> {
    if (dbClient.prepare) {
      await dbClient.prepare(
        "UPDATE rooms SET room_number = ?, monthly_rent = ?, status = ?, tenant_name = ?, tenant_phone = ? WHERE id = ? AND user_id = ?"
      ).bind(
        roomData.roomNumber, roomData.monthlyRent, roomData.status, roomData.tenantName || null, roomData.tenantPhone || null, id, userId
      ).run();
      return;
    }
    await dbClient.update(rooms)
      .set(roomData)
      .where(and(eq(rooms.id, id), eq(rooms.userId, userId)));
  }

  static async softDelete(id: number, userId: number, dbClient: any = db): Promise<void> {
    if (dbClient.prepare) {
      await dbClient.prepare("UPDATE rooms SET deleted_at = CURRENT_TIMESTAMP, deleted_by = ? WHERE id = ? AND user_id = ?").bind(userId, id, userId).run();
      return;
    }
    await dbClient.update(rooms)
      .set({ deletedAt: new Date(), deletedBy: userId })
      .where(and(eq(rooms.id, id), eq(rooms.userId, userId)));
  }
}
