import { Room, Bill } from '../types.ts';

// Create a new Google Spreadsheet
export async function createSpreadsheet(accessToken: string, title: string): Promise<string> {
  const response = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      properties: {
        title: title,
      },
    }),
  });

  if (!response.ok) {
    const errData = await response.json().catch(() => ({}));
    throw new Error(errData.error?.message || 'Failed to create Google Spreadsheet');
  }

  const data = await response.json();
  return data.spreadsheetId;
}

// Ensure required sheets (tabs) exist in the spreadsheet
export async function ensureSheetsExist(
  accessToken: string,
  spreadsheetId: string,
  sheetTitles: string[]
): Promise<void> {
  // 1. Get spreadsheet metadata to list existing sheet titles
  const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}`, {
    headers: {
      'Authorization': `Bearer ${accessToken}`,
    },
  });

  if (!response.ok) {
    throw new Error('Failed to fetch Spreadsheet metadata');
  }

  const data = await response.json();
  const existingTitles = data.sheets?.map((s: any) => s.properties.title) || [];

  // Find which titles are missing
  const missingTitles = sheetTitles.filter(title => !existingTitles.includes(title));

  if (missingTitles.length === 0) return;

  // 2. Add missing sheets via batchUpdate
  const requests = missingTitles.map(title => ({
    addSheet: {
      properties: {
        title: title,
      },
    },
  }));

  const updateResponse = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}:batchUpdate`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ requests }),
  });

  if (!updateResponse.ok) {
    throw new Error('Failed to create missing sheets/tabs in the spreadsheet');
  }
}

// Clear a range
export async function clearSheetRange(accessToken: string, spreadsheetId: string, range: string): Promise<void> {
  await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}:clear`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
    },
  });
}

// Write values to a range
export async function writeSheetValues(
  accessToken: string,
  spreadsheetId: string,
  range: string,
  values: any[][]
): Promise<void> {
  const response = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}?valueInputOption=USER_ENTERED`,
    {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        values: values,
      }),
    }
  );

  if (!response.ok) {
    const errData = await response.json().catch(() => ({}));
    throw new Error(errData.error?.message || 'Failed to write values to Google Sheet');
  }
}

// Export Rooms to Google Sheet
export async function exportRoomsToGoogleSheets(
  accessToken: string,
  spreadsheetId: string,
  rooms: Room[]
): Promise<void> {
  const sheetTitle = 'รายชื่อห้องพัก';
  await ensureSheetsExist(accessToken, spreadsheetId, [sheetTitle]);
  
  // Clear any existing content in the sheet first
  await clearSheetRange(accessToken, spreadsheetId, `${sheetTitle}!A1:Z500`);

  const headers = [
    'หมายเลขห้อง',
    'ชื่อผู้เช่า',
    'เบอร์โทรศัพท์ผู้เช่า',
    'สถานะของห้อง',
    'ค่าเช่ารายเดือน (บาท)',
    'บัญชี LINE',
    'สถานะการเชื่อมต่อ LINE',
    'LINE Notify Token'
  ];

  const rows = rooms.map(room => [
    room.roomNumber,
    room.tenantName || '-',
    room.tenantPhone || '-',
    room.status === 'occupied' ? 'มีผู้เช่า' : 'ห้องว่าง',
    room.monthlyRent,
    room.lineDisplayName || '-',
    room.lineStatus === 'linked' ? 'เชื่อมต่อแล้ว' : 'ไม่ได้เชื่อมต่อ',
    room.lineNotifyToken || '-'
  ]);

  const allValues = [headers, ...rows];
  await writeSheetValues(accessToken, spreadsheetId, `${sheetTitle}!A1`, allValues);
}

// Export Bills to Google Sheet
export async function exportBillsToGoogleSheets(
  accessToken: string,
  spreadsheetId: string,
  bills: Bill[]
): Promise<void> {
  const sheetTitle = 'ประวัติบิลค่าเช่า';
  await ensureSheetsExist(accessToken, spreadsheetId, [sheetTitle]);
  
  // Clear any existing content in the sheet first
  await clearSheetRange(accessToken, spreadsheetId, `${sheetTitle}!A1:Z1000`);

  const headers = [
    'ID บิล',
    'หมายเลขห้อง',
    'ชื่อผู้เช่า',
    'เบอร์โทรศัพท์',
    'รอบประจำเดือน',
    'ค่าเช่าห้องพัก (บาท)',
    'ค่าไฟครั้งก่อน',
    'ค่าไฟปัจจุบัน',
    'หักหน่วยไฟ',
    'อัตราค่าไฟต่อหน่วย',
    'ค่าน้ำครั้งก่อน',
    'ค่าน้ำปัจจุบัน',
    'อัตราค่าน้ำต่อหน่วย',
    'ค่าน้ำรวม (บาท)',
    'มัดจำ/ประกัน (บาท)',
    'ค่าใช้จ่ายอื่น ๆ (บาท)',
    'รายละเอียดค่าใช้จ่ายอื่น ๆ',
    'ยอดรวมค่าใช้จ่ายทั้งสิ้น (บาท)',
    'กำหนดชำระเงิน',
    'สถานะบิล',
    'วันที่จ่ายเงิน'
  ];

  const rows = bills.map(bill => {
    return [
      bill.id,
      bill.roomNumber,
      bill.tenantName || '-',
      bill.tenantPhone || '-',
      bill.billMonth,
      bill.rentCost,
      bill.priorElec,
      bill.currentElec,
      bill.elecDeduct,
      bill.elecUnitCost,
      bill.priorWater,
      bill.currentWater,
      bill.waterUnitCost,
      bill.waterCost,
      bill.depositCost,
      bill.otherCost,
      bill.otherDescription || '-',
      bill.totalCost,
      bill.dueDate,
      bill.status === 'paid' ? 'ชำระเงินแล้ว' : 'ค้างชำระ',
      bill.paidAt ? bill.paidAt : '-'
    ];
  });

  const allValues = [headers, ...rows];
  await writeSheetValues(accessToken, spreadsheetId, `${sheetTitle}!A1`, allValues);
}

// Export Maintenance Tickets to Google Sheet
export async function exportMaintenanceToGoogleSheets(
  accessToken: string,
  spreadsheetId: string,
  maintenanceList: any[]
): Promise<void> {
  const sheetTitle = 'รายการแจ้งซ่อม';
  await ensureSheetsExist(accessToken, spreadsheetId, [sheetTitle]);
  await clearSheetRange(accessToken, spreadsheetId, `${sheetTitle}!A1:Z500`);

  const headers = [
    'ID',
    'หมายเลขห้อง',
    'ผู้แจ้งซ่อม',
    'หัวข้อการแจ้งซ่อม',
    'รายละเอียด',
    'หมวดหมู่',
    'ระดับความสำคัญ',
    'สถานะ',
    'ค่าใช้จ่ายซ่อมแซม (บาท)'
  ];

  const rows = maintenanceList.map(item => [
    item.id,
    item.roomNumber || '-',
    item.tenantName || '-',
    item.title || '-',
    item.description || '-',
    item.category || '-',
    item.priority || '-',
    item.status || 'pending',
    item.repairCost || 0
  ]);

  const allValues = [headers, ...rows];
  await writeSheetValues(accessToken, spreadsheetId, `${sheetTitle}!A1`, allValues);
}

// Export Lease Contracts to Google Sheet
export async function exportContractsToGoogleSheets(
  accessToken: string,
  spreadsheetId: string,
  contractsList: any[]
): Promise<void> {
  const sheetTitle = 'รายการสัญญาเช่า';
  await ensureSheetsExist(accessToken, spreadsheetId, [sheetTitle]);
  await clearSheetRange(accessToken, spreadsheetId, `${sheetTitle}!A1:Z500`);

  const headers = [
    'ID สัญญา',
    'หมายเลขห้อง',
    'ชื่อผู้เช่า',
    'เบอร์โทรศัพท์',
    'เลขบัตรประชาชน',
    'วันที่เริ่มสัญญา',
    'วันที่สิ้นสุดสัญญา',
    'ค่าเช่ารายเดือน (บาท)',
    'เงินประกัน (บาท)',
    'ค่าเช่าล่วงหน้า (บาท)',
    'สถานะสัญญา'
  ];

  const rows = contractsList.map(c => [
    c.id,
    c.roomNumber || '-',
    c.tenantName || '-',
    c.tenantPhone || '-',
    c.idCardNumber || '-',
    c.startDate || '-',
    c.endDate || '-',
    c.monthlyRent || 0,
    c.depositAmount || 0,
    c.advanceRentAmount || 0,
    c.status || 'active'
  ]);

  const allValues = [headers, ...rows];
  await writeSheetValues(accessToken, spreadsheetId, `${sheetTitle}!A1`, allValues);
}

// 1-Click Sync All Data to Google Sheets
export async function syncAllDataToGoogleSheets(
  accessToken: string,
  spreadsheetId: string,
  data: {
    rooms?: Room[];
    bills?: Bill[];
    maintenance?: any[];
    contracts?: any[];
  }
): Promise<void> {
  if (data.rooms && data.rooms.length > 0) {
    await exportRoomsToGoogleSheets(accessToken, spreadsheetId, data.rooms);
  }
  if (data.bills && data.bills.length > 0) {
    await exportBillsToGoogleSheets(accessToken, spreadsheetId, data.bills);
  }
  if (data.maintenance && data.maintenance.length > 0) {
    await exportMaintenanceToGoogleSheets(accessToken, spreadsheetId, data.maintenance);
  }
  if (data.contracts && data.contracts.length > 0) {
    await exportContractsToGoogleSheets(accessToken, spreadsheetId, data.contracts);
  }
}
