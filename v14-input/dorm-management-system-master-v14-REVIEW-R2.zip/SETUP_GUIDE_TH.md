# คู่มือ Setup Cloudflare — Customer Delivery V14

## Windows

1. ติดตั้ง Node.js 22 ขึ้นไป
2. แตก ZIP ลงโฟลเดอร์ใหม่
3. ดับเบิลคลิก `SETUP-WINDOWS.cmd`

Wizard จะทำตามลำดับ:

1. ตรวจ Node/npm และติดตั้ง dependencies ด้วย `npm ci`
2. ตรวจบัญชี Cloudflare ที่ Login อยู่ และให้เลือกใช้เดิม / Login ใหม่ / ยกเลิก
3. ถามชื่อ Pages Project และ D1 Database
4. ใช้ resource เดิมถ้ามี หรือถามก่อนสร้างใหม่
5. ดึง D1 Database ID และสร้าง `wrangler.jsonc` จริงจาก `wrangler.template.jsonc`
6. ตรวจ `JWT_SECRET`; ถ้าขาดจะสร้างให้ ถ้ามีอยู่แล้วจะเก็บค่าเดิม
7. รัน Local migration + build ตามที่ยืนยัน
8. ก่อน Production รัน release checks, backup ฐานเดิม, migration และ deploy

## Android / Termux

รัน:

```bash
bash SETUP-ANDROID.sh
```

## ชื่อ Resource

แนะนำ:

```text
Pages Project: customer-dorm
D1 Database:   customer-dorm-db
```

ใช้ตัวพิมพ์เล็ก ตัวเลข และ `-` เท่านั้น

## หลัง Deploy

ใช้ URL ที่ Wizard แสดงจาก `Project Domains` ของ Cloudflare จริง ไม่ต้องเดา URL จากชื่อ Project

หาก Setup หยุดด้วย `[ERROR]` ให้แก้ error ก่อนแล้วรันใหม่ ระบบออกแบบให้หยุดก่อนแก้ Production เมื่อ release check ไม่ผ่าน
