#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "==============================================================="
echo " Dorm Management System - V14 Master Package Builder"
echo "==============================================================="
node -v
node -e "const m=Number(process.versions.node.split('.')[0]||0); if(m<22){console.error('ERROR: Node.js 22+ required. Found '+process.version); process.exit(1)}"
npm -v
npm ci
npm run packages:release
echo "[OK] V14 packages created in release-v14/"
