# Release Notes — Customer Delivery V13

V13 รวมงานที่ผ่านการแก้ไขระหว่างการทดสอบส่งมอบ:

- V13 Master Package Builder: พัฒนา source ชุดเดียวและสร้าง Demo / Basic / Standard / Pro อัตโนมัติ พร้อม audit + ZIP verify + SHA256

- Plan Entitlements แยกจาก RBAC สำหรับ Demo / Basic / Standard / Pro
- Windows launchers ใช้ `call npm` และ Node child-process รองรับ `.cmd`
- Setup ใช้ `wrangler.template.jsonc` และสร้าง config จริงหลังระบุ Cloudflare resource
- เลือก/เปลี่ยนบัญชี Cloudflare ก่อน Setup
- reuse Pages/D1 เดิมได้และไม่สร้างซ้ำโดยไม่ถาม
- D1 backup รองรับ Windows
- Upgrade Manager ใช้ฐานเดิมและรองรับ Upgrade อย่างเดียว
- บิลมือถือคง layout แบบคอมและย่อทั้งใบ
- แสดง URL จริงจาก Cloudflare Project Domains หลัง Deploy
- ตรวจ/รักษา JWT_SECRET ของ Project เดิมก่อน Deploy
- ปิด fallback รหัสผ่าน default ใน Express/VPS path
- ลบข้อมูลทดสอบส่วนบุคคลและเอกสารภายในออกจากชุดลูกค้า
