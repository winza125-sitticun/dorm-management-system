# สถานะชุดส่งมอบ — V14 Master

Master นี้เป็น source of truth สำหรับ Demo / Basic / Standard / Pro

## Release gate ก่อน Production

```bash
npm ci
npm run release:check
npm run build:pages
npm run packages:release
```

ถ้าคำสั่งใด fail ให้หยุดก่อนสร้างหรือส่ง CUSTOMER-READY

V14 เพิ่ม `.dormbackup`, strict validation, 10-minute Restore Token, safe D1 restore, Admin UI, package parity และ recovery documentation
