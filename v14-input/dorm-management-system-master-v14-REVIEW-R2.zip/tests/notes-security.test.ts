import assert from 'node:assert/strict';
import test from 'node:test';
import {
  NOTE_CONTENT_MAX_LENGTH,
  NOTE_LIST_MAX_LIMIT,
  NOTE_REQUEST_MAX_BYTES,
  NOTE_TITLE_MAX_LENGTH,
  NoteCreateSchema,
  NoteUpdateSchema,
} from '../src/server/validators/notes.validator.ts';
import { RateLimiterService } from '../src/server/services/rateLimiter.service.ts';

test('note create validation trims and normalizes allowed values', () => {
  const result = NoteCreateSchema.parse({
    title: '  ติดตามค่าเช่า  ',
    content: '  โทรหาผู้เช่าอีกครั้ง  ',
    roomId: '12',
    color: 'green',
    isPinned: 1,
  });

  assert.equal(result.title, 'ติดตามค่าเช่า');
  assert.equal(result.content, 'โทรหาผู้เช่าอีกครั้ง');
  assert.equal(result.roomId, 12);
  assert.equal(result.isPinned, true);
});

test('note validation rejects oversized and unknown input', () => {
  assert.equal(NoteCreateSchema.safeParse({ title: 'x'.repeat(NOTE_TITLE_MAX_LENGTH + 1), content: 'ok' }).success, false);
  assert.equal(NoteCreateSchema.safeParse({ title: 'ok', content: 'x'.repeat(NOTE_CONTENT_MAX_LENGTH + 1) }).success, false);
  assert.equal(NoteCreateSchema.safeParse({ title: 'ok', content: 'ok', injected: true }).success, false);
  assert.equal(NoteCreateSchema.safeParse({ title: 'ok', content: 'ok', roomId: true }).success, false);
  assert.equal(NoteCreateSchema.safeParse({ title: 'ok', content: 'ok', isPinned: 'yes' }).success, false);
  assert.equal(NoteUpdateSchema.safeParse({}).success, false);
});

test('note DoS limits stay bounded', () => {
  assert.equal(NOTE_REQUEST_MAX_BYTES, 16 * 1024);
  assert.equal(NOTE_LIST_MAX_LIMIT, 100);
});

test('note write limiter blocks the twenty-first request in a window', async () => {
  const key = `notes-test-${Date.now()}`;
  for (let index = 0; index < 20; index += 1) {
    const result = await RateLimiterService.checkRateLimit(null, key, 'notes_write');
    assert.equal(result.allowed, true);
  }
  const blocked = await RateLimiterService.checkRateLimit(null, key, 'notes_write');
  assert.equal(blocked.allowed, false);
  assert.ok(blocked.retryAfterSeconds > 0);
});
