import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import { requiredPlanFeatureForApiRequest, isDemoMutationRestricted, requiredPlanFeaturesForSettingsUpdate } from '../src/server/services/planAccess.service.ts';

test('API request mapping identifies Standard and Pro feature routes', () => {
  assert.equal(requiredPlanFeatureForApiRequest('/api/bills/bulk', 'POST'), 'bulkMeter');
  assert.equal(requiredPlanFeatureForApiRequest('/api/recurring-charges/templates', 'GET'), 'recurringCharges');
  assert.equal(requiredPlanFeatureForApiRequest('/api/rooms/12/recurring-charges', 'PUT'), 'recurringCharges');
  assert.equal(requiredPlanFeatureForApiRequest('/api/caretakers', 'POST'), 'staff');
  assert.equal(requiredPlanFeatureForApiRequest('/api/contracts/2/checkout', 'POST'), 'checkout');
  assert.equal(requiredPlanFeatureForApiRequest('/api/contracts', 'GET'), 'contracts');
  assert.equal(requiredPlanFeatureForApiRequest('/api/maintenance', 'GET'), 'maintenance');
  assert.equal(requiredPlanFeatureForApiRequest('/api/housekeeping/2', 'PUT'), 'housekeeping');
  assert.equal(requiredPlanFeatureForApiRequest('/api/announcements', 'GET'), 'announcements');
  assert.equal(requiredPlanFeatureForApiRequest('/api/audit-logs', 'GET'), 'auditLogs');
  assert.equal(requiredPlanFeatureForApiRequest('/api/google-sheets/connect', 'POST'), 'googleSheets');
  assert.equal(requiredPlanFeatureForApiRequest('/api/line/send-overdue', 'POST'), 'lineIntegration');
  assert.equal(requiredPlanFeatureForApiRequest('/api/notes', 'GET'), 'notes');
  assert.equal(requiredPlanFeatureForApiRequest('/api/rooms', 'GET'), null);
  assert.equal(requiredPlanFeatureForApiRequest('/api/bills', 'GET'), null);
  assert.equal(requiredPlanFeatureForApiRequest('/api/admin/backup/export', 'GET'), 'backupExport');
  assert.equal(requiredPlanFeatureForApiRequest('/api/admin/backup/validate', 'POST'), 'backupRestore');
  assert.equal(requiredPlanFeatureForApiRequest('/api/admin/backup/restore', 'POST'), 'backupRestore');
});


test('settings update identifies integration features that require higher plans', () => {
  assert.deepEqual(requiredPlanFeaturesForSettingsUpdate({ dormName: 'ABC' }), []);
  assert.deepEqual(requiredPlanFeaturesForSettingsUpdate({ promptpayId: '0812345678' }), ['promptPay']);
  assert.deepEqual(requiredPlanFeaturesForSettingsUpdate({ lineBotEnabled: true }), ['lineIntegration']);
  assert.deepEqual(requiredPlanFeaturesForSettingsUpdate({ googleSpreadsheetId: 'sheet-1' }), ['googleSheets']);
  assert.deepEqual(requiredPlanFeaturesForSettingsUpdate({ promptpayName: 'Owner', lineChannelSecret: 'secret', googleSpreadsheetId: 'sheet-1' }), ['promptPay', 'lineIntegration', 'googleSheets']);
});

test('demo blocks destructive and configuration mutations while preserving the sales flow', () => {
  assert.equal(isDemoMutationRestricted('/api/settings', 'PUT'), true);
  assert.equal(isDemoMutationRestricted('/api/rooms/1', 'DELETE'), true);
  assert.equal(isDemoMutationRestricted('/api/bills/1', 'DELETE'), true);
  assert.equal(isDemoMutationRestricted('/api/caretakers', 'POST'), true);
  assert.equal(isDemoMutationRestricted('/api/bills', 'POST'), false);
  assert.equal(isDemoMutationRestricted('/api/bills/bulk', 'POST'), false);
  assert.equal(isDemoMutationRestricted('/api/rooms/1', 'PUT'), false);
});


test('settings responses mask integrations that the current plan does not own', () => {
  const express = readFileSync(new URL('../server.ts', import.meta.url), 'utf8');
  const pages = readFileSync(new URL('../functions/api/[[path]].ts', import.meta.url), 'utf8');
  for (const source of [express, pages]) {
    assert.match(source, /hasPlanFeature\(subscriptionPlan, ['"]promptPay['"]\)/);
    assert.match(source, /hasPlanFeature\(subscriptionPlan, ['"]lineIntegration['"]\)/);
    assert.match(source, /hasPlanFeature\(subscriptionPlan, ['"]googleSheets['"]\)/);
  }
});


test('public tenant and LINE surfaces have owner-plan enforcement helpers', () => {
  const express = readFileSync(new URL('../server.ts', import.meta.url), 'utf8');
  const pages = readFileSync(new URL('../functions/api/[[path]].ts', import.meta.url), 'utf8');
  for (const source of [express, pages]) {
    assert.match(source, /ownerHasPlanFeature/);
    assert.match(source, /tenantPortal/);
    assert.match(source, /lineIntegration/);
  }
});


test('tenant verification follows tenantPortal entitlement while LINE registration remains Pro-only', () => {
  const express = readFileSync(new URL('../server.ts', import.meta.url), 'utf8');
  const pages = readFileSync(new URL('../functions/api/[[path]].ts', import.meta.url), 'utf8');
  for (const source of [express, pages]) {
    const verifyIndex = source.indexOf('/api/public/line/verify');
    const registerIndex = source.indexOf('/api/public/line/register');
    assert.notEqual(verifyIndex, -1);
    assert.notEqual(registerIndex, -1);
    assert.match(source.slice(verifyIndex, verifyIndex + 7000), /ownerHasPlanFeature[\s\S]*tenantPortal/);
    assert.match(source.slice(registerIndex, registerIndex + 5000), /ownerHasPlanFeature[\s\S]*lineIntegration/);
  }
});

test('both server implementations contain authoritative plan errors and limit checks', () => {
  const express = readFileSync(new URL('../server.ts', import.meta.url), 'utf8') + readFileSync(new URL('../src/middleware/auth.ts', import.meta.url), 'utf8');
  const pages = readFileSync(new URL('../functions/api/[[path]].ts', import.meta.url), 'utf8');
  for (const source of [express, pages]) {
    assert.match(source, /PLAN_REQUIRED/);
    assert.match(source, /PLAN_LIMIT_REACHED/);
    assert.match(source, /requiredPlanFeatureForApiRequest/);
    assert.match(source, /getPlanLimit/);
    assert.match(source, /isDemoMutationRestricted/);
    assert.match(source, /requiredPlanFeaturesForSettingsUpdate/);
  }
});
