import test from 'node:test';
import assert from 'node:assert/strict';
import { BackupDataSchema, BackupValidationError, validateBackupReferences } from '../src/server/validators/backup.ts';
import { computeOwnerScope, validateBackupForRestore, verifyRestoreToken } from '../src/server/services/backup.service.ts';
import { emptyBackupData, manifestFor, room, bill } from './helpers/backup-fixture.ts';

const SECRET = '0123456789abcdef0123456789abcdef';

class ValidationStmt {
  constructor(private db: ValidationDb, private sql: string, private args: unknown[] = []) {}
  bind(...args: unknown[]) { this.args = args; return this; }
  async first<T>() { return this.db.first(this.sql, this.args) as T | null; }
  async all<T>() { return { results: this.db.all(this.sql, this.args) as T[] }; }
}
class ValidationDb {
  constructor(public ownerId = 7, public uid = 'owner-uid') {}
  prepare(sql: string) { return new ValidationStmt(this, sql); }
  first(sql: string, _args: unknown[]) {
    const q = sql.toLowerCase();
    if (q.includes('select uid from users')) return { uid: this.uid };
    if (q.includes('count(*)')) return { count: 0 };
    return null;
  }
  all(sql: string, _args: unknown[]) {
    if (sql.toLowerCase().includes('select id, parent_id, role from users')) return [{ id: this.ownerId, parent_id: null, role: 'owner' }];
    return [];
  }
}

test('strict data schema rejects unknown fields and integration secrets', () => {
  const data: any = emptyBackupData();
  data.settings.lineChannelSecret = 'secret';
  assert.throws(() => BackupDataSchema.parse(data));
  const data2: any = emptyBackupData(); data2.rooms = [{ ...room(), lineUserId: 'U123' }];
  assert.throws(() => BackupDataSchema.parse(data2));
});

test('reference validation rejects broken room↔bill reference before restore', () => {
  const data = emptyBackupData(); data.bills = [bill(11, 999)];
  assert.throws(() => validateBackupReferences(data, { ownerId: 7, existingUserIds: new Set([7]), childUserIds: new Set() }), /BACKUP_REFERENCE_INVALID/);
});

test('D1 constraint mirror rejects duplicate active rooms', () => {
  const data = emptyBackupData(); data.rooms = [room(1, '101'), room(2, '101')];
  assert.throws(() => validateBackupReferences(data, { ownerId: 7, existingUserIds: new Set([7]), childUserIds: new Set() }), /BACKUP_DUPLICATE_ACTIVE_ROOM/);
});

test('server validation binds a 600-second token to owner and data hash', async () => {
  const db = new ValidationDb(); const data = emptyBackupData();
  const ownerScope = await computeOwnerScope(db.uid); const manifest = await manifestFor(data, ownerScope);
  const result = await validateBackupForRestore(db as any, db.ownerId, SECRET, { manifest, data });
  assert.equal(result.valid, true); assert.equal(result.expiresInSeconds, 600);
  assert.equal((await verifyRestoreToken(result.restoreToken, SECRET, { ownerId: 7, ownerScope, dataSha256: manifest.dataSha256, formatVersion: 1 })).ok, true);
  assert.equal((await verifyRestoreToken(result.restoreToken, SECRET, { ownerId: 8, ownerScope, dataSha256: manifest.dataSha256, formatVersion: 1 })).ok, false);
  assert.equal((await verifyRestoreToken(result.restoreToken, SECRET, { ownerId: 7, ownerScope, dataSha256: 'f'.repeat(64), formatVersion: 1 })).ok, false);
});

test('server validation rejects corrupt hash, owner scope, and manifest counts', async () => {
  const db = new ValidationDb(); const data = emptyBackupData(); const ownerScope = await computeOwnerScope(db.uid);
  const manifest = await manifestFor(data, ownerScope);
  await assert.rejects(() => validateBackupForRestore(db as any, 7, SECRET, { manifest: { ...manifest, dataSha256: '0'.repeat(64) }, data }), (e: any) => e instanceof BackupValidationError && e.code === 'BACKUP_HASH_MISMATCH');
  await assert.rejects(() => validateBackupForRestore(db as any, 7, SECRET, { manifest: { ...manifest, ownerScope: 'f'.repeat(64) }, data }), (e: any) => e instanceof BackupValidationError && e.code === 'BACKUP_OWNER_SCOPE_MISMATCH');
  await assert.rejects(() => validateBackupForRestore(db as any, 7, SECRET, { manifest: { ...manifest, counts: { ...manifest.counts, rooms: 1 } }, data }), (e: any) => e instanceof BackupValidationError && e.code === 'BACKUP_COUNT_MISMATCH');
});
