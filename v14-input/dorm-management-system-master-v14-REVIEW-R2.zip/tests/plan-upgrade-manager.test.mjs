import test from 'node:test';
import assert from 'node:assert/strict';
import {
  PLANS,
  upgradeTargets,
  validateUpgrade,
  extractSubscriptionPlans,
  buildPlanUpdateSql,
  readDeploymentConfig,
  commandUsesShell,
  wranglerInvocation,
} from '../scripts/plan-upgrade.mjs';

test('upgrade targets only include higher plans in order', () => {
  assert.deepEqual(PLANS, ['demo', 'basic', 'standard', 'pro']);
  assert.deepEqual(upgradeTargets('demo'), ['basic', 'standard', 'pro']);
  assert.deepEqual(upgradeTargets('basic'), ['standard', 'pro']);
  assert.deepEqual(upgradeTargets('standard'), ['pro']);
  assert.deepEqual(upgradeTargets('pro'), []);
});

test('validateUpgrade rejects same plan, downgrade, and invalid plan', () => {
  assert.equal(validateUpgrade('basic', 'standard'), 'standard');
  assert.throws(() => validateUpgrade('basic', 'basic'), /higher plan/i);
  assert.throws(() => validateUpgrade('standard', 'basic'), /higher plan/i);
  assert.throws(() => validateUpgrade('basic', 'enterprise'), /invalid target plan/i);
});

test('extractSubscriptionPlans reads nested Wrangler D1 JSON response shapes', () => {
  const payload = [
    { results: [{ subscription_plan: 'basic' }], success: true },
    { meta: { nested: { results: [{ subscriptionPlan: 'basic' }] } } },
  ];
  assert.deepEqual(extractSubscriptionPlans(payload), ['basic']);
});

test('extractSubscriptionPlans preserves ambiguity so caller can fail closed', () => {
  const payload = { results: [{ subscription_plan: 'basic' }, { subscription_plan: 'standard' }] };
  assert.deepEqual(extractSubscriptionPlans(payload), ['basic', 'standard']);
});

test('buildPlanUpdateSql only accepts fixed plan literals', () => {
  const sql = buildPlanUpdateSql('standard');
  assert.match(sql, /subscription_plan = 'standard'/);
  assert.match(sql, /role IN \('owner', 'super_admin'\)/);
  assert.match(sql, /subscription_status = 'active'/);
  assert.throws(() => buildPlanUpdateSql("pro'; DROP TABLE users; --"), /invalid target plan/i);
});

test('readDeploymentConfig extracts existing Pages and D1 names', () => {
  const source = `{
    "name": "mydorm-demo",
    "d1_databases": [{"binding":"DB","database_name":"mydorm-demo-db","database_id":"12345678-1234-1234-1234-123456789abc"}]
  }`;
  assert.deepEqual(readDeploymentConfig(source), {
    projectName: 'mydorm-demo',
    databaseName: 'mydorm-demo-db',
    databaseId: '12345678-1234-1234-1234-123456789abc',
  });
});

test('Windows cmd and bat executables require shell mode', () => {
  assert.equal(commandUsesShell('npx.cmd', 'win32'), true);
  assert.equal(commandUsesShell('npm.cmd', 'win32'), true);
  assert.equal(commandUsesShell('tool.bat', 'win32'), true);
  assert.equal(commandUsesShell('npx', 'linux'), false);
});


test('Wrangler uses local JS entrypoint when installed so Windows SQL args avoid cmd shell parsing', () => {
  const result = wranglerInvocation({
    root: 'C:/app',
    nodeExecutable: 'C:/Program Files/nodejs/node.exe',
    platform: 'win32',
    exists: (path) => path.replaceAll('\\', '/').endsWith('/node_modules/wrangler/bin/wrangler.js'),
  });
  assert.equal(result.bin, 'C:/Program Files/nodejs/node.exe');
  assert.match(result.prefix[0].replaceAll('\\', '/'), /node_modules\/wrangler\/bin\/wrangler\.js$/);
  assert.equal(commandUsesShell(result.bin, 'win32'), false);
});
