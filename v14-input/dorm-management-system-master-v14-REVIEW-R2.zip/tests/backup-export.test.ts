import test from 'node:test';
import assert from 'node:assert/strict';
import { exportBusinessBackup, computeOwnerScope, snapshotCurrentIntegrationState } from '../src/server/services/backup.service.ts';
import { sha256Hex, stableStringify } from '../src/utils/backupFormat.ts';

type Row = Record<string, unknown>;

class FakeStatement {
  private args: unknown[] = [];
  private db: FakeD1;
  private sql: string;
  constructor(db: FakeD1, sql: string) { this.db = db; this.sql = sql; }
  bind(...args: unknown[]) { this.args = args; return this; }
  async first<T = Row>(): Promise<T | null> { return this.db.first(this.sql, this.args) as T | null; }
  async all<T = Row>(): Promise<{ results: T[] }> { return { results: this.db.all(this.sql, this.args) as T[] }; }
}

class FakeD1 {
  public queries: string[] = [];
  private ownerId: number;
  constructor(ownerId = 7) { this.ownerId = ownerId; }
  prepare(sql: string) { this.queries.push(sql); return new FakeStatement(this, sql); }
  private normalized(sql: string) { return sql.replace(/\s+/g, ' ').trim().toLowerCase(); }
  first(sql: string, args: unknown[]): Row | null {
    const q = this.normalized(sql);
    if (q.includes('select uid from users')) return args[0] === this.ownerId ? { uid: 'owner-public-uid' } : null;
    if (q.includes('from settings')) return {
      dorm_name: 'หอพักทดสอบ', default_elec_rate: 7, default_water_rate: 13,
      default_due_date_day: 5, default_penalty_rate: 100,
      promptpay_id: '0812345678', promptpay_name: 'Owner', font_scale: 'medium',
      line_channel_secret: 'MUST_NOT_EXPORT', subscription_plan: 'pro',
    };
    return null;
  }
  all(sql: string, args: unknown[]): Row[] {
    const q = this.normalized(sql);
    assert.equal(args[0], this.ownerId, `query must be owner-scoped: ${q}`);
    if (q.includes('from rooms')) return [{
      id: 1, room_number: '101', monthly_rent: 3000, status: 'occupied', tenant_name: 'Tenant', tenant_phone: '0800000000',
      created_at: '2026-08-01T00:00:00Z', deleted_at: null, deleted_by: null,
      line_user_id: 'MUST_NOT_EXPORT', line_display_name: 'Secret Link', line_notify_token: 'MUST_NOT_EXPORT',
    }];
    if (q.includes('from bills ')) return [{ id: 11, room_id: 1, bill_month: '2026-08', prior_elec: 10, current_elec: 20, elec_deduct: 0, elec_unit_cost: 7, elec_cost: 70, prior_water: 1, current_water: 2, water_unit_cost: 13, water_cost: 13, rent_cost: 3000, deposit_cost: 0, other_cost: 0, other_description: null, total_cost: 3083, due_date: '2026-08-05', status: 'unpaid', paid_at: null, slip_image: null, slip_uploaded_at: null, slip_status: 'none', created_at: '2026-08-01', deleted_at: null, deleted_by: null }];
    if (q.includes('from recurring_charge_templates')) return [{ id: 2, name: 'Internet', description: null, default_amount: 300, frequency: 'monthly', billing_months: '[1,2,3]', is_active: 1, created_at: '2026-01-01', updated_at: '2026-01-01', deleted_at: null }];
    if (q.includes('from room_recurring_charges')) return [{ id: 3, room_id: 1, template_id: 2, amount_override: null, is_enabled: 1, created_at: '2026-01-01', updated_at: '2026-01-01' }];
    if (q.includes('from bill_charge_items')) return [{ id: 4, bill_id: 11, assignment_id: 3, label: 'Internet', amount: 300, kind: 'recurring', sort_order: 1, created_at: '2026-08-01' }];
    if (q.includes('from maintenance_tickets')) return [{ id: 5, room_id: 1, room_number: '101', tenant_name: 'Tenant', tenant_phone: '0800000000', title: 'Tap', description: null, category: 'plumbing', priority: 'medium', status: 'pending', image_url: null, repair_cost: 0, technician_note: null, created_at: '2026-08-01', updated_at: '2026-08-01', deleted_at: null, deleted_by: null }];
    if (q.includes('from housekeeping_tasks')) return [{ id: 6, room_id: 1, assigned_user_id: null, contract_id: 7, source: 'manual', status: 'pending', note: null, inspection_note: null, created_by: 7, created_at: '2026-08-01', updated_at: '2026-08-01', completed_at: null }];
    if (q.includes('from lease_contracts')) return [{ id: 7, room_id: 1, room_number: '101', tenant_name: 'Tenant', tenant_phone: '0800000000', id_card_number: '1234', start_date: '2026-01-01', end_date: '2026-12-31', monthly_rent: 3000, deposit_amount: 3000, advance_rent_amount: 3000, contract_document_url: null, status: 'active', note: null, created_at: '2026-01-01', updated_at: '2026-01-01', deleted_at: null, deleted_by: null }];
    if (q.includes('from announcements')) return [{ id: 8, title: 'Hello', content: 'World', category: 'general', is_pinned: 0, target_room_ids: '1', image_url: null, created_at: '2026-08-01', updated_at: '2026-08-01', deleted_at: null, deleted_by: null }];
    if (q.includes('from notes')) return [{ id: 9, created_by: 7, room_id: 1, title: 'Note', content: 'Text', color: 'yellow', is_pinned: 0, created_at: '2026-08-01', updated_at: '2026-08-01', deleted_at: null, deleted_by: null }];
    return [];
  }
}

test('computeOwnerScope hashes UID instead of exposing it', async () => {
  const hash = await computeOwnerScope('owner-public-uid');
  assert.equal(hash.length, 64);
  assert.notEqual(hash, 'owner-public-uid');
});

test('exportBusinessBackup exports safe owner-scoped business data and manifest', async () => {
  const db = new FakeD1();
  const result = await exportBusinessBackup(db as any, 7, '1.1.0');
  assert.equal(result.manifest.format, 'dorm-backup');
  assert.equal(result.manifest.schemaVersion, 6);
  assert.equal(result.manifest.counts.rooms, result.data.rooms.length);
  assert.equal(result.manifest.dataSha256, await sha256Hex(stableStringify(result.data)));
  assert.equal(result.manifest.ownerScope.length, 64);
  assert.notEqual(result.manifest.ownerScope, 'owner-public-uid');
  assert.equal(result.manifest.dormName, 'หอพักทดสอบ');
  assert.equal('lineChannelSecret' in result.data.settings, false);
  assert.equal('subscriptionPlan' in result.data.settings, false);
  assert.equal('lineUserId' in result.data.rooms[0], false);
  assert.deepEqual(result.manifest.excluded, [
    'users', 'audit_logs', 'rate_limits', 'google_oauth_states', 'google_oauth_tokens',
    'line_event_logs', 'integration_secrets', 'room_line_linkage', 'subscription_metadata',
  ]);
});

test('exportBusinessBackup fails when owner UID is missing', async () => {
  await assert.rejects(() => exportBusinessBackup(new FakeD1(999) as any, 7, '1.1.0'), /BACKUP_OWNER_NOT_FOUND/);
});

test('snapshotCurrentIntegrationState preserves room LINE linkage and integration settings only', async () => {
  const db = new FakeD1();
  const snapshot = await snapshotCurrentIntegrationState(db as any, 7);
  assert.deepEqual(snapshot.rooms[0], {
    id: 1,
    lineUserId: 'MUST_NOT_EXPORT',
    lineDisplayName: 'Secret Link',
    linePictureUrl: undefined,
    lineStatus: undefined,
    lineNotifyToken: 'MUST_NOT_EXPORT',
  });
  assert.equal((snapshot.settings as any).lineChannelSecret, 'MUST_NOT_EXPORT');
  assert.equal((snapshot.settings as any).subscriptionPlan, 'pro');
});


test('export queries use explicit columns and never SELECT *', async () => {
  const db = new FakeD1();
  await exportBusinessBackup(db as any, 7, '1.1.0');
  assert.equal(db.queries.some((sql) => /select\s+\*/i.test(sql)), false);
  const businessQueries = db.queries.filter((sql) => /from\s+(rooms|bills|recurring_charge_templates|room_recurring_charges|maintenance_tickets|housekeeping_tasks|lease_contracts|announcements|notes)|from\s+bill_charge_items/i.test(sql));
  assert.ok(businessQueries.length >= 10);
  for (const sql of businessQueries) assert.match(sql, /user_id\s*=\s*\?/i);
});

test('backup payload contains no integration or subscription state anywhere', async () => {
  const result = await exportBusinessBackup(new FakeD1() as any, 7, '1.1.0');
  const serialized = JSON.stringify(result.data);
  for (const forbidden of ['lineUserId', 'lineChannelSecret', 'lineChannelAccessToken', 'googleSpreadsheetId', 'subscriptionPlan', 'subscriptionStatus', 'subscriptionExpiresAt']) {
    assert.equal(serialized.includes(forbidden), false, `forbidden backup field: ${forbidden}`);
  }
});
