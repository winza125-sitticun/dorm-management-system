import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { generateToken } from '../src/server/services/jwt.service.ts';
import { verifyRestoreToken } from '../src/server/services/backup.service.ts';

const SECRET = '0123456789abcdef0123456789abcdef';

test('Cloudflare exposes export/validate/restore routes with no-store response layer', () => {
  const source = readFileSync(new URL('../functions/api/[[path]].ts', import.meta.url), 'utf8');
  assert.match(source, /\/api\/admin\/backup\/export/);
  assert.match(source, /\/api\/admin\/backup\/validate/);
  assert.match(source, /\/api\/admin\/backup\/restore/);
  assert.match(source, /Cache-Control["']?\s*:\s*["']no-store/);
  assert.match(source, /RESTORE_BACKUP/); assert.match(source, /RESTORE_BACKUP_FAILED/);
});

test('restore-specific limiter happens before exact confirmation check', () => {
  const source = readFileSync(new URL('../functions/api/[[path]].ts', import.meta.url), 'utf8');
  const start = source.indexOf("path === '/api/admin/backup/restore'");
  const block = source.slice(start, source.indexOf('if (path ===', start + 40) > start ? source.indexOf('if (path ===', start + 40) : start + 12000);
  assert.ok(block.indexOf('backup_restore') >= 0);
  assert.ok(block.indexOf('backup_restore') < block.indexOf('confirmation !== \'RESTORE\''));
});

test('a correctly signed but overlong restore token is rejected', async () => {
  const binding = { ownerId: 7, ownerScope: 'a'.repeat(64), dataSha256: 'b'.repeat(64), formatVersion: 1 };
  const token = await generateToken({ purpose: 'dorm-backup-restore', ...binding }, SECRET, 1);
  assert.equal((await verifyRestoreToken(token, SECRET, binding)).ok, false);
});

test('Express/VPS fails closed with auth and role checks before D1_REQUIRED', () => {
  const source = readFileSync(new URL('../server.ts', import.meta.url), 'utf8');
  const route = source.indexOf("app.all('/api/admin/backup/*'"); const staticFallback = source.indexOf('vite.middlewares');
  assert.ok(route >= 0); assert.ok(staticFallback < 0 || route < staticFallback);
  const block = source.slice(route, route + 1800);
  assert.match(block, /requireAuth/); assert.match(block, /owner|super_admin/); assert.match(block, /D1_REQUIRED/); assert.match(block, /501/);
});

test('plan API guards make Demo export-only and paid plans restore-capable', async () => {
  const { requiredPlanFeatureForApiRequest } = await import('../src/server/services/planAccess.service.ts');
  const { hasPlanFeature } = await import('../src/constants/planEntitlements.ts');
  assert.equal(requiredPlanFeatureForApiRequest('/api/admin/backup/export', 'GET'), 'backupExport');
  assert.equal(requiredPlanFeatureForApiRequest('/api/admin/backup/restore', 'POST'), 'backupRestore');
  assert.equal(hasPlanFeature('demo', 'backupExport'), true); assert.equal(hasPlanFeature('demo', 'backupRestore'), false);
  for (const plan of ['basic','standard','pro'] as const) assert.equal(hasPlanFeature(plan, 'backupRestore'), true);
});
