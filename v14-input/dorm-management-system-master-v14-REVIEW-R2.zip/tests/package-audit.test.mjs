import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import test from 'node:test';

test('customer package audit rejects master internals, active config, secrets, and plan mismatches', async () => {
  const { auditCustomerTree } = await import('../scripts/package-audit.mjs');
  const root = await mkdtemp(join(tmpdir(), 'dorm-v14-audit-'));
  try {
    await mkdir(join(root, 'package-plans'));
    await writeFile(join(root, 'package-plans/demo.json'), '{}');
    await writeFile(join(root, 'wrangler.jsonc'), '{}');
    await writeFile(join(root, '.env'), 'API_TOKEN=abc123secretvalue');
    await writeFile(join(root, 'package.json'), JSON.stringify({ name: 'wrong' }));
    const issues = await auditCustomerTree(root, { id: 'demo', packageName: 'dorm-management-system-demo' });
    assert.ok(issues.some((x) => /package-plans/.test(x)));
    assert.ok(issues.some((x) => /wrangler\.jsonc/.test(x)));
    assert.ok(issues.some((x) => /\.env/.test(x)));
    assert.ok(issues.some((x) => /package name/i.test(x)));
  } finally { await rm(root, { recursive: true, force: true }); }
});


test('customer package audit rejects stale delivery versions in customer-facing files', async () => {
  const { auditCustomerTree } = await import('../scripts/package-audit.mjs');
  const root = await mkdtemp(join(tmpdir(), 'dorm-v14-stale-'));
  try {
    await writeFile(join(root, 'package.json'), JSON.stringify({ name: 'dorm-management-system-demo', scripts: {} }));
    await writeFile(join(root, 'README.md'), '# Customer Delivery V13');
    const issues = await auditCustomerTree(root, { id: 'demo', packageName: 'dorm-management-system-demo' });
    assert.ok(issues.some((x) => /stale delivery label/i.test(x)));
  } finally { await rm(root, { recursive: true, force: true }); }
});
