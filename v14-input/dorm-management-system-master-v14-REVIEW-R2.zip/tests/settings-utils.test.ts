import assert from 'node:assert/strict';
import test from 'node:test';
import { buildValidDueDate, extractSpreadsheetId, fontScalePercent, isValidSpreadsheetId, normalizeFontScale, parseNumberOrFallback } from '../src/utils/settings.ts';
import { getApiErrorMessage, unwrapApiData } from '../src/utils/api.ts';
import { validatePasswordPolicy } from '../src/utils/passwordPolicy.ts';

test('due date is clamped to the final day of each month', () => {
  assert.equal(buildValidDueDate('2026-02', 31), '2026-02-28');
  assert.equal(buildValidDueDate('2028-02', 31), '2028-02-29');
  assert.equal(buildValidDueDate('2026-04', 31), '2026-04-30');
  assert.equal(buildValidDueDate('2026-01', 0), '2026-01-01');
  assert.equal(buildValidDueDate('invalid', 5), '');
});

test('numeric settings preserve valid zero and fall back only for invalid input', () => {
  assert.equal(parseNumberOrFallback('0', 100), 0);
  assert.equal(parseNumberOrFallback('', 100), 0);
  assert.equal(parseNumberOrFallback('not-a-number', 100), 100);
});

test('Google Spreadsheet ID is extracted and validated', () => {
  const id = '1AbCdEfGhIjKlMnOpQrStUvWxYz_123456789';
  assert.equal(extractSpreadsheetId(`https://docs.google.com/spreadsheets/d/${id}/edit#gid=0`), id);
  assert.equal(isValidSpreadsheetId(id), true);
  assert.equal(isValidSpreadsheetId('too-short'), false);
});

test('password policy requires mixed case, number, and special character', () => {
  assert.equal(validatePasswordPolicy('Strong#123').isValid, true);
  assert.equal(validatePasswordPolicy('weak').isValid, false);
  assert.equal(validatePasswordPolicy('NoSpecial123').isValid, false);
});

test('API helpers support Cloudflare envelopes and both error shapes', () => {
  assert.deepEqual(unwrapApiData<{ id: number }>({ success: true, data: { id: 7 } }), { id: 7 });
  assert.deepEqual(unwrapApiData<{ id: number }>({ id: 8 }), { id: 8 });
  assert.equal(getApiErrorMessage({ error: { message: 'nested' } }, 'fallback'), 'nested');
  assert.equal(getApiErrorMessage({ error: 'plain' }, 'fallback'), 'plain');
});

test('font scale accepts only supported values and maps to safe percentages', () => {
  assert.equal(normalizeFontScale('small'), 'small');
  assert.equal(normalizeFontScale('large'), 'large');
  assert.equal(normalizeFontScale('unexpected'), 'medium');
  assert.equal(fontScalePercent('small'), 90);
  assert.equal(fontScalePercent('medium'), 100);
  assert.equal(fontScalePercent('large'), 112.5);
});
