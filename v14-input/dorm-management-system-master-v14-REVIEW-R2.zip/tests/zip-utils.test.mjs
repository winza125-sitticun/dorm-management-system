import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import test from 'node:test';

test('built-in V14 zip writer creates a deterministic archive that verifies and preserves UTF-8 files', async () => {
  const { createZipFromDirectory, verifyZipBytes } = await import('../scripts/zip-utils.mjs');
  const root = await mkdtemp(join(tmpdir(), 'dorm-v13-zip-'));
  try {
    await mkdir(join(root, 'nested'));
    await writeFile(join(root, 'a.txt'), 'hello');
    await writeFile(join(root, 'nested', 'ไทย.txt'), 'ทดสอบ');
    const a = await createZipFromDirectory(root);
    const b = await createZipFromDirectory(root);
    assert.deepEqual(a, b, 'ZIP bytes must be deterministic for the same tree');
    const verified = verifyZipBytes(a);
    assert.deepEqual(verified.names, ['a.txt', 'nested/ไทย.txt']);
    assert.equal(verified.entries.get('a.txt').toString('utf8'), 'hello');
    assert.equal(verified.entries.get('nested/ไทย.txt').toString('utf8'), 'ทดสอบ');
  } finally { await rm(root, { recursive: true, force: true }); }
});

test('zip verifier rejects corrupted archive bytes', async () => {
  const { createZipFromDirectory, verifyZipBytes } = await import('../scripts/zip-utils.mjs');
  const root = await mkdtemp(join(tmpdir(), 'dorm-v13-zip-corrupt-'));
  try {
    await writeFile(join(root, 'a.txt'), 'hello');
    const zip = await createZipFromDirectory(root);
    const bad = Buffer.from(zip);
    bad[Math.floor(bad.length / 3)] ^= 0xff;
    assert.throws(() => verifyZipBytes(bad));
  } finally { await rm(root, { recursive: true, force: true }); }
});
