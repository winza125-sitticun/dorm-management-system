import assert from 'node:assert/strict';
import test from 'node:test';
import { readFileSync } from 'node:fs';
import { hasAppPermission, PERMISSIONS, permissionsForRole } from '../src/constants/permissions.ts';
import { isChargeDue, normalizeBillingMonths, resolveChargeAmount, sumChargeItems } from '../src/utils/recurringCharges.ts';
import { canTransitionHousekeeping } from '../src/utils/housekeeping.ts';

test('role presets grant only the intended operational modules', () => {
  const accountant = permissionsForRole('accountant').join(',');
  const technician = permissionsForRole('technician').join(',');
  const housekeeper = permissionsForRole('housekeeper').join(',');
  assert.equal(hasAppPermission('accountant', accountant, PERMISSIONS.MANAGE_BILLS), true);
  assert.equal(hasAppPermission('accountant', accountant, PERMISSIONS.PROCESS_CHECKOUT), true);
  assert.equal(hasAppPermission('accountant', accountant, PERMISSIONS.MANAGE_MAINTENANCE), false);
  assert.equal(hasAppPermission('technician', technician, PERMISSIONS.MANAGE_MAINTENANCE), true);
  assert.equal(hasAppPermission('technician', technician, PERMISSIONS.VIEW_BILLS), false);
  assert.equal(hasAppPermission('housekeeper', housekeeper, PERMISSIONS.MANAGE_HOUSEKEEPING), true);
  assert.equal(hasAppPermission('housekeeper', housekeeper, PERMISSIONS.MANAGE_ROOMS), false);
});

test('owner and super admin always resolve to full access while custom permissions are honored', () => {
  assert.equal(hasAppPermission('owner', '', PERMISSIONS.MANAGE_SETTINGS), true);
  assert.equal(hasAppPermission('super_admin', null, PERMISSIONS.MANAGE_RECURRING_CHARGES), true);
  assert.equal(hasAppPermission('technician', 'view_bills', PERMISSIONS.VIEW_BILLS), true);
});

test('legacy permissions expand without locking existing caretaker accounts', () => {
  assert.equal(hasAppPermission('caretaker', 'manage_rooms', PERMISSIONS.VIEW_CONTRACTS), true);
  assert.equal(hasAppPermission('caretaker', 'manage_bills', PERMISSIONS.VIEW_REPORTS), true);
  assert.equal(hasAppPermission('caretaker', 'manage_settings', PERMISSIONS.MANAGE_RECURRING_CHARGES), true);
});

test('billing month rules validate monthly, quarterly, and yearly templates', () => {
  assert.deepEqual(normalizeBillingMonths('monthly', []), [1,2,3,4,5,6,7,8,9,10,11,12]);
  assert.deepEqual(normalizeBillingMonths('quarterly', [10, 1, 7, 4]), [1,4,7,10]);
  assert.deepEqual(normalizeBillingMonths('yearly', [12]), [12]);
  assert.throws(() => normalizeBillingMonths('quarterly', [1,4,7]));
  assert.throws(() => normalizeBillingMonths('yearly', [1,12]));
  assert.equal(isChargeDue({ frequency: 'quarterly', billingMonths: [1,4,7,10], isActive: true }, '2026-04'), true);
  assert.equal(isChargeDue({ frequency: 'yearly', billingMonths: [12], isActive: true }, '2026-11'), false);
});

test('room override and charge-item totals are stable snapshot values', () => {
  assert.equal(resolveChargeAmount({ amountOverride: null }, { defaultAmount: 350 }), 350);
  assert.equal(resolveChargeAmount({ amountOverride: 275 }, { defaultAmount: 350 }), 275);
  assert.equal(sumChargeItems([{ amount: 275 }, { amount: 120 }, { amount: -5 }]), 395);
});

test('housekeeping workflow enforces inspection before completion', () => {
  assert.equal(canTransitionHousekeeping('pending', 'in_progress'), true);
  assert.equal(canTransitionHousekeeping('pending', 'completed'), false);
  assert.equal(canTransitionHousekeeping('in_progress', 'ready_for_inspection'), true);
  assert.equal(canTransitionHousekeeping('ready_for_inspection', 'completed'), true);
  assert.equal(canTransitionHousekeeping('completed', 'pending'), false);
});

test('Express and Pages handlers both enforce direct endpoint permissions', () => {
  const expressSource = readFileSync(new URL('../server.ts', import.meta.url), 'utf8');
  const pagesSource = readFileSync(new URL('../functions/api/[[path]].ts', import.meta.url), 'utf8');
  for (const permission of [
    PERMISSIONS.VIEW_ROOMS, PERMISSIONS.MANAGE_ROOMS, PERMISSIONS.VIEW_BILLS,
    PERMISSIONS.MANAGE_BILLS, PERMISSIONS.EDIT_PAYMENTS, PERMISSIONS.VIEW_MAINTENANCE,
    PERMISSIONS.MANAGE_MAINTENANCE, PERMISSIONS.VIEW_CONTRACTS,
    PERMISSIONS.MANAGE_CONTRACTS, PERMISSIONS.PROCESS_CHECKOUT,
    PERMISSIONS.VIEW_HOUSEKEEPING, PERMISSIONS.MANAGE_HOUSEKEEPING,
  ]) {
    assert.match(expressSource, new RegExp(`PERMISSIONS\\.${Object.entries(PERMISSIONS).find(([, value]) => value === permission)?.[0]}`));
    assert.match(pagesSource, new RegExp(`PERMISSIONS\\.${Object.entries(PERMISSIONS).find(([, value]) => value === permission)?.[0]}`));
  }
  assert.match(expressSource, /status\(403\)/);
  assert.match(pagesSource, /'FORBIDDEN'.*403/);
});
