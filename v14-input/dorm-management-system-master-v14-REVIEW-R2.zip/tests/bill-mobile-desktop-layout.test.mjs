import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const source = fs.readFileSync(new URL('../src/components/BillInvoice.tsx', import.meta.url), 'utf8');
const invoiceStart = source.indexOf('ref={printAreaRef}');
const invoiceEnd = source.indexOf('{/* Action Controls Footer */}');
const invoiceSource = source.slice(invoiceStart, invoiceEnd);

test('bill preview uses a canonical desktop canvas with responsive scale', () => {
  assert.match(source, /const BILL_CANVAS_WIDTH = 528;/);
  assert.match(source, /const \[previewScale, setPreviewScale\] = React\.useState\(1\);/);
  assert.match(source, /transform: `scale\(\$\{previewScale\}\)`/);
  assert.match(source, /transformOrigin: 'top center'/);
});

test('printable invoice keeps desktop layout on mobile', () => {
  assert.ok(invoiceStart >= 0 && invoiceEnd > invoiceStart, 'printable invoice section should be found');
  assert.doesNotMatch(invoiceSource, /grid-cols-1\s+sm:grid-cols-2/);
  assert.match(invoiceSource, /grid grid-cols-2 gap-3/);
  assert.doesNotMatch(invoiceSource, /p-3\s+sm:p-5/);
  assert.match(invoiceSource, /w-\[528px\]/);
});

test('visual scaling stays outside printAreaRef so exports remain full size', () => {
  const transformIndex = source.indexOf('transform: `scale(${previewScale})`');
  const printRefIndex = source.indexOf('ref={printAreaRef}');
  assert.ok(transformIndex >= 0, 'preview transform should exist');
  assert.ok(printRefIndex >= 0, 'print area ref should exist');
  assert.ok(transformIndex < printRefIndex, 'preview transform wrapper must be outside the exported invoice element');
});
