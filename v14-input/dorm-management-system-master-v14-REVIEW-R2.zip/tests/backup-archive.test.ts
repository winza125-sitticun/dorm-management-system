import test from 'node:test';
import assert from 'node:assert/strict';
import { zipSync, strToU8 } from 'fflate';
import { createDormBackupArchive, parseDormBackupArchive } from '../src/utils/backupArchive.ts';
import { sha256Hex, stableStringify } from '../src/utils/backupFormat.ts';
import { emptyBackupData, manifestFor, room } from './helpers/backup-fixture.ts';

test('canonical JSON ignores object insertion order but preserves array order', () => {
  assert.equal(stableStringify({ b: 2, a: 1 }), stableStringify({ a: 1, b: 2 }));
  assert.notEqual(stableStringify([1, 2]), stableStringify([2, 1]));
  assert.throws(() => stableStringify({ value: Number.NaN }), /INVALID_NUMBER/);
});

test('SHA-256 hashes UTF-8 deterministically', async () => {
  assert.equal(await sha256Hex('หอพัก'), await sha256Hex(new TextEncoder().encode('หอพัก')));
  assert.match(await sha256Hex('หอพัก'), /^[0-9a-f]{64}$/);
});

test('.dormbackup round-trips exactly two required entries', async () => {
  const data = emptyBackupData(); data.rooms = [room()];
  const manifest = await manifestFor(data);
  const bytes = createDormBackupArchive(manifest, data);
  const parsed = parseDormBackupArchive(bytes);
  assert.deepEqual(parsed.manifest, manifest);
  assert.deepEqual(parsed.data, data);
});

test('corrupt, extra-entry, and missing-entry archives are rejected', async () => {
  assert.throws(() => parseDormBackupArchive(new Uint8Array([1, 2, 3, 4])), /BACKUP_(ZIP|ARCHIVE)/);
  const data = emptyBackupData(); const manifest = await manifestFor(data);
  const extra = zipSync({ 'manifest.json': strToU8(JSON.stringify(manifest)), 'data.json': strToU8(JSON.stringify(data)), 'extra.txt': strToU8('x') });
  assert.throws(() => parseDormBackupArchive(extra), /BACKUP_ZIP_ENTRY_(COUNT|INVALID|MISSING)/);
  const missing = zipSync({ 'manifest.json': strToU8(JSON.stringify(manifest)) });
  assert.throws(() => parseDormBackupArchive(missing), /BACKUP_ZIP_ENTRY_(COUNT|INVALID|MISSING)/);
});

test('max-plan room count can be represented in one application backup', async () => {
  const data = emptyBackupData();
  data.rooms = Array.from({ length: 100 }, (_, i) => room(i + 1, String(i + 1).padStart(3, '0')));
  const manifest = await manifestFor(data);
  const parsed = parseDormBackupArchive(createDormBackupArchive(manifest, data));
  assert.equal(parsed.manifest.counts.rooms, 100);
  assert.equal(parsed.data.rooms.length, 100);
});
