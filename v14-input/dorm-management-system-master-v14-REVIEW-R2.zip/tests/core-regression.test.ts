import assert from 'node:assert/strict';
import test from 'node:test';
import { onRequest } from '../functions/api/[[path]].ts';
import { BillingService } from '../src/services/billing.service.ts';
import { PaymentService } from '../src/services/payment.service.ts';
import { RoomService } from '../src/services/room.service.ts';
import { BillSchema, RoomSchema, SettingsSchema } from '../src/server/validators/index.ts';
import { crc16, formatPromptPayTarget, generatePromptPayPayload } from '../src/utils/promptpay.tsx';
import { APP_VERSION } from '../src/generated/version.ts';

test('application version follows Semantic Versioning', () => {
  assert.match(APP_VERSION, /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$/);
});

test('billing calculation clamps reversed meters and totals every charge', () => {
  assert.deepEqual(BillingService.calculateBillTotal({
    rentCost: 4_000,
    priorElec: 100,
    currentElec: 135,
    elecDeduct: 5,
    elecUnitCost: 7,
    priorWater: 20,
    currentWater: 25,
    waterUnitCost: 15,
    depositCost: 500,
    otherCost: 100,
  }), {
    elecUnits: 30,
    elecCost: 210,
    waterUnits: 5,
    waterCost: 75,
    totalCost: 4_885,
  });

  const reversed = BillingService.calculateBillTotal({
    rentCost: 1_000,
    priorElec: 20,
    currentElec: 10,
    elecUnitCost: 7,
    priorWater: 20,
    currentWater: 10,
    waterUnitCost: 15,
  });
  assert.equal(reversed.elecUnits, 0);
  assert.equal(reversed.waterUnits, 0);
  assert.equal(reversed.totalCost, 1_000);
});

test('room and payment summaries handle empty and formatted input', () => {
  assert.deepEqual(RoomService.extractRoomMeta('A305'), { building: 'A', floor: '3' });
  assert.equal(RoomService.calculateOccupancyRate(10, 7), 70);
  assert.equal(RoomService.calculateOccupancyRate(0, 0), 0);
  assert.equal(PaymentService.formatPromptPayId('089-123-4567'), '0891234567');
  assert.equal(PaymentService.calculateCollectionRate(10_000, 7_500), 75);
});

test('PromptPay payload contains the normalized target, amount, and valid CRC', () => {
  assert.deepEqual(formatPromptPayTarget('081-234-5678'), { subtag: '01', targetId: '0066812345678' });
  const payload = generatePromptPayPayload('081-234-5678', 1_234.5);
  assert.ok(payload.includes('0066812345678'));
  assert.ok(payload.includes('54071234.50'));
  assert.equal(payload.slice(-4), crc16(payload.slice(0, -4)));
});

test('room, bill, and settings validators reject invalid business input', () => {
  assert.equal(RoomSchema.safeParse({ roomNumber: '', monthlyRent: -1 }).success, false);
  assert.equal(BillSchema.safeParse({ roomId: 0 }).success, false);
  assert.equal(SettingsSchema.safeParse({
    dormName: 'Test Dorm',
    defaultElecRate: 7,
    defaultWaterRate: 15,
    defaultDueDateDay: 32,
    defaultPenaltyRate: 0,
  }).success, false);
});

test('Cloudflare routes keep health public and protect every main data flow', async () => {
  const invoke = async (path: string, method = 'GET') => {
    const response = await onRequest({
      request: new Request(`https://example.test${path}`, { method }),
      env: { JWT_SECRET: 'regression-test-secret-at-least-32-characters' },
    } as any);
    return response.status;
  };

  const healthResponse = await onRequest({
    request: new Request('https://example.test/api/health'),
    env: { JWT_SECRET: 'regression-test-secret-at-least-32-characters' },
  } as any);
  assert.equal(healthResponse.status, 200);
  assert.equal((await healthResponse.json() as any).data.version, APP_VERSION);
  assert.equal(await invoke('/api/rooms'), 401);
  assert.equal(await invoke('/api/bills'), 401);
  assert.equal(await invoke('/api/maintenance'), 401);
  assert.equal(await invoke('/api/maintenance', 'POST'), 401);
  assert.equal(await invoke('/api/public/rooms/1'), 401);
  assert.equal(await invoke('/api/tenant/maintenance?roomId=1'), 401);
  assert.equal(await invoke('/api/public/announcements?roomId=1'), 401);
  assert.equal(await invoke('/api/public/bills/1/upload-slip', 'POST'), 401);
  assert.equal(await invoke('/api/route-that-must-not-exist'), 404);
});
