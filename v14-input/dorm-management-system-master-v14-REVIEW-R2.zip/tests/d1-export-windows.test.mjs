import test from 'node:test';
import assert from 'node:assert/strict';
import { commandUsesShell } from '../scripts/d1-export.mjs';

test('D1 export uses Windows shell for npx.cmd to avoid spawnSync EINVAL', () => {
  assert.equal(commandUsesShell('npx.cmd', 'win32'), true);
  assert.equal(commandUsesShell('npx', 'linux'), false);
});
