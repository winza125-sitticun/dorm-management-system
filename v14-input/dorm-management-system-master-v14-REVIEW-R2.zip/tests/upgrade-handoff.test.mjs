import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const pkg = JSON.parse(readFileSync(resolve('package.json'), 'utf8'));

test('customer package exposes upgrade commands and launchers', () => {
  assert.equal(pkg.scripts['upgrade:package'], 'node UPGRADE-PACKAGE.mjs');
  assert.equal(pkg.scripts['plan:show'], 'node UPGRADE-PACKAGE.mjs --show');
  for (const file of ['UPGRADE-PACKAGE.mjs', 'UPGRADE-WINDOWS.cmd', 'UPGRADE-ANDROID.sh', 'UPGRADE_GUIDE_TH.md']) {
    assert.equal(existsSync(resolve(file)), true, `${file} should exist`);
  }
});

test('Thai upgrade guide documents same project/database and upgrade-only policy', () => {
  const guide = readFileSync(resolve('UPGRADE_GUIDE_TH.md'), 'utf8');
  assert.match(guide, /Basic\s*→\s*Standard/i);
  assert.match(guide, /Pages Project เดิม/i);
  assert.match(guide, /D1.*เดิม/i);
  assert.match(guide, /สำรอง/i);
  assert.match(guide, /ไม่รองรับ.*Downgrade/i);
});

test('setup version identifies V14 customer delivery', () => {
  const version = readFileSync(resolve('SETUP_VERSION.txt'), 'utf8');
  assert.match(version, /V14/i);
  assert.match(version, /Upgrade Manager/i);
});
