import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import {
  createMainAppNavigationSession,
  loadAuthenticatedUserProfile,
} from '../src/App.tsx';
import {
  APP_TAB_PATHS,
  appSurfaceForLocation,
  applyPathFromHistory,
  canAccessAppTab,
  listenToAppHistory,
  navigateToAppTab,
  pathForTab,
  resolveAppPath,
  tabForPath,
  type AppTab,
  createAppNavigationSession,
} from '../src/utils/appNavigation.ts';

const expectedRoutes: Array<[AppTab, string]> = [
  ['dashboard', '/'],
  ['announcements', '/announcements'],
  ['notes', '/notes'],
  ['rooms', '/rooms'],
  ['contracts', '/contracts'],
  ['maintenance', '/maintenance'],
  ['housekeeping', '/housekeeping'],
  ['create_bill', '/bills/create'],
  ['bulk_meter', '/bills/meters'],
  ['history', '/bills/history'],
  ['report', '/reports'],
  ['settings', '/settings'],
  ['audit_logs', '/audit-logs'],
];

class FakeBrowserHistory {
  readonly events = new EventTarget();
  readonly location = { pathname: '/', search: '' };
  readonly replacements: string[] = [];
  private entries: Array<{ location: string; state: unknown }>;
  private index = 0;

  constructor(initialLocation = '/') {
    this.entries = [{ location: initialLocation, state: null }];
    this.setLocation(initialLocation);
  }

  currentLocation(): string {
    return `${this.location.pathname}${this.location.search}`;
  }

  get state(): unknown {
    return this.entries[this.index].state;
  }

  pushState(state: unknown, location: string): void {
    this.entries = this.entries.slice(0, this.index + 1);
    this.entries.push({ location, state });
    this.index += 1;
    this.setLocation(location);
  }

  replaceState(state: unknown, location: string): void {
    this.replacements.push(location);
    this.entries[this.index] = { location, state };
    this.setLocation(location);
  }

  dispatchPopState(): void {
    this.events.dispatchEvent(new Event('popstate'));
  }

  back(): void {
    assert.ok(this.index > 0, 'history must contain a previous entry');
    this.index -= 1;
    this.setLocation(this.entries[this.index].location);
    this.dispatchPopState();
  }

  forward(): void {
    assert.ok(this.index < this.entries.length - 1, 'history must contain a next entry');
    this.index += 1;
    this.setLocation(this.entries[this.index].location);
    this.dispatchPopState();
  }

  private setLocation(location: string): void {
    const url = new URL(location, 'https://app.test');
    this.location.pathname = url.pathname;
    this.location.search = url.search;
  }
}

const createExitHarness = () => {
  let drawerOpen = false;
  let warningVisible = false;
  let exitCount = 0;
  let timeout: (() => void) | null = null;
  return {
    effects: {
      isMobileMenuOpen: () => drawerOpen,
      showExitWarning: () => { warningVisible = true; },
      hideExitWarning: () => { warningVisible = false; },
      exitApp: () => { exitCount += 1; },
      scheduleTimeout: (callback: () => void, delayMs: number) => {
        assert.equal(delayMs, 2_000);
        timeout = callback;
        return callback;
      },
      cancelTimeout: (handle: unknown) => {
        if (timeout === handle) timeout = null;
      },
    },
    openDrawer: () => { drawerOpen = true; },
    closeDrawer: () => { drawerOpen = false; },
    warningVisible: () => warningVisible,
    exitCount: () => exitCount,
    timeoutPending: () => timeout !== null,
    expire: () => { const callback = timeout; timeout = null; callback?.(); },
  };
};

const inertDashboardExitEffects = {
  isMobileMenuOpen: () => false,
  showExitWarning: () => assert.fail('unexpected Dashboard exit warning'),
  hideExitWarning: () => undefined,
  exitApp: () => assert.fail('unexpected Dashboard exit'),
  scheduleTimeout: () => assert.fail('unexpected Dashboard exit timer'),
  cancelTimeout: () => undefined,
};

const createDashboardSession = (
  browser: FakeBrowserHistory,
  initialAccess = { role: 'owner', permissions: '' },
) => {
  const exit = createExitHarness();
  const visibleTabs: AppTab[] = [];
  const session = createAppNavigationSession({
    eventTarget: browser.events,
    location: browser.location,
    history: {
      get state() { return browser.state; },
      pushState: (state: unknown, _title: string, path: string) => browser.pushState(state, path),
      replaceState: (state: unknown, _title: string, path: string) => browser.replaceState(state, path),
      forward: () => browser.forward(),
    },
    initialAccess,
    setTab: (tab) => visibleTabs.push(tab),
    closeMobileMenu: exit.closeDrawer,
    dashboardExit: exit.effects,
  });
  return { browser, exit, session, visibleTabs };
};

const createDashboardSessionFixture = (initialAccess = { role: 'owner', permissions: '' }) => (
  createDashboardSession(new FakeBrowserHistory(), initialAccess)
);

test('initial history sync waits for delayed staff permissions before validating the retained URL', () => {
  const browser = new FakeBrowserHistory('/rooms?googleSheets=connected');
  const events: string[] = [];
  const session = createMainAppNavigationSession({
    eventTarget: browser.events,
    location: browser.location,
    history: {
      get state() { return browser.state; },
      pushState: (state: unknown, _title: string, path: string) => browser.pushState(state, path),
      replaceState: (state: unknown, _title: string, path: string) => browser.replaceState(state, path),
      forward: () => browser.forward(),
    },
    initialAccess: null,
    setTab: (tab) => events.push(`tab:${tab}`),
    closeMobileMenu: () => events.push('close'),
    dashboardExit: inertDashboardExitEffects,
  });

  try {
    assert.equal(browser.currentLocation(), '/settings?googleSheets=connected');
    assert.deepEqual(browser.replacements, ['/settings?googleSheets=connected']);
    assert.deepEqual(events, ['tab:settings']);

    session.updateAccess({ role: 'staff', permissions: 'view_rooms,manage_settings' });

    assert.equal(browser.currentLocation(), '/settings?googleSheets=connected');
    assert.deepEqual(browser.replacements, ['/settings?googleSheets=connected']);
    assert.deepEqual(events, ['tab:settings', 'tab:settings', 'close']);
  } finally {
    session.stop();
  }
});

test('every main tab round-trips through its canonical URL', () => {
  assert.deepEqual(Object.entries(APP_TAB_PATHS), expectedRoutes);
  for (const [tab, path] of expectedRoutes) {
    assert.equal(pathForTab(tab), path);
    assert.equal(tabForPath(path), tab);
  }
});

test('route lookup normalizes query-free trailing slashes and rejects unknown paths', () => {
  assert.equal(tabForPath('/rooms/'), 'rooms');
  assert.equal(tabForPath('///bills/history///'), 'history');
  assert.equal(tabForPath('/not-a-main-route'), null);
});

test('unknown and unauthorized paths request a replace to Dashboard', () => {
  assert.deepEqual(resolveAppPath('/missing', () => true), {
    tab: 'dashboard', path: '/', history: 'replace',
  });
  assert.deepEqual(resolveAppPath('/settings', (tab) => tab !== 'settings'), {
    tab: 'dashboard', path: '/', history: 'replace',
  });
  assert.deepEqual(resolveAppPath('/rooms', () => true), {
    tab: 'rooms', path: '/rooms', history: 'none',
  });
});

test('tab access uses the same permission policy as menu visibility', () => {
  assert.equal(canAccessAppTab('dashboard', 'staff', ''), true);
  assert.equal(canAccessAppTab('notes', 'staff', ''), true);
  assert.equal(canAccessAppTab('rooms', 'staff', 'view_rooms'), true);
  assert.equal(canAccessAppTab('rooms', 'staff', ''), false);
  assert.equal(canAccessAppTab('settings', 'staff', 'manage_recurring_charges'), true);
  assert.equal(canAccessAppTab('audit_logs', 'staff', 'manage_settings'), false);
  assert.equal(canAccessAppTab('audit_logs', 'owner', ''), true);
});

test('menu navigation pushes a different accessible tab and suppresses duplicate entries', () => {
  const events: string[] = [];
  const effects = {
    setTab: (tab: AppTab) => events.push(`tab:${tab}`),
    closeMobileMenu: () => events.push('close'),
    pushPath: (path: string) => events.push(`push:${path}`),
    replacePath: (path: string) => events.push(`replace:${path}`),
  };

  navigateToAppTab('rooms', 'create_bill', () => true, effects);
  assert.deepEqual(events, ['push:/bills/create', 'tab:create_bill', 'close']);

  events.length = 0;
  navigateToAppTab('create_bill', 'create_bill', () => true, effects);
  assert.deepEqual(events, ['close']);
});

test('popstate applies the previous URL without pushing and closes the drawer', () => {
  const events: string[] = [];
  const effects = {
    setTab: (tab: AppTab) => events.push(`tab:${tab}`),
    closeMobileMenu: () => events.push('close'),
    pushPath: (path: string) => events.push(`push:${path}`),
    replacePath: (path: string) => events.push(`replace:${path}`),
  };

  applyPathFromHistory('/rooms', () => true, effects);
  assert.deepEqual(events, ['tab:rooms', 'close']);
});

test('history traversal replaces an unauthorized URL with Dashboard', () => {
  const events: string[] = [];
  const effects = {
    setTab: (tab: AppTab) => events.push(`tab:${tab}`),
    closeMobileMenu: () => events.push('close'),
    pushPath: (path: string) => events.push(`push:${path}`),
    replacePath: (path: string) => events.push(`replace:${path}`),
  };

  applyPathFromHistory('/settings', (tab) => tab !== 'settings', effects);
  assert.deepEqual(events, ['replace:/', 'tab:dashboard', 'close']);
});

test('public location decisions keep LINE and tenant history outside main tab synchronization', () => {
  const transitions = [
    ['login', '/', 'main_app'],
    ['login to LINE registration', '/line-register', 'line_registration'],
    ['back to login', '/', 'main_app'],
    ['back into LINE registration', '/line-register?room=101', 'line_registration'],
    ['back into tenant portal path', '/tenant-portal?roomId=101', 'tenant_portal'],
    ['query-only LINE registration', '/?room=101', 'line_registration'],
    ['query-only tenant room', '/?roomId=101', 'tenant_portal'],
    ['query-only tenant portal', '/?portal=tenant', 'tenant_portal'],
    ['query-only tenant token', '/?tenant=token', 'tenant_portal'],
    ['normal app route', '/rooms?filter=occupied', 'main_app'],
  ] as const;

  for (const [label, location, expected] of transitions) {
    assert.equal(appSurfaceForLocation(location), expected, label);
  }
});

test('popstate adapter preserves public history and applies normal main routes', () => {
  const browser = new FakeBrowserHistory();
  const mainEvents: string[] = [];
  const observedLocations: string[] = [];
  const effects = {
    setTab: (tab: AppTab) => mainEvents.push(`tab:${tab}`),
    closeMobileMenu: () => mainEvents.push('close'),
    pushPath: (path: string) => browser.pushState(null, path),
    replacePath: (path: string) => {
      mainEvents.push(`replace:${path}`);
      browser.replaceState(null, path);
    },
  };

  const stopMainListener = listenToAppHistory({
    eventTarget: browser.events,
    location: browser.location,
    syncImmediately: true,
    onMainPath: (pathname) => applyPathFromHistory(pathname, () => true, effects),
  });
  mainEvents.length = 0;
  const stopOuterListener = listenToAppHistory({
    eventTarget: browser.events,
    location: browser.location,
    onLocation: (location) => observedLocations.push(location),
  });

  try {
    browser.pushState(null, '/line-register');
    browser.dispatchPopState();
    assert.equal(browser.currentLocation(), '/line-register');
    assert.deepEqual(mainEvents, []);
    assert.deepEqual(browser.replacements, []);
    assert.equal(observedLocations[observedLocations.length - 1], '/line-register');

    browser.pushState(null, '/rooms?filter=occupied');
    browser.dispatchPopState();
    assert.deepEqual(mainEvents, ['tab:rooms', 'close']);
    assert.equal(observedLocations[observedLocations.length - 1], '/rooms?filter=occupied');

    mainEvents.length = 0;
    browser.back();
    assert.equal(browser.currentLocation(), '/line-register');
    assert.deepEqual(mainEvents, []);
    assert.equal(observedLocations[observedLocations.length - 1], '/line-register');

    const verifyBackIntoPublicLocation = (publicLocation: string) => {
      browser.pushState(null, publicLocation);
      browser.dispatchPopState();
      browser.pushState(null, '/rooms');
      browser.dispatchPopState();
      mainEvents.length = 0;
      browser.back();
      assert.equal(browser.currentLocation(), publicLocation);
      assert.deepEqual(mainEvents, []);
      assert.equal(observedLocations[observedLocations.length - 1], publicLocation);
    };

    verifyBackIntoPublicLocation('/tenant-portal?roomId=101');
    verifyBackIntoPublicLocation('/?portal=tenant');
    verifyBackIntoPublicLocation('/?room=202');
    assert.deepEqual(browser.replacements, []);
  } finally {
    stopOuterListener();
    stopMainListener();
  }
});

test('Back traverses normal tabs, arrives on Dashboard silently, and preserves Forward', () => {
  const { browser, exit, session } = createDashboardSessionFixture();
  try {
    session.navigateTo('rooms');
    session.navigateTo('create_bill');
    browser.back();
    assert.equal(browser.currentLocation(), '/rooms');
    browser.back();
    assert.equal(browser.currentLocation(), '/');
    assert.equal(exit.warningVisible(), false);
    browser.forward();
    assert.equal(browser.currentLocation(), '/rooms');
  } finally {
    session.stop();
  }
});

test('an open drawer consumes Back and restores the same tab without arming exit', () => {
  const { browser, exit, session } = createDashboardSessionFixture();
  try {
    session.navigateTo('rooms');
    exit.openDrawer();
    browser.back();
    assert.equal(browser.currentLocation(), '/rooms');
    assert.equal(exit.warningVisible(), false);
    assert.equal(exit.exitCount(), 0);
  } finally {
    session.stop();
  }
});

test('an open drawer does not intercept Forward traversal or poison the next Back', () => {
  const { browser, exit, session, visibleTabs } = createDashboardSessionFixture();
  try {
    session.navigateTo('rooms');
    session.navigateTo('create_bill');
    browser.back();
    exit.openDrawer();
    browser.forward();
    assert.equal(browser.currentLocation(), '/bills/create');
    assert.equal(visibleTabs[visibleTabs.length - 1], 'create_bill');
    browser.back();
    assert.equal(browser.currentLocation(), '/rooms');
    assert.equal(visibleTabs[visibleTabs.length - 1], 'rooms');
  } finally {
    session.stop();
  }
});

test('logging out disarms Dashboard exit and ignores Login-state popstates', () => {
  const { browser, exit, session } = createDashboardSessionFixture();
  try {
    browser.back();
    assert.equal(exit.warningVisible(), true);
    assert.equal(exit.timeoutPending(), true);

    session.updateAccess(null);
    assert.equal(exit.warningVisible(), false);
    assert.equal(exit.timeoutPending(), false);

    browser.back();
    browser.dispatchPopState();
    assert.equal(exit.warningVisible(), false);
    assert.equal(exit.timeoutPending(), false);
    assert.equal(exit.exitCount(), 0);
  } finally {
    session.stop();
  }
});

test('an authenticated direct main-route entry preserves Forward drawer behavior and the next Back', () => {
  const browser = new FakeBrowserHistory('/rooms?filter=occupied');
  const { exit, session, visibleTabs } = createDashboardSession(browser);
  try {
    assert.equal(browser.currentLocation(), '/rooms?filter=occupied');
    assert.deepEqual(browser.replacements, ['/rooms?filter=occupied']);

    session.navigateTo('create_bill');
    browser.back();
    assert.equal(browser.currentLocation(), '/rooms?filter=occupied');
    assert.equal(visibleTabs[visibleTabs.length - 1], 'rooms');

    exit.openDrawer();
    browser.forward();
    assert.equal(browser.currentLocation(), '/bills/create');
    assert.equal(visibleTabs[visibleTabs.length - 1], 'create_bill');

    browser.back();
    assert.equal(browser.currentLocation(), '/rooms?filter=occupied');
    assert.equal(visibleTabs[visibleTabs.length - 1], 'rooms');
  } finally {
    session.stop();
  }
});

test('a reloaded session seeds persisted positions before drawer-open Back', () => {
  const browser = new FakeBrowserHistory();
  const initialSession = createDashboardSession(browser);
  initialSession.session.stop();
  const { exit, session } = createDashboardSession(browser);
  try {
    session.navigateTo('rooms');
    exit.openDrawer();
    browser.back();
    assert.equal(browser.currentLocation(), '/rooms');
    assert.equal(exit.warningVisible(), false);
    assert.equal(exit.exitCount(), 0);
  } finally {
    session.stop();
  }
});

test('denying an already-active Dashboard guard does not create another exit boundary', () => {
  const { browser, session } = createDashboardSessionFixture({ role: 'staff', permissions: '' });
  try {
    assert.equal(browser.replacements.length, 1);
    session.navigateTo('rooms');
    assert.equal(browser.replacements.length, 1);
  } finally {
    session.stop();
  }
});

test('two Dashboard Back presses within 2000ms exit exactly once', () => {
  const { browser, exit, session } = createDashboardSessionFixture();
  try {
    browser.back();
    assert.equal(exit.warningVisible(), true);
    assert.equal(exit.exitCount(), 0);
    browser.back();
    assert.equal(exit.warningVisible(), false);
    assert.equal(exit.exitCount(), 1);
  } finally {
    session.stop();
  }
});

test('an expired Dashboard Back window starts over instead of exiting', () => {
  const { browser, exit, session } = createDashboardSessionFixture();
  try {
    browser.back();
    exit.expire();
    assert.equal(exit.warningVisible(), false);
    browser.back();
    assert.equal(exit.warningVisible(), true);
    assert.equal(exit.exitCount(), 0);
  } finally {
    session.stop();
  }
});

test('choosing Dashboard creates a fresh exit boundary', () => {
  const { browser, exit, session } = createDashboardSessionFixture();
  try {
    session.navigateTo('rooms');
    session.navigateTo('dashboard');
    browser.back();
    assert.equal(browser.currentLocation(), '/');
    assert.equal(exit.warningVisible(), true);
  } finally {
    session.stop();
  }
});

test('the first Dashboard exit attempt restores the guard without deleting Forward history', () => {
  const { browser, exit, session } = createDashboardSessionFixture();
  try {
    session.navigateTo('rooms');
    browser.back();
    browser.back();
    assert.equal(exit.warningVisible(), true);
    browser.forward();
    assert.equal(browser.currentLocation(), '/rooms');
    assert.equal(exit.warningVisible(), false);
    assert.equal(exit.exitCount(), 0);
  } finally {
    session.stop();
  }
});

test('stopping a session disarms a pending Dashboard exit timer', () => {
  const { browser, exit, session } = createDashboardSessionFixture();
  browser.back();
  assert.equal(exit.warningVisible(), true);
  session.stop();
  assert.equal(exit.warningVisible(), false);
  exit.expire();
  assert.equal(exit.exitCount(), 0);
});

test('malformed Dashboard history metadata synchronizes Dashboard without exiting', () => {
  const { browser, exit, session } = createDashboardSessionFixture();
  try {
    browser.replaceState({ appTab: true, dashboardEntry: 'stale' }, '/');
    browser.dispatchPopState();
    assert.equal(browser.currentLocation(), '/');
    assert.equal(exit.warningVisible(), false);
    assert.equal(exit.exitCount(), 0);
  } finally {
    session.stop();
  }
});

test('App navigation session integrates delayed profile resolution, callback routing, menus, Back, and Forward', async () => {
  const browser = new FakeBrowserHistory('/rooms?googleSheets=connected');
  const visibleTabs: AppTab[] = [];
  let drawerOpen = false;
  let resolveProfileResponse!: (response: Response) => void;
  const delayedProfileResponse = new Promise<Response>((resolve) => {
    resolveProfileResponse = resolve;
  });
  const browserHistory = {
    get state() { return browser.state; },
    pushState: (state: unknown, _title: string, path: string) => browser.pushState(state, path),
    replaceState: (state: unknown, _title: string, path: string) => browser.replaceState(state, path),
    forward: () => browser.forward(),
  };
  const session = createMainAppNavigationSession({
    eventTarget: browser.events,
    location: browser.location,
    history: browserHistory,
    initialAccess: null,
    setTab: (tab) => visibleTabs.push(tab),
    closeMobileMenu: () => { drawerOpen = false; },
    dashboardExit: inertDashboardExitEffects,
  });

  try {
    const finishProfileLoading = loadAuthenticatedUserProfile(
      () => delayedProfileResponse,
      { Authorization: 'Bearer delayed-staff-token' },
      { uid: 'staff-7', email: 'staff@example.com' },
    ).then((profile) => session.updateAccess(profile));

    assert.equal(browser.currentLocation(), '/settings?googleSheets=connected');
    assert.deepEqual(browser.replacements, ['/settings?googleSheets=connected']);
    assert.equal(browser.replacements.includes('/'), false);

    resolveProfileResponse(new Response(JSON.stringify({
      data: {
        id: 7,
        uid: 'staff-7',
        email: 'staff@example.com',
        role: 'staff',
        permissions: 'view_rooms,manage_bills,manage_settings',
      },
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    }));
    await finishProfileLoading;

    assert.equal(browser.currentLocation(), '/settings?googleSheets=connected');
    assert.equal(visibleTabs[visibleTabs.length - 1], 'settings');

    session.navigateTo('dashboard');
    assert.equal(browser.currentLocation(), '/');
    session.navigateTo('rooms');
    assert.equal(browser.currentLocation(), '/rooms');
    session.navigateTo('create_bill');
    assert.equal(browser.currentLocation(), '/bills/create');

    drawerOpen = true;
    browser.back();
    assert.equal(browser.currentLocation(), '/rooms');
    assert.equal(visibleTabs[visibleTabs.length - 1], 'rooms');
    assert.equal(drawerOpen, false);

    drawerOpen = true;
    browser.forward();
    assert.equal(browser.currentLocation(), '/bills/create');
    assert.equal(visibleTabs[visibleTabs.length - 1], 'create_bill');
    assert.equal(drawerOpen, false);

    const pushesBeforeDuplicate = browser.currentLocation();
    session.navigateTo('create_bill');
    assert.equal(browser.currentLocation(), pushesBeforeDuplicate);
  } finally {
    session.stop();
  }
});

test('App navigation session gives public tenant and LINE routes precedence over callbacks and main tabs', () => {
  for (const publicLocation of [
    '/tenant-portal?roomId=101&googleSheets=connected',
    '/line-register?room=101&googleSheets=connected',
  ]) {
    const browser = new FakeBrowserHistory(publicLocation);
    const visibleTabs: AppTab[] = [];
    const exit = createExitHarness();
    const session = createMainAppNavigationSession({
      eventTarget: browser.events,
      location: browser.location,
      history: {
        get state() { return browser.state; },
        pushState: (state: unknown, _title: string, path: string) => browser.pushState(state, path),
        replaceState: (state: unknown, _title: string, path: string) => browser.replaceState(state, path),
        forward: () => browser.forward(),
      },
      initialAccess: { role: 'owner', permissions: '' },
      setTab: (tab) => visibleTabs.push(tab),
      closeMobileMenu: () => undefined,
      dashboardExit: exit.effects,
    });

    try {
      assert.equal(browser.currentLocation(), publicLocation);
      assert.deepEqual(browser.replacements, []);
      assert.deepEqual(visibleTabs, []);
      assert.equal(exit.warningVisible(), false);
      assert.equal(exit.exitCount(), 0);
      browser.dispatchPopState();
      assert.equal(exit.warningVisible(), false);
      assert.equal(exit.exitCount(), 0);
    } finally {
      session.stop();
    }
  }
});

test('App wires the Dashboard warning and exit without patching History APIs', () => {
  const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
  assert.equal(appSource.includes('กดปุ่มกลับ (Back) อีกครั้งเพื่อออกจากเว็บแอป'), true);
  assert.equal(appSource.includes('exitApp: () => { window.close(); }'), true);
  assert.equal(appSource.includes('about:blank'), false);
  for (const forbiddenSource of [
    'handlePopStateDoubleBack',
    'window.history.pushState =',
    'window.history.replaceState =',
  ]) {
    assert.equal(appSource.includes(forbiddenSource), false, forbiddenSource);
  }
});
