import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readFileSync, writeFileSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import {
  validateCloudflareName,
  patchWranglerConfig,
  extractD1Id,
  commandStdio,
  commandUsesShell,
  selectWranglerSource,
  prepareWranglerForLogin,
  chooseCloudflareAccount,
  parseCloudflareIdentity,
  collectResourceNames,
  isAlreadyExistsError,
  projectUrlsFromList,
  secretListHasKey,
} from '../SETUP-CLOUDFLARE.mjs';

test('validateCloudflareName accepts lowercase Cloudflare resource names and rejects unsafe input', () => {
  assert.equal(validateCloudflareName('my-dorm-01'), 'my-dorm-01');
  assert.throws(() => validateCloudflareName('My Dorm'), /lowercase/i);
  assert.throws(() => validateCloudflareName(''), /required/i);
});

test('patchWranglerConfig replaces only customer resource values and preserves DB binding', () => {
  const input = `{
  "name": "REPLACE_WITH_YOUR_PAGES_PROJECT",
  "pages_build_output_dir": "./dist",
  "d1_databases": [{
    "binding": "DB",
    "database_name": "REPLACE_WITH_YOUR_D1_DATABASE_NAME",
    "database_id": "00000000-0000-0000-0000-000000000000",
    "migrations_dir": "./d1-migrations"
  }]
}`;
  const output = patchWranglerConfig(input, {
    projectName: 'customer-dorm',
    databaseName: 'customer-dorm-db',
    databaseId: '11111111-2222-3333-4444-555555555555',
  });
  assert.match(output, /"name": "customer-dorm"/);
  assert.match(output, /"binding": "DB"/);
  assert.match(output, /"database_name": "customer-dorm-db"/);
  assert.match(output, /"database_id": "11111111-2222-3333-4444-555555555555"/);
  assert.match(output, /"migrations_dir": "\.\/d1-migrations"/);
});

test('extractD1Id finds a UUID from Wrangler d1 info JSON shapes', () => {
  assert.equal(
    extractD1Id({ uuid: 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee', name: 'db' }),
    'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee',
  );
  assert.equal(
    extractD1Id({ result: { id: '11111111-2222-3333-4444-555555555555' } }),
    '11111111-2222-3333-4444-555555555555',
  );
  assert.equal(extractD1Id({ name: 'db' }), null);
});


test('commandStdio keeps stdout visible while piping secret input to Wrangler', () => {
  assert.deepEqual(commandStdio({ capture: false, inputText: 'secret\n' }), ['pipe', 'inherit', 'inherit']);
  assert.deepEqual(commandStdio({ capture: false }), ['inherit', 'inherit', 'inherit']);
  assert.deepEqual(commandStdio({ capture: true }), ['pipe', 'pipe', 'pipe']);
});


test('Windows .cmd executables are spawned through a shell to avoid spawnSync EINVAL', () => {
  assert.equal(commandUsesShell('npm.cmd', 'win32'), true);
  assert.equal(commandUsesShell('npx.cmd', 'win32'), true);
  assert.equal(commandUsesShell('npm', 'linux'), false);
  assert.equal(commandUsesShell('node.exe', 'win32'), false);
});


test('customer package supports both first-run and configured Wrangler states', () => {
  const root = new URL('../', import.meta.url);
  const activeUrl = new URL('wrangler.jsonc', root);
  const templateUrl = new URL('wrangler.template.jsonc', root);

  assert.equal(existsSync(templateUrl), true);
  const template = readFileSync(templateUrl, 'utf8');
  assert.match(template, /REPLACE_WITH_YOUR_PAGES_PROJECT/);
  assert.match(template, /REPLACE_WITH_YOUR_D1_DATABASE_NAME/);

  if (existsSync(activeUrl)) {
    const active = readFileSync(activeUrl, 'utf8');
    assert.doesNotMatch(active, /REPLACE_WITH_YOUR|00000000-0000-0000-0000-000000000000/);
    assert.match(active, /\"name\"\s*:\s*\"[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\"/);
    assert.match(active, /\"binding\"\s*:\s*\"DB\"/);
    assert.match(active, /\"database_id\"\s*:\s*\"[0-9a-fA-F-]{36}\"/);
  }
});

test('first-run setup can select template source when active config is absent', () => {
  const template = '{\n  "name": "REPLACE_WITH_YOUR_PAGES_PROJECT"\n}';
  assert.equal(selectWranglerSource({ existingConfig: null, templateConfig: template }), template);
});

test('repeat setup prefers existing configured wrangler source', () => {
  const existing = '{\n  "name": "customer-dorm"\n}';
  const template = '{\n  "name": "REPLACE_WITH_YOUR_PAGES_PROJECT"\n}';
  assert.equal(selectWranglerSource({ existingConfig: existing, templateConfig: template }), existing);
});


test('bootstrap removes an old placeholder wrangler.jsonc before Wrangler login', () => {
  const dir = mkdtempSync(join(tmpdir(), 'dorm-wrangler-'));
  try {
    const activePath = join(dir, 'wrangler.jsonc');
    const templatePath = join(dir, 'wrangler.template.jsonc');
    writeFileSync(activePath, '{\n  "name": "REPLACE_WITH_YOUR_PAGES_PROJECT"\n}', 'utf8');
    const result = prepareWranglerForLogin({ activePath, templatePath });
    assert.equal(result, 'removed-placeholder');
    assert.equal(existsSync(activePath), false);
    assert.equal(existsSync(templatePath), true);
    assert.match(readFileSync(templatePath, 'utf8'), /REPLACE_WITH_YOUR_PAGES_PROJECT/);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test('bootstrap keeps an existing configured wrangler.jsonc', () => {
  const dir = mkdtempSync(join(tmpdir(), 'dorm-wrangler-'));
  try {
    const activePath = join(dir, 'wrangler.jsonc');
    const templatePath = join(dir, 'wrangler.template.jsonc');
    writeFileSync(activePath, '{\n  "name": "customer-dorm"\n}', 'utf8');
    const result = prepareWranglerForLogin({ activePath, templatePath });
    assert.equal(result, 'kept-configured');
    assert.equal(existsSync(activePath), true);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});


test('parseCloudflareIdentity extracts the logged-in email from Wrangler whoami output', () => {
  const output = `You are logged in with an OAuth Token, associated with the email customer@example.com.\nAccount Name  Account ID`;
  assert.deepEqual(parseCloudflareIdentity(output), { email: 'customer@example.com' });
});

test('existing Cloudflare login can be kept without logging out', async () => {
  const calls = [];
  const run = (args) => {
    calls.push(args.join(' '));
    if (args[0] === 'whoami') return 'You are logged in with an OAuth Token, associated with the email old@example.com.';
    return '';
  };
  const rl = { question: async () => '1' };
  const result = await chooseCloudflareAccount(rl, run);
  assert.equal(result.email, 'old@example.com');
  assert.equal(result.switched, false);
  assert.deepEqual(calls, ['whoami']);
});

test('existing Cloudflare login can logout and login with a different account', async () => {
  const calls = [];
  let whoamiCount = 0;
  const run = (args) => {
    calls.push(args.join(' '));
    if (args[0] === 'whoami') {
      whoamiCount += 1;
      return whoamiCount === 1
        ? 'You are logged in with an OAuth Token, associated with the email old@example.com.'
        : 'You are logged in with an OAuth Token, associated with the email new@example.com.';
    }
    return '';
  };
  const rl = { question: async () => '2' };
  const result = await chooseCloudflareAccount(rl, run);
  assert.equal(result.email, 'new@example.com');
  assert.equal(result.switched, true);
  assert.deepEqual(calls, ['whoami', 'logout', 'login', 'whoami']);
});

test('existing Cloudflare login can cancel setup before resource prompts', async () => {
  const run = (args) => {
    if (args[0] === 'whoami') return 'You are logged in with an OAuth Token, associated with the email old@example.com.';
    return '';
  };
  const rl = { question: async () => '3' };
  await assert.rejects(() => chooseCloudflareAccount(rl, run), /cancelled/i);
});

test('missing Cloudflare login opens login automatically and verifies the new account', async () => {
  const calls = [];
  let whoamiCount = 0;
  const run = (args) => {
    calls.push(args.join(' '));
    if (args[0] === 'whoami') {
      whoamiCount += 1;
      if (whoamiCount === 1) throw new Error('not logged in');
      return 'You are logged in with an OAuth Token, associated with the email fresh@example.com.';
    }
    return '';
  };
  const rl = { question: async () => { throw new Error('no account-choice prompt expected'); } };
  const result = await chooseCloudflareAccount(rl, run);
  assert.equal(result.email, 'fresh@example.com');
  assert.equal(result.switched, true);
  assert.deepEqual(calls, ['whoami', 'login', 'whoami']);
});


test('Wrangler Pages JSON using Project Name is recognized as an existing project', () => {
  const names = collectResourceNames([
    { 'Project Name': 'mydorm-demo', 'Project Domains': 'mydorm-demo.pages.dev' },
  ]);
  assert.equal(names.has('mydorm-demo'), true);
});

test('Cloudflare duplicate project error is recognized as already existing', () => {
  assert.equal(isAlreadyExistsError(new Error('A project with this name already exists. Choose a different project name. [code: 8000002]')), true);
  assert.equal(isAlreadyExistsError(new Error('network timeout')), false);
});


test('projectUrlsFromList returns the real Cloudflare project domains instead of guessing from the project name', () => {
  const urls = projectUrlsFromList([
    { 'Project Name': 'demo', 'Project Domains': 'demo-7ab.pages.dev, billing.example.com' },
    { 'Project Name': 'other', 'Project Domains': 'other.pages.dev' },
  ], 'demo');
  assert.deepEqual(urls, ['https://demo-7ab.pages.dev', 'https://billing.example.com']);
});

test('projectUrlsFromList returns an empty list when Cloudflare reports no domain for that project', () => {
  assert.deepEqual(projectUrlsFromList([{ 'Project Name': 'other', 'Project Domains': 'other.pages.dev' }], 'demo'), []);
});


test('secretListHasKey detects JWT_SECRET without exposing its value', () => {
  const output = `Secret Name\nJWT_SECRET\nGOOGLE_CLIENT_SECRET`;
  assert.equal(secretListHasKey(output, 'JWT_SECRET'), true);
  assert.equal(secretListHasKey(output, 'MISSING_SECRET'), false);
});
