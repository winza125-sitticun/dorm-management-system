import test from 'node:test';
import assert from 'node:assert/strict';
import { runUpgradeWorkflow } from '../UPGRADE-PACKAGE.mjs';

const CONFIG = `{
  "name": "customer-dorm",
  "d1_databases": [{"binding":"DB","database_name":"customer-dorm-db","database_id":"aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"}]
}`;

test('interactive Basic customer chooses first target and upgrades to Standard on the same Pages/D1 resources', async () => {
  const events = [];
  let plan = 'basic';
  const answers = ['y', '1', 'UPGRADE'];
  const ask = async () => answers.shift() ?? '';

  const runWrangler = (args, options = {}) => {
    events.push(['wrangler', ...args]);
    if (args[0] === 'whoami') return 'owner@example.com';
    if (args[0] === 'd1' && args[1] === 'execute') {
      const sql = args[args.indexOf('--command') + 1] || '';
      if (/^SELECT /i.test(sql.trim())) {
        return JSON.stringify([{ results: [{ subscription_plan: plan }], success: true }]);
      }
      if (/UPDATE settings/i.test(sql)) {
        const next = sql.match(/subscription_plan\s*=\s*'([^']+)'/i)?.[1];
        if (next) plan = next;
        return JSON.stringify([{ results: [], success: true }]);
      }
    }
    return options.capture ? '{}' : '';
  };

  const result = await runUpgradeWorkflow({
    configSource: CONFIG,
    ask,
    runNpm: (args) => events.push(['npm', ...args]),
    runNode: (args) => events.push(['node', ...args]),
    runWrangler,
    log: () => {},
    backupPathFactory: (from, to) => `./backups/${from}-to-${to}.sql`,
  });

  assert.equal(result.fromPlan, 'basic');
  assert.equal(result.toPlan, 'standard');
  assert.equal(result.projectName, 'customer-dorm');
  assert.equal(result.databaseName, 'customer-dorm-db');
  assert.equal(plan, 'standard');
  assert.ok(events.some((e) => e.join(' ') === 'node scripts/d1-export.mjs --remote ./backups/basic-to-standard.sql'));
  assert.ok(events.some((e) => e.join(' ') === 'wrangler pages deploy dist --project-name customer-dorm'));
});
