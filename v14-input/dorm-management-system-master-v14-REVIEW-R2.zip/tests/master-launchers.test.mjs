import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import test from 'node:test';

const read = (p) => readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');

test('master Windows builder launcher installs dependencies and preserves batch control flow', () => {
  assert.equal(existsSync(new URL('../BUILD-PACKAGES-WINDOWS.cmd', import.meta.url)), true);
  const cmd = read('BUILD-PACKAGES-WINDOWS.cmd');
  assert.match(cmd, /call npm ci/i);
  assert.match(cmd, /NODE_MAJOR/i);
  assert.match(cmd, /LSS 22/i);
  assert.match(cmd, /call npm run packages:release/i);
  assert.match(cmd, /pause/i);
  assert.match(cmd, /V14 Master Package Builder/i);
  assert.match(cmd, /release-v14/i);
  assert.doesNotMatch(cmd, /V13|release-v13/i);
});

test('master package uses a master-safe release gate while generated packages restore customer gate', () => {
  const pkg = JSON.parse(read('package.json'));
  assert.match(pkg.scripts.test, /test:builder/);
  assert.match(pkg.scripts.test, /test:setup:master/);
  assert.doesNotMatch(pkg.scripts['release:check'], /customer:preflight/);
  const builder = read('scripts/build-packages.mjs');
  assert.match(builder, /CUSTOMER_TEST_SCRIPT/);
  assert.match(builder, /CUSTOMER_RELEASE_CHECK/);
});


test('master Android builder launcher also targets V14 release output', () => {
  const sh = read('BUILD-PACKAGES-ANDROID.sh');
  assert.match(sh, /V14 Master Package Builder/i);
  assert.match(sh, /npm ci/);
  assert.match(sh, /npm run packages:release/);
  assert.match(sh, /release-v14/);
  assert.doesNotMatch(sh, /V13|release-v13/i);
});
