import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import test from 'node:test';

test('subscription metadata is added by the dedicated migration and present in schema snapshots', () => {
  assert.equal(existsSync(new URL('../d1-migrations/0005_add_subscription_plan.sql', import.meta.url)), true);
  const migration = readFileSync(new URL('../d1-migrations/0005_add_subscription_plan.sql', import.meta.url), 'utf8');
  const drizzle = readFileSync(new URL('../src/db/schema.ts', import.meta.url), 'utf8');
  const baseline = readFileSync(new URL('../d1-migrations/0000_baseline_current_schema.sql', import.meta.url), 'utf8');
  const schemaD1 = readFileSync(new URL('../schema_d1.sql', import.meta.url), 'utf8');
  for (const column of ['subscription_plan', 'subscription_status', 'subscription_expires_at']) {
    assert.match(migration, new RegExp(column));
    assert.doesNotMatch(baseline, new RegExp(column));
    assert.match(schemaD1, new RegExp(column));
  }
  assert.match(drizzle, /subscriptionPlan:\s*text\('subscription_plan'/);
  assert.match(drizzle, /subscriptionStatus:\s*text\('subscription_status'/);
  assert.match(drizzle, /subscriptionExpiresAt:\s*text\('subscription_expires_at'/);
});

test('profile and settings APIs expose plan metadata without accepting it from normal settings validation', () => {
  const pages = readFileSync(new URL('../functions/api/[[path]].ts', import.meta.url), 'utf8');
  const express = readFileSync(new URL('../server.ts', import.meta.url), 'utf8');
  const validators = readFileSync(new URL('../src/server/validators/index.ts', import.meta.url), 'utf8');
  for (const source of [pages, express]) {
    assert.match(source, /subscriptionPlan/);
    assert.match(source, /subscriptionStatus/);
    assert.match(source, /subscriptionExpiresAt/);
    assert.match(source, /normalizeSubscriptionPlan/);
  }
  assert.doesNotMatch(validators, /subscriptionPlan\s*:/);
});

test('frontend-facing Settings and UserProfile types carry subscription metadata', () => {
  const types = readFileSync(new URL('../src/types.ts', import.meta.url), 'utf8');
  assert.match(types, /subscriptionPlan\?:\s*SubscriptionPlan/);
  assert.match(types, /subscriptionStatus\?:\s*string/);
  assert.match(types, /subscriptionExpiresAt\?:\s*string\s*\|\s*null/);
});
