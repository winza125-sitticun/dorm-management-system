import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { prepareRestoreData, RESTORE_BATCH_SIZE, RESTORE_DELETE_ORDER, RESTORE_INSERT_ORDER } from '../src/server/services/restore.service.ts';
import { canStartRestore } from '../src/utils/backupRestoreUi.ts';
import { emptyBackupData, room } from './helpers/backup-fixture.ts';

test('restore state machine requires validation, confirmation, and exact RESTORE text', () => {
  assert.equal(canStartRestore({ validated: true, confirmed: true, typed: 'RESTORE', allowed: true, busy: false }), true);
  for (const typed of ['restore', 'Restore', ' RESTORE ', '']) assert.equal(canStartRestore({ validated: true, confirmed: true, typed, allowed: true, busy: false }), false);
});

test('restore prepares current ownership, preserves LINE linkage, and remaps missing users', () => {
  const data = emptyBackupData();
  data.rooms = [room(1, '101'), room(2, '102')];
  data.notes = [{ id: 9, createdBy: 999, roomId: 1, title: 'n', content: 'c', color: 'yellow', isPinned: 0, createdAt: null, updatedAt: null, deletedAt: null, deletedBy: null }];
  data.housekeepingTasks = [{ id: 10, roomId: 1, assignedUserId: 999, contractId: null, source: 'manual', status: 'pending', note: null, inspectionNote: null, createdBy: 999, createdAt: null, updatedAt: null, completedAt: null }];
  const current = {
    integrations: { rooms: [{ id: 1, lineUserId: 'U1', lineDisplayName: 'Tenant', linePictureUrl: 'pic', lineStatus: 'linked', lineNotifyToken: 'token' }], settings: { lineChannelSecret: 'keep', googleSpreadsheetId: 'sheet', subscriptionPlan: 'pro' } },
    existingUserIds: new Set([7, 8]), childUserIds: new Set([8]),
  };
  const prepared = prepareRestoreData(data, current as any, 7);
  assert.equal(prepared.rooms[0].userId, 7); assert.equal(prepared.rooms[0].lineUserId, 'U1');
  assert.equal(prepared.rooms[1].lineUserId, null); assert.equal(prepared.rooms[1].lineStatus, 'unlinked');
  assert.equal(prepared.notes[0].createdBy, 7); assert.equal(prepared.housekeepingTasks[0].assignedUserId, null); assert.equal(prepared.housekeepingTasks[0].createdBy, 7);
  assert.equal((prepared.settings as any).subscriptionPlan, undefined);
  assert.equal((prepared.expectedIntegrations.settings as any).lineChannelSecret, 'keep');
  assert.equal((prepared.expectedIntegrations.settings as any).googleSpreadsheetId, 'sheet');
  assert.equal((prepared.expectedIntegrations.settings as any).subscriptionPlan, 'pro');
});

test('restore normalizes backup row order to the D1 export order before post-restore verification', () => {
  const data = emptyBackupData(); data.rooms = [room(2, '102'), room(1, '101')];
  const current = { integrations: { rooms: [], settings: {} }, existingUserIds: new Set([7]), childUserIds: new Set<number>() };
  const prepared = prepareRestoreData(data, current as any, 7);
  assert.deepEqual(prepared.backupData.rooms.map((x: any) => x.id), [1, 2]);
  assert.deepEqual(prepared.expectedIntegrations.rooms.map((x: any) => x.id), [1, 2]);
});

test('restore orders are child-first for delete, parent-first for insert, and batch cap is 50', () => {
  assert.equal(RESTORE_DELETE_ORDER[0], 'bill_charge_items'); assert.equal(RESTORE_DELETE_ORDER.at(-1), 'rooms');
  assert.equal(RESTORE_INSERT_ORDER[0], 'rooms'); assert.equal(RESTORE_INSERT_ORDER.at(-1), 'bill_charge_items');
  assert.equal(RESTORE_BATCH_SIZE, 50);
});

test('Admin UI downloads pre-restore backup before POST restore and legacy JSON backup is gone', () => {
  const ui = readFileSync(new URL('../src/components/BackupRestoreSettings.tsx', import.meta.url), 'utf8');
  const settings = readFileSync(new URL('../src/components/SettingsView.tsx', import.meta.url), 'utf8');
  const pre = ui.indexOf("backupFilename('pre-restore'");
  const post = ui.indexOf("fetch('/api/admin/backup/restore'");
  assert.ok(pre >= 0 && post > pre, 'pre-restore download must occur before restore POST');
  assert.match(ui, /recoveryRequired/); assert.match(ui, /preRestoreDataSha256/);
  assert.doesNotMatch(settings, /handleExportJSONBackup/);
  assert.match(settings, /ส่งออกเพื่อรายงาน \(CSV Export\)/);
});

test('App wires restore refresh into SettingsView, not an unrelated tab', () => {
  const app = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
  const start = app.indexOf("activeTab === 'settings'"); const end = app.indexOf("activeTab === 'audit_logs'", start);
  const block = app.slice(start, end);
  assert.match(block, /<SettingsView[\s\S]*onRestoreSuccess=\{triggerRefreshData\}/);
});
