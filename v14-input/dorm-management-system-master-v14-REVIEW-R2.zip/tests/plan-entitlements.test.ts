import assert from 'node:assert/strict';
import test from 'node:test';
import {
  getPlanEntitlements,
  getPlanLimit,
  hasPlanFeature,
  isDemoPlan,
  normalizeSubscriptionPlan,
} from '../src/constants/planEntitlements.ts';

test('subscription plan normalization preserves valid plans and falls back to pro', () => {
  assert.equal(normalizeSubscriptionPlan('demo'), 'demo');
  assert.equal(normalizeSubscriptionPlan('BASIC'), 'basic');
  assert.equal(normalizeSubscriptionPlan(' standard '), 'standard');
  assert.equal(normalizeSubscriptionPlan('pro'), 'pro');
  assert.equal(normalizeSubscriptionPlan(null), 'pro');
  assert.equal(normalizeSubscriptionPlan('enterprise'), 'pro');
});

test('room and staff limits match the approved commercial packages', () => {
  assert.equal(getPlanLimit('demo', 'maxRooms'), 5);
  assert.equal(getPlanLimit('basic', 'maxRooms'), 10);
  assert.equal(getPlanLimit('standard', 'maxRooms'), 30);
  assert.equal(getPlanLimit('pro', 'maxRooms'), 100);
  assert.equal(getPlanLimit('demo', 'maxStaff'), 0);
  assert.equal(getPlanLimit('basic', 'maxStaff'), 0);
  assert.equal(getPlanLimit('standard', 'maxStaff'), 2);
  assert.equal(getPlanLimit('pro', 'maxStaff'), 5);
});

test('standard unlocks operational billing features but not pro property operations', () => {
  for (const feature of ['bulkMeter', 'reports', 'promptPay', 'recurringCharges', 'staff'] as const) {
    assert.equal(hasPlanFeature('standard', feature), true, feature);
  }
  for (const feature of ['contracts', 'checkout', 'maintenance', 'housekeeping', 'tenantPortal', 'lineIntegration', 'googleSheets', 'auditLogs'] as const) {
    assert.equal(hasPlanFeature('standard', feature), false, feature);
  }
});

test('basic keeps core owner tools but excludes standard and pro add-ons', () => {
  assert.equal(hasPlanFeature('basic', 'settings'), true);
  assert.equal(hasPlanFeature('basic', 'notes'), true);
  assert.equal(hasPlanFeature('basic', 'bulkMeter'), false);
  assert.equal(hasPlanFeature('basic', 'reports'), false);
  assert.equal(hasPlanFeature('basic', 'promptPay'), false);
  assert.equal(hasPlanFeature('basic', 'staff'), false);
  assert.equal(hasPlanFeature('basic', 'contracts'), false);
  assert.equal(hasPlanFeature('basic', 'backupExport'), true);
  assert.equal(hasPlanFeature('basic', 'backupRestore'), true);
});

test('demo exposes only safe sales-demo surfaces', () => {
  assert.equal(isDemoPlan('demo'), true);
  assert.equal(hasPlanFeature('demo', 'bulkMeter'), true);
  assert.equal(hasPlanFeature('demo', 'reports'), true);
  assert.equal(hasPlanFeature('demo', 'promptPay'), true);
  assert.equal(hasPlanFeature('demo', 'tenantPortal'), true);
  assert.equal(hasPlanFeature('demo', 'announcements'), true);
  assert.equal(hasPlanFeature('demo', 'backupExport'), true);
  assert.equal(hasPlanFeature('demo', 'backupRestore'), false);
  assert.equal(hasPlanFeature('demo', 'settings'), false);
  assert.equal(hasPlanFeature('demo', 'notes'), false);
  assert.equal(hasPlanFeature('demo', 'staff'), false);
  assert.equal(hasPlanFeature('demo', 'lineIntegration'), false);
});

test('pro unlocks every catalogued feature', () => {
  const entitlements = getPlanEntitlements('pro');
  for (const [key, value] of Object.entries(entitlements.features)) {
    assert.equal(value, true, key);
  }
});
