import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import test from 'node:test';

const read = (path) => readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');

test('customer delivery excludes internal agent artifacts', () => {
  assert.equal(existsSync(new URL('../docs/superpowers', import.meta.url)), false);
  assert.equal(existsSync(new URL('../assets/.aistudio', import.meta.url)), false);
});

test('customer delivery contains no developer personal email fixture', () => {
  const setupTest = read('tests/setup-cloudflare.test.mjs');
  assert.doesNotMatch(setupTest, /winza125@gmail\.com/i);
});

test('Express password change never falls back to a default admin password', () => {
  const server = read('server.ts');
  assert.doesNotMatch(server, /userObj\.password\s*\|\|\s*["']admin["']/);
});

test('customer-facing setup and upgrade labels use V14 consistently', () => {
  assert.match(read('SETUP_VERSION.txt'), /V14/i);
  assert.match(read('SETUP-CLOUDFLARE.mjs'), /Cloudflare Setup V14/);
  assert.match(read('UPGRADE-WINDOWS.cmd'), /Upgrade Manager V14/);
  assert.match(read('UPGRADE-ANDROID.sh'), /Upgrade Manager V14/);
});

test('Pro callback guide does not guess the Pages domain from the project name', () => {
  const guide = read('CUSTOMER_DEPLOY_GUIDE_TH.md');
  assert.doesNotMatch(guide, /https:\/\/<PROJECT_NAME>\.pages\.dev\/api\/google-sheets\/callback/);
});


test('customer-facing docs do not contain stale V5-V13 release labels', () => {
  const files = [
    'README.md', 'SETUP_GUIDE_TH.md', 'CLOUDFLARE_DEPLOY_GUIDE_TH.md',
    'CUSTOMER_DEPLOY_GUIDE_TH.md', 'CUSTOMER_CHECKLIST_TH.md', 'UPGRADE_GUIDE_TH.md',
    'PACKAGE_VARIANT.md', 'SETUP_VERSION.txt', 'SETUP-CLOUDFLARE.mjs',
    'UPGRADE-WINDOWS.cmd', 'UPGRADE-ANDROID.sh', 'UPGRADE-PACKAGE.mjs',
  ];
  for (const file of files) {
    assert.doesNotMatch(read(file), /\bV(?:5|6|7|8|9|10|11|12|13)\b/i, `${file} contains a stale release label`);
  }
});

test('gitignore excludes real local secret files but keeps examples', () => {
  const ignore = read('.gitignore');
  assert.match(ignore, /^\.dev\.vars\*/m);
  assert.match(ignore, /^\.env\*/m);
  assert.match(ignore, /^!\.dev\.vars\.example$/m);
});
