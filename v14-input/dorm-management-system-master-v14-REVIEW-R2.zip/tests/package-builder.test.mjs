import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import test from 'node:test';

const root = new URL('../', import.meta.url);

const expected = {
  demo: { label: 'Demo', packageName: 'dorm-management-system-demo', maxRooms: 5, maxStaff: 0, googleOAuthExample: false },
  basic: { label: 'Basic', packageName: 'dorm-management-system-basic', maxRooms: 10, maxStaff: 0, googleOAuthExample: false },
  standard: { label: 'Standard', packageName: 'dorm-management-system-standard', maxRooms: 30, maxStaff: 2, googleOAuthExample: false },
  pro: { label: 'Pro', packageName: 'dorm-management-system-pro', maxRooms: 100, maxStaff: 5, googleOAuthExample: true },
};

test('V14 master ships one declarative config for every commercial package', () => {
  assert.equal(existsSync(new URL('../scripts/build-packages.mjs', import.meta.url)), true);
  for (const plan of Object.keys(expected)) {
    assert.equal(existsSync(new URL(`../package-plans/${plan}.json`, import.meta.url)), true, `${plan} plan config missing`);
  }
});

test('package plan configs preserve approved commercial limits and identity', async () => {
  const { loadPlans } = await import('../scripts/build-packages.mjs');
  const plans = await loadPlans(new URL('../package-plans/', import.meta.url));
  assert.deepEqual(Object.keys(plans).sort(), Object.keys(expected).sort());
  for (const [id, exp] of Object.entries(expected)) {
    assert.equal(plans[id].id, id);
    assert.equal(plans[id].label, exp.label);
    assert.equal(plans[id].packageName, exp.packageName);
    assert.equal(plans[id].limits.maxRooms, exp.maxRooms);
    assert.equal(plans[id].limits.maxStaff, exp.maxStaff);
    assert.equal(plans[id].googleOAuthExample, exp.googleOAuthExample);
    assert.ok(Array.isArray(plans[id].features) && plans[id].features.length > 0);
  }
});

test('builder validation rejects malformed, unknown, or inconsistent plan config', async () => {
  const { validatePlanConfig } = await import('../scripts/build-packages.mjs');
  assert.throws(() => validatePlanConfig({ id: 'enterprise' }), /unsupported plan/i);
  assert.throws(() => validatePlanConfig({ id: 'basic', label: 'Basic', packageName: 'dorm-management-system-basic', limits: { maxRooms: 99, maxStaff: 0 }, features: ['x'], googleOAuthExample: false }), /maxRooms/i);
});

test('master package scripts expose V14 generation and release commands', () => {
  const pkg = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
  assert.equal(pkg.name, 'dorm-management-system-master');
  assert.equal(pkg.scripts['packages:generate'], 'node scripts/build-packages.mjs --preview');
  assert.equal(pkg.scripts['packages:release'], 'node scripts/release-packages.mjs');
  assert.equal(existsSync(new URL('../scripts/release-packages.mjs', import.meta.url)), true);
});

test('declarative package limits stay in sync with runtime PLAN_ENTITLEMENTS source', async () => {
  const source = readFileSync(new URL('../src/constants/planEntitlements.ts', import.meta.url), 'utf8');
  const { loadPlans } = await import('../scripts/build-packages.mjs');
  const plans = await loadPlans();
  for (const [id, plan] of Object.entries(plans)) {
    const block = source.match(new RegExp(`${id}: \\{[\\s\\S]*?limits: \\{ maxRooms: (\\d+), maxStaff: (\\d+) \\}`));
    assert.ok(block, `runtime entitlement block missing for ${id}`);
    assert.equal(Number(block[1]), plan.limits.maxRooms, `${id} maxRooms drift`);
    assert.equal(Number(block[2]), plan.limits.maxStaff, `${id} maxStaff drift`);
  }
});


test('V14 master release gate runs backup and handoff suites before builder', () => {
  const pkg = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
  assert.equal(pkg.scripts['test:backup'], 'tsx --test tests/backup-archive.test.ts tests/backup-validation.test.ts tests/backup-restore.test.ts tests/backup-restore-api.test.ts');
  const sequence = pkg.scripts.test;
  assert.ok(sequence.includes('npm run test:backup'));
  assert.ok(sequence.includes('npm run test:handoff'));
  assert.ok(sequence.indexOf('npm run test:backup') < sequence.indexOf('npm run test:handoff'));
  assert.ok(sequence.indexOf('npm run test:handoff') < sequence.indexOf('npm run test:builder'));
});
