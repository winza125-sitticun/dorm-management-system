import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import test from 'node:test';

test('customer package uses customer-owned Cloudflare placeholders', () => {
  const pages = readFileSync(new URL('../functions/api/[[path]].ts', import.meta.url), 'utf8');
  const wranglerTemplate = readFileSync(new URL('../wrangler.template.jsonc', import.meta.url), 'utf8');
  const activeWranglerUrl = new URL('../wrangler.jsonc', import.meta.url);
  const pkg = readFileSync(new URL('../package.json', import.meta.url), 'utf8');
  assert.match(wranglerTemplate, /REPLACE_WITH_YOUR_PAGES_PROJECT/);
  assert.match(wranglerTemplate, /REPLACE_WITH_YOUR_D1_DATABASE_NAME/);
  assert.match(wranglerTemplate, /00000000-0000-0000-0000-000000000000/);
  if (existsSync(activeWranglerUrl)) {
    const activeWrangler = readFileSync(activeWranglerUrl, 'utf8');
    assert.doesNotMatch(activeWrangler, /REPLACE_WITH_YOUR|00000000-0000-0000-0000-000000000000/);
  }
  assert.doesNotMatch(pages, /https:\/\/[^'"\s]+\.pages\.dev/);
  assert.doesNotMatch(pkg, /--project-name=/);
});

test('customer package uses portable Pages and D1 commands', () => {
  const pkg = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
  assert.equal(pkg.scripts['deploy:pages'], 'npm run build:pages && wrangler pages deploy');
  assert.match(pkg.scripts['d1:migrate:local'], /migrations apply DB --local/);
  assert.match(pkg.scripts['d1:migrate:remote'], /migrations apply DB --remote/);
  assert.equal(pkg.scripts['d1:backup'], 'node scripts/d1-export.mjs --remote ./backups/d1_backup.sql');
  assert.equal(pkg.scripts['d1:export'], 'node scripts/d1-export.mjs --local ./backups/d1_local_backup.sql');
  assert.equal(pkg.scripts['customer:preflight'], 'node scripts/customer-preflight.mjs');
});

test('customer package fails closed when profile loading fails and excludes manual seed credentials', () => {
  const app = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
  const pkg = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
  assert.doesNotMatch(app, /admin_owner_default|admin@dorm\.com/);
  assert.match(app, /catch \(error\)[\s\S]*?return null;/);
  assert.equal(pkg.scripts['db:seed'], undefined);
  assert.equal(existsSync(new URL('../src/db/seed.ts', import.meta.url)), false);
});

test('customer preflight validation is covered by the state-independent Node test suite', () => {
  const pkg = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
  assert.match(pkg.scripts['test:setup'], /customer-preflight\.test\.mjs/);
});


test('staff creation API enforces the shared strong password policy', () => {
  const pages = readFileSync(new URL('../functions/api/[[path]].ts', import.meta.url), 'utf8');
  const marker = 'if (path === "/api/caretakers" && method === "POST")';
  const start = pages.indexOf(marker);
  const end = pages.indexOf('if (env.DB)', start);
  const block = start >= 0 && end > start ? pages.slice(start, end) : '';
  assert.match(block, /validatePasswordPolicy\(rawPassword\)/);
  assert.doesNotMatch(block, /rawPassword\.length < 4/);
});


test('customer package includes interactive Cloudflare setup wizard', () => {
  const pkg = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
  const setup = readFileSync(new URL('../SETUP-CLOUDFLARE.mjs', import.meta.url), 'utf8');
  assert.equal(pkg.scripts['setup:cloudflare'], 'node SETUP-CLOUDFLARE.mjs');
  assert.equal(pkg.scripts['deploy:customer'], 'node SETUP-CLOUDFLARE.mjs --deploy');
  assert.match(pkg.scripts['test:setup'], /setup-cloudflare\.test\.mjs/);
  assert.match(pkg.scripts['test:setup'], /customer-preflight\.test\.mjs/);
  assert.match(setup, /ชื่อ Cloudflare Pages Project/);
  assert.match(setup, /ชื่อ D1 Database/);
  assert.match(setup, /ใช้บัญชีนี้/);
  assert.match(setup, /Logout และ Login บัญชีใหม่/);
  assert.match(setup, /ยกเลิก Setup/);
  assert.match(setup, /d1.*info.*--json/s);
  assert.match(setup, /พิมพ์ DEPLOY/);
  assert.doesNotMatch(setup, /CLOUDFLARE_API_TOKEN\s*=|JWT_SECRET\s*=\s*["'][^"']+/);
});

test('V14 handoff documents layered backup and recovery without restoring identity or integrations', () => {
  const checklist = readFileSync(new URL('../CUSTOMER_CHECKLIST_TH.md', import.meta.url), 'utf8');
  const deploy = readFileSync(new URL('../CUSTOMER_DEPLOY_GUIDE_TH.md', import.meta.url), 'utf8');
  const notes = readFileSync(new URL('../RELEASE_NOTES_V14_TH.md', import.meta.url), 'utf8');
  const text = `${checklist}\n${deploy}\n${notes}`;
  for (const concept of ['.dormbackup', 'pre-restore', 'users/password not restored', 'LINE/Google credentials not restored', 'D1 raw export', 'Time Travel']) {
    assert.match(text, new RegExp(concept.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i'), `missing handoff concept: ${concept}`);
  }
  assert.match(text, /Demo[^\n]{0,80}(?:ไม่สามารถ Restore|cannot restore)/i);
  assert.match(text, /\.dormbackup[^\n]{0,180}(?:ไม่ใช่ตัวแทน|not.*replacement)[^\n]{0,120}(?:D1 raw export|Time Travel)/i);
});
