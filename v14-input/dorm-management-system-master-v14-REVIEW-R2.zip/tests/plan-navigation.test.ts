import assert from 'node:assert/strict';
import test from 'node:test';
import { PERMISSIONS } from '../src/constants/permissions.ts';
import {
  canAccessTabForPlan,
  requiredPaidPlanForTab,
  requiredPlanFeatureForTab,
} from '../src/utils/planNavigation.ts';

test('basic keeps core billing and settings while locking standard and pro tabs', () => {
  for (const tab of ['dashboard', 'rooms', 'create_bill', 'history', 'settings', 'notes'] as const) {
    assert.equal(canAccessTabForPlan(tab, 'owner', '', 'basic'), true, tab);
  }
  for (const tab of ['bulk_meter', 'report', 'contracts', 'maintenance', 'housekeeping', 'announcements', 'audit_logs'] as const) {
    assert.equal(canAccessTabForPlan(tab, 'owner', '', 'basic'), false, tab);
  }
});

test('standard unlocks bulk meter and reports but keeps pro operations locked', () => {
  assert.equal(canAccessTabForPlan('bulk_meter', 'owner', '', 'standard'), true);
  assert.equal(canAccessTabForPlan('report', 'owner', '', 'standard'), true);
  assert.equal(canAccessTabForPlan('contracts', 'owner', '', 'standard'), false);
  assert.equal(canAccessTabForPlan('maintenance', 'owner', '', 'standard'), false);
  assert.equal(canAccessTabForPlan('audit_logs', 'owner', '', 'standard'), false);
});

test('demo exposes the sales flow and backup settings entry but not internal notes', () => {
  for (const tab of ['dashboard', 'rooms', 'create_bill', 'bulk_meter', 'history', 'report', 'announcements'] as const) {
    assert.equal(canAccessTabForPlan(tab, 'owner', '', 'demo'), true, tab);
  }
  assert.equal(canAccessTabForPlan('settings', 'owner', '', 'demo'), true);
  assert.equal(canAccessTabForPlan('notes', 'owner', '', 'demo'), false);
  assert.equal(canAccessTabForPlan('contracts', 'owner', '', 'demo'), false);
});

test('plan access never bypasses RBAC', () => {
  const technicianPermissions = `${PERMISSIONS.VIEW_DASHBOARD},${PERMISSIONS.VIEW_MAINTENANCE},${PERMISSIONS.MANAGE_MAINTENANCE}`;
  assert.equal(canAccessTabForPlan('maintenance', 'technician', technicianPermissions, 'pro'), true);
  assert.equal(canAccessTabForPlan('report', 'technician', technicianPermissions, 'pro'), false);
});

test('locked tabs advertise the correct paid upgrade tier', () => {
  assert.equal(requiredPlanFeatureForTab('bulk_meter'), 'bulkMeter');
  assert.equal(requiredPaidPlanForTab('bulk_meter'), 'standard');
  assert.equal(requiredPaidPlanForTab('report'), 'standard');
  assert.equal(requiredPaidPlanForTab('contracts'), 'pro');
  assert.equal(requiredPaidPlanForTab('maintenance'), 'pro');
  assert.equal(requiredPaidPlanForTab('settings'), 'basic');
  assert.equal(requiredPaidPlanForTab('dashboard'), null);
});

import { readFileSync } from 'node:fs';

test('App uses plan-aware navigation and renders locked upgrade entries', () => {
  const app = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
  assert.match(app, /canAccessTabForPlan/);
  assert.match(app, /requiredPaidPlanForTab/);
  assert.match(app, /normalizeSubscriptionPlan/);
  assert.match(app, /currentSubscriptionPlan/);
  assert.match(app, /planLocked/);
  assert.match(app, /ฟีเจอร์นี้อยู่ในแพ็กเกจ/);
});

test('SettingsView disables package-specific integrations before the API rejects them', () => {
  const settingsView = readFileSync(new URL('../src/components/SettingsView.tsx', import.meta.url), 'utf8');
  assert.match(settingsView, /hasPlanFeature/);
  assert.match(settingsView, /canUsePromptPay/);
  assert.match(settingsView, /canUseGoogleSheets/);
  assert.match(settingsView, /canUseLineIntegration/);
  assert.match(settingsView, /canManageRecurringCharges[\s\S]*recurringCharges/);
  assert.match(settingsView, /canManageStaff[\s\S]*staff/);
  assert.match(settingsView, /canExportData[\s\S]*contracts/);
});
