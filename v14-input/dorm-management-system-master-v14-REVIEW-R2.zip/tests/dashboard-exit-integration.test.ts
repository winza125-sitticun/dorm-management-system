import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';

test('Dashboard double-Back requests window close without navigating to about:blank', () => {
  const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');

  assert.equal(appSource.includes('exitApp: () => { window.close(); }'), true);
  assert.equal(appSource.includes('about:blank'), false);
});
