import test from 'node:test';
import assert from 'node:assert/strict';
import { validateCustomerConfig } from '../scripts/customer-preflight.mjs';

test('customer preflight validation rejects unresolved setup placeholders', () => {
  const issues = validateCustomerConfig(`{
    "name": "REPLACE_WITH_YOUR_PAGES_PROJECT",
    "d1_databases": [{
      "database_name": "REPLACE_WITH_YOUR_D1_DATABASE_NAME",
      "database_id": "00000000-0000-0000-0000-000000000000"
    }]
  }`);
  assert.ok(issues.some((issue) => /Pages project name/.test(issue)));
  assert.ok(issues.some((issue) => /D1 database name/.test(issue)));
  assert.ok(issues.some((issue) => /database_id/.test(issue)));
});

test('customer preflight validation accepts configured customer identifiers', () => {
  const issues = validateCustomerConfig(`{
    "name": "my-dorm-demo",
    "d1_databases": [{
      "database_name": "my-dorm-demo-db",
      "database_id": "11111111-2222-3333-4444-555555555555"
    }]
  }`);
  assert.deepEqual(issues, []);
});
