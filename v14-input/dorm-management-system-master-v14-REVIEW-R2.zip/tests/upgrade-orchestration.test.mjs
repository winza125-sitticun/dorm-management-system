import test from 'node:test';
import assert from 'node:assert/strict';
import { runUpgradeWorkflow } from '../UPGRADE-PACKAGE.mjs';

const CONFIG = `{
  "name": "mydorm-demo",
  "d1_databases": [{"binding":"DB","database_name":"mydorm-demo-db","database_id":"12345678-1234-1234-1234-123456789abc"}]
}`;

function fakeWrangler(events, state) {
  return (args, options = {}) => {
    events.push(['wrangler', ...args]);
    if (args[0] === 'whoami') return 'You are logged in with an OAuth Token associated with the email owner@example.com';
    if (args[0] === 'd1' && args[1] === 'execute') {
      const sql = args[args.indexOf('--command') + 1] || '';
      if (/^SELECT /i.test(sql.trim())) {
        return JSON.stringify([{ results: [{ subscription_plan: state.plan }], success: true }]);
      }
      if (/UPDATE settings/i.test(sql)) {
        const match = sql.match(/subscription_plan\s*=\s*'([^']+)'/i);
        state.plan = match?.[1] || state.plan;
        return JSON.stringify([{ results: [], success: true }]);
      }
    }
    if (args[0] === 'pages' && args[1] === 'deploy') return 'Deployment complete';
    if (args[0] === 'pages' && args[1] === 'project' && args[2] === 'list') return JSON.stringify([{ 'Project Name': 'mydorm-demo', 'Project Domains': 'mydorm-real.pages.dev' }]);
    return options.capture ? '{}' : '';
  };
}

test('upgrade workflow backs up and validates before updating Basic to Standard, then deploys same project', async () => {
  const events = [];
  const state = { plan: 'basic' };
  const answers = ['y', 'UPGRADE'];
  const ask = async () => answers.shift() ?? '';
  const runNpm = (args) => events.push(['npm', ...args]);
  const runNode = (args) => events.push(['node', ...args]);
  const runWrangler = fakeWrangler(events, state);

  const result = await runUpgradeWorkflow({
    configSource: CONFIG,
    targetPlan: 'standard',
    ask,
    runNpm,
    runNode,
    runWrangler,
    log: () => {},
    backupPathFactory: () => './backups/upgrade-basic-to-standard.sql',
  });

  assert.deepEqual(result, {
    projectName: 'mydorm-demo',
    databaseName: 'mydorm-demo-db',
    fromPlan: 'basic',
    toPlan: 'standard',
    backupPath: './backups/upgrade-basic-to-standard.sql',
    projectUrls: ['https://mydorm-real.pages.dev'],
  });
  assert.equal(state.plan, 'standard');

  const labels = events.map((event) => event.join(' '));
  const backupAt = labels.indexOf('node scripts/d1-export.mjs --remote ./backups/upgrade-basic-to-standard.sql');
  const releaseAt = labels.indexOf('npm run release:check');
  const migrateAt = labels.indexOf('npm run d1:migrate:remote');
  const updateAt = labels.findIndex((line) => /wrangler d1 execute DB --remote --json --command UPDATE settings/.test(line));
  const buildAt = labels.indexOf('npm run build:pages');
  const deployAt = labels.indexOf('wrangler pages deploy dist --project-name mydorm-demo');

  assert.ok(backupAt >= 0);
  assert.ok(backupAt < releaseAt);
  assert.ok(releaseAt < migrateAt);
  assert.ok(migrateAt < updateAt);
  assert.ok(updateAt < buildAt);
  assert.ok(buildAt < deployAt);
});

test('upgrade workflow does not mutate plan when exact UPGRADE confirmation is missing', async () => {
  const events = [];
  const state = { plan: 'basic' };
  const answers = ['y', 'no'];
  const ask = async () => answers.shift() ?? '';

  await assert.rejects(
    runUpgradeWorkflow({
      configSource: CONFIG,
      targetPlan: 'standard',
      ask,
      runNpm: (args) => events.push(['npm', ...args]),
      runNode: (args) => events.push(['node', ...args]),
      runWrangler: fakeWrangler(events, state),
      log: () => {},
      backupPathFactory: () => './backups/cancelled.sql',
    }),
    /cancelled/i,
  );

  assert.equal(state.plan, 'basic');
  assert.equal(events.some((event) => event.join(' ').includes('UPDATE settings')), false);
  assert.equal(events.some((event) => event[0] === 'wrangler' && event[1] === 'pages' && event[2] === 'deploy'), false);
});
