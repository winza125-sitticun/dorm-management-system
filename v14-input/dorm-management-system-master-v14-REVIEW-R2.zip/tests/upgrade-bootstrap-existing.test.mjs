import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync, writeFileSync, readFileSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { configureExistingResourcesForUpgrade } from '../SETUP-CLOUDFLARE.mjs';
import { resolveUpgradeConfig } from '../UPGRADE-PACKAGE.mjs';

const TEMPLATE = `{
  "name": "REPLACE_WITH_YOUR_PAGES_PROJECT",
  "pages_build_output_dir": "./dist",
  "d1_databases": [{
    "binding": "DB",
    "database_name": "REPLACE_WITH_YOUR_D1_DATABASE_NAME",
    "database_id": "00000000-0000-0000-0000-000000000000",
    "migrations_dir": "./d1-migrations"
  }]
}`;

test('upgrade bootstrap configures an existing Pages project and D1 without creating new resources', async () => {
  const answers = ['mydorm', 'mydorm-db', 'y'];
  const rl = { question: async () => answers.shift() ?? '' };
  const calls = [];
  let persisted = '';
  const run = (args, options = {}) => {
    calls.push(args.join(' '));
    if (args.join(' ') === 'pages project list --json') {
      return JSON.stringify([{ 'Project Name': 'mydorm', 'Project Domains': 'mydorm.pages.dev' }]);
    }
    if (args.join(' ') === 'd1 list --json') {
      return JSON.stringify([{ name: 'mydorm-db', uuid: 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee' }]);
    }
    if (args.join(' ') === 'd1 info mydorm-db --json') {
      return JSON.stringify({ uuid: 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee', name: 'mydorm-db' });
    }
    return options.capture ? '{}' : '';
  };

  const result = await configureExistingResourcesForUpgrade(rl, {
    run,
    configSource: TEMPLATE,
    persist: (source) => { persisted = source; },
    log: () => {},
  });

  assert.deepEqual(result, {
    projectName: 'mydorm',
    databaseName: 'mydorm-db',
    databaseId: 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee',
  });
  assert.match(persisted, /"name": "mydorm"/);
  assert.match(persisted, /"database_name": "mydorm-db"/);
  assert.match(persisted, /"database_id": "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"/);
  assert.equal(calls.some((line) => /\bcreate\b/.test(line)), false);
});

test('upgrade bootstrap refuses to create a missing Pages project or D1', async () => {
  const rlPages = { question: async () => 'missing-pages' };
  const runPages = (args) => {
    if (args.join(' ') === 'pages project list --json') return '[]';
    return '[]';
  };
  await assert.rejects(
    configureExistingResourcesForUpgrade(rlPages, { run: runPages, configSource: TEMPLATE, persist: () => {}, log: () => {} }),
    /ไม่พบ Pages Project/i,
  );

  const answers = ['mydorm', 'missing-db'];
  const rlDb = { question: async () => answers.shift() ?? '' };
  const runDb = (args) => {
    if (args.join(' ') === 'pages project list --json') return JSON.stringify([{ 'Project Name': 'mydorm' }]);
    if (args.join(' ') === 'd1 list --json') return '[]';
    return '{}';
  };
  await assert.rejects(
    configureExistingResourcesForUpgrade(rlDb, { run: runDb, configSource: TEMPLATE, persist: () => {}, log: () => {} }),
    /ไม่พบ D1 Database/i,
  );
});

test('resolveUpgradeConfig creates active config through existing-resource bootstrap when missing', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'dorm-upgrade-bootstrap-'));
  try {
    const active = join(dir, 'wrangler.jsonc');
    let configured = 0;
    const config = await resolveUpgradeConfig({
      hasConfig: () => existsSync(active),
      readConfig: () => readFileSync(active, 'utf8'),
      configureExisting: async () => {
        configured += 1;
        writeFileSync(active, '{"name":"mydorm"}', 'utf8');
      },
    });
    assert.equal(configured, 1);
    assert.equal(config, '{"name":"mydorm"}');
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});
