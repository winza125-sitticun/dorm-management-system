import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

for (const [file, script] of [
  ['SETUP-WINDOWS.cmd', 'setup:cloudflare'],
  ['DEPLOY-WINDOWS.cmd', 'deploy:customer'],
  ['UPGRADE-WINDOWS.cmd', 'upgrade:package'],
]) {
  test(`${file} calls npm so execution returns to pause`, () => {
    const text = readFileSync(resolve(file), 'utf8').toLowerCase();
    assert.ok(text.includes(`call npm run ${script}`));
    const npmLines = text.split(/\r?\n/).map((line) => line.trim()).filter((line) => /^(?:call\s+)?npm\b/.test(line));
    assert.ok(npmLines.length > 0);
    assert.deepEqual(npmLines.filter((line) => !line.startsWith('call npm')), []);
    assert.ok(text.includes('pause'));
    assert.ok(text.includes('exitcode'));
  });
}
