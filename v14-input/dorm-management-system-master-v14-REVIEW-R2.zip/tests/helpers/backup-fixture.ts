import {
  BACKUP_FORMAT,
  BACKUP_FORMAT_VERSION,
  BACKUP_SCHEMA_VERSION,
  computeBackupCounts,
  sha256Hex,
  stableStringify,
  type BackupDataV1,
  type BackupManifestV1,
} from '../../src/utils/backupFormat.ts';

export function emptyBackupData(): BackupDataV1 {
  return {
    rooms: [], bills: [], recurringChargeTemplates: [], roomRecurringCharges: [], billChargeItems: [],
    maintenanceTickets: [], housekeepingTasks: [], leaseContracts: [], announcements: [], notes: [],
    settings: {
      dormName: 'หอพักทดสอบ', defaultElecRate: 7, defaultWaterRate: 13,
      defaultDueDateDay: 5, defaultPenaltyRate: 100,
      promptpayId: null, promptpayName: null, fontScale: 'medium',
    },
  };
}

export function room(id = 1, roomNumber = '101') {
  return { id, roomNumber, monthlyRent: 3000, status: 'available', tenantName: null, tenantPhone: null, createdAt: '2026-08-01T00:00:00Z', deletedAt: null, deletedBy: null };
}

export function bill(id = 11, roomId = 1) {
  return {
    id, roomId, billMonth: '2026-08', priorElec: 10, currentElec: 20, elecDeduct: 0,
    elecUnitCost: 7, elecCost: 70, priorWater: 1, currentWater: 2, waterUnitCost: 13, waterCost: 13,
    rentCost: 3000, depositCost: 0, otherCost: 0, otherDescription: null, totalCost: 3083,
    dueDate: '2026-08-05', status: 'unpaid', paidAt: null, slipImage: null, slipUploadedAt: null,
    slipStatus: 'none', createdAt: '2026-08-01T00:00:00Z', deletedAt: null, deletedBy: null,
  };
}

export async function manifestFor(data: BackupDataV1, ownerScope = 'a'.repeat(64)): Promise<BackupManifestV1> {
  return {
    format: BACKUP_FORMAT,
    formatVersion: BACKUP_FORMAT_VERSION,
    appVersion: '1.1.0',
    schemaVersion: BACKUP_SCHEMA_VERSION,
    createdAt: '2026-08-16T00:00:00.000Z',
    ownerScope,
    dormName: data.settings.dormName,
    counts: computeBackupCounts(data),
    excluded: ['users', 'integration_secrets'],
    dataSha256: await sha256Hex(stableStringify(data)),
  };
}
