@echo off
setlocal
cd /d "%~dp0"
title Dorm Management System - Package Upgrade V14

echo ============================================================
echo  Dorm Management System - Package Upgrade Manager V14
echo ============================================================
echo.

echo Node:
node -v
if errorlevel 1 goto :node_error

echo npm:
call npm -v
if errorlevel 1 goto :npm_error

echo.
echo Starting Package Upgrade Manager...
call npm run upgrade:package
set "EXITCODE=%ERRORLEVEL%"
if not "%EXITCODE%"=="0" (
  echo.
  echo [ERROR] Upgrade stopped with exit code %EXITCODE%.
  echo No deployment should be considered complete until the error is fixed.
) else (
  echo.
  echo Upgrade Manager finished successfully.
)
echo.
pause
exit /b %EXITCODE%

:node_error
echo.
echo [ERROR] Node.js 22 or newer is required.
set "EXITCODE=1"
pause
exit /b %EXITCODE%

:npm_error
echo.
echo [ERROR] npm is not available in PATH.
set "EXITCODE=1"
pause
exit /b %EXITCODE%
