# V14 Task 12 — Final Verification Status

สถานะ: **PREVIEW / REVIEW ผ่านด่านที่รันได้ใน sandbox แต่ Production Release Gate ยัง BLOCKED**

> ห้ามเรียกไฟล์ชุดนี้ว่า CUSTOMER-READY จนกว่าจะรัน `npm ci`, full release gate และ D1 smoke test ด้วย dependencies จริงผ่านทั้งหมด

## Source checkpoint

- Recovery branch: `feature/v14-task12-recovery`
- Recovery commit: `1a8d0e3`
- เหตุผลที่เป็น recovery branch: runtime sandbox remount ทำให้ workspace/ประวัติ git ช่วง Task 5–11 ที่อยู่แบบ ephemeral หาย ระหว่าง Task 12
- กู้ฐานจาก persistent V14 Task 4 checkpoint แล้ว reconstruct Task 5–11 จากสเปกที่อนุมัติและ safety tests ก่อนสร้าง commit นี้
- Tracked source ที่ commit แล้วไม่มี diff ค้าง

## Verification ที่ผ่านจาก commit 1a8d0e3

### Master focused/native tests

| Suite | ผล | หมายเหตุ |
|---|---:|---|
| Backup safety | 21/21 | ใช้ test-only `tsx/zod/fflate` shims เพราะ npm registry เข้าไม่ได้ |
| Plan tests | 23/23 | ใช้ test-only `tsx` shim |
| Customer handoff | 7/7 | ใช้ test-only `tsx` shim |
| Setup Master | 29/29 | Node native `.mjs` |
| Upgrade | 17/17 | Node native `.mjs` |
| Builder / ZIP parity | 20/20 | Node native `.mjs` |
| Settings | 6/6 | ใช้ test-only `tsx` shim |
| `git diff HEAD --check` | PASS | tracked source clean |
| JS/MJS syntax | PASS | Node native `--check` |
| V14 core TS syntax | PASS | Node 22 `--experimental-transform-types --check` |
| secret-file scan | PASS | ไม่พบ `.env`, `.dev.vars`, active `wrangler.jsonc` ใน source |

### Generated PREVIEW packages

Builder สร้าง 4 ZIP แบบ PREVIEW สำเร็จ และตรวจ CRC/โครงสร้างหลังสร้างจริง:

- Demo — Backup Export = true, Restore = false
- Basic — Backup Export = true, Restore = true
- Standard — Backup Export = true, Restore = true
- Pro — Backup Export = true, Restore = true

แต่ละ ZIP มี 174 entries, มีไฟล์ V14 Backup/Restore ที่ต้องใช้ และไม่มี `.git`, `node_modules`, active `wrangler.jsonc`, `.env`, `.dev.vars`, Master-only files, `package-plans`, `docs/superpowers` หรือ Release Notes V13

หลังแตก ZIP แต่ละแพ็กเกจ:

| Suite ต่อแพ็กเกจ | Demo | Basic | Standard | Pro |
|---|---:|---:|---:|---:|
| Portable customer tests (native) | 33/33 | 33/33 | 33/33 | 33/33 |
| Backup focused | 21/21 | 21/21 | 21/21 | 21/21 |
| Plan focused | 23/23 | 23/23 | 23/23 | 23/23 |
| Handoff focused | 7/7 | 7/7 | 7/7 | 7/7 |

หมายเหตุ: Backup/Plan/Handoff focused tests ใน sandbox ใช้ test-only dependency shims และ **ไม่ใช่หลักฐานแทน `npm ci` + dependencies จริง**

## SHA-256 ของ PREVIEW ZIP

- Demo: `a307173dacf6ec90a9517b1d01463d6459369238ac5ae0af1758a0e3709347e8`
- Basic: `8ab91a11cc2fdebdbb387f1c4a0e20e1d76a7d7b6927491623bc8459843f3210`
- Standard: `087fb487eb41c3ab3b5b5a7c9caf3652bab9474aa57145a98e7edc36ee71962f`
- Pro: `843d87b86b6a00d0d2427fe0fdea33bdd4ef18e329401e10125da5d387f6d439`

## Revision 2 — package reproducibility fix

รอบ verify ต่อเนื่องพบว่า Master REVIEW ที่มี `TASK12_STATUS_TH.md` แล้ว ทำให้ `packages:generate` สร้าง ZIP 175 entries และ SHA-256 เปลี่ยนจาก PREVIEW ชุดแรก เพราะไฟล์สถานะ QA ภายในถูก copy เข้า customer package โดยไม่ตั้งใจ

แก้แบบ TDD:

- เพิ่ม regression assertion ใน `tests/package-release.test.mjs` ว่า customer ZIP ต้องไม่มี `TASK12_STATUS_TH.md`
- ยืนยัน RED: test fail เพราะไฟล์นี้อยู่ใน ZIP จริง
- เพิ่ม `TASK12_STATUS_TH.md` เข้า Master-only exclusions ของ `scripts/build-packages.mjs`
- เพิ่มเข้า forbidden customer artifacts ของ `scripts/package-audit.mjs`
- ยืนยัน GREEN: `tests/package-release.test.mjs` 4/4 PASS
- rerun native QA รวม 66/66 PASS
- regenerate PREVIEW ทั้ง 4 รุ่น: กลับมา 174 entries และ SHA-256 ตรงกับชุด PREVIEW เดิมทุกไฟล์

ผลนี้ยืนยันว่า Revision 2 เปลี่ยนเฉพาะ release-engineering guard และไม่เปลี่ยน customer package bytes จากชุด PREVIEW ที่ตรวจไว้ก่อนหน้า

## Production Release Gate ที่ยัง BLOCKED

`npm ci` ไม่สามารถดึง dependencies จริงได้ เนื่องจาก sandbox resolve `registry.npmjs.org` ไม่ได้:

- `getent` หา `registry.npmjs.org`: ไม่สำเร็จ
- `curl` ไป npm registry: `Could not resolve host`
- npm cache entries: 0
- `node_modules/.bin/tsx`: ไม่มี
- `node_modules/.bin/tsc`: ไม่มี
- `node_modules/.bin/vite`: ไม่มี
- `node_modules/.bin/wrangler`: ไม่มี

ดังนั้น Task 12 ยังไม่สามารถยืนยัน:

1. full `npm test` ด้วย dependencies จริง
2. `npm run lint`
3. `npm run check:cloudflare-types:master`
4. `npm run build:pages`
5. `npm run packages:release`
6. temporary Cloudflare D1 end-to-end smoke restore

## Release decision

- `packages:generate` / PREVIEW: **อนุญาต**
- Master REVIEW ZIP: **อนุญาตสำหรับตรวจ/พัฒนาต่อ**
- CUSTOMER-READY ZIP: **ยังไม่อนุญาต**
- Production deployment sign-off: **ยังไม่อนุญาต**

ด่านสุดท้ายต้องรันบนเครื่อง/CI ที่เข้าถึง npm registry และ Cloudflare D1 ได้ แล้วค่อยเรียก `npm run packages:release`
