#!/usr/bin/env node
import { randomBytes } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync, unlinkSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import process from 'node:process';
import readline from 'node:readline/promises';
import { stdin as input, stdout as output } from 'node:process';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const SCRIPT_PATH = fileURLToPath(import.meta.url);
const ROOT = dirname(SCRIPT_PATH);
const WRANGLER_CONFIG = resolve(ROOT, 'wrangler.jsonc');
const WRANGLER_TEMPLATE = resolve(ROOT, 'wrangler.template.jsonc');
const PACKAGE_JSON = resolve(ROOT, 'package.json');
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab0-9][0-9a-f]{3}-[0-9a-f]{12}$/i;
const GENERIC_UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export function validateCloudflareName(value) {
  const name = String(value ?? '').trim();
  if (!name) throw new Error('Cloudflare resource name is required');
  if (name !== name.toLowerCase()) throw new Error('Use lowercase letters for Cloudflare resource names');
  if (!/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(name)) {
    throw new Error('Use only lowercase a-z, 0-9 and dashes; do not start/end with a dash');
  }
  return name;
}

export function extractD1Id(value) {
  if (typeof value === 'string' && GENERIC_UUID_RE.test(value)) return value;
  if (Array.isArray(value)) {
    for (const item of value) {
      const found = extractD1Id(item);
      if (found) return found;
    }
    return null;
  }
  if (value && typeof value === 'object') {
    const preferredKeys = ['uuid', 'id', 'database_id'];
    for (const key of preferredKeys) {
      if (key in value) {
        const found = extractD1Id(value[key]);
        if (found) return found;
      }
    }
    for (const nested of Object.values(value)) {
      const found = extractD1Id(nested);
      if (found) return found;
    }
  }
  return null;
}

export function configHasSetupPlaceholders(source) {
  const text = String(source ?? '');
  return /REPLACE_WITH_YOUR_PAGES_PROJECT|REPLACE_WITH_YOUR_D1_DATABASE_NAME|00000000-0000-0000-0000-000000000000/.test(text);
}

export function prepareWranglerForLogin({ activePath = WRANGLER_CONFIG, templatePath = WRANGLER_TEMPLATE } = {}) {
  if (!existsSync(activePath)) return 'no-active-config';
  const active = readFileSync(activePath, 'utf8');
  if (!configHasSetupPlaceholders(active)) return 'kept-configured';
  if (!existsSync(templatePath)) writeFileSync(templatePath, active, 'utf8');
  unlinkSync(activePath);
  return 'removed-placeholder';
}

export function selectWranglerSource({ existingConfig, templateConfig }) {
  if (typeof existingConfig === 'string' && existingConfig.trim()) return existingConfig;
  if (typeof templateConfig === 'string' && templateConfig.trim()) return templateConfig;
  throw new Error('wrangler.template.jsonc not found. Re-extract the customer package and run setup again.');
}

function readWranglerSource() {
  const existingConfig = existsSync(WRANGLER_CONFIG) ? readFileSync(WRANGLER_CONFIG, 'utf8') : null;
  const templateConfig = existsSync(WRANGLER_TEMPLATE) ? readFileSync(WRANGLER_TEMPLATE, 'utf8') : null;
  return selectWranglerSource({ existingConfig, templateConfig });
}

export function patchWranglerConfig(source, { projectName, databaseName, databaseId }) {
  const project = validateCloudflareName(projectName);
  const database = validateCloudflareName(databaseName);
  if (!GENERIC_UUID_RE.test(databaseId)) throw new Error('D1 database ID must be a UUID');

  let next = source;
  const rootName = /(\"name\"\s*:\s*)\"[^\"]*\"/;
  const dbName = /(\"database_name\"\s*:\s*)\"[^\"]*\"/;
  const dbId = /(\"database_id\"\s*:\s*)\"[^\"]*\"/;
  if (!rootName.test(next) || !dbName.test(next) || !dbId.test(next)) {
    throw new Error('wrangler.jsonc does not contain the expected Pages/D1 fields');
  }
  next = next.replace(rootName, `$1\"${project}\"`);
  next = next.replace(dbName, `$1\"${database}\"`);
  next = next.replace(dbId, `$1\"${databaseId}\"`);

  // Current Cloudflare Pages local D1 guidance uses preview_database_id for local development.
  if (!/\"preview_database_id\"\s*:/.test(next)) {
    next = next.replace(
      /(\"database_id\"\s*:\s*\"[^\"]+\"\s*,?)/,
      `$1\n      \"preview_database_id\": \"DB\",`,
    );
  }
  return next;
}

function parseJsonOutput(text) {
  const raw = String(text ?? '').trim();
  if (!raw) throw new Error('Wrangler returned empty JSON output');
  const positions = [raw.indexOf('['), raw.indexOf('{')].filter((n) => n >= 0).sort((a, b) => a - b);
  for (const start of positions) {
    try {
      return JSON.parse(raw.slice(start));
    } catch {
      // try next candidate
    }
  }
  throw new Error(`Cannot parse Wrangler JSON output: ${raw.slice(0, 240)}`);
}



function normalizeProjectDomain(value) {
  const raw = String(value ?? '').trim();
  if (!raw) return null;
  if (/^https?:\/\//i.test(raw)) return raw.replace(/\/$/, '');
  return `https://${raw.replace(/^\/+|\/+$/g, '')}`;
}

export function projectUrlsFromList(value, projectName) {
  const target = String(projectName ?? '').trim();
  if (!target || !Array.isArray(value)) return [];
  const project = value.find((item) => {
    if (!item || typeof item !== 'object') return false;
    return [item.name, item.project_name, item['Project Name']].some((name) => name === target);
  });
  if (!project) return [];

  const rawDomains = project['Project Domains'] ?? project.domains ?? project.project_domains ?? [];
  const domains = Array.isArray(rawDomains)
    ? rawDomains
    : String(rawDomains).split(',');
  return [...new Set(domains.map(normalizeProjectDomain).filter(Boolean))];
}

export function readProjectUrls(projectName, run = runWrangler) {
  try {
    const json = parseJsonOutput(run(['pages', 'project', 'list', '--json'], { capture: true }));
    return projectUrlsFromList(json, projectName);
  } catch {
    return [];
  }
}

export function secretListHasKey(output, key) {
  const target = String(key ?? '').trim();
  if (!target) return false;
  const clean = String(output ?? '').replace(/\x1B\[[0-?]*[ -/]*[@-~]/g, ' ');
  const escaped = target.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return new RegExp(`(^|[^A-Za-z0-9_])${escaped}([^A-Za-z0-9_]|$)`).test(clean);
}

function jwtSecretState(projectName) {
  try {
    const output = runWrangler(['pages', 'secret', 'list', '--project-name', projectName], { capture: true });
    return secretListHasKey(output, 'JWT_SECRET') ? 'present' : 'missing';
  } catch {
    return 'unknown';
  }
}

export function collectResourceNames(value, names = new Set()) {
  if (Array.isArray(value)) {
    for (const item of value) collectResourceNames(item, names);
  } else if (value && typeof value === 'object') {
    const candidateKeys = ['name', 'project_name', 'Project Name', 'database_name', 'Database Name'];
    for (const key of candidateKeys) {
      if (typeof value[key] === 'string') names.add(value[key]);
    }
    for (const nested of Object.values(value)) collectResourceNames(nested, names);
  }
  return names;
}

export function commandStdio({ capture = false, inputText } = {}) {
  if (capture) return ['pipe', 'pipe', 'pipe'];
  return inputText === undefined ? ['inherit', 'inherit', 'inherit'] : ['pipe', 'inherit', 'inherit'];
}

export function commandUsesShell(bin, platform = process.platform) {
  return platform === 'win32' && /\.(?:cmd|bat)$/i.test(String(bin));
}

function command(bin, args, { capture = false, inputText } = {}) {
  const result = spawnSync(bin, args, {
    cwd: ROOT,
    encoding: 'utf8',
    stdio: commandStdio({ capture, inputText }),
    input: inputText,
    shell: commandUsesShell(bin),
  });
  if (result.error) throw result.error;
  if (result.status !== 0) {
    const detail = capture ? `${result.stdout ?? ''}\n${result.stderr ?? ''}`.trim() : '';
    throw new Error(`${bin} ${args.join(' ')} failed${detail ? `\n${detail}` : ''}`);
  }
  return capture ? String(result.stdout ?? '') : '';
}

function npmBin() {
  return process.platform === 'win32' ? 'npm.cmd' : 'npm';
}
function npxBin() {
  return process.platform === 'win32' ? 'npx.cmd' : 'npx';
}

function runNpm(args) {
  return command(npmBin(), args);
}
function runWrangler(args, opts = {}) {
  return command(npxBin(), ['wrangler', ...args], opts);
}

function currentConfiguredValue(source, key, placeholder) {
  const match = source.match(new RegExp(`\\"${key}\\"\\s*:\\s*\\"([^\\"]+)\\"`));
  const value = match?.[1] ?? '';
  return !value || value === placeholder || /^0{8}-/.test(value) ? '' : value;
}

async function askName(rl, label, defaultValue = '') {
  while (true) {
    const hint = defaultValue ? ` [${defaultValue}]` : '';
    const answer = (await rl.question(`${label}${hint}: `)).trim() || defaultValue;
    try {
      return validateCloudflareName(answer);
    } catch (error) {
      console.log(`✗ ${error.message}`);
    }
  }
}

async function askYesNo(rl, label, defaultYes = true) {
  const suffix = defaultYes ? ' [Y/n]: ' : ' [y/N]: ';
  const answer = (await rl.question(label + suffix)).trim().toLowerCase();
  if (!answer) return defaultYes;
  return answer === 'y' || answer === 'yes';
}

function ensureNode22() {
  const major = Number(process.versions.node.split('.')[0] || 0);
  if (major < 22) throw new Error(`Node.js 22+ required. Found ${process.version}`);
}

function ensureDependencies() {
  const wranglerBin = resolve(ROOT, 'node_modules', '.bin', process.platform === 'win32' ? 'wrangler.cmd' : 'wrangler');
  if (existsSync(wranglerBin)) return;
  console.log('\nติดตั้ง dependencies ด้วย npm ci ...');
  runNpm(['ci']);
}

export function parseCloudflareIdentity(text) {
  const clean = String(text ?? '').replace(/\x1B\[[0-?]*[ -\/]*[@-~]/g, '');
  const email = clean.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i)?.[0] ?? null;
  return { email };
}

export async function chooseCloudflareAccount(rl, run = runWrangler) {
  let currentOutput;
  try {
    currentOutput = run(['whoami'], { capture: true });
  } catch {
    console.log('\nยังไม่ได้ Login Cloudflare — กำลังเปิด Wrangler login ...');
    run(['login']);
    const verified = run(['whoami'], { capture: true });
    const identity = parseCloudflareIdentity(verified);
    console.log(`Login Cloudflare แล้ว: ${identity.email ?? 'ตรวจสอบบัญชีสำเร็จ'}`);
    return { ...identity, switched: true };
  }

  const current = parseCloudflareIdentity(currentOutput);
  while (true) {
    console.log('\n=== เลือกบัญชี Cloudflare ===');
    console.log(`พบบัญชีที่ Login อยู่: ${current.email ?? 'ไม่พบอีเมลในผล whoami'}`);
    console.log('[1] ใช้บัญชีนี้');
    console.log('[2] Logout และ Login บัญชีใหม่');
    console.log('[3] ยกเลิก Setup');
    const choice = (await rl.question('เลือก 1 / 2 / 3: ')).trim();

    if (choice === '1') {
      console.log(`ใช้บัญชี Cloudflare: ${current.email ?? 'บัญชีปัจจุบัน'}`);
      return { ...current, switched: false };
    }
    if (choice === '2') {
      console.log('\nกำลัง Logout จาก Cloudflare และเปิด Login ใหม่ ...');
      run(['logout']);
      run(['login']);
      const verified = run(['whoami'], { capture: true });
      const identity = parseCloudflareIdentity(verified);
      console.log(`ใช้บัญชี Cloudflare ใหม่: ${identity.email ?? 'ตรวจสอบบัญชีสำเร็จ'}`);
      return { ...identity, switched: true };
    }
    if (choice === '3') throw new Error('Setup cancelled by user before Cloudflare resource selection');
    console.log('✗ กรุณาเลือก 1, 2 หรือ 3');
  }
}

function getD1Info(databaseName) {
  const json = parseJsonOutput(runWrangler(['d1', 'info', databaseName, '--json'], { capture: true }));
  const id = extractD1Id(json);
  if (!id) throw new Error(`Cannot find D1 database ID for ${databaseName}`);
  return { json, id };
}

function pagesProjectExists(projectName) {
  const json = parseJsonOutput(runWrangler(['pages', 'project', 'list', '--json'], { capture: true }));
  return collectResourceNames(json).has(projectName);
}

function d1DatabaseExists(databaseName) {
  const json = parseJsonOutput(runWrangler(['d1', 'list', '--json'], { capture: true }));
  return collectResourceNames(json).has(databaseName);
}


export function isAlreadyExistsError(error) {
  const text = String(error?.message ?? error ?? '').toLowerCase();
  return text.includes('already exists') || text.includes('code: 8000002') || text.includes('[code: 8000002]');
}


export async function configureExistingResourcesForUpgrade(rl, {
  run = runWrangler,
  configSource = readWranglerSource(),
  persist = (source) => writeFileSync(WRANGLER_CONFIG, source, 'utf8'),
  log = console.log,
} = {}) {
  log('\n=== เชื่อมระบบเดิมสำหรับ Upgrade ===');
  log('โหมด Upgrade จะใช้เฉพาะ Pages Project และ D1 ที่มีอยู่แล้วเท่านั้น');

  const currentProject = currentConfiguredValue(configSource, 'name', 'REPLACE_WITH_YOUR_PAGES_PROJECT');
  const currentDb = currentConfiguredValue(configSource, 'database_name', 'REPLACE_WITH_YOUR_D1_DATABASE_NAME');
  const projectName = await askName(rl, 'ชื่อ Cloudflare Pages Project เดิม', currentProject);

  const projectsJson = parseJsonOutput(run(['pages', 'project', 'list', '--json'], { capture: true }));
  if (!collectResourceNames(projectsJson).has(projectName)) {
    throw new Error(`ไม่พบ Pages Project "${projectName}" ในบัญชี Cloudflare นี้ — Upgrade จะไม่สร้าง Project ใหม่`);
  }

  const databaseName = await askName(rl, 'ชื่อ D1 Database เดิม', currentDb || `${projectName}-db`);
  const databasesJson = parseJsonOutput(run(['d1', 'list', '--json'], { capture: true }));
  if (!collectResourceNames(databasesJson).has(databaseName)) {
    throw new Error(`ไม่พบ D1 Database "${databaseName}" ในบัญชี Cloudflare นี้ — Upgrade จะไม่สร้างฐานใหม่`);
  }

  const infoJson = parseJsonOutput(run(['d1', 'info', databaseName, '--json'], { capture: true }));
  const databaseId = extractD1Id(infoJson);
  if (!databaseId) throw new Error(`ไม่พบ D1 database ID สำหรับ ${databaseName}`);

  log('\nตรวจพบระบบเดิม:');
  log(`- Pages Project: ${projectName}`);
  log(`- D1 Database:   ${databaseName}`);
  log(`- D1 ID:         ${databaseId}`);
  const confirm = await askYesNo(rl, 'ใช้ Project และ D1 นี้สำหรับ Upgrade หรือไม่?', true);
  if (!confirm) throw new Error('Upgrade cancelled before writing Cloudflare config');

  const next = patchWranglerConfig(configSource, { projectName, databaseName, databaseId });
  persist(next);
  return { projectName, databaseName, databaseId };
}
function writeConfig(projectName, databaseName, databaseId) {
  const original = readWranglerSource();
  const next = patchWranglerConfig(original, { projectName, databaseName, databaseId });
  writeFileSync(WRANGLER_CONFIG, next, 'utf8');
}

function setJwtSecret(projectName) {
  const secret = randomBytes(48).toString('hex');
  console.log('กำลังสร้าง JWT_SECRET แบบสุ่มและบันทึกเป็น Cloudflare Secret ...');
  runWrangler(['pages', 'secret', 'put', 'JWT_SECRET', '--project-name', projectName], {
    inputText: `${secret}\n`,
  });
}

async function ensureJwtSecret(rl, projectName, projectWasCreated) {
  if (projectWasCreated) {
    setJwtSecret(projectName);
    return;
  }

  const state = jwtSecretState(projectName);
  if (state === 'present') {
    console.log('✓ พบ JWT_SECRET เดิมใน Pages Project — เก็บค่าเดิมไว้ ไม่หมุน Secret โดยไม่จำเป็น');
    return;
  }
  if (state === 'missing') {
    console.log('ไม่พบ JWT_SECRET ใน Pages Project เดิม — กำลังสร้าง Secret ใหม่เพื่อให้ระบบ Login/API ใช้งานได้');
    setJwtSecret(projectName);
    return;
  }

  const setNow = await askYesNo(rl, 'ตรวจรายการ Secret ไม่สำเร็จ ต้องการตั้ง JWT_SECRET ตอนนี้หรือไม่?', true);
  if (!setNow) {
    throw new Error('JWT_SECRET was not verified. Setup stopped before deployment for safety.');
  }
  setJwtSecret(projectName);
}

function packageLabel() {
  try {
    const pkg = JSON.parse(readFileSync(PACKAGE_JSON, 'utf8'));
    return pkg.name || 'dorm-management-system';
  } catch {
    return 'dorm-management-system';
  }
}

async function configureResources(rl) {
  const config = readWranglerSource();
  const currentProject = currentConfiguredValue(config, 'name', 'REPLACE_WITH_YOUR_PAGES_PROJECT');
  const currentDb = currentConfiguredValue(config, 'database_name', 'REPLACE_WITH_YOUR_D1_DATABASE_NAME');

  console.log('\n=== Cloudflare Setup ===');
  console.log('ระบบจะถามชื่อ Project และ Database ทุกครั้ง เพื่อป้องกันส่ง ID ข้ามลูกค้า');
  const projectName = await askName(rl, 'ชื่อ Cloudflare Pages Project', currentProject);
  const databaseName = await askName(rl, 'ชื่อ D1 Database', currentDb || `${projectName}-db`);

  let databaseWasCreated = false;
  if (!d1DatabaseExists(databaseName)) {
    const create = await askYesNo(rl, `ไม่พบ D1 "${databaseName}" ต้องการสร้างใหม่หรือไม่?`, true);
    if (!create) throw new Error('Setup cancelled because the D1 database does not exist');
    runWrangler(['d1', 'create', databaseName], { inputText: 'n\n' });
    databaseWasCreated = true;
  }
  const { id: databaseId } = getD1Info(databaseName);

  let projectWasCreated = false;
  if (!pagesProjectExists(projectName)) {
    const create = await askYesNo(rl, `ไม่พบ Pages Project "${projectName}" ต้องการสร้างใหม่หรือไม่?`, true);
    if (!create) throw new Error('Setup cancelled because the Pages project does not exist');
    try {
      runWrangler(['pages', 'project', 'create', projectName, '--production-branch', 'main']);
      projectWasCreated = true;
    } catch (error) {
      if (!isAlreadyExistsError(error)) throw error;
      console.log(`Pages Project "${projectName}" มีอยู่แล้ว — ใช้ Project เดิมต่อ`);
    }
  }

  console.log('\nตรวจพบข้อมูล Cloudflare:');
  console.log(`- Pages Project: ${projectName}`);
  console.log(`- D1 Database:   ${databaseName}`);
  console.log(`- D1 ID:         ${databaseId}`);
  const confirm = await askYesNo(rl, 'บันทึกข้อมูลนี้ลง wrangler.jsonc หรือไม่?', true);
  if (!confirm) throw new Error('Setup cancelled before writing wrangler.jsonc');

  writeConfig(projectName, databaseName, databaseId);
  runNpm(['run', 'customer:preflight']);

  await ensureJwtSecret(rl, projectName, projectWasCreated);

  let localVerified = false;
  if (await askYesNo(rl, 'รัน Local D1 migration + build เพื่อตรวจพื้นฐานตอนนี้หรือไม่?', true)) {
    runNpm(['run', 'd1:migrate:local']);
    runNpm(['run', 'build:pages']);
    localVerified = true;
  }

  return { projectName, databaseName, databaseId, projectWasCreated, databaseWasCreated, localVerified };
}

async function maybeDeploy(rl, resources, forceDeployPrompt) {
  const wantsDeploy = forceDeployPrompt || await askYesNo(rl, 'ต้องการตรวจระบบ + migrate Production + Deploy ตอนนี้หรือไม่?', false);
  if (!wantsDeploy) {
    console.log('\nตั้งค่า Cloudflare เสร็จแล้ว ยังไม่ได้แก้ฐาน Production หรือ Deploy');
    console.log('รัน `npm run deploy:customer` เมื่อต้องการ Deploy ภายหลัง');
    return;
  }

  if (!resources.localVerified) {
    console.log('\nตรวจ Local D1 migration + build ก่อนแตะ Production ...');
    runNpm(['run', 'd1:migrate:local']);
    runNpm(['run', 'build:pages']);
  }

  console.log('\n=== Release check ก่อนแตะ Production ===');
  runNpm(['run', 'release:check']);

  if (!resources.databaseWasCreated) {
    console.log('\nฐาน D1 นี้มีอยู่ก่อนแล้ว — สำรองข้อมูลก่อน migration ...');
    runNpm(['run', 'd1:backup']);
  }

  console.log('\nเป้าหมาย Production:');
  console.log(`Pages: ${resources.projectName}`);
  console.log(`D1:    ${resources.databaseName}`);
  const productionConfirm = await rl.question('พิมพ์ DEPLOY เพื่อยืนยัน migration + deploy Production: ');
  if (productionConfirm.trim() !== 'DEPLOY') {
    console.log('ยกเลิกก่อนแก้ Production');
    return;
  }

  runNpm(['run', 'd1:migrate:remote']);
  runNpm(['run', 'deploy:pages']);
  const projectUrls = readProjectUrls(resources.projectName);
  console.log('\nDeploy สำเร็จ');
  if (projectUrls.length > 0) {
    console.log('URL จริงจาก Cloudflare:');
    projectUrls.forEach((url) => console.log(`- ${url}`));
  } else {
    console.log('ไม่สามารถอ่าน URL จาก Cloudflare ได้อัตโนมัติ — เปิด Workers & Pages > Project > Deployments เพื่อดู URL จริง');
  }
}

export async function main(argv = process.argv.slice(2)) {
  ensureNode22();
  if (!existsSync(WRANGLER_CONFIG) && !existsSync(WRANGLER_TEMPLATE)) {
    throw new Error('wrangler.template.jsonc not found. Re-extract the customer package and run setup again.');
  }
  console.log(`\nDorm Management Cloudflare Setup V14 — ${packageLabel()}`);
  const bootstrapState = prepareWranglerForLogin();
  if (bootstrapState === 'removed-placeholder') {
    console.log('ตรวจพบ wrangler.jsonc แบบ placeholder จากรุ่นเก่า — ย้ายออกจากทางก่อน Cloudflare login แล้ว');
  }
  ensureDependencies();

  const rl = readline.createInterface({ input, output });
  try {
    await chooseCloudflareAccount(rl);
    const resources = await configureResources(rl);
    await maybeDeploy(rl, resources, argv.includes('--deploy'));
  } finally {
    rl.close();
  }
}

const invokedAsMain = process.argv[1] && resolve(process.argv[1]) === resolve(SCRIPT_PATH);
if (invokedAsMain) {
  main().catch((error) => {
    console.error(`\nSETUP FAILED: ${error instanceof Error ? error.message : String(error)}`);
    process.exitCode = 1;
  });
}
