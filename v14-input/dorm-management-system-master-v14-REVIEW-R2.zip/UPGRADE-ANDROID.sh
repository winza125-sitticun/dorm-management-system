#!/data/data/com.termux/files/usr/bin/bash
set -u
cd "$(dirname "$0")" || exit 1

echo "============================================================"
echo " Dorm Management System - Package Upgrade Manager V14"
echo "============================================================"

echo "Node:"
node -v || { echo "[ERROR] Node.js 22+ required"; exit 1; }
echo "npm:"
npm -v || { echo "[ERROR] npm not found"; exit 1; }

echo
echo "Starting Package Upgrade Manager..."
npm run upgrade:package
code=$?
if [ "$code" -ne 0 ]; then
  echo
  echo "[ERROR] Upgrade stopped with exit code $code"
fi
exit "$code"
