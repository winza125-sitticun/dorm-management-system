@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title Dorm Management System - Cloudflare Setup
echo.
echo ==========================================
echo  Dorm Management System - Cloudflare Setup
echo ==========================================
echo.
where node >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Node.js was not found.
  echo Install Node.js 22 or newer, then run this file again.
  echo.
  pause
  exit /b 1
)
where npm >nul 2>&1
if errorlevel 1 (
  echo [ERROR] npm was not found. Reinstall Node.js 22 or newer.
  echo.
  pause
  exit /b 1
)
echo Node:
node -v
echo npm:
call npm -v
echo.
echo Starting Cloudflare setup...
echo.
call npm run setup:cloudflare
set "EXITCODE=%ERRORLEVEL%"
echo.
if not "%EXITCODE%"=="0" (
  echo [ERROR] Setup stopped with exit code %EXITCODE%.
  echo Take a screenshot of the error above and send it for troubleshooting.
) else (
  echo [OK] Setup command finished.
)
echo.
pause
exit /b %EXITCODE%
