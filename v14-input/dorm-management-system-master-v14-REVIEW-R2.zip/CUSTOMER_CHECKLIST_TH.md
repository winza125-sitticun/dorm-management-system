# Customer Delivery Checklist — V14

## ก่อน Setup

- [ ] ใช้ ZIP ของแพ็กเกจที่ถูกต้อง
- [ ] แตก ZIP ลงโฟลเดอร์ใหม่
- [ ] Node.js 22+ และ npm ใช้งานได้
- [ ] ไม่มี Secret จริงอยู่ใน source / `.env` / `.dev.vars` ที่จะส่งต่อ

## Cloudflare

- [ ] Login บัญชีลูกค้าที่ถูกต้อง
- [ ] Pages Project ถูกต้อง
- [ ] D1 Database ถูกต้อง
- [ ] `wrangler.jsonc` ไม่มี placeholder
- [ ] binding D1 ชื่อ `DB`
- [ ] `JWT_SECRET` มีอยู่ใน Pages Project

## Backup ก่อน Production / Upgrade ใหญ่

- [ ] Owner ดาวน์โหลด Application Backup `.dormbackup` จากหน้า Settings > Backup/Restore
- [ ] รัน `npm run d1:backup` เพื่อเก็บ **D1 raw export** แยกอีกชั้น
- [ ] เก็บไฟล์ Backup ไว้นอกโฟลเดอร์โปรเจกต์และตรวจว่าเปิดอ่าน/คัดลอกได้
- [ ] เข้าใจว่า `.dormbackup` ไม่ใช่ตัวแทนของ D1 raw export หรือ Cloudflare D1 Time Travel

Application Backup `.dormbackup` สำรองเฉพาะข้อมูลธุรกิจที่ระบบอนุญาต โดย **users/password not restored**, **LINE/Google credentials not restored**, ไม่ย้อน audit history และไม่ย้อน subscription/สิทธิ์การใช้งาน

## ก่อน Production

- [ ] `npm ci` สำเร็จ
- [ ] `npm run release:check` สำเร็จ
- [ ] `npm run build:pages` สำเร็จ
- [ ] ถ้าใช้ฐานเดิม มีไฟล์ Backup D1
- [ ] migrations ผ่าน
- [ ] Deploy ผ่าน
- [ ] เปิด URL จริงที่ Cloudflare แสดงได้

## Smoke Test หลัง Deploy

- [ ] `/api/health` ตอบกลับ
- [ ] Setup owner ครั้งแรก / Login ทำงาน
- [ ] เพิ่มห้องตาม limit แพ็กเกจ
- [ ] บันทึกมิเตอร์และออกบิลได้
- [ ] บิลบนมือถือคง layout แบบคอม
- [ ] JPG / Print / PDF ทำงาน
- [ ] ฟีเจอร์ที่ไม่อยู่ในแพ็กเกจถูกล็อกทั้ง UI และ API
- [ ] Owner ดาวน์โหลด `.dormbackup` ได้
- [ ] Demo ไม่สามารถ Restore ได้; Basic / Standard / Pro จึงเปิด Restore ตาม Plan Entitlement

## ก่อน Restore

- [ ] ตรวจ Preview จำนวนข้อมูลปัจจุบันเทียบกับ Backup แล้ว
- [ ] อ่าน warnings ทั้งหมด
- [ ] ระบบดาวน์โหลด **pre-restore** `.dormbackup` สำเร็จก่อนกดเขียนข้อมูลจริง
- [ ] ยืนยันว่ามี D1 raw export ล่าสุดสำหรับกรณีฉุกเฉินที่รุนแรงกว่า Application Restore

## ถ้า Restore ล้ม

- [ ] หยุดแก้ไข/เพิ่มข้อมูลต่อทันที
- [ ] เก็บข้อความ error และ `preRestoreDataSha256`
- [ ] ใช้ไฟล์ **pre-restore** เป็นตัวเลือกแรกเมื่อ Application Backup ยังใช้งานได้
- [ ] ถ้าฐานเสียหายกว้างหรือ Application Restore ใช้ไม่ได้ ให้ใช้ **D1 raw export** หรือ **Cloudflare D1 Time Travel** ตามระดับเหตุการณ์
- [ ] ตรวจ Login, จำนวนข้อมูล, LINE/Google และ subscription state หลัง Recovery ทุกครั้ง

## Upgrade

- [ ] ใช้ Pages Project เดิม
- [ ] ใช้ D1 Database เดิม
- [ ] Backup ก่อน Upgrade ทั้ง `.dormbackup` และ `npm run d1:backup`
- [ ] Upgrade เฉพาะแพ็กเกจที่สูงกว่า
