import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { eq, and, asc, desc, inArray, isNull, or, sql } from "drizzle-orm";
import { db, withRetry } from "./src/db/index.ts";
import { rooms, bills, settings, users, maintenanceTickets, leaseContracts, announcements, notes, auditLogs, recurringChargeTemplates, roomRecurringCharges, billChargeItems, housekeepingTasks } from "./src/db/schema.ts";
import { requireAuth, AuthRequest } from "./src/middleware/auth.ts";
import { verifyPassword, hashPassword, validatePasswordPolicy } from "./src/server/services/crypto.service.ts";
import {
  NOTE_LIST_MAX_LIMIT,
  NOTE_REQUEST_MAX_BYTES,
  NoteCreateSchema,
  NoteUpdateSchema,
  SettingsSchema,
  getNoteValidationDetails,
} from "./src/server/validators/index.ts";
import { RateLimiterService } from "./src/server/services/rateLimiter.service.ts";
import { generateToken, verifyToken } from "./src/server/services/jwt.service.ts";
import { APP_VERSION } from "./src/generated/version.ts";
import { PERMISSIONS, hasAppPermission, permissionsForRole } from "./src/constants/permissions.ts";
import { hasPlanFeature, normalizeSubscriptionPlan, type PlanFeature } from "./src/constants/planEntitlements.ts";
import { normalizeBillingMonths } from "./src/utils/recurringCharges.ts";
import { canTransitionHousekeeping } from "./src/utils/housekeeping.ts";

async function startServer() {
  const jwtSecret = process.env.JWT_SECRET;
  if (!jwtSecret || jwtSecret.length < 32) {
    throw new Error("JWT_SECRET must be configured with at least 32 characters before starting the server");
  }
  const app = express();
  const PORT = parseInt(process.env.PORT || '3000', 10);

  // Security Headers Middleware
  app.use((req, res, next) => {
    res.setHeader("X-Frame-Options", "DENY");
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-XSS-Protection", "1; mode=block");
    res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    next();
  });

  // Rate Limiting Security Middleware
  app.use("/api/", async (req, res, next) => {
    const clientIp = req.ip || req.socket.remoteAddress || "127.0.0.1";
    const isAuth = req.path.includes("/auth/") || req.path.includes("/setup/");
    const isNotes = req.path === '/notes' || req.path.startsWith('/notes/');
    const category = isAuth
      ? 'auth'
      : req.path.includes('/upload')
        ? 'upload'
        : isNotes
          ? (req.method === 'GET' ? 'notes_read' : 'notes_write')
          : 'api';
    
    const limitCheck = await RateLimiterService.checkRateLimit(null, clientIp, category);
    if (!limitCheck.allowed) {
      return res.status(429).json({
        success: false,
        error: {
          code: "TOO_MANY_REQUESTS",
          message: `คุณทำรายการถี่เกินไป กรุณารอ ${limitCheck.retryAfterSeconds} วินาทีก่อนลองใหม่อีกครั้ง`
        }
      });
    }
    next();
  });

  // Parse note bodies with a much smaller hard limit. This applies even to
  // chunked requests where Content-Length cannot be trusted.
  const notesJsonParser = express.json({ limit: NOTE_REQUEST_MAX_BYTES, strict: true });
  app.use('/api/notes', (req, res, next) => {
    if (!['POST', 'PUT', 'PATCH'].includes(req.method)) return next();
    if (!String(req.headers['content-type'] || '').toLowerCase().includes('application/json')) {
      return res.status(415).json({
        success: false,
        error: { code: 'UNSUPPORTED_MEDIA_TYPE', message: 'คำขอโน้ตต้องส่งเป็น application/json' },
      });
    }
    notesJsonParser(req, res, (error) => {
      if (!error) return next();
      const isTooLarge = error.type === 'entity.too.large' || error.status === 413;
      return res.status(isTooLarge ? 413 : 400).json({
        success: false,
        error: {
          code: isTooLarge ? 'PAYLOAD_TOO_LARGE' : 'INVALID_JSON',
          message: isTooLarge ? 'ข้อมูลโน้ตมีขนาดใหญ่เกินกำหนด' : 'รูปแบบ JSON ไม่ถูกต้อง',
        },
      });
    });
  });

  // JSON request body parser
  app.use(express.json());

  // Helper to resolve user ID for caretakers
  const staffRoles = ['caretaker', 'accountant', 'technician', 'housekeeper', 'staff'];
  const isStaffRole = (role?: string | null) => staffRoles.includes(String(role || ''));
  function getEffectiveUserId(dbUser: any) {
    if (isStaffRole(dbUser.role) && dbUser.parentId) {
      return dbUser.parentId;
    }
    return dbUser.id;
  }

  // Helper to check if user has permission
  function hasPermission(dbUser: any, permissionName: string) {
    return Boolean(dbUser) && hasAppPermission(dbUser.role, dbUser.permissions, permissionName as any);
  }

  async function getSubscriptionMetadata(ownerId: number) {
    const rows = await db.select({
      subscriptionPlan: settings.subscriptionPlan,
      subscriptionStatus: settings.subscriptionStatus,
      subscriptionExpiresAt: settings.subscriptionExpiresAt,
    }).from(settings).where(eq(settings.userId, ownerId)).limit(1);
    const row = rows[0];
    return {
      subscriptionPlan: normalizeSubscriptionPlan(row?.subscriptionPlan),
      subscriptionStatus: String(row?.subscriptionStatus || 'active'),
      subscriptionExpiresAt: row?.subscriptionExpiresAt || null,
    };
  }

  async function ownerHasPlanFeature(ownerId: number, feature: PlanFeature): Promise<boolean> {
    const { subscriptionPlan } = await getSubscriptionMetadata(ownerId);
    return hasPlanFeature(subscriptionPlan, feature);
  }

  const planRequiredResponse = (res: express.Response, message: string) => res.status(403).json({
    success: false,
    error: { code: 'PLAN_REQUIRED', message },
  });

  async function logNoteAudit(req: AuthRequest, action: string, noteId: number, value: Record<string, unknown> | null) {
    try {
      await db.insert(auditLogs).values({
        userId: req.dbUser ? getEffectiveUserId(req.dbUser) : null,
        userEmail: req.dbUser?.email || 'system',
        userRole: req.dbUser?.role || 'owner',
        action,
        targetType: 'note',
        targetId: String(noteId),
        newValue: value ? JSON.stringify(value) : null,
        ipAddress: String(req.ip || req.socket.remoteAddress || '127.0.0.1').slice(0, 64),
        userAgent: String(req.get('user-agent') || 'Unknown').slice(0, 500),
      });
    } catch (error) {
      console.warn('Note audit log warning:', error);
    }
  }

  async function logOperationalAudit(req: AuthRequest, action: string, targetType: string, targetId: number | string | null, value?: Record<string, unknown> | null) {
    try {
      await db.insert(auditLogs).values({
        userId: req.dbUser ? getEffectiveUserId(req.dbUser) : null,
        userEmail: req.dbUser?.email || 'system', userRole: req.dbUser?.role || 'owner',
        action, targetType, targetId: targetId === null ? null : String(targetId),
        newValue: value ? JSON.stringify(value) : null,
        ipAddress: String(req.ip || req.socket.remoteAddress || '127.0.0.1').slice(0, 64),
        userAgent: String(req.get('user-agent') || 'Unknown').slice(0, 500),
      });
    } catch (error) { console.warn('Operational audit warning:', error); }
  }

  // Helper to normalize room numbers/names for robust matching (e.g. "ห้องแรก" -> "1", "ห้อง 1 ล่าง" -> "1ล่าง")
  function normalizeRoomName(name: string): string {
    if (!name) return "";
    let clean = name.toString().trim().toLowerCase()
      .replace(/^ห้อง\s*/, "") // remove leading "ห้อง" or "ห้อง "
      .replace(/\s+/g, "");    // remove all spaces
    
    const thaiNumberMap: Record<string, string> = {
      "แรก": "1",
      "หนึ่ง": "1",
      "สอง": "2",
      "สาม": "3",
      "สี่": "4",
      "ห้า": "5",
      "หก": "6",
      "เจ็ด": "7",
      "แปด": "8",
      "เก้า": "9",
      "สิบ": "10"
    };

    for (const [thaiWord, digit] of Object.entries(thaiNumberMap)) {
      if (clean === thaiWord) {
        clean = digit;
      } else {
        clean = clean.replace(new RegExp(thaiWord, 'g'), digit);
      }
    }
    
    return clean;
  }

  // API Route: Health check
  app.get("/api/health", (req, res) => {
    res.json({ success: true, data: { status: "ok", mode: "node-vps", version: APP_VERSION } });
  });

  // First Setup Wizard Status Check
  app.get("/api/setup/status", async (req, res) => {
    try {
      let isSetupRequired = false;
      try {
        const allUsers = await db.select().from(users);
        isSetupRequired = allUsers.length === 0;
      } catch {
        isSetupRequired = false;
      }
      res.json({ success: true, data: { isSetupRequired } });
    } catch {
      res.json({ success: true, data: { isSetupRequired: false } });
    }
  });

  // First Setup Initialization
  app.post("/api/setup/init", async (req, res) => {
    try {
      const allUsers = await db.select().from(users);
      if (allUsers.length > 0) {
        return res.status(403).json({
          success: false,
          error: { code: "FORBIDDEN", message: "ระบบได้รับการตั้งค่าบัญชีผู้ดูแลระบบหลักไปแล้ว" }
        });
      }

      const { email, password, displayName, dormName } = req.body || {};
      if (!email || !password || password.length < 8) {
        return res.status(400).json({
          success: false,
          error: { code: "VALIDATION_ERROR", message: "กรุณาระบุอีเมลและรหัสผ่านอย่างน้อย 8 ตัวอักษร" }
        });
      }

      const hashedPassword = await hashPassword(password);
      const cleanUid = email.trim().toLowerCase();

      const newUser = await db.insert(users).values({
        uid: cleanUid,
        email: email.trim(),
        role: "super_admin",
        password: hashedPassword,
        permissions: "manage_rooms,manage_bills,edit_payments,manage_settings"
      }).returning();

      await db.insert(settings).values({
        userId: newUser[0].id,
        dormName: dormName?.trim() || "หอพักของฉัน"
      });

      const tokenPayload = {
        id: newUser[0].id,
        uid: cleanUid,
        email: email.trim(),
        role: "super_admin"
      };
      const token = await generateToken(tokenPayload, jwtSecret);

      res.status(201).json({
        success: true,
        data: {
          user: {
            id: newUser[0].id,
            uid: cleanUid,
            email: email.trim(),
            role: "super_admin",
            displayName: displayName || "Super Admin"
          },
          token
        },
        message: "ตั้งค่าระบบและสร้างบัญชีผู้ดูแลระบบสำเร็จแล้วค่ะ!"
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: { code: "DATABASE_ERROR", message: "เกิดข้อผิดพลาดในการตั้งค่าระบบ: " + error.message }
      });
    }
  });

  // Ensure table maintenance_tickets & lease_contracts exist
  try {
    await (db as any).execute(`
      CREATE TABLE IF NOT EXISTS maintenance_tickets (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE NOT NULL,
        room_id INTEGER REFERENCES rooms(id) ON DELETE CASCADE NOT NULL,
        room_number TEXT NOT NULL,
        tenant_name TEXT,
        tenant_phone TEXT,
        title TEXT NOT NULL,
        description TEXT,
        category TEXT DEFAULT 'other' NOT NULL,
        priority TEXT DEFAULT 'medium' NOT NULL,
        status TEXT DEFAULT 'pending' NOT NULL,
        image_url TEXT,
        repair_cost INTEGER DEFAULT 0 NOT NULL,
        technician_note TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS lease_contracts (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE NOT NULL,
        room_id INTEGER REFERENCES rooms(id) ON DELETE CASCADE NOT NULL,
        room_number TEXT NOT NULL,
        tenant_name TEXT NOT NULL,
        tenant_phone TEXT,
        id_card_number TEXT,
        start_date TEXT NOT NULL,
        end_date TEXT NOT NULL,
        monthly_rent INTEGER DEFAULT 0 NOT NULL,
        deposit_amount INTEGER DEFAULT 0 NOT NULL,
        advance_rent_amount INTEGER DEFAULT 0 NOT NULL,
        contract_document_url TEXT,
        status TEXT DEFAULT 'active' NOT NULL,
        note TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS announcements (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE NOT NULL,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        category TEXT DEFAULT 'general' NOT NULL,
        is_pinned INTEGER DEFAULT 0 NOT NULL,
        target_room_ids TEXT,
        image_url TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS notes (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE NOT NULL,
        created_by INTEGER REFERENCES users(id) NOT NULL,
        room_id INTEGER REFERENCES rooms(id) ON DELETE SET NULL,
        title TEXT NOT NULL CHECK(char_length(title) BETWEEN 1 AND 120),
        content TEXT NOT NULL CHECK(char_length(content) BETWEEN 1 AND 5000),
        color TEXT DEFAULT 'yellow' NOT NULL CHECK(color IN ('yellow', 'green', 'blue', 'pink', 'purple', 'gray')),
        is_pinned INTEGER DEFAULT 0 NOT NULL CHECK(is_pinned IN (0, 1)),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        deleted_at TIMESTAMP,
        deleted_by INTEGER
      );

      CREATE INDEX IF NOT EXISTS idx_notes_user_active_updated
        ON notes(user_id, deleted_at, is_pinned, updated_at DESC);
      CREATE INDEX IF NOT EXISTS idx_notes_room_id ON notes(room_id);
    `);
  } catch (err) {
    console.log("Notice: DB table initialization check:", err);
  }

  // POST local credentials login for Admin and Caretakers
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body || {};
      if (!username || !password) {
        return res.status(400).json({ error: "กรุณากรอกชื่อผู้ใช้และรหัสผ่าน" });
      }

      const cleanUser = String(username).trim().toLowerCase();
      const cleanPass = String(password).trim();

      // SECURITY: Resolve users solely from the database. No hardcoded admin
      // fallback and no master/default passwords — every login is verified
      // strictly against the stored password hash.
      let allUsers: any[] = [];
      try {
        allUsers = await db.select().from(users).where(isNull(users.deletedAt));
      } catch (e) {
        console.error("DB query error during login:", e);
        return res.status(500).json({ error: "เกิดข้อผิดพลาดในการเข้าสู่ระบบ" });
      }

      const userObj = allUsers.find(u => {
        const uEmail = (u.email || "").trim().toLowerCase();
        const uUid = (u.uid || "").trim().toLowerCase();
        return uEmail === cleanUser ||
               uEmail.split('@')[0] === cleanUser ||
               uUid === cleanUser;
      });

      if (!userObj) {
        return res.status(401).json({ error: "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง" });
      }

      // SECURITY: Always verify the submitted password against the stored hash.
      const isCorrect = await verifyPassword(cleanPass, userObj.password);

      if (!isCorrect) {
        return res.status(401).json({ error: "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง" });
      }

      const tokenPayload = {
        id: userObj.id,
        uid: userObj.uid,
        email: userObj.email,
        role: userObj.role
      };
      const token = await generateToken(tokenPayload, jwtSecret);

      return res.json({
        user: {
          uid: userObj.uid,
          email: userObj.email,
          displayName: userObj.role === 'owner' ? "เจ้าของหอพัก" : "ผู้ดูแลหอพัก",
        },
        token
      });
    } catch (error: any) {
      console.error("Local login failed:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการเข้าสู่ระบบ" });
    }
  });

  // PUT Change Local Password
  app.put("/api/auth/change-password", requireAuth, async (req: AuthRequest, res) => {
    try {
      const { currentPassword, newPassword } = req.body;
      if (!currentPassword || !newPassword) {
        return res.status(400).json({ error: "กรุณากรอกรหัสผ่านเดิมและรหัสผ่านใหม่" });
      }

      const userObj = req.dbUser!;
      
      // Verify current password (supports both plaintext legacy and PBKDF2 hashed).
      // Fail closed if an account has no stored password; never fall back to a default password.
      if (!userObj.password) {
        return res.status(401).json({ error: "ไม่สามารถตรวจสอบรหัสผ่านปัจจุบันได้ กรุณาติดต่อผู้ดูแลระบบ" });
      }
      const isPasswordCorrect = await verifyPassword(String(currentPassword).trim(), userObj.password);
      
      if (!isPasswordCorrect) {
        return res.status(400).json({ error: "รหัสผ่านปัจจุบันไม่ถูกต้อง" });
      }

      const passwordPolicy = validatePasswordPolicy(newPassword.trim());
      if (!passwordPolicy.isValid) {
        return res.status(400).json({ error: passwordPolicy.error });
      }

      // Store as PBKDF2 hash to match Cloudflare Pages production behavior
      const hashedPassword = await hashPassword(newPassword.trim());
      await db.update(users)
        .set({ password: hashedPassword })
        .where(eq(users.id, userObj.id));

      res.json({ success: true, message: "เปลี่ยนรหัสผ่านสำเร็จแล้ว" });
    } catch (error: any) {
      console.error("Failed to change password:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการเปลี่ยนรหัสผ่าน" });
    }
  });

  // --- API Endpoints with authentication ---

  // GET User Profile (to get role, parentId, etc)
  app.get("/api/profile", requireAuth, async (req: AuthRequest, res) => {
    const subscription = await getSubscriptionMetadata(getEffectiveUserId(req.dbUser!));
    res.json({ ...req.dbUser, ...subscription });
  });

  // Owner-only activity history. Caretakers must not see other staff members'
  // audit details even though they operate under the same effective owner ID.
  app.get("/api/audit-logs", requireAuth, async (req: AuthRequest, res) => {
    const currentUser = req.dbUser;
    if (!currentUser || isStaffRole(currentUser.role)) {
      return res.status(403).json({
        success: false,
        error: { code: 'FORBIDDEN', message: 'เฉพาะเจ้าของหอพักหรือผู้ดูแลระบบเท่านั้นที่ดูประวัติกิจกรรมได้' },
      });
    }

    try {
      const effectiveUserId = getEffectiveUserId(currentUser);
      const caretakerRows = await withRetry(() => db.select({ id: users.id })
        .from(users)
        .where(eq(users.parentId, effectiveUserId)));
      const visibleUserIds = [effectiveUserId, ...caretakerRows.map((row) => row.id)];
      const rows = await withRetry(() => db.select()
        .from(auditLogs)
        .where(visibleUserIds.length === 1
          ? eq(auditLogs.userId, effectiveUserId)
          : or(eq(auditLogs.userId, effectiveUserId), inArray(auditLogs.userId, visibleUserIds)))
        .orderBy(desc(auditLogs.id))
        .limit(100));
      return res.json({ success: true, data: rows });
    } catch (error) {
      console.error('Audit logs fetch error:', error);
      return res.status(500).json({
        success: false,
        error: { code: 'DATABASE_ERROR', message: 'ไม่สามารถโหลดประวัติกิจกรรมได้' },
      });
    }
  });

  // GET Caretakers (for owner, super_admin, and caretaker under owner scope)
  app.get("/api/caretakers", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (req.dbUser!.role !== 'owner' && req.dbUser!.role !== 'super_admin' && !isStaffRole(req.dbUser!.role)) {
        return res.status(403).json({ error: "Only owners, super admins, and caretakers can access caretakers." });
      }
      const ownerId = (isStaffRole(req.dbUser!.role) && req.dbUser!.parentId) ? req.dbUser!.parentId : req.dbUser!.id;
      const list = await db.select().from(users).where(and(inArray(users.role, staffRoles), eq(users.parentId, ownerId), isNull(users.deletedAt))).orderBy(desc(users.id));
      res.json(list);
    } catch (error: any) {
      console.error("Failed to fetch caretakers:", error);
      res.status(500).json({ error: "Failed to fetch caretakers." });
    }
  });

  // POST Create Caretaker (for owner and super_admin)
  app.post("/api/caretakers", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (req.dbUser!.role !== 'owner' && req.dbUser!.role !== 'super_admin') {
        return res.status(403).json({ error: "Only owners and admins can manage caretakers." });
      }
      const ownerId = req.dbUser!.id;
      const { email, password, permissions, role = 'caretaker' } = req.body;
      if (!staffRoles.includes(role)) return res.status(400).json({ error: 'Invalid staff role.' });
      if (!email) {
        return res.status(400).json({ error: "กรุณาระบุ Username / User ID หรืออีเมลผู้ดูแลร่วม" });
      }

      const cleanEmail = email.trim().toLowerCase();

      // Check if user is already an owner/another caretaker
      const existingOwnerList = await db.select().from(users).where(and(eq(users.email, cleanEmail), isNull(users.deletedAt)));
      if (existingOwnerList.length > 0) {
        const existingUser = existingOwnerList[0];
        if (existingUser.role === 'owner' || existingUser.role === 'super_admin') {
          return res.status(400).json({ error: "ชื่อผู้ใช้นี้ถูกลงทะเบียนเป็นเจ้าของหอพักแล้ว" });
        }
        if (isStaffRole(existingUser.role)) {
          return res.status(400).json({ error: "ชื่อผู้ใช้นี้ถูกใช้งานแล้วในระบบของคุณ" });
        }
      }

      // Create pre-registered caretaker with a temp UID
      const tempUid = `invited_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
      const customPassword = String(password || '').trim();
      const passwordPolicy = validatePasswordPolicy(customPassword);
      if (!passwordPolicy.isValid) {
        return res.status(400).json({ error: passwordPolicy.error });
      }
      const customPermissions = permissions ? permissions : permissionsForRole(role).join(',');

      // PBKDF2 Password Hashing
      const hashedPassword = await hashPassword(customPassword);

      const newCaretaker = await db.insert(users)
        .values({
          uid: tempUid,
          email: cleanEmail,
          role,
          parentId: ownerId,
          password: hashedPassword,
          permissions: customPermissions
        })
        .returning();

      await logOperationalAudit(req, 'CREATE_STAFF', 'user', newCaretaker[0].id, { email: cleanEmail, role, permissions: customPermissions });

      res.json(newCaretaker[0]);
    } catch (error: any) {
      console.error("Failed to add caretaker:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการเพิ่มผู้ดูแลร่วม" });
    }
  });

  // DELETE Caretaker (for owner and super_admin with ownership check & soft delete)
  app.delete("/api/caretakers/:id", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (req.dbUser!.role !== 'owner' && req.dbUser!.role !== 'super_admin') {
        return res.status(403).json({ error: "Only owners and admins can manage caretakers." });
      }
      const ownerId = req.dbUser!.id;
      const caretakerId = parseInt(req.params.id);

      // Verify this caretaker actually belongs to this owner and is not deleted
      const caretakerCheck = await db.select().from(users).where(and(eq(users.id, caretakerId), inArray(users.role, staffRoles), eq(users.parentId, ownerId), isNull(users.deletedAt)));
      if (caretakerCheck.length === 0) {
        return res.status(404).json({ error: "Caretaker not found." });
      }

      // Soft delete
      await db.update(users)
        .set({ deletedAt: new Date().toISOString(), deletedBy: req.dbUser!.id })
        .where(and(eq(users.id, caretakerId), eq(users.parentId, ownerId)));

      await logOperationalAudit(req, 'DELETE_STAFF', 'user', caretakerId, { role: caretakerCheck[0].role, permissions: caretakerCheck[0].permissions });

      res.json({ success: true, message: "Caretaker removed successfully." });
    } catch (error: any) {
      console.error("Failed to delete caretaker:", error);
      res.status(500).json({ error: "Failed to remove caretaker." });
    }
  });

  // PUT Update Caretaker permissions or password (for owner and super_admin with ownership check & PBKDF2 hashing)
  app.put("/api/caretakers/:id", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (req.dbUser!.role !== 'owner' && req.dbUser!.role !== 'super_admin') {
        return res.status(403).json({ error: "เฉพาะเจ้าของหอพักและผู้ดูแลระบบเท่านั้นที่สามารถจัดการผู้ดูแลได้" });
      }
      const ownerId = req.dbUser!.id;
      const caretakerId = parseInt(req.params.id);
      const { permissions, password, role } = req.body;
      if (role !== undefined && !staffRoles.includes(role)) return res.status(400).json({ error: 'Invalid staff role.' });

      // Verify this caretaker actually belongs to this owner and is not deleted
      const caretakerCheck = await db.select().from(users).where(and(eq(users.id, caretakerId), inArray(users.role, staffRoles), eq(users.parentId, ownerId), isNull(users.deletedAt)));
      if (caretakerCheck.length === 0) {
        return res.status(404).json({ error: "ไม่พบข้อมูลผู้ดูแลหอพักนี้" });
      }

      const updateData: any = {};
      if (permissions !== undefined) {
        updateData.permissions = permissions;
      }
      if (role !== undefined) updateData.role = role;
      if (password !== undefined && String(password).trim()) {
        const passwordPolicy = validatePasswordPolicy(String(password).trim());
        if (!passwordPolicy.isValid) {
          return res.status(400).json({ error: passwordPolicy.error });
        }
        updateData.password = await hashPassword(String(password).trim());
      }

      const updated = await db.update(users)
        .set(updateData)
        .where(and(eq(users.id, caretakerId), eq(users.parentId, ownerId)))
        .returning();

      await logOperationalAudit(req, 'UPDATE_STAFF_ACCESS', 'user', caretakerId, { oldRole: caretakerCheck[0].role, newRole: updated[0].role, oldPermissions: caretakerCheck[0].permissions, newPermissions: updated[0].permissions });

      res.json(updated[0]);
    } catch (error: any) {
      console.error("Failed to update caretaker:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการอัปเดตสิทธิ์ผู้ดูแล" });
    }
  });

  // GET User Settings
  app.get("/api/settings", requireAuth, async (req: AuthRequest, res) => {
    try {
      const userId = getEffectiveUserId(req.dbUser!);
      const result = await db.select().from(settings).where(eq(settings.userId, userId));
      
      if (result.length === 0) {
        // Return defaults if somehow settings doesn't exist yet
        return res.json({
          dormName: "หอพักของฉัน",
          defaultElecRate: 7,
          defaultWaterRate: 13,
          defaultDueDateDay: 5,
          defaultPenaltyRate: 100,
          promptpayId: "",
          promptpayName: "",
          googleSpreadsheetId: "",
          subscriptionPlan: "demo",
          subscriptionStatus: "active",
          subscriptionExpiresAt: null,
          fontScale: "medium"
        });
      }
      const row = result[0];
      const subscriptionPlan = normalizeSubscriptionPlan(row.subscriptionPlan);
      res.json({
        ...row,
        promptpayId: hasPlanFeature(subscriptionPlan, 'promptPay') ? row.promptpayId : '',
        promptpayName: hasPlanFeature(subscriptionPlan, 'promptPay') ? row.promptpayName : '',
        googleSpreadsheetId: hasPlanFeature(subscriptionPlan, 'googleSheets') ? row.googleSpreadsheetId : '',
        lineBotEnabled: hasPlanFeature(subscriptionPlan, 'lineIntegration') ? row.lineBotEnabled : 0,
        subscriptionPlan,
        subscriptionStatus: String(row.subscriptionStatus || 'active'),
        subscriptionExpiresAt: row.subscriptionExpiresAt || null,
        lineChannelAccessToken: null,
        lineChannelSecret: null,
        lineTokenConfigured: hasPlanFeature(subscriptionPlan, 'lineIntegration') && !!row.lineChannelAccessToken,
        lineSecretConfigured: hasPlanFeature(subscriptionPlan, 'lineIntegration') && !!row.lineChannelSecret,
      });
    } catch (error: any) {
      console.error("Failed to fetch settings:", error);
      res.status(500).json({ error: "Failed to fetch settings." });
    }
  });

  // PUT User Settings
  app.put("/api/settings", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (isStaffRole(req.dbUser!.role) && !hasPermission(req.dbUser!, 'manage_settings')) {
        return res.status(403).json({ error: "คุณไม่มีสิทธิ์แก้ไขการตั้งค่าระบบ" });
      }
      const userId = getEffectiveUserId(req.dbUser!);
      const parsedSettings = SettingsSchema.safeParse(req.body);
      if (!parsedSettings.success) {
        return res.status(400).json({ error: parsedSettings.error.issues[0]?.message || "ข้อมูลการตั้งค่าไม่ถูกต้อง" });
      }
      const { 
        dormName, 
        defaultElecRate, 
        defaultWaterRate, 
        defaultDueDateDay, 
        defaultPenaltyRate,
        promptpayId, 
        promptpayName,
        lineChannelAccessToken,
        lineChannelSecret,
        lineBotEnabled,
        googleSpreadsheetId,
        fontScale
      } = parsedSettings.data;

      const existingList = await db.select().from(settings).where(eq(settings.userId, userId));
      const existing = existingList.length > 0 ? existingList[0] : null;
      const isSettingsAdmin = req.dbUser!.role === 'owner' || req.dbUser!.role === 'super_admin';
      const existingFontScale = existing?.fontScale || 'medium';
      if (!isSettingsAdmin && fontScale !== undefined && fontScale !== existingFontScale) {
        return res.status(403).json({ error: "เฉพาะ Admin หรือเจ้าของหอพักเท่านั้นที่ปรับขนาดตัวอักษรได้" });
      }
      const fontScaleToSave = isSettingsAdmin ? (fontScale || existingFontScale) : existingFontScale;

      let tokenToSave = lineChannelAccessToken;
      if (tokenToSave === '********' || tokenToSave === undefined) {
        tokenToSave = existing ? existing.lineChannelAccessToken : "";
      } else if (tokenToSave === null) {
        tokenToSave = "";
      }

      let secretToSave = lineChannelSecret;
      if (secretToSave === '********' || secretToSave === undefined) {
        secretToSave = existing ? existing.lineChannelSecret : "";
      } else if (secretToSave === null) {
        secretToSave = "";
      }

      const botEnabledVal = lineBotEnabled === 1 ? 1 : 0;
      if (botEnabledVal && (!tokenToSave || !secretToSave)) {
        return res.status(400).json({ error: "ต้องตั้งค่า LINE Channel Access Token และ Channel Secret ก่อนเปิดใช้งานบอท" });
      }

      const result = await db.insert(settings)
        .values({
          userId,
          dormName: dormName || "หอพักของฉัน",
          defaultElecRate,
          defaultWaterRate,
          defaultDueDateDay,
          defaultPenaltyRate,
          promptpayId: promptpayId || "",
          promptpayName: promptpayName || "",
          lineChannelAccessToken: tokenToSave || "",
          lineChannelSecret: secretToSave || "",
          lineBotEnabled: botEnabledVal,
          googleSpreadsheetId: googleSpreadsheetId || "",
          fontScale: fontScaleToSave,
          updatedAt: new Date().toISOString()
        })
        .onConflictDoUpdate({
          target: settings.userId,
          set: {
            dormName: dormName || "หอพักของฉัน",
            defaultElecRate,
            defaultWaterRate,
            defaultDueDateDay,
            defaultPenaltyRate,
            promptpayId: promptpayId || "",
            promptpayName: promptpayName || "",
            lineChannelAccessToken: tokenToSave || "",
            lineChannelSecret: secretToSave || "",
            lineBotEnabled: botEnabledVal,
            googleSpreadsheetId: googleSpreadsheetId || "",
            fontScale: fontScaleToSave,
            updatedAt: new Date().toISOString()
          }
        })
        .returning();

      const row = result[0];
      const subscriptionPlan = normalizeSubscriptionPlan(row.subscriptionPlan);
      res.json({
        ...row,
        promptpayId: hasPlanFeature(subscriptionPlan, 'promptPay') ? row.promptpayId : '',
        promptpayName: hasPlanFeature(subscriptionPlan, 'promptPay') ? row.promptpayName : '',
        googleSpreadsheetId: hasPlanFeature(subscriptionPlan, 'googleSheets') ? row.googleSpreadsheetId : '',
        lineBotEnabled: hasPlanFeature(subscriptionPlan, 'lineIntegration') ? row.lineBotEnabled : 0,
        subscriptionPlan,
        subscriptionStatus: String(row.subscriptionStatus || 'active'),
        subscriptionExpiresAt: row.subscriptionExpiresAt || null,
        lineChannelAccessToken: null,
        lineChannelSecret: null,
        lineTokenConfigured: hasPlanFeature(subscriptionPlan, 'lineIntegration') && !!row.lineChannelAccessToken,
        lineSecretConfigured: hasPlanFeature(subscriptionPlan, 'lineIntegration') && !!row.lineChannelSecret,
      });
    } catch (error: any) {
      console.error("Failed to update settings:", error);
      res.status(500).json({ error: "Failed to update settings." });
    }
  });

  const mapTemplate = (row: any) => ({
    ...row,
    billingMonths: (() => { try { return JSON.parse(row.billingMonths || '[]'); } catch { return []; } })(),
    isActive: row.isActive === 1 || row.isActive === true,
  });

  async function normalizeBillChargeItems(input: any, userId: number, roomId: number) {
    if (!Array.isArray(input)) return null;
    if (input.length > 50) throw new Error('รายการค่าบริการต้องไม่เกิน 50 รายการต่อบิล');
    const items = input.map((item: any, index: number) => ({ assignmentId: item.assignmentId ? Number(item.assignmentId) : null, label: String(item.label || '').trim(), amount: Math.max(0, Math.round(Number(item.amount) || 0)), kind: item.kind === 'recurring' ? 'recurring' : 'manual', sortOrder: index })).filter((item: any) => item.label && item.label.length <= 120 && item.amount <= 1_000_000);
    if (items.length !== input.length) throw new Error('รายการค่าบริการไม่ถูกต้อง');
    const assignmentIds = items.filter((item: any) => item.assignmentId).map((item: any) => item.assignmentId);
    if (assignmentIds.length) {
      const valid = await db.select({ id: roomRecurringCharges.id }).from(roomRecurringCharges).where(and(eq(roomRecurringCharges.userId, userId), eq(roomRecurringCharges.roomId, roomId), inArray(roomRecurringCharges.id, assignmentIds)));
      if (valid.length !== new Set(assignmentIds).size) throw new Error('มีค่าบริการที่ไม่ตรงกับห้องพัก');
    }
    return items;
  }

  app.get('/api/recurring-charges/templates', requireAuth, async (req: AuthRequest, res) => {
    if (!hasPermission(req.dbUser!, PERMISSIONS.VIEW_BILLS) && !hasPermission(req.dbUser!, PERMISSIONS.MANAGE_RECURRING_CHARGES)) return res.status(403).json({ error: 'ไม่มีสิทธิ์ดูค่าบริการประจำ' });
    const userId = getEffectiveUserId(req.dbUser!);
    const rows = await db.select().from(recurringChargeTemplates).where(and(eq(recurringChargeTemplates.userId, userId), isNull(recurringChargeTemplates.deletedAt))).orderBy(asc(recurringChargeTemplates.name));
    res.json({ success: true, data: rows.map(mapTemplate) });
  });

  app.post('/api/recurring-charges/templates', requireAuth, async (req: AuthRequest, res) => {
    if (!hasPermission(req.dbUser!, PERMISSIONS.MANAGE_RECURRING_CHARGES)) return res.status(403).json({ error: 'ไม่มีสิทธิ์จัดการค่าบริการประจำ' });
    try {
      const name = String(req.body.name || '').trim();
      const frequency = String(req.body.frequency || 'monthly') as any;
      if (!name || name.length > 120 || !['monthly', 'quarterly', 'yearly'].includes(frequency)) return res.status(400).json({ error: 'ข้อมูลแม่แบบไม่ถูกต้อง' });
      const months = normalizeBillingMonths(frequency, Array.isArray(req.body.billingMonths) ? req.body.billingMonths : []);
      const [created] = await db.insert(recurringChargeTemplates).values({ userId: getEffectiveUserId(req.dbUser!), name, description: String(req.body.description || '').trim() || null, defaultAmount: Math.max(0, Math.round(Number(req.body.defaultAmount) || 0)), frequency, billingMonths: JSON.stringify(months), isActive: req.body.isActive === false ? 0 : 1 }).returning();
      await logOperationalAudit(req, 'CREATE_RECURRING_TEMPLATE', 'recurring_charge_template', created.id, { name, frequency, months });
      res.status(201).json({ success: true, data: mapTemplate(created) });
    } catch (error) { res.status(400).json({ error: error instanceof Error ? error.message : 'ข้อมูลแม่แบบไม่ถูกต้อง' }); }
  });

  app.put('/api/recurring-charges/templates/:id', requireAuth, async (req: AuthRequest, res) => {
    if (!hasPermission(req.dbUser!, PERMISSIONS.MANAGE_RECURRING_CHARGES)) return res.status(403).json({ error: 'ไม่มีสิทธิ์จัดการค่าบริการประจำ' });
    try {
      const id = Number(req.params.id); const userId = getEffectiveUserId(req.dbUser!);
      const name = String(req.body.name || '').trim(); const frequency = String(req.body.frequency || 'monthly') as any;
      const months = normalizeBillingMonths(frequency, Array.isArray(req.body.billingMonths) ? req.body.billingMonths : []);
      const [updated] = await db.update(recurringChargeTemplates).set({ name, description: String(req.body.description || '').trim() || null, defaultAmount: Math.max(0, Math.round(Number(req.body.defaultAmount) || 0)), frequency, billingMonths: JSON.stringify(months), isActive: req.body.isActive === false ? 0 : 1, updatedAt: new Date().toISOString() }).where(and(eq(recurringChargeTemplates.id, id), eq(recurringChargeTemplates.userId, userId), isNull(recurringChargeTemplates.deletedAt))).returning();
      if (!updated) return res.status(404).json({ error: 'ไม่พบแม่แบบ' });
      await logOperationalAudit(req, 'UPDATE_RECURRING_TEMPLATE', 'recurring_charge_template', id, { name, frequency, months });
      res.json({ success: true, data: mapTemplate(updated) });
    } catch (error) { res.status(400).json({ error: error instanceof Error ? error.message : 'ข้อมูลแม่แบบไม่ถูกต้อง' }); }
  });

  app.delete('/api/recurring-charges/templates/:id', requireAuth, async (req: AuthRequest, res) => {
    if (!hasPermission(req.dbUser!, PERMISSIONS.MANAGE_RECURRING_CHARGES)) return res.status(403).json({ error: 'ไม่มีสิทธิ์จัดการค่าบริการประจำ' });
    const id = Number(req.params.id); const userId = getEffectiveUserId(req.dbUser!);
    await db.update(recurringChargeTemplates).set({ deletedAt: new Date().toISOString(), isActive: 0 }).where(and(eq(recurringChargeTemplates.id, id), eq(recurringChargeTemplates.userId, userId)));
    await db.update(roomRecurringCharges).set({ isEnabled: 0, updatedAt: new Date().toISOString() }).where(and(eq(roomRecurringCharges.templateId, id), eq(roomRecurringCharges.userId, userId)));
    await logOperationalAudit(req, 'DELETE_RECURRING_TEMPLATE', 'recurring_charge_template', id);
    res.json({ success: true, data: { id } });
  });

  app.get('/api/rooms/:id/recurring-charges', requireAuth, async (req: AuthRequest, res) => {
    if (!hasPermission(req.dbUser!, PERMISSIONS.VIEW_ROOMS)) return res.status(403).json({ error: 'ไม่มีสิทธิ์ดูข้อมูลห้องพัก' });
    const roomId = Number(req.params.id); const userId = getEffectiveUserId(req.dbUser!);
    const rows = await db.select({ assignment: roomRecurringCharges, template: recurringChargeTemplates }).from(roomRecurringCharges).innerJoin(recurringChargeTemplates, eq(roomRecurringCharges.templateId, recurringChargeTemplates.id)).where(and(eq(roomRecurringCharges.userId, userId), eq(roomRecurringCharges.roomId, roomId), isNull(recurringChargeTemplates.deletedAt)));
    res.json({ success: true, data: rows.map(({ assignment, template }) => ({ ...assignment, isEnabled: assignment.isEnabled === 1, template: mapTemplate(template) })) });
  });

  app.put('/api/rooms/:id/recurring-charges', requireAuth, async (req: AuthRequest, res) => {
    if (!hasPermission(req.dbUser!, PERMISSIONS.MANAGE_RECURRING_CHARGES) && !hasPermission(req.dbUser!, PERMISSIONS.MANAGE_ROOMS)) return res.status(403).json({ error: 'ไม่มีสิทธิ์ผูกค่าบริการกับห้อง' });
    const roomId = Number(req.params.id); const userId = getEffectiveUserId(req.dbUser!); const assignments = Array.isArray(req.body.assignments) ? req.body.assignments : [];
    const [room] = await db.select({ id: rooms.id }).from(rooms).where(and(eq(rooms.id, roomId), eq(rooms.userId, userId), isNull(rooms.deletedAt))).limit(1);
    if (!room) return res.status(404).json({ error: 'ไม่พบห้องพัก' });
    const templateIds = assignments.map((item: any) => Number(item.templateId)).filter(Number.isInteger);
    const valid = templateIds.length ? await db.select({ id: recurringChargeTemplates.id }).from(recurringChargeTemplates).where(and(eq(recurringChargeTemplates.userId, userId), inArray(recurringChargeTemplates.id, templateIds), isNull(recurringChargeTemplates.deletedAt))) : [];
    if (valid.length !== new Set(templateIds).size) return res.status(400).json({ error: 'มีแม่แบบที่ไม่อยู่ในหอพักนี้' });
    await db.delete(roomRecurringCharges).where(and(eq(roomRecurringCharges.userId, userId), eq(roomRecurringCharges.roomId, roomId)));
    if (assignments.length) await db.insert(roomRecurringCharges).values(assignments.map((item: any) => ({ userId, roomId, templateId: Number(item.templateId), amountOverride: item.amountOverride === null || item.amountOverride === '' ? null : Math.max(0, Math.round(Number(item.amountOverride) || 0)), isEnabled: item.isEnabled === false ? 0 : 1 })));
    await logOperationalAudit(req, 'UPDATE_ROOM_RECURRING_CHARGES', 'room', roomId, { assignments: assignments.length });
    res.json({ success: true, data: { roomId } });
  });

  app.get('/api/recurring-charges/due', requireAuth, async (req: AuthRequest, res) => {
    if (!hasPermission(req.dbUser!, PERMISSIONS.MANAGE_BILLS)) return res.status(403).json({ error: 'ไม่มีสิทธิ์ออกบิล' });
    const billMonth = String(req.query.billMonth || ''); const roomId = req.query.roomId ? Number(req.query.roomId) : null; const month = Number(billMonth.slice(5, 7)); const userId = getEffectiveUserId(req.dbUser!);
    if (!/^\d{4}-\d{2}$/.test(billMonth)) return res.status(400).json({ error: 'billMonth ต้องเป็น YYYY-MM' });
    const conditions: any[] = [eq(roomRecurringCharges.userId, userId), eq(roomRecurringCharges.isEnabled, 1), eq(recurringChargeTemplates.isActive, 1), isNull(recurringChargeTemplates.deletedAt)]; if (roomId) conditions.push(eq(roomRecurringCharges.roomId, roomId));
    const rows = await db.select({ assignment: roomRecurringCharges, template: recurringChargeTemplates }).from(roomRecurringCharges).innerJoin(recurringChargeTemplates, eq(roomRecurringCharges.templateId, recurringChargeTemplates.id)).where(and(...conditions));
    const due = rows.filter(({ template }) => template.frequency === 'monthly' || (() => { try { return JSON.parse(template.billingMonths).includes(month); } catch { return false; } })()).map(({ assignment, template }) => ({ roomId: assignment.roomId, assignmentId: assignment.id, label: template.name, amount: assignment.amountOverride ?? template.defaultAmount, kind: 'recurring' }));
    res.json({ success: true, data: due });
  });

  app.get('/api/housekeeping', requireAuth, async (req: AuthRequest, res) => {
    if (!hasPermission(req.dbUser!, PERMISSIONS.VIEW_HOUSEKEEPING)) return res.status(403).json({ error: 'ไม่มีสิทธิ์ดูงานแม่บ้าน' });
    const userId = getEffectiveUserId(req.dbUser!);
    const rows = await db.select({ task: housekeepingTasks, roomNumber: rooms.roomNumber, assignedUserEmail: users.email }).from(housekeepingTasks).innerJoin(rooms, eq(housekeepingTasks.roomId, rooms.id)).leftJoin(users, eq(housekeepingTasks.assignedUserId, users.id)).where(eq(housekeepingTasks.userId, userId)).orderBy(desc(housekeepingTasks.id));
    res.json({ success: true, data: rows.map((row) => ({ ...row.task, roomNumber: row.roomNumber, assignedUserEmail: row.assignedUserEmail })) });
  });

  app.post('/api/housekeeping', requireAuth, async (req: AuthRequest, res) => {
    if (!hasPermission(req.dbUser!, PERMISSIONS.MANAGE_HOUSEKEEPING)) return res.status(403).json({ error: 'ไม่มีสิทธิ์สร้างงานแม่บ้าน' });
    const userId = getEffectiveUserId(req.dbUser!); const roomId = Number(req.body.roomId);
    const [room] = await db.select({ id: rooms.id }).from(rooms).where(and(eq(rooms.id, roomId), eq(rooms.userId, userId), isNull(rooms.deletedAt))).limit(1); if (!room) return res.status(404).json({ error: 'ไม่พบห้องพัก' });
    const assignedUserId = req.body.assignedUserId ? Number(req.body.assignedUserId) : null;
    if (assignedUserId) { const [assigned] = await db.select({ id: users.id }).from(users).where(and(eq(users.id, assignedUserId), eq(users.parentId, userId), eq(users.role, 'housekeeper'), isNull(users.deletedAt))).limit(1); if (!assigned) return res.status(400).json({ error: 'ผู้รับผิดชอบต้องเป็นแม่บ้านในหอพักนี้' }); }
    const [created] = await db.insert(housekeepingTasks).values({ userId, roomId, assignedUserId, source: 'manual', status: 'pending', note: String(req.body.note || '').trim().slice(0, 2000) || null, createdBy: req.dbUser!.id }).returning();
    await logOperationalAudit(req, 'CREATE_HOUSEKEEPING_TASK', 'housekeeping', created.id, { roomId });
    res.status(201).json({ success: true, data: created });
  });

  app.put('/api/housekeeping/:id', requireAuth, async (req: AuthRequest, res) => {
    if (!hasPermission(req.dbUser!, PERMISSIONS.MANAGE_HOUSEKEEPING)) return res.status(403).json({ error: 'ไม่มีสิทธิ์แก้ไขงานแม่บ้าน' });
    const allowed = ['pending', 'in_progress', 'ready_for_inspection', 'completed', 'cancelled']; const status = String(req.body.status || ''); if (!allowed.includes(status)) return res.status(400).json({ error: 'สถานะไม่ถูกต้อง' });
    const id = Number(req.params.id); const userId = getEffectiveUserId(req.dbUser!);
    const [existingTask] = await db.select().from(housekeepingTasks).where(and(eq(housekeepingTasks.id, id), eq(housekeepingTasks.userId, userId))).limit(1); if (!existingTask) return res.status(404).json({ error: 'ไม่พบงานแม่บ้าน' });
    if (!canTransitionHousekeeping(existingTask.status, status)) return res.status(409).json({ error: 'ไม่สามารถเปลี่ยนสถานะงานตามลำดับนี้ได้' });
    if (req.body.assignedUserId) { const [assigned] = await db.select({ id: users.id }).from(users).where(and(eq(users.id, Number(req.body.assignedUserId)), eq(users.parentId, userId), eq(users.role, 'housekeeper'), isNull(users.deletedAt))).limit(1); if (!assigned) return res.status(400).json({ error: 'ผู้รับผิดชอบต้องเป็นแม่บ้านในหอพักนี้' }); }
    const [updated] = await db.update(housekeepingTasks).set({ status, assignedUserId: req.body.assignedUserId === undefined ? undefined : (req.body.assignedUserId ? Number(req.body.assignedUserId) : null), note: req.body.note === undefined ? undefined : String(req.body.note || '').trim() || null, inspectionNote: req.body.inspectionNote === undefined ? undefined : String(req.body.inspectionNote || '').trim() || null, updatedAt: new Date().toISOString(), completedAt: status === 'completed' ? new Date().toISOString() : null }).where(and(eq(housekeepingTasks.id, id), eq(housekeepingTasks.userId, userId))).returning();
    if (!updated) return res.status(404).json({ error: 'ไม่พบงานแม่บ้าน' }); await logOperationalAudit(req, 'UPDATE_HOUSEKEEPING_TASK', 'housekeeping', id, { status }); res.json({ success: true, data: updated });
  });

  // ----------------------------------------------------------------
  // GOOGLE SHEETS INTEGRATION ENDPOINTS
  // ----------------------------------------------------------------
  const googleOAuthStates = new Map<string, { userId: number; expiresAt: number }>();
  const googleOAuthTokens = new Map<number, { refreshToken: string; accessToken?: string; expiresAt?: number }>();

  // GET /api/google-sheets/status
  app.get("/api/google-sheets/status", requireAuth, async (req: AuthRequest, res) => {
    try {
      const ownerId = getEffectiveUserId(req.dbUser!);
      const tokenInfo = googleOAuthTokens.get(ownerId);
      const isConnected = !!(tokenInfo && tokenInfo.refreshToken);
      res.json({
        connected: isConnected,
        hasClientConfig: !!(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET)
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // POST /api/google-sheets/connect
  app.post("/api/google-sheets/connect", requireAuth, async (req: AuthRequest, res) => {
    try {
      const clientId = process.env.GOOGLE_CLIENT_ID || req.body?.clientId;
      const clientSecret = process.env.GOOGLE_CLIENT_SECRET || req.body?.clientSecret;
      
      if (!clientId || !clientSecret) {
        return res.status(400).json({
          error: {
            code: "GOOGLE_OAUTH_CONFIG",
            message: "กรุณาตั้งค่า GOOGLE_CLIENT_ID และ GOOGLE_CLIENT_SECRET ในไฟล์ .env หรือระบุข้อมูลในระบบก่อนเชื่อมต่อ"
          }
        });
      }

      const ownerId = getEffectiveUserId(req.dbUser!);
      const state = crypto.randomUUID();
      googleOAuthStates.set(state, { userId: ownerId, expiresAt: Date.now() + 600000 });

      const host = req.get('host') || 'localhost:3000';
      const protocol = req.protocol || 'http';
      const redirectUri = `${protocol}://${host}/api/google-sheets/callback`;

      const url = new URL('https://accounts.google.com/o/oauth2/v2/auth');
      url.search = new URLSearchParams({
        client_id: clientId,
        redirect_uri: redirectUri,
        response_type: 'code',
        access_type: 'offline',
        prompt: 'consent',
        scope: 'https://www.googleapis.com/auth/spreadsheets',
        state: state
      }).toString();

      res.json({ data: { authorizationUrl: url.toString() } });
    } catch (error: any) {
      res.status(500).json({ error: { message: error.message } });
    }
  });

  // GET /api/google-sheets/callback
  app.get("/api/google-sheets/callback", async (req, res) => {
    try {
      const state = req.query.state as string;
      const code = req.query.code as string;
      
      if (!state || !code) {
        return res.status(400).send("คำขอสิทธิ์จาก Google ไม่ถูกต้อง");
      }

      const stateInfo = googleOAuthStates.get(state);
      if (!stateInfo || stateInfo.expiresAt < Date.now()) {
        googleOAuthStates.delete(state);
        return res.status(400).send("การขอสิทธิ์ Google หมดอายุแล้ว กรุณาลองใหม่อีกครั้ง");
      }

      googleOAuthStates.delete(state);

      const clientId = process.env.GOOGLE_CLIENT_ID;
      const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
      
      if (!clientId || !clientSecret) {
        return res.status(400).send("ไม่พบข้อมูล GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET บนเซิร์ฟเวอร์");
      }

      const host = req.get('host') || 'localhost:3000';
      const protocol = req.protocol || 'http';
      const redirectUri = `${protocol}://${host}/api/google-sheets/callback`;

      const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          code,
          client_id: clientId,
          client_secret: clientSecret,
          redirect_uri: redirectUri,
          grant_type: 'authorization_code'
        })
      });

      const tokens: any = await tokenRes.json();
      if (!tokenRes.ok || !tokens.refresh_token) {
        return res.status(400).send(`Google ไม่ส่ง Refresh Token กลับมา (${tokens.error_description || 'อาจจะเคยอนุญาตสิทธิ์ไปแล้ว'}) กรุณาลองใหม่อีกครั้ง`);
      }

      googleOAuthTokens.set(stateInfo.userId, {
        refreshToken: tokens.refresh_token,
        accessToken: tokens.access_token,
        expiresAt: Date.now() + (tokens.expires_in || 3600) * 1000
      });

      return res.redirect('/?googleSheets=connected');
    } catch (error: any) {
      console.error("Google OAuth callback error:", error);
      res.status(500).send(`การเชื่อมต่อ Google Sheets ล้มเหลว: ${error.message}`);
    }
  });

  // GET /api/google-sheets/token
  app.get("/api/google-sheets/token", requireAuth, async (req: AuthRequest, res) => {
    try {
      const ownerId = getEffectiveUserId(req.dbUser!);
      const stored = googleOAuthTokens.get(ownerId);
      
      if (!stored || !stored.refreshToken) {
        return res.status(400).json({ error: { code: 'GOOGLE_NOT_CONNECTED', message: 'ยังไม่ได้เชื่อมต่อบัญชี Google Sheets' } });
      }

      if (stored.accessToken && stored.expiresAt && stored.expiresAt > Date.now() + 60000) {
        return res.json({ data: { accessToken: stored.accessToken } });
      }

      const clientId = process.env.GOOGLE_CLIENT_ID;
      const clientSecret = process.env.GOOGLE_CLIENT_SECRET;

      if (!clientId || !clientSecret) {
        return res.status(400).json({ error: { message: 'ไม่พบการตั้งค่า GOOGLE_CLIENT_ID/GOOGLE_CLIENT_SECRET' } });
      }

      const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          client_id: clientId,
          client_secret: clientSecret,
          refresh_token: stored.refreshToken,
          grant_type: 'refresh_token'
        })
      });

      const tokenData: any = await tokenRes.json();
      if (!tokenRes.ok) {
        return res.status(400).json({ error: { message: tokenData.error_description || 'ไม่สามารถรับ Access Token จาก Google ได้' } });
      }

      stored.accessToken = tokenData.access_token;
      stored.expiresAt = Date.now() + (tokenData.expires_in || 3600) * 1000;
      googleOAuthTokens.set(ownerId, stored);

      res.json({ data: { accessToken: tokenData.access_token } });
    } catch (error: any) {
      res.status(500).json({ error: { message: error.message } });
    }
  });

  // POST /api/google-sheets/disconnect
  app.post("/api/google-sheets/disconnect", requireAuth, async (req: AuthRequest, res) => {
    try {
      const ownerId = getEffectiveUserId(req.dbUser!);
      googleOAuthTokens.delete(ownerId);
      res.json({ success: true, message: "ยกเลิกการเชื่อมต่อ Google Sheets เรียบร้อยแล้ว" });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // GET Rooms
  app.get("/api/rooms", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (!hasPermission(req.dbUser!, PERMISSIONS.VIEW_ROOMS)) return res.status(403).json({ error: 'ไม่มีสิทธิ์ดูข้อมูลห้องพัก' });
      const userId = getEffectiveUserId(req.dbUser!);
      const allRooms = await db.select().from(rooms).where(and(eq(rooms.userId, userId), isNull(rooms.deletedAt))).orderBy(asc(rooms.roomNumber));
      res.json(allRooms);
    } catch (error: any) {
      console.error("Failed to fetch rooms:", error);
      res.status(500).json({ error: "Failed to fetch rooms." });
    }
  });

  // POST Create Room
  app.post("/api/rooms", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (isStaffRole(req.dbUser!.role) && !hasPermission(req.dbUser!, 'manage_rooms')) {
        return res.status(403).json({ error: "คุณไม่มีสิทธิ์จัดการหรือสร้างห้องพัก" });
      }
      const userId = getEffectiveUserId(req.dbUser!);
      const { roomNumber, monthlyRent, status, tenantName, tenantPhone, lineNotifyToken } = req.body;

      if (!roomNumber) {
        return res.status(400).json({ error: "Room number is required." });
      }

      const newRoom = await db.insert(rooms)
        .values({
          userId,
          roomNumber,
          monthlyRent: parseInt(monthlyRent) || 0,
          status: status || "vacant",
          tenantName: tenantName || "",
          tenantPhone: tenantPhone || "",
          lineNotifyToken: lineNotifyToken || null
        })
        .returning();

      res.json(newRoom[0]);
    } catch (error: any) {
      console.error("Failed to create room:", error);
      res.status(500).json({ error: "Failed to create room." });
    }
  });

  // PUT Update Room
  app.put("/api/rooms/:id", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (isStaffRole(req.dbUser!.role) && !hasPermission(req.dbUser!, 'manage_rooms')) {
        return res.status(403).json({ error: "คุณไม่มีสิทธิ์จัดการหรือแก้ไขห้องพัก" });
      }
      const userId = getEffectiveUserId(req.dbUser!);
      const roomId = parseInt(req.params.id);
      const { roomNumber, monthlyRent, status, tenantName, tenantPhone, lineNotifyToken } = req.body;

      if (!roomNumber) {
        return res.status(400).json({ error: "Room number is required." });
      }

      const updated = await db.update(rooms)
        .set({
          roomNumber,
          monthlyRent: parseInt(monthlyRent) || 0,
          status: status || "vacant",
          tenantName: status === "vacant" ? "" : (tenantName || ""),
          tenantPhone: status === "vacant" ? "" : (tenantPhone || ""),
          lineNotifyToken: status === "vacant" ? null : (lineNotifyToken || null)
        })
        .where(and(eq(rooms.id, roomId), eq(rooms.userId, userId)))
        .returning();

      if (updated.length === 0) {
        return res.status(404).json({ error: "Room not found or unauthorized." });
      }

      res.json(updated[0]);
    } catch (error: any) {
      console.error("Failed to update room:", error);
      res.status(500).json({ error: "Failed to update room." });
    }
  });

  // DELETE Room
  app.delete("/api/rooms/:id", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (isStaffRole(req.dbUser!.role) && !hasPermission(req.dbUser!, 'manage_rooms')) {
        return res.status(403).json({ error: "คุณไม่มีสิทธิ์ลบห้องพัก" });
      }
      const userId = getEffectiveUserId(req.dbUser!);
      const roomId = parseInt(req.params.id);

      const deleted = await db.delete(rooms)
        .where(and(eq(rooms.id, roomId), eq(rooms.userId, userId)))
        .returning();

      if (deleted.length === 0) {
        return res.status(404).json({ error: "Room not found or unauthorized." });
      }

      res.json({ success: true, message: "Room deleted successfully." });
    } catch (error: any) {
      console.error("Failed to delete room:", error);
      res.status(500).json({ error: "Failed to delete room." });
    }
  });

  // GET Bills
  app.get("/api/bills", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (!hasPermission(req.dbUser!, PERMISSIONS.VIEW_BILLS)) return res.status(403).json({ error: 'ไม่มีสิทธิ์ดูบิล' });
      const userId = getEffectiveUserId(req.dbUser!);
      const { roomId, month, status } = req.query;

      // Join bills with rooms to get the room number in response
      let queryResult = await db
        .select({
          id: bills.id,
          roomId: bills.roomId,
          roomNumber: rooms.roomNumber,
          billMonth: bills.billMonth,
          priorElec: bills.priorElec,
          currentElec: bills.currentElec,
          elecDeduct: bills.elecDeduct,
          elecUnitCost: bills.elecUnitCost,
          elecCost: bills.elecCost,
          priorWater: bills.priorWater,
          currentWater: bills.currentWater,
          waterUnitCost: bills.waterUnitCost,
          waterCost: bills.waterCost,
          rentCost: bills.rentCost,
          depositCost: bills.depositCost,
          otherCost: bills.otherCost,
          otherDescription: bills.otherDescription,
          totalCost: bills.totalCost,
          dueDate: bills.dueDate,
          status: bills.status,
          paidAt: bills.paidAt,
          createdAt: bills.createdAt,
          tenantName: rooms.tenantName,
          tenantPhone: rooms.tenantPhone,
        })
        .from(bills)
        .innerJoin(rooms, eq(bills.roomId, rooms.id))
        .where(and(eq(bills.userId, userId), isNull(bills.deletedAt), isNull(rooms.deletedAt)))
        .orderBy(desc(bills.billMonth), desc(rooms.roomNumber));

      // Filter in-memory for simpler query structure
      if (roomId) {
        queryResult = queryResult.filter(b => b.roomId === parseInt(roomId as string));
      }
      if (month) {
        queryResult = queryResult.filter(b => b.billMonth === (month as string));
      }
      if (status) {
        queryResult = queryResult.filter(b => b.status === (status as string));
      }

      const visibleBillIds = queryResult.map((bill) => bill.id);
      const chargeRows = visibleBillIds.length ? await db.select().from(billChargeItems).where(inArray(billChargeItems.billId, visibleBillIds)).orderBy(asc(billChargeItems.sortOrder), asc(billChargeItems.id)) : [];
      const chargesByBill = new Map<number, any[]>();
      chargeRows.forEach((item) => chargesByBill.set(item.billId, [...(chargesByBill.get(item.billId) || []), item]));
      res.json(queryResult.map((bill) => ({ ...bill, chargeItems: chargesByBill.get(bill.id) || [] })));
    } catch (error: any) {
      console.error("Failed to fetch bills:", error);
      res.status(500).json({ error: "Failed to fetch bills." });
    }
  });

  // POST Create Bill
  app.post("/api/bills", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (isStaffRole(req.dbUser!.role) && !hasPermission(req.dbUser!, 'manage_bills')) {
        return res.status(403).json({ error: "คุณไม่มีสิทธิ์สร้างบิลค่าเช่า" });
      }
      const userId = getEffectiveUserId(req.dbUser!);
      const {
        roomId,
        billMonth,
        priorElec,
        currentElec,
        elecDeduct,
        elecUnitCost,
        elecCost,
        priorWater,
        currentWater,
        waterUnitCost,
        waterCost,
        rentCost,
        depositCost,
        otherCost,
        otherDescription,
        dueDate,
        status,
        chargeItems: rawChargeItems
      } = req.body;

      if (!roomId || !billMonth || !dueDate) {
        return res.status(400).json({ error: "Room, month, and due date are required." });
      }

      // Check if room belongs to user
      const roomCheck = await db.select().from(rooms).where(and(eq(rooms.id, roomId), eq(rooms.userId, userId)));
      if (roomCheck.length === 0) {
        return res.status(404).json({ error: "Room not found." });
      }

      // Calculate totals
      let finalElecCost = 0;
      if (elecCost !== undefined && elecCost !== null && elecCost !== '') {
        finalElecCost = parseFloat(elecCost) || 0;
      } else {
        const elecUnits = Math.max(0, (parseFloat(currentElec) || 0) - (parseFloat(priorElec) || 0) - (parseFloat(elecDeduct) || 0));
        finalElecCost = Math.round(elecUnits * (parseFloat(elecUnitCost) || 7));
      }
      
      let finalWaterCost = 0;
      if (waterCost !== undefined) {
        finalWaterCost = parseFloat(waterCost) || 0;
      } else {
        const waterUnits = Math.max(0, (parseFloat(currentWater) || 0) - (parseFloat(priorWater) || 0));
        finalWaterCost = waterUnits > 0 ? Math.round(waterUnits * (parseFloat(waterUnitCost) || 13)) : 0;
      }

      const normalizedChargeItems = await normalizeBillChargeItems(rawChargeItems, userId, Number(roomId));
      const finalOtherCost = normalizedChargeItems ? normalizedChargeItems.reduce((sum: number, item: any) => sum + item.amount, 0) : (parseInt(otherCost) || 0);
      const finalOtherDescription = normalizedChargeItems ? normalizedChargeItems.map((item: any) => item.label).join(', ') : (otherDescription || '');
      const total = (parseInt(rentCost) || 0) + finalElecCost + finalWaterCost + (parseInt(depositCost) || 0) + finalOtherCost;

      const newBill = await db.insert(bills)
        .values({
          userId,
          roomId,
          billMonth,
          priorElec: parseFloat(priorElec) || 0,
          currentElec: parseFloat(currentElec) || 0,
          elecDeduct: parseFloat(elecDeduct) || 0,
          elecUnitCost: parseFloat(elecUnitCost) || 7,
          elecCost: finalElecCost,
          priorWater: parseFloat(priorWater) || 0,
          currentWater: parseFloat(currentWater) || 0,
          waterUnitCost: parseFloat(waterUnitCost) || 13,
          waterCost: finalWaterCost,
          rentCost: parseInt(rentCost) || 0,
          depositCost: parseInt(depositCost) || 0,
          otherCost: finalOtherCost,
          otherDescription: finalOtherDescription,
          totalCost: total,
          dueDate,
          status: status || "unpaid",
          paidAt: status === "paid" ? new Date().toISOString() : null
        })
        .returning();

      if (normalizedChargeItems?.length) await db.insert(billChargeItems).values(normalizedChargeItems.map((item: any) => ({ ...item, billId: newBill[0].id })));

      res.json({ ...newBill[0], chargeItems: normalizedChargeItems || [] });
    } catch (error: any) {
      console.error("Failed to create bill:", error);
      res.status(500).json({ error: "Failed to create bill." });
    }
  });

  // PUT Update Bill (including Recalculating)
  app.put("/api/bills/:id", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (!hasPermission(req.dbUser!, PERMISSIONS.MANAGE_BILLS) && !hasPermission(req.dbUser!, PERMISSIONS.EDIT_PAYMENTS)) return res.status(403).json({ error: 'ไม่มีสิทธิ์แก้ไขบิล' });
      const userId = getEffectiveUserId(req.dbUser!);
      const billId = parseInt(req.params.id);
      const {
        billMonth,
        priorElec,
        currentElec,
        elecDeduct,
        elecUnitCost,
        elecCost,
        priorWater,
        currentWater,
        waterUnitCost,
        waterCost,
        rentCost,
        depositCost,
        otherCost,
        otherDescription,
        dueDate,
        status,
        paidAt,
        chargeItems: rawChargeItems
      } = req.body;

      // Find the bill
      const billCheck = await db.select().from(bills).where(and(eq(bills.id, billId), eq(bills.userId, userId)));
      if (billCheck.length === 0) {
        return res.status(404).json({ error: "Bill not found." });
      }

      if (isStaffRole(req.dbUser!.role)) {
        const isStatusChangeOnly = Object.keys(req.body).every(k => k === 'status' || k === 'paidAt' || k === 'id');
        if (isStatusChangeOnly) {
          if (!hasPermission(req.dbUser!, 'edit_payments')) {
            return res.status(403).json({ error: "คุณไม่มีสิทธิ์บันทึกหรือแก้ไขสถานะการชำระเงิน" });
          }
        } else {
          // It modifies other details. Does caretaker have manage_bills permission?
          if (!hasPermission(req.dbUser!, 'manage_bills')) {
            return res.status(403).json({ error: "คุณไม่มีสิทธิ์แก้ไขข้อมูลบิลค่าเช่า" });
          }
          // Also if they are changing status as part of the details update, we need edit_payments too
          if (status !== undefined && status !== billCheck[0].status && !hasPermission(req.dbUser!, 'edit_payments')) {
            return res.status(403).json({ error: "คุณไม่มีสิทธิ์บันทึกหรือแก้ไขสถานะการชำระเงิน" });
          }
        }
      }

      // Calculate totals robustly
      const cElec = currentElec !== undefined ? (parseFloat(currentElec) || 0) : billCheck[0].currentElec;
      const pElec = priorElec !== undefined ? (parseFloat(priorElec) || 0) : billCheck[0].priorElec;
      const dElec = elecDeduct !== undefined ? (parseFloat(elecDeduct) || 0) : (billCheck[0].elecDeduct || 0);
      const elecUnits = Math.max(0, cElec - pElec - dElec);

      let finalElecCost = 0;
      if (elecCost !== undefined && elecCost !== null && elecCost !== '') {
        finalElecCost = parseFloat(elecCost) || 0;
      } else {
        if (currentElec !== undefined || priorElec !== undefined || elecDeduct !== undefined || elecUnitCost !== undefined) {
          const eRate = parseFloat(elecUnitCost !== undefined ? elecUnitCost : billCheck[0].elecUnitCost.toString()) || 7;
          finalElecCost = Math.round(elecUnits * eRate);
        } else {
          finalElecCost = billCheck[0].elecCost || Math.round(elecUnits * (billCheck[0].elecUnitCost || 7));
        }
      }
      
      const cWater = currentWater !== undefined ? (parseFloat(currentWater) || 0) : billCheck[0].currentWater;
      const pWater = priorWater !== undefined ? (parseFloat(priorWater) || 0) : billCheck[0].priorWater;
      const waterUnits = Math.max(0, cWater - pWater);
      
      let finalWaterCost = 0;
      if (waterCost !== undefined) {
        finalWaterCost = parseFloat(waterCost) || 0;
      } else {
        if (currentWater !== undefined || priorWater !== undefined || waterUnitCost !== undefined) {
          const wRate = parseFloat(waterUnitCost !== undefined ? waterUnitCost : billCheck[0].waterUnitCost.toString()) || 13;
          finalWaterCost = waterUnits > 0 ? Math.round(waterUnits * wRate) : 0;
        } else {
          finalWaterCost = billCheck[0].waterCost || 0;
        }
      }

      const rCost = rentCost !== undefined ? (parseInt(rentCost) || 0) : billCheck[0].rentCost;
      const dCost = depositCost !== undefined ? (parseInt(depositCost) || 0) : billCheck[0].depositCost;
      const normalizedChargeItems = rawChargeItems === undefined ? null : await normalizeBillChargeItems(rawChargeItems, userId, billCheck[0].roomId);
      const oCost = normalizedChargeItems ? normalizedChargeItems.reduce((sum: number, item: any) => sum + item.amount, 0) : (otherCost !== undefined ? (parseInt(otherCost) || 0) : billCheck[0].otherCost);

      const total = rCost + finalElecCost + finalWaterCost + dCost + oCost;

      // Determine paidAt value
      let updatedPaidAt = null;
      if (status === "paid") {
        updatedPaidAt = paidAt ? (typeof paidAt === 'string' ? paidAt : new Date(paidAt).toISOString()) : (billCheck[0].paidAt || new Date().toISOString());
      }

      const updated = await db.update(bills)
        .set({
          billMonth: billMonth || billCheck[0].billMonth,
          priorElec: priorElec !== undefined ? (parseFloat(priorElec) || 0) : billCheck[0].priorElec,
          currentElec: currentElec !== undefined ? (parseFloat(currentElec) || 0) : billCheck[0].currentElec,
          elecDeduct: elecDeduct !== undefined ? (parseFloat(elecDeduct) || 0) : (billCheck[0].elecDeduct || 0),
          elecUnitCost: elecUnitCost !== undefined ? (parseFloat(elecUnitCost) || 7) : billCheck[0].elecUnitCost,
          elecCost: finalElecCost,
          priorWater: priorWater !== undefined ? (parseFloat(priorWater) || 0) : billCheck[0].priorWater,
          currentWater: currentWater !== undefined ? (parseFloat(currentWater) || 0) : billCheck[0].currentWater,
          waterUnitCost: waterUnitCost !== undefined ? (parseFloat(waterUnitCost) || 13) : billCheck[0].waterUnitCost,
          waterCost: finalWaterCost,
          rentCost: rentCost !== undefined ? (parseInt(rentCost) || 0) : billCheck[0].rentCost,
          depositCost: depositCost !== undefined ? (parseInt(depositCost) || 0) : billCheck[0].depositCost,
          otherCost: oCost,
          otherDescription: normalizedChargeItems ? normalizedChargeItems.map((item: any) => item.label).join(', ') : (otherDescription !== undefined ? otherDescription : billCheck[0].otherDescription),
          totalCost: total,
          dueDate: dueDate || billCheck[0].dueDate,
          status: status || billCheck[0].status,
          paidAt: updatedPaidAt
        })
        .where(and(eq(bills.id, billId), eq(bills.userId, userId)))
        .returning();

      if (normalizedChargeItems) {
        await db.delete(billChargeItems).where(eq(billChargeItems.billId, billId));
        if (normalizedChargeItems.length) await db.insert(billChargeItems).values(normalizedChargeItems.map((item: any) => ({ ...item, billId })));
      }

      res.json({ ...updated[0], chargeItems: normalizedChargeItems || undefined });
    } catch (error: any) {
      console.error("Failed to update bill:", error);
      res.status(500).json({ error: "Failed to update bill." });
    }
  });

  // DELETE Bill
  app.delete("/api/bills/:id", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (isStaffRole(req.dbUser!.role) && !hasPermission(req.dbUser!, 'manage_bills')) {
        return res.status(403).json({ error: "คุณไม่มีสิทธิ์ลบบิลค่าเช่า" });
      }
      const userId = getEffectiveUserId(req.dbUser!);
      const billId = parseInt(req.params.id);

      const deleted = await db.delete(bills)
        .where(and(eq(bills.id, billId), eq(bills.userId, userId)))
        .returning();

      if (deleted.length === 0) {
        return res.status(404).json({ error: "Bill not found or unauthorized." });
      }

      res.json({ success: true, message: "Bill deleted successfully." });
    } catch (error: any) {
      console.error("Failed to delete bill:", error);
      res.status(500).json({ error: "Failed to delete bill." });
    }
  });

  // GET Dashboard data
  app.get("/api/dashboard", requireAuth, async (req: AuthRequest, res) => {
    try {
      const userId = getEffectiveUserId(req.dbUser!);

      // 1. Fetch all rooms
      const allRooms = await db.select().from(rooms).where(eq(rooms.userId, userId));
      const totalRooms = allRooms.length;
      const occupiedRooms = allRooms.filter(r => r.status === "occupied").length;
      const vacantRooms = totalRooms - occupiedRooms;

      // 2. Fetch all bills
      const allBills = await db
        .select({
          id: bills.id,
          totalCost: bills.totalCost,
          status: bills.status,
          billMonth: bills.billMonth,
          roomId: bills.roomId,
          roomNumber: rooms.roomNumber,
          tenantName: rooms.tenantName,
        })
        .from(bills)
        .innerJoin(rooms, eq(bills.roomId, rooms.id))
        .where(eq(bills.userId, userId));

      // Get current month format YYYY-MM
      const now = new Date();
      const currentMonthStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;

      // This month's bills
      const thisMonthBills = allBills.filter(b => b.billMonth === currentMonthStr);
      
      const thisMonthRevenueExpected = thisMonthBills.reduce((acc, b) => acc + b.totalCost, 0);
      const thisMonthRevenuePaid = thisMonthBills.filter(b => b.status === "paid").reduce((acc, b) => acc + b.totalCost, 0);
      const thisMonthRevenueUnpaid = thisMonthBills.filter(b => b.status === "unpaid").reduce((acc, b) => acc + b.totalCost, 0);

      // Unpaid rooms (any unpaid bill across all months)
      const unpaidBills = allBills.filter(b => b.status === "unpaid");
      const unpaidRoomsList = unpaidBills.map(b => ({
        billId: b.id,
        roomId: b.roomId,
        roomNumber: b.roomNumber,
        tenantName: b.tenantName || "ไม่ทราบชื่อ",
        amount: b.totalCost,
        month: b.billMonth
      }));

      // Group revenue by month (last 6 months) for charts
      const monthlyRevenueMap: Record<string, { month: string; paid: number; unpaid: number; total: number }> = {};
      
      // Seed last 6 months to guarantee values
      for (let i = 5; i >= 0; i--) {
        const d = new Date();
        d.setMonth(now.getMonth() - i);
        const mStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
        monthlyRevenueMap[mStr] = {
          month: mStr,
          paid: 0,
          unpaid: 0,
          total: 0
        };
      }

      // Aggregate
      allBills.forEach(b => {
        if (monthlyRevenueMap[b.billMonth]) {
          if (b.status === "paid") {
            monthlyRevenueMap[b.billMonth].paid += b.totalCost;
          } else {
            monthlyRevenueMap[b.billMonth].unpaid += b.totalCost;
          }
          monthlyRevenueMap[b.billMonth].total += b.totalCost;
        }
      });

      const revenueHistory = Object.values(monthlyRevenueMap).sort((a, b) => a.month.localeCompare(b.month));

      res.json({
        rooms: {
          total: totalRooms,
          occupied: occupiedRooms,
          vacant: vacantRooms
        },
        revenueThisMonth: {
          total: thisMonthRevenueExpected,
          paid: thisMonthRevenuePaid,
          unpaid: thisMonthRevenueUnpaid
        },
        unpaidRooms: unpaidRoomsList,
        revenueHistory
      });
    } catch (error: any) {
      console.error("Failed to fetch dashboard statistics:", error);
      res.status(500).json({ error: "Failed to fetch dashboard statistics." });
    }
  });

  // --- LINE REGISTER & BOT SYSTEM ENDPOINTS ---

  const lineLogs: Array<{
    id: number;
    timestamp: string;
    type: 'incoming' | 'outgoing' | 'system';
    message: string;
    roomNumber?: string;
  }> = [];

  function addLineLog(type: 'incoming' | 'outgoing' | 'system', message: string, roomNumber?: string) {
    lineLogs.unshift({
      id: Date.now() + Math.random(),
      timestamp: new Date().toISOString(),
      type,
      message,
      roomNumber
    });
    if (lineLogs.length > 100) {
      lineLogs.pop();
    }
  }

  async function replyLineMessage(userSettings: any, replyToken: string, text: string) {
    if (userSettings && userSettings.lineChannelAccessToken) {
      try {
        const response = await fetch('https://api.line.me/v2/bot/message/reply', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${userSettings.lineChannelAccessToken}`
          },
          body: JSON.stringify({
            replyToken,
            messages: [{ type: 'text', text }]
          })
        });
        if (!response.ok) {
          console.error("Failed to reply via LINE API:", await response.text());
        }
      } catch (err) {
        console.error("Error in replyLineMessage:", err);
      }
    }
  }

  async function pushLineMessage(userSettings: any, toUserId: string, text: string) {
    if (userSettings && userSettings.lineChannelAccessToken) {
      try {
        const response = await fetch('https://api.line.me/v2/bot/message/push', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${userSettings.lineChannelAccessToken}`
          },
          body: JSON.stringify({
            to: toUserId,
            messages: [{ type: 'text', text }]
          })
        });
        if (!response.ok) {
          console.error("Failed to push via LINE API:", await response.text());
          return false;
        }
        return true;
      } catch (err) {
        console.error("Error in pushLineMessage:", err);
        return false;
      }
    }
    return true; // Simulate success
  }

  async function sendLineNotifyMessage(token: string, message: string): Promise<boolean> {
    try {
      const response = await fetch("https://notify-api.line.me/api/notify", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          "Authorization": `Bearer ${token}`
        },
        body: new URLSearchParams({ message })
      });
      if (!response.ok) {
        console.error("Failed to send LINE Notify:", await response.text());
        return false;
      }
      return true;
    } catch (err) {
      console.error("Error in sendLineNotifyMessage:", err);
      return false;
    }
  }

  // 1. Landlord: Fetch LINE System logs
  app.get("/api/line/logs", requireAuth, (req: AuthRequest, res) => {
    res.json(lineLogs);
  });

  // 2. Public: LINE webhook receiver
  app.post("/api/line/webhook", async (req, res) => {
    try {
      const events = req.body.events;
      if (!events || !Array.isArray(events)) {
        return res.status(200).send("OK");
      }

      for (const event of events) {
        if (event.type === "message" && event.message.type === "text") {
          const lineUserId = event.source.userId;
          const text = event.message.text.trim();
          const replyToken = event.replyToken;

          addLineLog('incoming', `ได้รับข้อความ: "${text}" จาก LINE ID: ${lineUserId}`);

          const allUsers = await db.select().from(users).limit(1);
          if (allUsers.length === 0) continue;
          const userId = allUsers[0].id;
          
          const userSettingsList = await db.select().from(settings).where(eq(settings.userId, userId));
          const userSettings = userSettingsList[0];

          // 1. Handle registration keyword: "ลงทะเบียน [เลขห้อง] [เบอร์โทร]"
          const regRegex = /^(ลงทะเบียน|register)\s+(\S+)\s+(\S+)$/i;
          const match = text.match(regRegex);

          if (match) {
            const roomNum = match[2];
            const phone = match[3];

            // Fetch all rooms for this landlord
            const allRooms = await db.select().from(rooms).where(eq(rooms.userId, userId));
            const normalizedInput = normalizeRoomName(roomNum);
            
            let roomMatch = allRooms.filter(r => normalizeRoomName(r.roomNumber) === normalizedInput);

            // Fallback: match by tenant phone number if room name search yields nothing
            const cleanPhoneInput = phone.replace(/[- ]/g, "");
            if (roomMatch.length === 0 && cleanPhoneInput) {
              roomMatch = allRooms.filter(r => {
                const cleanRoomPhone = (r.tenantPhone || "").replace(/[- ]/g, "");
                return cleanRoomPhone && cleanRoomPhone === cleanPhoneInput;
              });
            }

            if (roomMatch.length === 0) {
              const occupiedRooms = allRooms.filter(r => r.status === "occupied");
              const roomList = occupiedRooms.map(r => r.roomNumber.trim()).join(", ");
              await replyLineMessage(
                userSettings, 
                replyToken, 
                `❌ ไม่พบห้องหมายเลข "${roomNum}" ในระบบค่ะ\n\nหมายเลขห้องที่เปิดใช้งานในขณะนี้ เช่น: ${roomList || "ยังไม่มีข้อมูลห้องพัก"}`
              );
              addLineLog('outgoing', `ส่งคำตอบผิดพลาด: ไม่พบห้อง ${roomNum}`, roomNum);
            } else {
              const room = roomMatch[0];
              const cleanRoomPhone = (room.tenantPhone || "").replace(/[- ]/g, "");

              if (cleanRoomPhone && cleanPhoneInput !== cleanRoomPhone) {
                await replyLineMessage(userSettings, replyToken, `❌ เบอร์โทรศัพท์ไม่ถูกต้อง สำหรับห้อง ${room.roomNumber}`);
                addLineLog('outgoing', `ส่งคำตอบผิดพลาด: เบอร์โทรศัพท์ไม่ถูกต้องสำหรับห้อง ${room.roomNumber}`, room.roomNumber);
              } else {
                let displayName = `LINE User`;
                let pictureUrl = "";
                if (userSettings && userSettings.lineChannelAccessToken) {
                  try {
                    const profileRes = await fetch(`https://api.line.me/v2/bot/profile/${lineUserId}`, {
                      headers: { 'Authorization': `Bearer ${userSettings.lineChannelAccessToken}` }
                    });
                    if (profileRes.ok) {
                      const profile = await profileRes.json();
                      displayName = profile.displayName || displayName;
                      pictureUrl = profile.pictureUrl || pictureUrl;
                    }
                  } catch (err) {
                    console.error("Failed to fetch LINE profile:", err);
                  }
                }

                await db.update(rooms)
                  .set({
                    lineUserId,
                    lineDisplayName: displayName,
                    linePictureUrl: pictureUrl,
                    lineStatus: 'linked'
                  })
                  .where(eq(rooms.id, room.id));

                await replyLineMessage(userSettings, replyToken, `🎉 ลงทะเบียนสำเร็จ!\nห้อง: ${room.roomNumber}\nผู้เช่า: ${room.tenantName || 'ไม่ระบุ'}\nตอนนี้คุณจะได้รับบิลแจ้งเตือนผ่านช่องทางนี้แล้วค่ะ`);
                addLineLog('system', `ลงทะเบียนผู้เช่าสำเร็จผ่าน LINE Webhook สำหรับห้อง ${room.roomNumber}`, room.roomNumber);
              }
            }
            continue;
          }

          // 2. Query bills: "บิล" or "ยอดค้างชำระ"
          const isQueryBill = ["บิล", "ค่าเช่า", "ยอดค้างชำระ", "ยอดค้าง", "bill", "check"].some(k => text.toLowerCase().includes(k));
          if (isQueryBill) {
            const linkedRooms = await db.select().from(rooms).where(and(
              eq(rooms.userId, userId),
              eq(rooms.lineUserId, lineUserId)
            ));

            if (linkedRooms.length === 0) {
              await replyLineMessage(userSettings, replyToken, `⚠️ คุณยังไม่ได้ลงทะเบียนในระบบค่ะ\nกรุณาลงทะเบียนโดยพิมพ์:\nลงทะเบียน [เลขห้อง] [เบอร์โทร]\nเช่น: ลงทะเบียน 101 0812345678`);
              addLineLog('outgoing', `ส่งคำแนะนำลงทะเบียนให้กับ LINE ID: ${lineUserId}`);
            } else {
              const room = linkedRooms[0];
              const unpaid = await db.select()
                .from(bills)
                .where(and(
                  eq(bills.roomId, room.id),
                  eq(bills.status, "unpaid")
                ))
                .orderBy(desc(bills.billMonth));

              if (unpaid.length === 0) {
                await replyLineMessage(userSettings, replyToken, `✅ ห้อง ${room.roomNumber} ไม่มียอดค้างชำระในระบบค่ะ ขอบคุณค่ะ!`);
                addLineLog('outgoing', `แจ้งไม่มียอดค้างชำระสำหรับห้อง ${room.roomNumber}`, room.roomNumber);
              } else {
                const latestBill = unpaid[0];
                const msg = `🧾 บิลค้างชำระ ห้อง ${room.roomNumber}\n` +
                            `รอบประจำเดือน: ${latestBill.billMonth}\n` +
                            `• ค่าเช่าห้อง: ${latestBill.rentCost.toLocaleString()} บาท\n` +
                            `• ค่าไฟ: ${Math.round(Math.max(0, latestBill.currentElec - latestBill.priorElec - (latestBill.elecDeduct ?? 0)) * latestBill.elecUnitCost).toLocaleString()} บาท${(latestBill.elecDeduct ?? 0) > 0 ? ` (หักล้าง ${(latestBill.elecDeduct ?? 0)} หน่วย)` : ''}\n` +
                            `• ค่าน้ำ: ${(latestBill.waterCost ?? (latestBill.currentWater - latestBill.priorWater > 0 ? (Math.round((latestBill.currentWater - latestBill.priorWater) * latestBill.waterUnitCost) + 10) : 0)).toLocaleString()} บาท\n` +
                            `• ยอดรวมสุทธิ: ${latestBill.totalCost.toLocaleString()} บาท\n` +
                            `📅 ครบกำหนดชำระ: ${latestBill.dueDate}\n\n` +
                            `🔗 ตรวจสอบรายละเอียดและชำระเงินที่นี่:\n` +
                            `${req.protocol}://${req.get('host')}/line-register?room=${room.roomNumber}&phone=${room.tenantPhone}`;
                
                await replyLineMessage(userSettings, replyToken, msg);
                addLineLog('outgoing', `แจ้งยอดค้างชำระ ${latestBill.totalCost} บาท สำหรับห้อง ${room.roomNumber}`, room.roomNumber);
              }
            }
            continue;
          }

          // 3. Fallback help message
          await replyLineMessage(
            userSettings, 
            replyToken, 
            `ยินดีต้อนรับสู่บริการแจ้งบิลอัตโนมัติค่ะ 😊\n\n` +
            `• หากต้องการลงทะเบียน พิมพ์:\nลงทะเบียน [เลขห้อง] [เบอร์โทร]\n` +
            `• หากต้องการตรวจสอบบิลล่าสุด พิมพ์:\n"บิล" หรือ "ยอดค้างชำระ"`
          );
        }
      }

      res.status(200).send("OK");
    } catch (error) {
      console.error("LINE Webhook error:", error);
      res.status(500).send("Internal Server Error");
    }
  });

  // 3. Public: Verification endpoint for tenant-facing web page
  const getTenantSession = async (req: express.Request) => {
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) return null;
    const payload = await verifyToken(authHeader.slice('Bearer '.length), jwtSecret);
    if (!payload || payload.role !== 'tenant' || !Number.isInteger(payload.roomId) || !Number.isInteger(payload.userId)) return null;
    return { roomId: payload.roomId as number, userId: payload.userId as number };
  };

  app.post("/api/public/line/verify", async (req, res) => {
    try {
      const { roomNumber, tenantPhone } = req.body;
      if (!roomNumber || !tenantPhone) {
        return res.status(400).json({ error: "กรุณากรอกเลขห้องและเบอร์โทรศัพท์ให้ครบถ้วน" });
      }

      // This is the sole unauthenticated room lookup. It authenticates the
      // tenant by the room number and phone together; all later operations use
      // the short-lived tenant token returned below.
      const activeRooms = await db.select().from(rooms).where(and(eq(rooms.roomNumber, roomNumber.trim()), isNull(rooms.deletedAt)));
      const cleanPhoneInput = tenantPhone.replace(/[- ]/g, "");

      let roomMatch = activeRooms.filter(r => {
        const cleanRoomPhone = (r.tenantPhone || "").replace(/[- ]/g, "");
        return cleanRoomPhone === cleanPhoneInput;
      });

      if (roomMatch.length === 0) {
        return res.status(404).json({ error: `ไม่พบหมายเลขห้อง "${roomNumber}" ในระบบ` });
      }

      const room = roomMatch[0];
      const userId = room.userId;
      const cleanRoomPhone = (room.tenantPhone || "").replace(/[- ]/g, "");

      if (!await ownerHasPlanFeature(userId, 'tenantPortal')) {
        return planRequiredResponse(res, 'Tenant Portal ยังไม่เปิดในแพ็กเกจนี้');
      }

      if (cleanRoomPhone && cleanPhoneInput !== cleanRoomPhone) {
        return res.status(400).json({ error: "เบอร์โทรศัพท์ไม่ตรงกับข้อมูลในระบบ" });
      }

      // Get settings for landlord to display QR or show details
      const userSettingsList = await db.select().from(settings).where(eq(settings.userId, userId));
      const userSettings = userSettingsList[0] || { dormName: "หอพักของฉัน" };

      // Fetch unpaid bills
      const unpaidBillsList = await db.select()
        .from(bills)
        .where(and(eq(bills.roomId, room.id), eq(bills.userId, userId), eq(bills.status, "unpaid"), isNull(bills.deletedAt)))
        .orderBy(desc(bills.billMonth));

      // Fetch paid bills
      const paidBillsList = await db.select()
        .from(bills)
        .where(and(eq(bills.roomId, room.id), eq(bills.userId, userId), eq(bills.status, "paid"), isNull(bills.deletedAt)))
        .orderBy(desc(bills.billMonth))
        .limit(5);

      res.json({
        success: true,
        tenantToken: await generateToken({ role: 'tenant', roomId: room.id, userId }, jwtSecret, 1),
        room: {
          id: room.id,
          roomNumber: room.roomNumber,
          tenantName: room.tenantName,
          tenantPhone: room.tenantPhone,
          lineStatus: room.lineStatus,
          lineDisplayName: room.lineDisplayName,
          linePictureUrl: room.linePictureUrl
        },
        settings: userSettings,
        unpaidBills: unpaidBillsList,
        paidBills: paidBillsList
      });

    } catch (error: any) {
      console.error("Public verify error:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการตรวจสอบข้อมูล" });
    }
  });

  // Public endpoint to get room details and bills by roomId
  app.get("/api/public/rooms/:id", async (req, res) => {
    try {
      const roomId = parseInt(req.params.id);
      if (isNaN(roomId)) {
        return res.status(400).json({ error: "ระบุรหัสห้องพักไม่ถูกต้อง" });
      }
      const tenant = await getTenantSession(req);
      if (!tenant || tenant.roomId !== roomId) {
        return res.status(401).json({ error: "กรุณายืนยันตัวตนผู้เช่าก่อนเข้าดูข้อมูลห้องพัก" });
      }
      if (!await ownerHasPlanFeature(tenant.userId, 'tenantPortal')) {
        return planRequiredResponse(res, 'Tenant Portal อยู่ในแพ็กเกจ Pro');
      }

      // Fetch room
      const roomResult = await db.select().from(rooms).where(and(eq(rooms.id, roomId), eq(rooms.userId, tenant.userId), isNull(rooms.deletedAt)));
      if (roomResult.length === 0) {
        return res.status(404).json({ error: "ไม่พบข้อมูลห้องพักนี้ในระบบ" });
      }
      const room = roomResult[0];

      // Get settings for landlord
      const userSettingsList = await db.select().from(settings).where(eq(settings.userId, room.userId));
      const userSettings = userSettingsList[0] || { dormName: "หอพักของฉัน" };

      // Fetch bills
      const allBillsList = await db.select()
        .from(bills)
        .where(and(eq(bills.roomId, room.id), eq(bills.userId, room.userId), isNull(bills.deletedAt)))
        .orderBy(desc(bills.billMonth));
      const publicChargeRows = allBillsList.length ? await db.select().from(billChargeItems).where(inArray(billChargeItems.billId, allBillsList.map((bill) => bill.id))).orderBy(asc(billChargeItems.sortOrder)) : [];
      const publicBills = allBillsList.map((bill) => ({ ...bill, chargeItems: publicChargeRows.filter((item) => item.billId === bill.id) }));

      // Separate into unpaid and paid
      const unpaidBillsList = publicBills.filter(b => b.status === "unpaid" || b.slipStatus === "pending" || b.slipStatus === "rejected");
      const paidBillsList = publicBills.filter(b => b.status === "paid" && b.slipStatus !== "pending").slice(0, 10);

      res.json({
        success: true,
        room: {
          id: room.id,
          roomNumber: room.roomNumber,
          tenantName: room.tenantName,
          tenantPhone: room.tenantPhone,
          lineStatus: room.lineStatus,
          lineDisplayName: room.lineDisplayName,
          linePictureUrl: room.linePictureUrl
        },
        settings: userSettings,
        unpaidBills: unpaidBillsList,
        paidBills: paidBillsList
      });
    } catch (error: any) {
      console.error("Public fetch room error:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการดึงข้อมูลห้องพัก" });
    }
  });

  // Public endpoint to upload payment slip
  app.post("/api/public/bills/:id/upload-slip", async (req, res) => {
    try {
      const billId = parseInt(req.params.id);
      const { slipImage } = req.body;

      if (!slipImage) {
        return res.status(400).json({ error: "กรุณาแนบรูปภาพสลิปโอนเงิน" });
      }
      const tenant = await getTenantSession(req);
      if (!tenant) return res.status(401).json({ error: "กรุณายืนยันตัวตนผู้เช่าก่อนอัปโหลดสลิป" });
      if (!await ownerHasPlanFeature(tenant.userId, 'tenantPortal')) {
        return planRequiredResponse(res, 'Tenant Portal อยู่ในแพ็กเกจ Pro');
      }

      const existingBills = await db.select().from(bills).where(and(eq(bills.id, billId), eq(bills.roomId, tenant.roomId), eq(bills.userId, tenant.userId), isNull(bills.deletedAt)));
      if (existingBills.length === 0) {
        return res.status(404).json({ error: "ไม่พบบิลเรียกเก็บเงิน" });
      }
      const billObj = existingBills[0];

      const updated = await db.update(bills)
        .set({
          slipImage,
          slipUploadedAt: new Date().toISOString(),
          slipStatus: 'pending'
        })
        .where(and(eq(bills.id, billId), eq(bills.userId, billObj.userId)))
        .returning();

      if (updated.length === 0) {
        return res.status(404).json({ error: "ไม่พบบิลเรียกเก็บเงิน" });
      }

      // Add LINE Log
      const roomMatch = await db.select().from(rooms).where(and(eq(rooms.id, updated[0].roomId), eq(rooms.userId, tenant.userId)));
      const roomNum = roomMatch.length > 0 ? roomMatch[0].roomNumber : "";
      addLineLog('system', `ผู้เช่าห้อง ${roomNum} อัปโหลดสลิปโอนเงินสำหรับรอบบิล ${updated[0].billMonth}`, roomNum);

      res.json({ success: true, bill: updated[0] });
    } catch (error: any) {
      console.error("Upload slip error:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการอัปโหลดสลิป" });
    }
  });

  // POST Create Bulk Bills
  app.post("/api/bills/bulk", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (isStaffRole(req.dbUser!.role) && !hasPermission(req.dbUser!, 'manage_bills')) {
        return res.status(403).json({ error: "คุณไม่มีสิทธิ์สร้างบิลค่าเช่า" });
      }
      const userId = getEffectiveUserId(req.dbUser!);
      const { billMonth, dueDate, bills: bulkBills } = req.body;

      if (!billMonth || !dueDate || !bulkBills || !Array.isArray(bulkBills)) {
        return res.status(400).json({ error: "กรุณากรอกข้อมูลเดือน กำหนดชำระ และรายการบิลให้ครบถ้วน" });
      }

      const createdBills = [];
      const userSettingsList = await db.select().from(settings).where(eq(settings.userId, userId));
      const userSettings = userSettingsList[0] || { defaultElecRate: 7, defaultWaterRate: 13 };

      for (const billItem of bulkBills) {
        const {
          roomId,
          priorElec,
          currentElec,
          elecDeduct,
          elecCost,
          priorWater,
          currentWater,
          waterCost,
          rentCost,
          depositCost,
          otherCost,
          otherDescription,
          chargeItems: rawChargeItems
        } = billItem;

        // Calculate totals
        let finalElecCost = 0;
        if (elecCost !== undefined && elecCost !== null && elecCost !== '') {
          finalElecCost = parseFloat(elecCost) || 0;
        } else {
          const elecUnits = Math.max(0, (parseFloat(currentElec) || 0) - (parseFloat(priorElec) || 0) - (parseFloat(elecDeduct) || 0));
          finalElecCost = Math.round(elecUnits * userSettings.defaultElecRate);
        }
        
        let finalWaterCost = 0;
        if (waterCost !== undefined) {
          finalWaterCost = parseFloat(waterCost) || 0;
        } else {
          const waterUnits = Math.max(0, (parseFloat(currentWater) || 0) - (parseFloat(priorWater) || 0));
          finalWaterCost = waterUnits > 0 ? (Math.round(waterUnits * userSettings.defaultWaterRate) + 10) : 0;
        }

        const normalizedChargeItems = await normalizeBillChargeItems(rawChargeItems, userId, Number(roomId));
        const finalOtherCost = normalizedChargeItems ? normalizedChargeItems.reduce((sum: number, item: any) => sum + item.amount, 0) : (parseInt(otherCost) || 0);
        const finalOtherDescription = normalizedChargeItems ? normalizedChargeItems.map((item: any) => item.label).join(', ') : (otherDescription || '');
        const total = (parseInt(rentCost) || 0) + finalElecCost + finalWaterCost + (parseInt(depositCost) || 0) + finalOtherCost;

        const newBill = await db.insert(bills)
          .values({
            userId,
            roomId,
            billMonth,
            priorElec: parseFloat(priorElec) || 0,
            currentElec: parseFloat(currentElec) || 0,
            elecDeduct: parseFloat(elecDeduct) || 0,
            elecUnitCost: userSettings.defaultElecRate,
            elecCost: finalElecCost,
            priorWater: parseFloat(priorWater) || 0,
            currentWater: parseFloat(currentWater) || 0,
            waterUnitCost: userSettings.defaultWaterRate,
            waterCost: finalWaterCost,
            rentCost: parseInt(rentCost) || 0,
            depositCost: parseInt(depositCost) || 0,
            otherCost: finalOtherCost,
            otherDescription: finalOtherDescription,
            totalCost: total,
            dueDate,
            status: "unpaid",
            slipStatus: "none"
          })
          .returning();

        if (normalizedChargeItems?.length) await db.insert(billChargeItems).values(normalizedChargeItems.map((item: any) => ({ ...item, billId: newBill[0].id })));

        createdBills.push({ ...newBill[0], chargeItems: normalizedChargeItems || [] });
      }

      res.json({ success: true, count: createdBills.length, bills: createdBills });
    } catch (error: any) {
      console.error("Bulk bills creation failed:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการสร้างบิลแบบกลุ่ม" });
    }
  });

  // POST Send bulk LINE reminders for all overdue bills
  app.post("/api/line/send-overdue", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (!hasPermission(req.dbUser!, PERMISSIONS.MANAGE_BILLS)) return res.status(403).json({ error: 'ไม่มีสิทธิ์จัดการบิล' });
      const userId = getEffectiveUserId(req.dbUser!);

      const overdueBillsList = await db
        .select({
          id: bills.id,
          billMonth: bills.billMonth,
          totalCost: bills.totalCost,
          dueDate: bills.dueDate,
          roomNumber: rooms.roomNumber,
          lineUserId: rooms.lineUserId,
          lineStatus: rooms.lineStatus,
          lineNotifyToken: rooms.lineNotifyToken,
          tenantPhone: rooms.tenantPhone
        })
        .from(bills)
        .innerJoin(rooms, eq(bills.roomId, rooms.id))
        .where(and(
          eq(bills.userId, userId),
          eq(bills.status, "unpaid")
        ));

      // Filter bills that are overdue (dueDate <= today)
      const todayStr = new Date().toISOString().substring(0, 10);
      const overdueBills = overdueBillsList.filter(b => b.dueDate <= todayStr);

      if (overdueBills.length === 0) {
        return res.json({ success: true, count: 0, message: "ไม่มีห้องค้างชำระที่เกินกำหนดเวลาส่งแจ้งเตือน" });
      }

      const userSettingsList = await db.select().from(settings).where(eq(settings.userId, userId));
      const userSettings: any = userSettingsList[0] || {};
      let sentCount = 0;

      for (const bill of overdueBills) {
        const hasNotify = !!bill.lineNotifyToken;
        const hasMessaging = !!(bill.lineUserId && bill.lineStatus === 'linked');

        if (!hasNotify && !hasMessaging) continue;

        const msg = `⚠️ แจ้งเตือนยอดค้างชำระหอพัก ${userSettings.dormName || 'หอพัก'}\n` +
                    `⚠️ เกินกำหนดชำระเงินเรียบร้อยแล้วค่ะ\n` +
                    `ห้อง: ${bill.roomNumber}\n` +
                    `รอบบิลประจำเดือน: ${bill.billMonth}\n` +
                    `💰 ยอดคงค้างทั้งหมด: ${bill.totalCost.toLocaleString()} บาท\n` +
                    `📅 ครบกำหนดตั้งแต่วันที่: ${bill.dueDate}\n\n` +
                    `🔗 รบกวนสแกนจ่ายหรือแนบสลิปชำระเงินที่ลิงก์นี้:\n` +
                    `${req.protocol}://${req.get('host')}/line-register?room=${bill.roomNumber}&phone=${bill.tenantPhone}\n\n` +
                    `หากชำระเงินเรียบร้อยแล้ว ขออภัยในความไม่สะดวกนะคะ 🙏`;

        let pushSuccess = false;
        if (hasNotify) {
          pushSuccess = await sendLineNotifyMessage(bill.lineNotifyToken!, msg);
        } else {
          pushSuccess = await pushLineMessage(userSettings, bill.lineUserId!, msg);
        }

        if (pushSuccess) {
          sentCount++;
          addLineLog('outgoing', `ส่งข้อความทวงยอดค้างชำระรอบเดือน ${bill.billMonth} ห้อง ${bill.roomNumber} สำเร็จ`, bill.roomNumber);
        }
      }

      res.json({ success: true, count: sentCount, message: `ส่งข้อความทวงถามสำเร็จทั้งหมด ${sentCount} ห้อง` });
    } catch (error: any) {
      console.error("Failed to send overdue reminders:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการส่งข้อความแจ้งเตือน" });
    }
  });

  // 4. Public: Submit LINE registration from web form
  app.post("/api/public/line/register", async (req, res) => {
    try {
      const { roomId, lineUserId, lineDisplayName, linePictureUrl } = req.body;
      if (!roomId || !lineUserId) {
        return res.status(400).json({ error: "Missing required fields." });
      }
      const tenant = await getTenantSession(req);
      if (!tenant || tenant.roomId !== parseInt(roomId)) return res.status(401).json({ error: "กรุณายืนยันตัวตนผู้เช่าก่อนเชื่อมต่อ LINE" });
      if (!await ownerHasPlanFeature(tenant.userId, 'lineIntegration')) {
        return planRequiredResponse(res, 'LINE Integration อยู่ในแพ็กเกจ Pro');
      }

      const existingRooms = await db.select().from(rooms).where(and(eq(rooms.id, parseInt(roomId)), eq(rooms.userId, tenant.userId), isNull(rooms.deletedAt)));
      if (existingRooms.length === 0) {
        return res.status(404).json({ error: "Room not found." });
      }
      const roomObj = existingRooms[0];

      const updated = await db.update(rooms)
        .set({
          lineUserId,
          lineDisplayName: lineDisplayName || "LINE User",
          linePictureUrl: linePictureUrl || "",
          lineStatus: 'linked'
        })
        .where(and(eq(rooms.id, roomObj.id), eq(rooms.userId, roomObj.userId)))
        .returning();

      if (updated.length === 0) {
        return res.status(404).json({ error: "Room not found." });
      }

      addLineLog('system', `ลงทะเบียนผู้เช่าสำเร็จผ่าน Web Portal สำหรับห้อง ${updated[0].roomNumber}`, updated[0].roomNumber);

      // Try to send a welcome push notification
      const userSettingsList = await db.select().from(settings).where(eq(settings.userId, updated[0].userId));
      if (userSettingsList.length > 0) {
        await pushLineMessage(
          userSettingsList[0],
          lineUserId,
          `🎉 ยินดีต้อนรับเข้าสู่ระบบแจ้งเตือนบิลหอพัก ${userSettingsList[0].dormName}!\nคุณได้ทำการเชื่อมต่อ LINE สำเร็จสำหรับห้อง ${updated[0].roomNumber} เรียบร้อยแล้วค่ะ`
        );
      }

      res.json({ success: true, room: updated[0] });
    } catch (error: any) {
      console.error("Public register error:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการบันทึกการเชื่อมโยง LINE" });
    }
  });

  // 5. Landlord: Send Active Bill to Linked Room's LINE
  app.post("/api/line/send-bill/:billId", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (!hasPermission(req.dbUser!, PERMISSIONS.MANAGE_BILLS)) return res.status(403).json({ error: 'ไม่มีสิทธิ์จัดการบิล' });
      const userId = getEffectiveUserId(req.dbUser!);
      const billId = parseInt(req.params.billId);

      const billDetailList = await db
        .select({
          id: bills.id,
          billMonth: bills.billMonth,
          totalCost: bills.totalCost,
          rentCost: bills.rentCost,
          priorElec: bills.priorElec,
          currentElec: bills.currentElec,
          elecDeduct: bills.elecDeduct,
          elecUnitCost: bills.elecUnitCost,
          elecCost: bills.elecCost,
          priorWater: bills.priorWater,
          currentWater: bills.currentWater,
          waterUnitCost: bills.waterUnitCost,
          waterCost: bills.waterCost,
          depositCost: bills.depositCost,
          otherCost: bills.otherCost,
          dueDate: bills.dueDate,
          roomNumber: rooms.roomNumber,
          lineUserId: rooms.lineUserId,
          lineStatus: rooms.lineStatus,
          lineNotifyToken: rooms.lineNotifyToken,
          tenantPhone: rooms.tenantPhone
        })
        .from(bills)
        .innerJoin(rooms, eq(bills.roomId, rooms.id))
        .where(and(eq(bills.id, billId), eq(bills.userId, userId)));

      if (billDetailList.length === 0) {
        return res.status(404).json({ error: "ไม่พบบิลเรียกเก็บเงินหรือคุณไม่มีสิทธิ์เข้าถึง" });
      }

      const bill = billDetailList[0];
      const hasNotify = !!bill.lineNotifyToken;
      const hasMessaging = !!(bill.lineUserId && bill.lineStatus === 'linked');

      if (!hasNotify && !hasMessaging) {
        return res.status(400).json({ error: "ห้องนี้ยังไม่ได้ลงทะเบียน LINE ผู้เช่า หรือ LINE Notify" });
      }

      const userSettingsList = await db.select().from(settings).where(eq(settings.userId, userId));
      const userSettings: any = userSettingsList[0] || {};
      const lineChargeItems = await db.select().from(billChargeItems).where(eq(billChargeItems.billId, bill.id)).orderBy(asc(billChargeItems.sortOrder));
      const lineChargeText = lineChargeItems.length
        ? lineChargeItems.map((item) => `• ${item.label}: ${Number(item.amount).toLocaleString()} บาท\n`).join('')
        : (bill.otherCost > 0 ? `• ค่าใช้จ่ายอื่น ๆ: ${bill.otherCost.toLocaleString()} บาท\n` : '');

      const msg = `🧾 ใบแจ้งค่าเช่าหอพัก ${userSettings.dormName || 'หอพัก'}\n` +
                  `ประจำเดือน: ${bill.billMonth}\n` +
                  `ห้อง: ${bill.roomNumber}\n` +
                  `-------------------------\n` +
                  `• ค่าเช่าห้อง: ${bill.rentCost.toLocaleString()} บาท\n` +
                  `• ค่าไฟฟ้า: ${(bill.elecCost ?? Math.round(Math.max(0, bill.currentElec - bill.priorElec - (bill.elecDeduct ?? 0)) * bill.elecUnitCost)).toLocaleString()} บาท (${bill.priorElec} -> ${bill.currentElec} หน่วย${(bill.elecDeduct ?? 0) > 0 ? `, หักล้าง ${(bill.elecDeduct ?? 0)} หน่วย` : ''})\n` +
                  `• ค่าน้ำ: ${(bill.waterCost ?? (bill.currentWater - bill.priorWater > 0 ? Math.round((bill.currentWater - bill.priorWater) * bill.waterUnitCost) : 0)).toLocaleString()} บาท (${bill.priorWater} -> ${bill.currentWater} หน่วย)\n` +
                  (bill.depositCost > 0 ? `• ค่าประกัน: ${bill.depositCost.toLocaleString()} บาท\n` : '') +
                  lineChargeText +
                  `-------------------------\n` +
                  `💰 ยอดรวมทั้งสิ้น: ${bill.totalCost.toLocaleString()} บาท\n` +
                  `📅 ครบกำหนดชำระ: ${bill.dueDate}\n\n` +
                  `🔗 ลิงก์ตรวจสอบและชำระเงิน:\n` +
                  `${req.protocol}://${req.get('host')}/line-register?room=${bill.roomNumber}&phone=${bill.tenantPhone}`;

      let pushSuccess = false;
      let methodUsed = '';

      if (hasNotify) {
        pushSuccess = await sendLineNotifyMessage(bill.lineNotifyToken!, msg);
        methodUsed = 'LINE Notify';
      } else {
        pushSuccess = await pushLineMessage(userSettings, bill.lineUserId!, msg);
        methodUsed = 'LINE Push Message';
      }

      if (pushSuccess) {
        addLineLog('outgoing', `ส่งบิลเดือน ${bill.billMonth} ยอด ${bill.totalCost} บาท ไปยัง ${methodUsed} ห้อง ${bill.roomNumber}`, bill.roomNumber);
        res.json({ success: true, message: `ส่งบิลห้อง ${bill.roomNumber} เรียบร้อยแล้ว (ผ่าน ${methodUsed})` });
      } else {
        res.status(500).json({ error: `ไม่สามารถส่งข้อความผ่าน API ของ ${methodUsed} ได้ (โปรดตรวจสอบค่าความถูกต้องของ Token)` });
      }

    } catch (error: any) {
      console.error("Failed to send bill:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการส่งบิล" });
    }
  });

  // 6. Landlord: Send test message
  app.post("/api/line/send-test/:roomId", requireAuth, async (req: AuthRequest, res) => {
    try {
      const userId = getEffectiveUserId(req.dbUser!);
      const roomId = parseInt(req.params.roomId);

      const roomDetail = await db.select().from(rooms).where(and(eq(rooms.id, roomId), eq(rooms.userId, userId)));
      if (roomDetail.length === 0) {
        return res.status(404).json({ error: "ไม่พบห้องพัก" });
      }

      const room = roomDetail[0];
      const hasNotify = !!room.lineNotifyToken;
      const hasMessaging = !!room.lineUserId;

      if (!hasNotify && !hasMessaging) {
        return res.status(400).json({ error: "ห้องนี้ยังไม่ได้ลงทะเบียน LINE หรือ LINE Notify Token" });
      }

      const userSettingsList = await db.select().from(settings).where(eq(settings.userId, userId));
      const userSettings: any = userSettingsList[0] || {};

      const msg = `🔔 ข้อความทดสอบจากผู้ดูแลหอพัก ${userSettings.dormName || ''}\nระบบแจ้งเตือน LINE ของคุณใช้งานได้ปกติแล้วค่ะ!`;
      
      let pushSuccess = false;
      let methodUsed = '';

      if (hasNotify) {
        pushSuccess = await sendLineNotifyMessage(room.lineNotifyToken!, msg);
        methodUsed = 'LINE Notify';
      } else {
        pushSuccess = await pushLineMessage(userSettings, room.lineUserId!, msg);
        methodUsed = 'LINE Push';
      }

      if (pushSuccess) {
        addLineLog('outgoing', `ส่งข้อความทดสอบสำเร็จ ไปยัง ${methodUsed} ห้อง ${room.roomNumber}`, room.roomNumber);
        res.json({ success: true, message: `ส่งข้อความทดสอบสำเร็จ (ผ่าน ${methodUsed})` });
      } else {
        res.status(500).json({ error: `ล้มเหลวในการส่งข้อความทดสอบทาง ${methodUsed}` });
      }

    } catch (error: any) {
      console.error("Test send error:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการส่งข้อความทดสอบ" });
    }
  });

  // 7. Landlord: Unlink LINE from room
  app.post("/api/line/unlink/:roomId", requireAuth, async (req: AuthRequest, res) => {
    try {
      const userId = getEffectiveUserId(req.dbUser!);
      const roomId = parseInt(req.params.roomId);

      const updated = await db.update(rooms)
        .set({
          lineUserId: null,
          lineDisplayName: null,
          linePictureUrl: null,
          lineStatus: 'unlinked'
        })
        .where(and(eq(rooms.id, roomId), eq(rooms.userId, userId)))
        .returning();

      if (updated.length === 0) {
        return res.status(404).json({ error: "ไม่พบห้องพักหรือคุณไม่มีสิทธิ์" });
      }

      addLineLog('system', `ยกเลิกการเชื่อมต่อ LINE สำหรับห้อง ${updated[0].roomNumber}`, updated[0].roomNumber);
      res.json({ success: true, room: updated[0] });
    } catch (error: any) {
      console.error("Unlink error:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาด" });
    }
  });

  // --- Maintenance Ticket Endpoints ---

  // 1. GET Maintenance Tickets (Admin / Caretaker)
  app.get("/api/maintenance", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (!hasPermission(req.dbUser!, PERMISSIONS.VIEW_MAINTENANCE)) return res.status(403).json({ error: 'ไม่มีสิทธิ์ดูงานแจ้งซ่อม' });
      const userId = getEffectiveUserId(req.dbUser!);
      const tickets = await db.select()
        .from(maintenanceTickets)
        .where(eq(maintenanceTickets.userId, userId))
        .orderBy(desc(maintenanceTickets.createdAt));
      res.json(tickets);
    } catch (error: any) {
      console.error("Fetch maintenance tickets error:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการดึงข้อมูลรายการแจ้งซ่อม" });
    }
  });

  // 2. GET Maintenance Tickets for Tenant (Public / Tenant Portal)
  app.get("/api/tenant/maintenance", async (req, res) => {
    try {
      const { roomId, roomNumber } = req.query;
      if (!roomId && !roomNumber) {
        return res.status(400).json({ error: "กรุณาระบุห้องพัก" });
      }
      const tenant = await getTenantSession(req);
      if (!tenant || (roomId && tenant.roomId !== parseInt(roomId as string))) {
        return res.status(401).json({ error: "กรุณายืนยันตัวตนผู้เช่าก่อนดูรายการแจ้งซ่อม" });
      }
      if (!await ownerHasPlanFeature(tenant.userId, 'tenantPortal') || !await ownerHasPlanFeature(tenant.userId, 'maintenance')) {
        return planRequiredResponse(res, 'แจ้งซ่อมผ่าน Tenant Portal อยู่ในแพ็กเกจ Pro');
      }

      let list = [];
      if (roomId) {
        const targetRoom = await db.select().from(rooms).where(and(eq(rooms.id, tenant.roomId), eq(rooms.userId, tenant.userId), isNull(rooms.deletedAt)));
        if (targetRoom.length > 0) {
          list = await db.select()
            .from(maintenanceTickets)
            .where(and(eq(maintenanceTickets.roomId, targetRoom[0].id), eq(maintenanceTickets.userId, targetRoom[0].userId), isNull(maintenanceTickets.deletedAt)))
            .orderBy(desc(maintenanceTickets.createdAt));
        }
      } else if (roomNumber) {
        const targetRoom = await db.select().from(rooms).where(and(eq(rooms.id, tenant.roomId), eq(rooms.userId, tenant.userId), isNull(rooms.deletedAt)));
        if (targetRoom.length > 0) {
          list = await db.select()
            .from(maintenanceTickets)
            .where(and(eq(maintenanceTickets.roomId, targetRoom[0].id), eq(maintenanceTickets.userId, targetRoom[0].userId), isNull(maintenanceTickets.deletedAt)))
            .orderBy(desc(maintenanceTickets.createdAt));
        }
      }
      res.json(list);
    } catch (error: any) {
      console.error("Fetch tenant maintenance error:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการดึงรายการแจ้งซ่อมของผู้เช่า" });
    }
  });

  // 3. POST Create Maintenance Ticket
  app.post("/api/maintenance", async (req, res) => {
    try {
      const { roomId, roomNumber, tenantName, tenantPhone, title, description, category, priority, imageUrl } = req.body;
      if (!roomId || !title) {
        return res.status(400).json({ error: "กรุณาระบุห้องพักและหัวข้อเรื่องแจ้งซ่อม" });
      }
      const tenant = await getTenantSession(req);
      if (!tenant || tenant.roomId !== parseInt(roomId)) return res.status(401).json({ error: "กรุณายืนยันตัวตนผู้เช่าก่อนแจ้งซ่อม" });

      const targetRoom = await db.select().from(rooms).where(and(eq(rooms.id, tenant.roomId), eq(rooms.userId, tenant.userId), isNull(rooms.deletedAt)));
      if (targetRoom.length === 0) {
        return res.status(404).json({ error: "ไม่พบห้องพักที่ระบุ" });
      }

      const roomObj = targetRoom[0];
      const newTicket = await db.insert(maintenanceTickets).values({
        userId: roomObj.userId,
        roomId: roomObj.id,
        roomNumber: roomObj.roomNumber,
        tenantName: tenantName || roomObj.tenantName || 'ผู้เช่า',
        tenantPhone: tenantPhone || roomObj.tenantPhone || '',
        title: title.trim(),
        description: description ? description.trim() : '',
        category: category || 'other',
        priority: priority || 'medium',
        status: 'pending',
        imageUrl: imageUrl || null,
        repairCost: 0,
        technicianNote: '',
      }).returning();

      res.status(201).json(newTicket[0]);
    } catch (error: any) {
      console.error("Create maintenance ticket error:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการสร้างรายการแจ้งซ่อม" });
    }
  });

  // 4. PUT Update Maintenance Ticket
  app.put("/api/maintenance/:id", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (!hasPermission(req.dbUser!, PERMISSIONS.MANAGE_MAINTENANCE)) return res.status(403).json({ error: 'ไม่มีสิทธิ์จัดการงานแจ้งซ่อม' });
      const userId = getEffectiveUserId(req.dbUser!);
      const ticketId = parseInt(req.params.id);
      const { status, priority, category, repairCost, technicianNote } = req.body;

      const existing = await db.select()
        .from(maintenanceTickets)
        .where(and(eq(maintenanceTickets.id, ticketId), eq(maintenanceTickets.userId, userId)));

      if (existing.length === 0) {
        return res.status(404).json({ error: "ไม่พบรายการแจ้งซ่อมหรือคุณไม่มีสิทธิ์แก้ไข" });
      }

      const updateData: any = { updatedAt: new Date() };
      if (status !== undefined) updateData.status = status;
      if (priority !== undefined) updateData.priority = priority;
      if (category !== undefined) updateData.category = category;
      if (repairCost !== undefined) updateData.repairCost = parseInt(repairCost) || 0;
      if (technicianNote !== undefined) updateData.technicianNote = technicianNote;

      const updated = await db.update(maintenanceTickets)
        .set(updateData)
        .where(and(eq(maintenanceTickets.id, ticketId), eq(maintenanceTickets.userId, userId)))
        .returning();

      res.json(updated[0]);
    } catch (error: any) {
      console.error("Update maintenance ticket error:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการแก้ไขรายการแจ้งซ่อม" });
    }
  });

  // 5. DELETE Maintenance Ticket
  app.delete("/api/maintenance/:id", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (!hasPermission(req.dbUser!, PERMISSIONS.MANAGE_MAINTENANCE)) return res.status(403).json({ error: 'ไม่มีสิทธิ์จัดการงานแจ้งซ่อม' });
      const userId = getEffectiveUserId(req.dbUser!);
      const ticketId = parseInt(req.params.id);

      const deleted = await db.delete(maintenanceTickets)
        .where(and(eq(maintenanceTickets.id, ticketId), eq(maintenanceTickets.userId, userId)))
        .returning();

      if (deleted.length === 0) {
        return res.status(404).json({ error: "ไม่พบรายการแจ้งซ่อม" });
      }

      res.json({ success: true, message: "ลบรายการแจ้งซ่อมเรียบร้อยแล้ว" });
    } catch (error: any) {
      console.error("Delete maintenance ticket error:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการลบรายการแจ้งซ่อม" });
    }
  });

  // --- Lease Contracts Endpoints ---

  // 1. GET Lease Contracts
  app.get("/api/contracts", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (!hasPermission(req.dbUser!, PERMISSIONS.VIEW_CONTRACTS)) return res.status(403).json({ error: 'ไม่มีสิทธิ์ดูสัญญา' });
      const userId = getEffectiveUserId(req.dbUser!);
      const contracts = await db.select()
        .from(leaseContracts)
        .where(eq(leaseContracts.userId, userId))
        .orderBy(desc(leaseContracts.createdAt));

      // Calculate expiring_soon or expired dynamically based on current date
      const today = new Date().toISOString().substring(0, 10);
      const in60Days = new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toISOString().substring(0, 10);

      const processed = contracts.map(c => {
        let currentStatus = c.status;
        if (c.status !== 'terminated') {
          if (c.endDate < today) {
            currentStatus = 'expired';
          } else if (c.endDate <= in60Days) {
            currentStatus = 'expiring_soon';
          } else {
            currentStatus = 'active';
          }
        }
        return { ...c, status: currentStatus };
      });

      res.json(processed);
    } catch (error: any) {
      console.error("Fetch contracts error:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการดึงข้อมูลสัญญาเช่า" });
    }
  });

  // 2. POST Create Lease Contract
  app.post("/api/contracts", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (!hasPermission(req.dbUser!, PERMISSIONS.MANAGE_CONTRACTS)) return res.status(403).json({ error: 'ไม่มีสิทธิ์จัดการสัญญา' });
      const userId = getEffectiveUserId(req.dbUser!);
      const { roomId, tenantName, tenantPhone, idCardNumber, startDate, endDate, monthlyRent, depositAmount, advanceRentAmount, contractDocumentUrl, note } = req.body;

      if (!roomId || !tenantName || !startDate || !endDate) {
        return res.status(400).json({ error: "กรุณาระบุห้องพัก, ชื่อผู้เช่า, วันเริ่มและวันสิ้นสุดสัญญา" });
      }

      const targetRoom = await db.select().from(rooms).where(and(eq(rooms.id, parseInt(roomId)), eq(rooms.userId, userId)));
      if (targetRoom.length === 0) {
        return res.status(404).json({ error: "ไม่พบห้องพักที่เลือก" });
      }

      const roomObj = targetRoom[0];

      // Calculate initial status
      const today = new Date().toISOString().substring(0, 10);
      const in60Days = new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toISOString().substring(0, 10);
      let initialStatus = 'active';
      if (endDate < today) initialStatus = 'expired';
      else if (endDate <= in60Days) initialStatus = 'expiring_soon';

      // Insert new contract
      const newContract = await db.insert(leaseContracts).values({
        userId,
        roomId: roomObj.id,
        roomNumber: roomObj.roomNumber,
        tenantName: tenantName.trim(),
        tenantPhone: tenantPhone ? tenantPhone.trim() : null,
        idCardNumber: idCardNumber ? idCardNumber.trim() : null,
        startDate,
        endDate,
        monthlyRent: monthlyRent ? parseInt(monthlyRent) : roomObj.monthlyRent,
        depositAmount: depositAmount ? parseInt(depositAmount) : 0,
        advanceRentAmount: advanceRentAmount ? parseInt(advanceRentAmount) : 0,
        contractDocumentUrl: contractDocumentUrl || null,
        status: initialStatus,
        note: note ? note.trim() : null,
      }).returning();

      // Update room to occupied and update tenant info
      await db.update(rooms)
        .set({
          status: 'occupied',
          tenantName: tenantName.trim(),
          tenantPhone: tenantPhone ? tenantPhone.trim() : roomObj.tenantPhone,
        })
        .where(and(eq(rooms.id, roomObj.id), eq(rooms.userId, userId)));

      res.status(201).json(newContract[0]);
    } catch (error: any) {
      console.error("Create contract error:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการทำสัญญาเช่า" });
    }
  });

  // 3. PUT Update Lease Contract
  app.put("/api/contracts/:id", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (!hasPermission(req.dbUser!, PERMISSIONS.MANAGE_CONTRACTS)) return res.status(403).json({ error: 'ไม่มีสิทธิ์จัดการสัญญา' });
      const userId = getEffectiveUserId(req.dbUser!);
      const contractId = parseInt(req.params.id);
      const { tenantName, tenantPhone, idCardNumber, startDate, endDate, monthlyRent, depositAmount, advanceRentAmount, contractDocumentUrl, status, note } = req.body;

      const existing = await db.select().from(leaseContracts).where(and(eq(leaseContracts.id, contractId), eq(leaseContracts.userId, userId)));
      if (existing.length === 0) {
        return res.status(404).json({ error: "ไม่พบสัญญาเช่าที่ระบุ" });
      }

      const updateData: any = { updatedAt: new Date() };
      if (tenantName !== undefined) updateData.tenantName = tenantName.trim();
      if (tenantPhone !== undefined) updateData.tenantPhone = tenantPhone ? tenantPhone.trim() : null;
      if (idCardNumber !== undefined) updateData.idCardNumber = idCardNumber ? idCardNumber.trim() : null;
      if (startDate !== undefined) updateData.startDate = startDate;
      if (endDate !== undefined) updateData.endDate = endDate;
      if (monthlyRent !== undefined) updateData.monthlyRent = parseInt(monthlyRent) || 0;
      if (depositAmount !== undefined) updateData.depositAmount = parseInt(depositAmount) || 0;
      if (advanceRentAmount !== undefined) updateData.advanceRentAmount = parseInt(advanceRentAmount) || 0;
      if (contractDocumentUrl !== undefined) updateData.contractDocumentUrl = contractDocumentUrl;
      if (status !== undefined) updateData.status = status;
      if (note !== undefined) updateData.note = note;

      const updated = await db.update(leaseContracts)
        .set(updateData)
        .where(and(eq(leaseContracts.id, contractId), eq(leaseContracts.userId, userId)))
        .returning();

      // If active contract tenant info updated, sync with rooms table
      if (updated[0].status === 'active' || updated[0].status === 'expiring_soon') {
        await db.update(rooms)
          .set({
            tenantName: updated[0].tenantName,
            tenantPhone: updated[0].tenantPhone,
          })
          .where(and(eq(rooms.id, updated[0].roomId), eq(rooms.userId, userId)));
      }

      res.json(updated[0]);
    } catch (error: any) {
      console.error("Update contract error:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการแก้ไขสัญญาเช่า" });
    }
  });

  // 4. POST Checkout / Terminate Contract & Refund Deposit
  app.post("/api/contracts/:id/checkout", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (!hasPermission(req.dbUser!, PERMISSIONS.PROCESS_CHECKOUT)) return res.status(403).json({ error: 'ไม่มีสิทธิ์ดำเนินการย้ายออก' });
      const userId = getEffectiveUserId(req.dbUser!);
      const contractId = parseInt(req.params.id);

      const existing = await db.select().from(leaseContracts).where(and(eq(leaseContracts.id, contractId), eq(leaseContracts.userId, userId)));
      if (existing.length === 0) {
        return res.status(404).json({ error: "ไม่พบสัญญาเช่าที่ระบุ" });
      }

      const contractObj = existing[0];

      // Mark contract as terminated
      const updatedContract = await db.update(leaseContracts)
        .set({
          status: 'terminated',
          updatedAt: new Date().toISOString(),
        })
        .where(and(eq(leaseContracts.id, contractId), eq(leaseContracts.userId, userId)))
        .returning();

      // Update room to vacant
      await db.update(rooms)
        .set({
          status: 'vacant',
          tenantName: null,
          tenantPhone: null,
          lineUserId: null,
          lineDisplayName: null,
          linePictureUrl: null,
          lineStatus: 'unlinked',
          lineNotifyToken: null,
        })
        .where(and(eq(rooms.id, contractObj.roomId), eq(rooms.userId, userId)));

      await db.insert(housekeepingTasks).values({ userId, roomId: contractObj.roomId, contractId, source: 'checkout', status: 'pending', note: `ทำความสะอาดหลังย้ายออก: ${contractObj.tenantName}`, createdBy: req.dbUser!.id }).onConflictDoNothing();
      await logOperationalAudit(req, 'CHECKOUT_CONTRACT', 'contract', contractId, { roomId: contractObj.roomId, housekeepingCreated: true });

      res.json({ success: true, contract: updatedContract[0], message: "ทำรายการย้ายออกและคืนห้องพักสำเร็จ" });
    } catch (error: any) {
      console.error("Checkout contract error:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการทำรายการย้ายออก" });
    }
  });

  // 5. DELETE Lease Contract
  app.delete("/api/contracts/:id", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (!hasPermission(req.dbUser!, PERMISSIONS.MANAGE_CONTRACTS)) return res.status(403).json({ error: 'ไม่มีสิทธิ์จัดการสัญญา' });
      const userId = getEffectiveUserId(req.dbUser!);
      const contractId = parseInt(req.params.id);

      const deleted = await db.delete(leaseContracts)
        .where(and(eq(leaseContracts.id, contractId), eq(leaseContracts.userId, userId)))
        .returning();

      if (deleted.length === 0) {
        return res.status(404).json({ error: "ไม่พบสัญญาเช่า" });
      }

      res.json({ success: true, message: "ลบสัญญาเช่าเรียบร้อยแล้ว" });
    } catch (error: any) {
      console.error("Delete contract error:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการลบสัญญาเช่า" });
    }
  });

  // --- Internal Notes Endpoints ---

  app.use('/api/notes', requireAuth, async (req: AuthRequest, res, next) => {
    const actorId = req.dbUser?.id;
    if (!actorId) return res.status(401).json({ success: false, error: { code: 'UNAUTHORIZED', message: 'กรุณาเข้าสู่ระบบก่อนใช้งานโน้ต' } });
    const clientIp = String(req.ip || req.socket.remoteAddress || '127.0.0.1').slice(0, 64);
    const category = req.method === 'GET' ? 'notes_read' : 'notes_write';
    const limitCheck = await RateLimiterService.checkRateLimit(null, `${actorId}:${clientIp}`, category);
    if (!limitCheck.allowed) {
      res.setHeader('Retry-After', String(limitCheck.retryAfterSeconds));
      return res.status(429).json({
        success: false,
        error: { code: 'TOO_MANY_REQUESTS', message: `ทำรายการโน้ตถี่เกินไป กรุณารอ ${limitCheck.retryAfterSeconds} วินาที` },
      });
    }
    res.setHeader('Cache-Control', 'no-store');
    next();
  });

  app.get('/api/notes', async (req: AuthRequest, res) => {
    try {
      const userId = getEffectiveUserId(req.dbUser!);
      const rawLimit = Number.parseInt(String(req.query.limit || ''), 10);
      const rawOffset = Number.parseInt(String(req.query.offset || ''), 10);
      const limit = Number.isFinite(rawLimit) ? Math.min(Math.max(rawLimit, 1), NOTE_LIST_MAX_LIMIT) : NOTE_LIST_MAX_LIMIT;
      const offset = Number.isFinite(rawOffset) ? Math.min(Math.max(rawOffset, 0), 10_000) : 0;

      const list = await db.select({
        id: notes.id,
        userId: notes.userId,
        createdBy: notes.createdBy,
        createdByEmail: users.email,
        roomId: notes.roomId,
        roomNumber: rooms.roomNumber,
        title: notes.title,
        content: notes.content,
        color: notes.color,
        isPinned: notes.isPinned,
        createdAt: notes.createdAt,
        updatedAt: notes.updatedAt,
      })
        .from(notes)
        .leftJoin(users, eq(notes.createdBy, users.id))
        .leftJoin(rooms, eq(notes.roomId, rooms.id))
        .where(and(eq(notes.userId, userId), isNull(notes.deletedAt)))
        .orderBy(desc(notes.isPinned), desc(notes.updatedAt), desc(notes.id))
        .limit(limit)
        .offset(offset);

      res.json(list);
    } catch (error) {
      console.error('Fetch notes error:', error);
      res.status(500).json({ success: false, error: { code: 'DATABASE_ERROR', message: 'ไม่สามารถดึงข้อมูลโน้ตได้' } });
    }
  });

  app.post('/api/notes', async (req: AuthRequest, res) => {
    try {
      const parsed = NoteCreateSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({
          success: false,
          error: { code: 'VALIDATION_ERROR', message: parsed.error.issues[0]?.message || 'ข้อมูลโน้ตไม่ถูกต้อง', details: getNoteValidationDetails(parsed.error) },
        });
      }

      const userId = getEffectiveUserId(req.dbUser!);
      const input = parsed.data;
      let roomNumber: string | null = null;
      if (input.roomId !== null) {
        const [room] = await db.select({ roomNumber: rooms.roomNumber }).from(rooms)
          .where(and(eq(rooms.id, input.roomId), eq(rooms.userId, userId), isNull(rooms.deletedAt)))
          .limit(1);
        if (!room) return res.status(400).json({ success: false, error: { code: 'INVALID_ROOM', message: 'ไม่พบห้องพักที่เลือกในหอพักนี้' } });
        roomNumber = room.roomNumber;
      }

      const [created] = await db.insert(notes).values({
        userId,
        createdBy: req.dbUser!.id,
        roomId: input.roomId,
        title: input.title,
        content: input.content,
        color: input.color,
        isPinned: input.isPinned ? 1 : 0,
      }).returning();

      await logNoteAudit(req, 'CREATE_NOTE', created.id, {
        title: created.title,
        roomId: created.roomId,
        color: created.color,
        isPinned: created.isPinned,
        contentLength: created.content.length,
      });

      res.status(201).json({ ...created, createdByEmail: req.dbUser!.email, roomNumber });
    } catch (error) {
      console.error('Create note error:', error);
      res.status(500).json({ success: false, error: { code: 'DATABASE_ERROR', message: 'ไม่สามารถสร้างโน้ตได้' } });
    }
  });

  app.put('/api/notes/:id', async (req: AuthRequest, res) => {
    try {
      const noteId = Number.parseInt(req.params.id, 10);
      if (!Number.isInteger(noteId) || noteId <= 0) {
        return res.status(400).json({ success: false, error: { code: 'VALIDATION_ERROR', message: 'รหัสโน้ตไม่ถูกต้อง' } });
      }
      const parsed = NoteUpdateSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({
          success: false,
          error: { code: 'VALIDATION_ERROR', message: parsed.error.issues[0]?.message || 'ข้อมูลโน้ตไม่ถูกต้อง', details: getNoteValidationDetails(parsed.error) },
        });
      }

      const userId = getEffectiveUserId(req.dbUser!);
      const [existing] = await db.select().from(notes)
        .where(and(eq(notes.id, noteId), eq(notes.userId, userId), isNull(notes.deletedAt)))
        .limit(1);
      if (!existing) return res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'ไม่พบโน้ตที่ระบุ' } });

      const input = parsed.data;
      if (input.roomId !== undefined && input.roomId !== null) {
        const [room] = await db.select({ id: rooms.id }).from(rooms)
          .where(and(eq(rooms.id, input.roomId), eq(rooms.userId, userId), isNull(rooms.deletedAt)))
          .limit(1);
        if (!room) return res.status(400).json({ success: false, error: { code: 'INVALID_ROOM', message: 'ไม่พบห้องพักที่เลือกในหอพักนี้' } });
      }

      const updateData: Partial<typeof notes.$inferInsert> = { updatedAt: new Date().toISOString() };
      if (input.title !== undefined) updateData.title = input.title;
      if (input.content !== undefined) updateData.content = input.content;
      if (input.roomId !== undefined) updateData.roomId = input.roomId;
      if (input.color !== undefined) updateData.color = input.color;
      if (input.isPinned !== undefined) updateData.isPinned = input.isPinned ? 1 : 0;

      const [updated] = await db.update(notes).set(updateData)
        .where(and(eq(notes.id, noteId), eq(notes.userId, userId), isNull(notes.deletedAt)))
        .returning();

      await logNoteAudit(req, 'UPDATE_NOTE', noteId, {
        title: updated.title,
        roomId: updated.roomId,
        color: updated.color,
        isPinned: updated.isPinned,
        contentLength: updated.content.length,
      });
      res.json(updated);
    } catch (error) {
      console.error('Update note error:', error);
      res.status(500).json({ success: false, error: { code: 'DATABASE_ERROR', message: 'ไม่สามารถแก้ไขโน้ตได้' } });
    }
  });

  app.delete('/api/notes/:id', async (req: AuthRequest, res) => {
    try {
      const noteId = Number.parseInt(req.params.id, 10);
      if (!Number.isInteger(noteId) || noteId <= 0) {
        return res.status(400).json({ success: false, error: { code: 'VALIDATION_ERROR', message: 'รหัสโน้ตไม่ถูกต้อง' } });
      }
      const userId = getEffectiveUserId(req.dbUser!);
      const [deleted] = await db.update(notes)
        .set({ deletedAt: new Date().toISOString(), deletedBy: req.dbUser!.id, updatedAt: new Date().toISOString() })
        .where(and(eq(notes.id, noteId), eq(notes.userId, userId), isNull(notes.deletedAt)))
        .returning();
      if (!deleted) return res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'ไม่พบโน้ตที่ระบุ' } });

      await logNoteAudit(req, 'DELETE_NOTE', noteId, { title: deleted.title });
      res.json({ success: true, message: 'ลบโน้ตเรียบร้อยแล้ว' });
    } catch (error) {
      console.error('Delete note error:', error);
      res.status(500).json({ success: false, error: { code: 'DATABASE_ERROR', message: 'ไม่สามารถลบโน้ตได้' } });
    }
  });

  // --- Announcements & Notice Board Endpoints ---

  // 1. GET Announcements (Admin / Caretaker)
  app.get("/api/announcements", requireAuth, async (req: AuthRequest, res) => {
    try {
      const userId = getEffectiveUserId(req.dbUser!);
      const list = await db.select()
        .from(announcements)
        .where(eq(announcements.userId, userId))
        .orderBy(desc(announcements.isPinned), desc(announcements.createdAt));
      res.json(list);
    } catch (error: any) {
      console.error("Fetch announcements error:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการดึงข้อมูลประกาศข่าวสาร" });
    }
  });

  // 2. GET Announcements for Tenant (Public / Tenant Portal)
  app.get("/api/public/announcements", async (req, res) => {
    try {
      const { roomId } = req.query;
      const tenant = await getTenantSession(req);
      if (!tenant || !roomId || tenant.roomId !== parseInt(roomId.toString())) return res.status(401).json({ error: "กรุณายืนยันตัวตนผู้เช่าก่อนดูประกาศ" });
      if (!await ownerHasPlanFeature(tenant.userId, 'tenantPortal') || !await ownerHasPlanFeature(tenant.userId, 'announcements')) {
        return planRequiredResponse(res, 'ประกาศใน Tenant Portal อยู่ในแพ็กเกจ Pro');
      }

      let list = await db.select().from(announcements)
        .where(and(eq(announcements.userId, tenant.userId), isNull(announcements.deletedAt)))
        .orderBy(desc(announcements.isPinned), desc(announcements.createdAt));

      if (roomId) {
        const rId = roomId.toString();
        list = list.filter(item => {
          if (!item.targetRoomIds) return true; // targeted to all rooms
          const targets = item.targetRoomIds.split(',').map(t => t.trim());
          return targets.includes(rId);
        });
      }

      res.json(list);
    } catch (error: any) {
      console.error("Fetch tenant announcements error:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการดึงประกาศข่าวสาร" });
    }
  });

  // 3. POST Create Announcement
  app.post("/api/announcements", requireAuth, async (req: AuthRequest, res) => {
    try {
      const userId = getEffectiveUserId(req.dbUser!);
      const { title, content, category, isPinned, targetRoomIds, imageUrl } = req.body;

      if (!title || !content) {
        return res.status(400).json({ error: "กรุณาระบุหัวข้อและเนื้อหาประกาศ" });
      }

      const created = await db.insert(announcements).values({
        userId,
        title: title.trim(),
        content: content.trim(),
        category: category || 'general',
        isPinned: isPinned ? 1 : 0,
        targetRoomIds: targetRoomIds ? targetRoomIds.trim() : null,
        imageUrl: imageUrl || null,
      }).returning();

      res.status(201).json(created[0]);
    } catch (error: any) {
      console.error("Create announcement error:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการสร้างประกาศ" });
    }
  });

  // 4. PUT Update Announcement
  app.put("/api/announcements/:id", requireAuth, async (req: AuthRequest, res) => {
    try {
      const userId = getEffectiveUserId(req.dbUser!);
      const announcementId = parseInt(req.params.id);
      const { title, content, category, isPinned, targetRoomIds, imageUrl } = req.body;

      const existing = await db.select()
        .from(announcements)
        .where(and(eq(announcements.id, announcementId), eq(announcements.userId, userId)));

      if (existing.length === 0) {
        return res.status(404).json({ error: "ไม่พบประกาศหรือคุณไม่มีสิทธิ์แก้ไข" });
      }

      const updateData: any = { updatedAt: new Date() };
      if (title !== undefined) updateData.title = title.trim();
      if (content !== undefined) updateData.content = content.trim();
      if (category !== undefined) updateData.category = category;
      if (isPinned !== undefined) updateData.isPinned = isPinned ? 1 : 0;
      if (targetRoomIds !== undefined) updateData.targetRoomIds = targetRoomIds ? targetRoomIds.trim() : null;
      if (imageUrl !== undefined) updateData.imageUrl = imageUrl;

      const updated = await db.update(announcements)
        .set(updateData)
        .where(and(eq(announcements.id, announcementId), eq(announcements.userId, userId)))
        .returning();

      res.json(updated[0]);
    } catch (error: any) {
      console.error("Update announcement error:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการแก้ไขประกาศ" });
    }
  });

  // 5. DELETE Announcement
  app.delete("/api/announcements/:id", requireAuth, async (req: AuthRequest, res) => {
    try {
      const userId = getEffectiveUserId(req.dbUser!);
      const announcementId = parseInt(req.params.id);

      const deleted = await db.delete(announcements)
        .where(and(eq(announcements.id, announcementId), eq(announcements.userId, userId)))
        .returning();

      if (deleted.length === 0) {
        return res.status(404).json({ error: "ไม่พบประกาศที่ระบุ" });
      }

      res.json({ success: true, message: "ลบประกาศเรียบร้อยแล้ว" });
    } catch (error: any) {
      console.error("Delete announcement error:", error);
      res.status(500).json({ error: "เกิดข้อผิดพลาดในการลบประกาศ" });
    }
  });

  // V14 application Backup/Restore is intentionally Cloudflare D1-only.
  // Authenticate and authorize first so staff/caretakers do not learn deployment details.
  app.all('/api/admin/backup/*', requireAuth, async (req: AuthRequest, res) => {
    res.setHeader('Cache-Control', 'no-store');
    const role = String(req.dbUser?.role || '');
    if (role !== 'owner' && role !== 'super_admin') {
      return res.status(403).json({
        success: false,
        error: { code: 'FORBIDDEN', message: 'เฉพาะเจ้าของหอพักหรือผู้ดูแลระบบเท่านั้นที่ใช้ Backup/Restore ได้' },
      });
    }
    return res.status(501).json({
      success: false,
      error: {
        code: 'D1_REQUIRED',
        message: 'Backup/Restore V14 รองรับ Cloudflare D1 เท่านั้น',
      },
    });
  });

  // Vite development / production static server middleware setup
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
