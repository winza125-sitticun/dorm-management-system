#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "ต้องติดตั้ง Node.js 22+ ก่อน: pkg install nodejs"
  exit 1
fi
npm run setup:cloudflare
