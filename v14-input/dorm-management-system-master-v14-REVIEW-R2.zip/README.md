# Dorm Management System — V14 Master

นี่คือ **Master Project V14** สำหรับพัฒนาและสร้าง Demo / Basic / Standard / Pro จาก source เดียว โดย V14 เพิ่ม Application Backup/Restore สำหรับ Cloudflare D1

อย่า Deploy Master นี้ให้ลูกค้าโดยตรง ให้ใช้:

```bash
npm ci
npm run packages:release
```

หรือบน Windows ดับเบิลคลิก `BUILD-PACKAGES-WINDOWS.cmd`

อ่านรายละเอียดใน `MASTER_PROJECT_TH.md`, `RELEASE_NOTES_V14_TH.md` และ `package-plans/*.json`
