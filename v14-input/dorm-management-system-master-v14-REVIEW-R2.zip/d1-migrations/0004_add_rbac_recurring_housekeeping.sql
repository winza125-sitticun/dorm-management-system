CREATE TABLE IF NOT EXISTS recurring_charge_templates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  default_amount INTEGER NOT NULL DEFAULT 0 CHECK(default_amount >= 0),
  frequency TEXT NOT NULL DEFAULT 'monthly' CHECK(frequency IN ('monthly','quarterly','yearly')),
  billing_months TEXT NOT NULL DEFAULT '[1,2,3,4,5,6,7,8,9,10,11,12]',
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_recurring_templates_owner ON recurring_charge_templates(user_id, deleted_at);

CREATE TABLE IF NOT EXISTS room_recurring_charges (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  room_id INTEGER NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  template_id INTEGER NOT NULL REFERENCES recurring_charge_templates(id) ON DELETE CASCADE,
  amount_override INTEGER CHECK(amount_override IS NULL OR amount_override >= 0),
  is_enabled INTEGER NOT NULL DEFAULT 1,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(room_id, template_id)
);

CREATE INDEX IF NOT EXISTS idx_room_recurring_owner_room ON room_recurring_charges(user_id, room_id);

CREATE TABLE IF NOT EXISTS bill_charge_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  bill_id INTEGER NOT NULL REFERENCES bills(id) ON DELETE CASCADE,
  assignment_id INTEGER REFERENCES room_recurring_charges(id) ON DELETE SET NULL,
  label TEXT NOT NULL,
  amount INTEGER NOT NULL DEFAULT 0 CHECK(amount >= 0),
  kind TEXT NOT NULL DEFAULT 'manual' CHECK(kind IN ('recurring','manual','legacy')),
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_bill_charge_items_bill ON bill_charge_items(bill_id, sort_order, id);

CREATE TABLE IF NOT EXISTS housekeeping_tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  room_id INTEGER NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  assigned_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  contract_id INTEGER REFERENCES lease_contracts(id) ON DELETE SET NULL,
  source TEXT NOT NULL DEFAULT 'manual' CHECK(source IN ('manual','checkout')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','in_progress','ready_for_inspection','completed','cancelled')),
  note TEXT,
  inspection_note TEXT,
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
  completed_at TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_housekeeping_checkout_once ON housekeeping_tasks(contract_id) WHERE source = 'checkout' AND contract_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_housekeeping_owner_status ON housekeeping_tasks(user_id, status, created_at DESC);
