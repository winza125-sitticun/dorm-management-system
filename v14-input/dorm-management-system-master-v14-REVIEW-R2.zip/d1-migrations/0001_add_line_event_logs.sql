CREATE TABLE IF NOT EXISTS line_event_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type TEXT NOT NULL CHECK (type IN ('incoming', 'outgoing', 'error', 'system')),
  message TEXT NOT NULL,
  room_number TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_line_event_logs_user_created
  ON line_event_logs(user_id, created_at DESC);
