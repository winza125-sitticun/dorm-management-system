ALTER TABLE settings ADD COLUMN subscription_plan TEXT NOT NULL DEFAULT 'pro';
ALTER TABLE settings ADD COLUMN subscription_status TEXT NOT NULL DEFAULT 'active';
ALTER TABLE settings ADD COLUMN subscription_expires_at TEXT;
