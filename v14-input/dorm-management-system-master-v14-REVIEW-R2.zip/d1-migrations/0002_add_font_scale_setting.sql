ALTER TABLE settings
  ADD COLUMN font_scale TEXT NOT NULL DEFAULT 'medium'
  CHECK (font_scale IN ('small', 'medium', 'large'));
