# V14 Master Project

โฟลเดอร์นี้เป็น **ต้นฉบับกลางเพียงชุดเดียว** สำหรับพัฒนา Dorm Management System V14 โดยสืบทอด Master Package Builder architecture จาก V13

## หลักการ

- แก้ source code ที่ Master เท่านั้น
- ห้ามแก้ Demo / Basic / Standard / Pro แยกเป็น 4 source
- ความต่างเชิงพาณิชย์อยู่ใน `package-plans/*.json`
- `npm run packages:generate` สร้าง **PREVIEW** สำหรับ QA เท่านั้น
- สร้างไฟล์ส่งลูกค้าด้วย `BUILD-PACKAGES-WINDOWS.cmd` หรือ `npm run packages:release` เท่านั้น
- `packages:release` ต้องผ่าน full release gate + production build ก่อนจึงสร้าง `CUSTOMER-READY`
- ห้ามใช้ Preview เป็นไฟล์ Production

## V14 Backup / Restore

Application Backup ใช้ `.dormbackup` และออกแบบสำหรับ Cloudflare D1 เท่านั้นใน V14

Recovery มี 3 ชั้น:

1. `.dormbackup` — Application Backup/Restore ของ business data
2. **D1 raw export** — `npm run d1:backup`
3. **Cloudflare D1 Time Travel** — recovery ระดับฐานข้อมูล

`.dormbackup` ไม่ใช่ตัวแทนของ D1 raw export หรือ Time Travel. โดยตั้งใจให้ **users/password not restored**, **LINE/Google credentials not restored**, audit history และ subscription metadata ไม่ถูกย้อน

ก่อน Restore UI ต้องดาวน์โหลด **pre-restore** Backup สำเร็จก่อนเขียน D1 จริง หากเกิด partial failure ให้หยุดเขียนข้อมูลต่อและใช้ pre-restore / raw SQL / Time Travel ตามระดับเหตุการณ์

Demo สามารถ Export Backup แต่ Demo ไม่สามารถ Restore ได้; Basic / Standard / Pro จึงมีสิทธิ์ Restore ตาม Plan Entitlement

## Release gate

Master `npm test` ต้องรวม:

- Plan/RBAC/navigation regression
- Setup/Upgrade tests
- V14 Backup Safety Matrix ผ่าน `npm run test:backup`
- Customer handoff/recovery documentation assertions ผ่าน `npm run test:handoff`
- Master Package Builder/parity/audit tests

จากนั้น release gate ต้องผ่าน TypeScript/lint, Cloudflare type check และ production build ก่อน Builder จะสร้างแต่ละแพ็กเกจ, รัน customer tests, audit ไฟล์ต้องห้าม/secret/plan identity และค่อยสร้าง ZIP

ถ้าด่านใด fail ให้หยุดและแก้ error ก่อนส่งลูกค้า
