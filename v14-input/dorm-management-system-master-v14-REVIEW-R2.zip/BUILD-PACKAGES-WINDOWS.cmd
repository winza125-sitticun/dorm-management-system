@echo off
setlocal
cd /d "%~dp0"
title Dorm Management System - V14 Master Package Builder

echo ================================================================
echo  Dorm Management System - V14 Master Package Builder
echo ================================================================
echo.

where node >nul 2>&1 || (
  echo [ERROR] Node.js 22+ is required.
  pause
  exit /b 1
)
where npm >nul 2>&1 || (
  echo [ERROR] npm was not found.
  pause
  exit /b 1
)

echo Node:
node -v
for /f %%V in ('node -p "process.versions.node.split('.')[0]"') do set "NODE_MAJOR=%%V"
if not defined NODE_MAJOR (
  echo [ERROR] Unable to detect Node.js version.
  pause
  exit /b 1
)
if %NODE_MAJOR% LSS 22 (
  echo [ERROR] Node.js 22+ is required. Found major version %NODE_MAJOR%.
  pause
  exit /b 1
)
echo npm:
call npm -v
if errorlevel 1 goto :failed

echo.
echo Installing exact dependencies from package-lock.json...
call npm ci
if errorlevel 1 goto :failed

echo.
echo Running V14 release gate and building all customer packages...
call npm run packages:release
if errorlevel 1 goto :failed

echo.
echo [OK] V14 packages created in release-v14\
echo.
pause
exit /b 0

:failed
echo.
echo [ERROR] V14 package build stopped. No failed package should be delivered.
pause
exit /b 1
