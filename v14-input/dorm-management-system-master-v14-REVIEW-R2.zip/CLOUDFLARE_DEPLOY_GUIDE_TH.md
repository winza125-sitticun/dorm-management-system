# Cloudflare Deploy Guide — V14

วิธีแนะนำคือใช้ Wizard ในแพ็กเกจ ไม่ต้องแก้ `wrangler.jsonc` ด้วยมือ

## ติดตั้งครั้งแรก

Windows:

```text
SETUP-WINDOWS.cmd
```

Android / Termux:

```bash
bash SETUP-ANDROID.sh
```

## Deploy ครั้งต่อไป

Windows: `DEPLOY-WINDOWS.cmd`

หรือ:

```bash
npm run deploy:customer
```

## คำสั่งตรวจด้วยมือ

```bash
npm ci
npm run customer:preflight
npm run release:check
npm run build:pages
```

สร้าง Project ด้วยมือเมื่อจำเป็น:

```bash
npx wrangler pages project create <PROJECT_NAME> --production-branch main
```

Migration D1:

```bash
npm run d1:migrate:local
npm run d1:migrate:remote
```

Deploy:

```bash
npm run deploy:pages
```

หลัง Deploy ให้ใช้ URL จริงจาก `Project Domains` ที่ Wizard แสดง หรือเปิด Cloudflare Dashboard > Workers & Pages > Project > Deployments

## Secret

`JWT_SECRET` ต้องเก็บเป็น Cloudflare Secret เท่านั้น Wizard จะตรวจว่ามีหรือไม่ก่อนดำเนินการต่อ
