# คู่มือ Upgrade Package — Customer Delivery V14

V14 รองรับ **Upgrade เท่านั้น** และ **ไม่รองรับ Downgrade อัตโนมัติ** เพื่อหลีกเลี่ยงปัญหาข้อมูลเกิน limit ของแพ็กเกจต่ำกว่า

เส้นทางที่รองรับ:

- Demo → Basic / Standard / Pro
- Basic → Standard / Pro
- Standard → Pro

## Windows

ดับเบิลคลิก `UPGRADE-WINDOWS.cmd`

Upgrade Manager จะ:

1. ตรวจ/เลือกบัญชี Cloudflare
2. ถ้าโฟลเดอร์ใหม่ไม่มี `wrangler.jsonc` จะถาม Pages Project เดิมและ D1 Database เดิม
3. ตรวจว่า Project และ D1 มีอยู่จริง — โหมด Upgrade จะไม่สร้าง resource ใหม่
4. อ่าน `subscription_plan` ปัจจุบันจาก D1
5. สำรองข้อมูล D1 (Backup)
6. รัน release checks และ migration ที่ค้าง
7. แสดงแพ็กเกจต้นทาง → ปลายทาง
8. รอให้พิมพ์ `UPGRADE` ก่อนเปลี่ยนข้อมูลจริง
9. เปลี่ยน `subscription_plan`, ตรวจผล, build และ deploy ทับ Project เดิม
10. แสดง URL จริงจาก Cloudflare หลัง Deploy

## Basic → Standard

เลือกระบบเดิมของลูกค้าและเลือก `standard` เมื่อ Wizard ถาม ข้อมูลห้อง ผู้เช่า บิล และประวัติใน D1 เดิมจะไม่ถูกสร้างใหม่

## ข้อห้าม

- อย่าสร้าง D1 ใหม่สำหรับการ Upgrade
- อย่าลบฐานเดิมก่อน Upgrade
- อย่าข้าม Backup / release checks
- V14 ไม่มี Downgrade อัตโนมัติ
