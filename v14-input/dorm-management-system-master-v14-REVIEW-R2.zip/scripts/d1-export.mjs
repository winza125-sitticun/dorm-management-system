import { mkdirSync, readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import process from 'node:process';

export function databaseNameFromWrangler(text) {
  const match = text.match(/"database_name"\s*:\s*"([^"]+)"/);
  if (!match) throw new Error('database_name not found in wrangler.jsonc');
  const name = match[1].trim();
  if (!name || name === 'REPLACE_WITH_YOUR_D1_DATABASE_NAME') {
    throw new Error('Configure database_name in wrangler.jsonc before exporting D1');
  }
  return name;
}

export function commandUsesShell(bin, platform = process.platform) {
  return platform === 'win32' && /\.(?:cmd|bat)$/i.test(String(bin));
}

export function exportD1({ mode, outputArg, platform = process.platform } = {}) {
  if (!['--local', '--remote'].includes(mode) || !outputArg) {
    throw new Error('Usage: node scripts/d1-export.mjs (--local|--remote) <output.sql>');
  }

  const config = readFileSync(new URL('../wrangler.jsonc', import.meta.url), 'utf8');
  const databaseName = databaseNameFromWrangler(config);
  const output = resolve(outputArg);
  mkdirSync(dirname(output), { recursive: true });
  const npx = platform === 'win32' ? 'npx.cmd' : 'npx';
  const result = spawnSync(npx, ['wrangler', 'd1', 'export', databaseName, mode, `--output=${output}`], {
    stdio: 'inherit',
    shell: commandUsesShell(npx, platform),
  });
  if (result.error) throw result.error;
  return result.status ?? 1;
}

function isMainModule() {
  if (!process.argv[1]) return false;
  try {
    return resolve(process.argv[1]) === resolve(fileURLToPath(import.meta.url));
  } catch {
    return false;
  }
}

if (isMainModule()) {
  try {
    process.exitCode = exportD1({ mode: process.argv[2], outputArg: process.argv[3] });
  } catch (error) {
    console.error(`D1 export failed: ${error instanceof Error ? error.message : String(error)}`);
    process.exitCode = 1;
  }
}
