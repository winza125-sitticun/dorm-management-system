import { readFile, readdir } from 'node:fs/promises';
import { relative, resolve } from 'node:path';
import { deflateRawSync, inflateRawSync } from 'node:zlib';

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    table[n] = c >>> 0;
  }
  return table;
})();

export function crc32(buffer) {
  let c = 0xffffffff;
  for (const byte of buffer) c = CRC_TABLE[(c ^ byte) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

async function walkFiles(root, current = root, out = []) {
  const entries = await readdir(current, { withFileTypes: true });
  entries.sort((a, b) => a.name.localeCompare(b.name, 'en'));
  for (const entry of entries) {
    const full = resolve(current, entry.name);
    if (entry.isDirectory()) await walkFiles(root, full, out);
    else if (entry.isFile()) out.push(full);
  }
  return out;
}

function localHeader({ nameBytes, crc, compressedSize, uncompressedSize }) {
  const h = Buffer.alloc(30);
  h.writeUInt32LE(0x04034b50, 0);
  h.writeUInt16LE(20, 4);
  h.writeUInt16LE(0x0800, 6);
  h.writeUInt16LE(8, 8);
  h.writeUInt16LE(0, 10);
  h.writeUInt16LE(33, 12); // 1980-01-01, deterministic
  h.writeUInt32LE(crc, 14);
  h.writeUInt32LE(compressedSize, 18);
  h.writeUInt32LE(uncompressedSize, 22);
  h.writeUInt16LE(nameBytes.length, 26);
  h.writeUInt16LE(0, 28);
  return h;
}

function centralHeader({ nameBytes, crc, compressedSize, uncompressedSize, localOffset }) {
  const h = Buffer.alloc(46);
  h.writeUInt32LE(0x02014b50, 0);
  h.writeUInt16LE(20, 4);
  h.writeUInt16LE(20, 6);
  h.writeUInt16LE(0x0800, 8);
  h.writeUInt16LE(8, 10);
  h.writeUInt16LE(0, 12);
  h.writeUInt16LE(33, 14);
  h.writeUInt32LE(crc, 16);
  h.writeUInt32LE(compressedSize, 20);
  h.writeUInt32LE(uncompressedSize, 24);
  h.writeUInt16LE(nameBytes.length, 28);
  h.writeUInt16LE(0, 30);
  h.writeUInt16LE(0, 32);
  h.writeUInt16LE(0, 34);
  h.writeUInt16LE(0, 36);
  h.writeUInt32LE(0, 38);
  h.writeUInt32LE(localOffset, 42);
  return h;
}

export async function createZipFromDirectory(root) {
  const files = await walkFiles(root);
  if (files.length > 0xffff) throw new Error('ZIP file count exceeds non-ZIP64 limit');
  const localParts = [];
  const centralParts = [];
  let localOffset = 0;

  for (const full of files) {
    const name = relative(root, full).replaceAll('\\', '/');
    const nameBytes = Buffer.from(name, 'utf8');
    const data = await readFile(full);
    const compressed = deflateRawSync(data, { level: 9 });
    if (data.length > 0xffffffff || compressed.length > 0xffffffff || localOffset > 0xffffffff) throw new Error(`ZIP64 required for ${name}`);
    const crc = crc32(data);
    const local = localHeader({ nameBytes, crc, compressedSize: compressed.length, uncompressedSize: data.length });
    localParts.push(local, nameBytes, compressed);
    const central = centralHeader({ nameBytes, crc, compressedSize: compressed.length, uncompressedSize: data.length, localOffset });
    centralParts.push(central, nameBytes);
    localOffset += local.length + nameBytes.length + compressed.length;
  }

  const centralBuffer = Buffer.concat(centralParts);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(0, 4);
  end.writeUInt16LE(0, 6);
  end.writeUInt16LE(files.length, 8);
  end.writeUInt16LE(files.length, 10);
  end.writeUInt32LE(centralBuffer.length, 12);
  end.writeUInt32LE(localOffset, 16);
  end.writeUInt16LE(0, 20);
  return Buffer.concat([...localParts, centralBuffer, end]);
}

function findEocd(bytes) {
  const min = Math.max(0, bytes.length - 0xffff - 22);
  for (let i = bytes.length - 22; i >= min; i--) if (bytes.readUInt32LE(i) === 0x06054b50) return i;
  throw new Error('ZIP EOCD record not found');
}

export function verifyZipBytes(bytesInput) {
  const bytes = Buffer.isBuffer(bytesInput) ? bytesInput : Buffer.from(bytesInput);
  const eocd = findEocd(bytes);
  const disk = bytes.readUInt16LE(eocd + 4);
  const centralDisk = bytes.readUInt16LE(eocd + 6);
  if (disk !== 0 || centralDisk !== 0) throw new Error('Multi-disk ZIP is unsupported');
  const count = bytes.readUInt16LE(eocd + 10);
  const centralSize = bytes.readUInt32LE(eocd + 12);
  const centralOffset = bytes.readUInt32LE(eocd + 16);
  if (centralOffset + centralSize > eocd) throw new Error('Invalid central directory bounds');

  const entries = new Map();
  const names = [];
  let cursor = centralOffset;
  for (let i = 0; i < count; i++) {
    if (cursor + 46 > bytes.length || bytes.readUInt32LE(cursor) !== 0x02014b50) throw new Error(`Invalid central header at entry ${i}`);
    const flags = bytes.readUInt16LE(cursor + 8);
    const method = bytes.readUInt16LE(cursor + 10);
    const expectedCrc = bytes.readUInt32LE(cursor + 16);
    const compressedSize = bytes.readUInt32LE(cursor + 20);
    const uncompressedSize = bytes.readUInt32LE(cursor + 24);
    const nameLen = bytes.readUInt16LE(cursor + 28);
    const extraLen = bytes.readUInt16LE(cursor + 30);
    const commentLen = bytes.readUInt16LE(cursor + 32);
    const localOffset = bytes.readUInt32LE(cursor + 42);
    const nameStart = cursor + 46;
    const nameEnd = nameStart + nameLen;
    if (nameEnd + extraLen + commentLen > bytes.length) throw new Error(`Invalid central entry bounds at ${i}`);
    const name = bytes.subarray(nameStart, nameEnd).toString((flags & 0x0800) ? 'utf8' : 'utf8');

    if (localOffset + 30 > bytes.length || bytes.readUInt32LE(localOffset) !== 0x04034b50) throw new Error(`Invalid local header for ${name}`);
    const localNameLen = bytes.readUInt16LE(localOffset + 26);
    const localExtraLen = bytes.readUInt16LE(localOffset + 28);
    const dataStart = localOffset + 30 + localNameLen + localExtraLen;
    const dataEnd = dataStart + compressedSize;
    if (dataEnd > bytes.length) throw new Error(`Compressed data out of bounds for ${name}`);
    const compressed = bytes.subarray(dataStart, dataEnd);
    let data;
    if (method === 8) data = inflateRawSync(compressed);
    else if (method === 0) data = Buffer.from(compressed);
    else throw new Error(`Unsupported ZIP method ${method} for ${name}`);
    if (data.length !== uncompressedSize) throw new Error(`Uncompressed size mismatch for ${name}`);
    if (crc32(data) !== expectedCrc) throw new Error(`CRC mismatch for ${name}`);
    entries.set(name, data);
    names.push(name);
    cursor = nameEnd + extraLen + commentLen;
  }
  if (cursor !== centralOffset + centralSize) throw new Error('Central directory size mismatch');
  return { names, entries };
}
