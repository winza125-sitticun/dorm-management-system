import { readFileSync } from 'node:fs';
import process from 'node:process';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';

export function validateCustomerConfig(config) {
  const issues = [];
  const text = String(config ?? '');
  const checks = [
    ['Pages project name', /REPLACE_WITH_YOUR_PAGES_PROJECT/],
    ['D1 database name', /REPLACE_WITH_YOUR_D1_DATABASE_NAME/],
    ['D1 database_id', /00000000-0000-0000-0000-000000000000/],
  ];
  for (const [label, pattern] of checks) {
    if (pattern.test(text)) issues.push(`${label} is still a Cloudflare setup placeholder`);
  }
  return issues;
}

export function runCustomerPreflight() {
  const issues = [];
  const major = Number(process.versions.node.split('.')[0] || 0);
  if (major < 22) issues.push(`Node.js 22+ required (found ${process.version})`);

  let config = '';
  try {
    config = readFileSync(new URL('../wrangler.jsonc', import.meta.url), 'utf8');
  } catch (error) {
    issues.push(`Cannot read wrangler.jsonc: ${error instanceof Error ? error.message : String(error)}`);
  }

  issues.push(...validateCustomerConfig(config));

  if (issues.length) {
    console.error('Customer preflight failed:');
    for (const issue of issues) console.error(`- ${issue}`);
    console.error('Run `npm run setup:cloudflare` before deploying.');
    return 1;
  }

  console.log('Customer preflight passed: Node version and Cloudflare identifiers are configured.');
  return 0;
}

const invokedAsMain = process.argv[1] && resolve(process.argv[1]) === resolve(fileURLToPath(import.meta.url));
if (invokedAsMain) {
  process.exitCode = runCustomerPreflight();
}
