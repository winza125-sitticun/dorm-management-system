import { hashPassword, verifyPassword, validatePasswordPolicy } from '../../src/server/services/crypto.service.ts';
import { logAuditAction, logAuditActionStrict } from '../../src/server/services/audit.service.ts';
import { sanitizeInput } from '../../src/server/services/sanitizer.service.ts';
import { RateLimiterService } from '../../src/server/services/rateLimiter.service.ts';
import { UploadValidationService } from '../../src/server/services/uploadValidation.service.ts';
import {
  NOTE_LIST_MAX_LIMIT,
  NOTE_REQUEST_MAX_BYTES,
  NoteCreateSchema,
  NoteUpdateSchema,
  SetupSchema,
  LoginSchema,
  RoomSchema,
  BillSchema,
  SettingsSchema,
  getNoteValidationDetails,
  validateZod,
} from '../../src/server/validators/index.ts';
import { generateToken, verifyToken } from '../../src/server/services/jwt.service.ts';
import { APP_VERSION } from '../../src/generated/version.ts';
import { PERMISSIONS, hasAppPermission, permissionsForRole } from '../../src/constants/permissions.ts';
import { getPlanLimit, hasPlanFeature, isDemoPlan, normalizeSubscriptionPlan, type PlanFeature } from '../../src/constants/planEntitlements.ts';
import { isDemoMutationRestricted, minimumPaidPlanForFeature, requiredPlanFeatureForApiRequest, requiredPlanFeaturesForSettingsUpdate } from '../../src/server/services/planAccess.service.ts';
import { normalizeBillingMonths } from '../../src/utils/recurringCharges.ts';
import { canTransitionHousekeeping } from '../../src/utils/housekeeping.ts';
import { BACKUP_REQUEST_MAX_BYTES, type BackupDataV1, type BackupManifestV1 } from '../../src/utils/backupFormat.ts';
import { exportBusinessBackup, validateBackupForRestore, verifyRestoreToken } from '../../src/server/services/backup.service.ts';
import { loadRestoreCurrentState, prepareRestoreData, restoreBusinessBackup, verifyRestoredBackup, RestorePartialFailure } from '../../src/server/services/restore.service.ts';
import { BackupValidationError } from '../../src/server/validators/backup.ts';

function getJwtSecret(env: Env): string {
  if (!env.JWT_SECRET || env.JWT_SECRET.length < 32) {
    throw new Error("Server misconfiguration: JWT_SECRET must be set to at least 32 characters");
  }
  return env.JWT_SECRET;
}

type LineSettingsRow = Record<string, unknown> & {
  user_id: number;
  dorm_name?: string | null;
  line_channel_access_token: string | null;
  line_channel_secret: string | null;
  line_bot_enabled: number;
};

// The generated Env remains authoritative. These transitional query-result
// defaults keep the existing dynamic D1 row mapping type-safe at the binding
// boundary while individual API response schemas are migrated incrementally.
interface AppD1PreparedStatement extends D1PreparedStatement {
  bind(...values: unknown[]): AppD1PreparedStatement;
  first<T = Record<string, any>>(): Promise<T | null>;
  run<T = Record<string, any>>(): Promise<D1Result<T>>;
  all<T = Record<string, any>>(): Promise<D1Result<T>>;
}

interface AppD1Database extends D1Database {
  prepare(query: string): AppD1PreparedStatement;
  batch<T = Record<string, any>>(statements: AppD1PreparedStatement[]): Promise<D1Result<T>[]>;
}

type BoundedJsonResult =
  | { ok: true; data: Record<string, unknown> }
  | { ok: false; status: 400 | 413 | 415; code: string; message: string };

async function readBoundedJson(
  request: Request,
  maxBytes: number,
  messages: { entityName: string; invalid: string; tooLarge: string },
): Promise<BoundedJsonResult> {
  const contentType = String(request.headers.get('Content-Type') || '').toLowerCase();
  if (!contentType.includes('application/json')) {
    return { ok: false, status: 415, code: 'UNSUPPORTED_MEDIA_TYPE', message: `${messages.entityName}ต้องส่งเป็น application/json` };
  }

  const declaredLength = Number(request.headers.get('Content-Length'));
  if (Number.isFinite(declaredLength) && declaredLength > maxBytes) {
    return { ok: false, status: 413, code: 'PAYLOAD_TOO_LARGE', message: messages.tooLarge };
  }

  const reader = request.body?.getReader();
  if (!reader) return { ok: false, status: 400, code: 'INVALID_JSON', message: messages.invalid };

  const decoder = new TextDecoder();
  let bytesRead = 0;
  let raw = '';
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      bytesRead += value.byteLength;
      if (bytesRead > maxBytes) {
        await reader.cancel();
        return { ok: false, status: 413, code: 'PAYLOAD_TOO_LARGE', message: messages.tooLarge };
      }
      raw += decoder.decode(value, { stream: true });
    }
    raw += decoder.decode();
    const parsed: unknown = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      return { ok: false, status: 400, code: 'INVALID_JSON', message: messages.invalid };
    }
    return { ok: true, data: parsed as Record<string, unknown> };
  } catch {
    return { ok: false, status: 400, code: 'INVALID_JSON', message: messages.invalid };
  }
}

function decodeBase64(value: string): Uint8Array | null {
  try {
    const binary = atob(value);
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index++) {
      bytes[index] = binary.charCodeAt(index);
    }
    return bytes;
  } catch {
    return null;
  }
}

async function verifyLineWebhookSignature(rawBody: string, signature: string, channelSecret: string): Promise<boolean> {
  const encoder = new TextEncoder();
  const key = await crypto.subtle.importKey(
    'raw',
    encoder.encode(channelSecret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  const expected = new Uint8Array(await crypto.subtle.sign('HMAC', key, encoder.encode(rawBody)));
  const provided = decodeBase64(signature);
  if (!provided) return false;

  // Hash both values to a fixed length before the constant-time comparison.
  const [expectedHash, providedHash] = await Promise.all([
    crypto.subtle.digest('SHA-256', expected),
    crypto.subtle.digest('SHA-256', provided)
  ]);
  const subtle = crypto.subtle as SubtleCrypto & {
    timingSafeEqual(a: ArrayBuffer | ArrayBufferView, b: ArrayBuffer | ArrayBufferView): boolean;
  };
  return subtle.timingSafeEqual(expectedHash, providedHash);
}

function redactSettingsForAudit(value: unknown): Record<string, unknown> | null {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  const redacted = { ...(value as Record<string, unknown>) };
  for (const key of ['line_channel_access_token', 'line_channel_secret', 'lineChannelAccessToken', 'lineChannelSecret']) {
    if (key in redacted) redacted[key] = redacted[key] ? '********' : null;
  }
  return redacted;
}

const ALLOWED_ORIGINS = [
  'http://localhost:3000',
  'http://localhost:5173',
  'http://localhost:8788'
];

const SECURITY_HEADERS = {
  "Content-Type": "application/json; charset=utf-8",
  "Cache-Control": "no-store",
  "X-Frame-Options": "DENY",
  "X-Content-Type-Options": "nosniff",
  "X-XSS-Protection": "1; mode=block",
  "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
  "Referrer-Policy": "strict-origin-when-cross-origin",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Requested-With, X-CSRF-Token",
};

const jsonResponse = (data: any, status = 200, requestOrigin?: string | null) => {
  const origin = requestOrigin && ALLOWED_ORIGINS.includes(requestOrigin) ? requestOrigin : null;

  return new Response(JSON.stringify(data), {
    status,
    headers: {
      ...SECURITY_HEADERS,
      ...(origin ? { "Access-Control-Allow-Origin": origin, "Vary": "Origin" } : {}),
    },
  });
};

const successResponse = (data: any, message?: string, status = 200, requestOrigin?: string | null) => {
  return jsonResponse({
    success: true,
    data: sanitizeInput(data),
    ...(message ? { message: sanitizeInput(message) } : {})
  }, status, requestOrigin);
};

const errorResponse = (code: string, message: string, status = 400, details?: any[]) => {
  return jsonResponse({
    success: false,
    error: {
      code,
      message,
      ...(details ? { details } : {})
    }
  }, status);
};

class PlanAccessError extends Error {
  constructor(public code: 'PLAN_REQUIRED' | 'PLAN_LIMIT_REACHED', message: string, public status = 403) {
    super(message);
    this.name = 'PlanAccessError';
  }
}

function normalizeRoomName(name: string): string {
  if (!name) return "";
  let clean = name.toString().trim().toLowerCase()
    .replace(/^ห้อง\s*/, "")
    .replace(/\s+/g, "");
  
  const thaiNumberMap: Record<string, string> = {
    "แรก": "1", "หนึ่ง": "1", "สอง": "2", "สาม": "3", "สี่": "4", "ห้า": "5",
    "หก": "6", "เจ็ด": "7", "แปด": "8", "เก้า": "9", "สิบ": "10"
  };

  for (const [thaiWord, digit] of Object.entries(thaiNumberMap)) {
    if (clean === thaiWord) {
      clean = digit;
    } else {
      clean = clean.replace(new RegExp(thaiWord, 'g'), digit);
    }
  }
  
  return clean;
}

async function initTables(db: any) {
  if (!db) return;
  try {
    await db.batch([
      db.prepare(`
        CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          uid TEXT NOT NULL UNIQUE,
          email TEXT NOT NULL,
          role TEXT DEFAULT 'owner' NOT NULL,
          parent_id INTEGER,
          password TEXT NOT NULL,
          permissions TEXT DEFAULT 'manage_rooms,manage_bills,edit_payments' NOT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          deleted_at TIMESTAMP,
          deleted_by INTEGER
        );
      `),
      db.prepare(`
        CREATE TABLE IF NOT EXISTS settings (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL DEFAULT 1,
          dorm_name TEXT DEFAULT 'หอพักของฉัน' NOT NULL,
          default_elec_rate REAL DEFAULT 7 NOT NULL,
          default_water_rate REAL DEFAULT 13 NOT NULL,
          default_due_date_day INTEGER DEFAULT 5 NOT NULL,
          default_penalty_rate REAL DEFAULT 100 NOT NULL,
          promptpay_id TEXT,
          promptpay_name TEXT,
          line_channel_access_token TEXT,
          line_channel_secret TEXT,
          line_bot_enabled INTEGER DEFAULT 0,
          google_spreadsheet_id TEXT,
          subscription_plan TEXT NOT NULL DEFAULT 'pro',
          subscription_status TEXT NOT NULL DEFAULT 'active',
          subscription_expires_at TEXT,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
      `),
      db.prepare(`
        CREATE TABLE IF NOT EXISTS rooms (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL DEFAULT 1,
          room_number TEXT NOT NULL,
          monthly_rent INTEGER DEFAULT 0 NOT NULL,
          status TEXT DEFAULT 'vacant' NOT NULL,
          tenant_name TEXT,
          tenant_phone TEXT,
          line_user_id TEXT,
          line_display_name TEXT,
          line_picture_url TEXT,
          line_status TEXT DEFAULT 'unlinked',
          line_notify_token TEXT,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          deleted_at TIMESTAMP,
          deleted_by INTEGER
        );
      `),
      db.prepare(`
        CREATE TABLE IF NOT EXISTS bills (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL DEFAULT 1,
          room_id INTEGER NOT NULL,
          bill_month TEXT NOT NULL,
          prior_elec REAL DEFAULT 0 NOT NULL,
          current_elec REAL DEFAULT 0 NOT NULL,
          elec_deduct REAL DEFAULT 0 NOT NULL,
          elec_unit_cost REAL DEFAULT 7 NOT NULL,
          elec_cost REAL DEFAULT 0 NOT NULL,
          prior_water REAL DEFAULT 0 NOT NULL,
          current_water REAL DEFAULT 0 NOT NULL,
          water_unit_cost REAL DEFAULT 13 NOT NULL,
          water_cost REAL DEFAULT 0 NOT NULL,
          rent_cost INTEGER DEFAULT 0 NOT NULL,
          deposit_cost INTEGER DEFAULT 0 NOT NULL,
          other_cost INTEGER DEFAULT 0 NOT NULL,
          other_description TEXT,
          total_cost INTEGER DEFAULT 0 NOT NULL,
          due_date TEXT NOT NULL,
          status TEXT DEFAULT 'unpaid' NOT NULL,
          paid_at TIMESTAMP,
          slip_image TEXT,
          slip_uploaded_at TIMESTAMP,
          slip_status TEXT DEFAULT 'none' NOT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          deleted_at TIMESTAMP,
          deleted_by INTEGER
        );
      `),
      db.prepare(`
        CREATE TABLE IF NOT EXISTS maintenance_tickets (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL DEFAULT 1,
          room_id INTEGER NOT NULL,
          room_number TEXT NOT NULL,
          tenant_name TEXT,
          tenant_phone TEXT,
          title TEXT NOT NULL,
          description TEXT,
          category TEXT DEFAULT 'other' NOT NULL,
          priority TEXT DEFAULT 'medium' NOT NULL,
          status TEXT DEFAULT 'pending' NOT NULL,
          image_url TEXT,
          repair_cost INTEGER DEFAULT 0 NOT NULL,
          technician_note TEXT,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          deleted_at TIMESTAMP,
          deleted_by INTEGER
        );
      `),
      db.prepare(`
        CREATE TABLE IF NOT EXISTS lease_contracts (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL DEFAULT 1,
          room_id INTEGER NOT NULL,
          room_number TEXT NOT NULL,
          tenant_name TEXT NOT NULL,
          tenant_phone TEXT,
          id_card_number TEXT,
          start_date TEXT NOT NULL,
          end_date TEXT NOT NULL,
          monthly_rent INTEGER DEFAULT 0 NOT NULL,
          deposit_amount INTEGER DEFAULT 0 NOT NULL,
          advance_rent_amount INTEGER DEFAULT 0 NOT NULL,
          contract_document_url TEXT,
          status TEXT DEFAULT 'active' NOT NULL,
          note TEXT,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          deleted_at TIMESTAMP,
          deleted_by INTEGER
        );
      `),
      db.prepare(`
        CREATE TABLE IF NOT EXISTS announcements (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL DEFAULT 1,
          title TEXT NOT NULL,
          content TEXT NOT NULL,
          category TEXT DEFAULT 'general' NOT NULL,
          is_pinned INTEGER DEFAULT 0 NOT NULL,
          target_room_ids TEXT,
          image_url TEXT,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          deleted_at TIMESTAMP,
          deleted_by INTEGER
        );
      `),
      db.prepare(`
        CREATE TABLE IF NOT EXISTS notes (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          created_by INTEGER NOT NULL REFERENCES users(id),
          room_id INTEGER REFERENCES rooms(id) ON DELETE SET NULL,
          title TEXT NOT NULL CHECK(length(title) BETWEEN 1 AND 120),
          content TEXT NOT NULL CHECK(length(content) BETWEEN 1 AND 5000),
          color TEXT NOT NULL DEFAULT 'yellow' CHECK(color IN ('yellow', 'green', 'blue', 'pink', 'purple', 'gray')),
          is_pinned INTEGER NOT NULL DEFAULT 0 CHECK(is_pinned IN (0, 1)),
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
          deleted_at TEXT,
          deleted_by INTEGER
        );
      `),
      db.prepare(`
        CREATE TABLE IF NOT EXISTS audit_logs (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER,
          user_email TEXT NOT NULL,
          user_role TEXT DEFAULT 'owner' NOT NULL,
          action TEXT NOT NULL,
          target_type TEXT NOT NULL,
          target_id TEXT,
          old_value TEXT,
          new_value TEXT,
          ip_address TEXT,
          user_agent TEXT,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
      `),
      db.prepare(`CREATE INDEX IF NOT EXISTS idx_bills_room_id ON bills(room_id);`),
      db.prepare(`CREATE INDEX IF NOT EXISTS idx_bills_bill_month ON bills(bill_month);`),
      db.prepare(`CREATE INDEX IF NOT EXISTS idx_bills_status ON bills(status);`),
      db.prepare(`CREATE INDEX IF NOT EXISTS idx_rooms_status ON rooms(status);`),
      db.prepare(`CREATE UNIQUE INDEX IF NOT EXISTS idx_bills_unique_active ON bills(user_id, room_id, bill_month) WHERE deleted_at IS NULL;`),
      db.prepare(`CREATE INDEX IF NOT EXISTS idx_notes_user_active_updated ON notes(user_id, deleted_at, is_pinned, updated_at DESC);`),
      db.prepare(`CREATE INDEX IF NOT EXISTS idx_notes_room_id ON notes(room_id);`),
      db.prepare(`
        CREATE TABLE IF NOT EXISTS google_oauth_states (
          state TEXT PRIMARY KEY,
          user_id INTEGER NOT NULL,
          expires_at INTEGER NOT NULL
        );
      `),
      db.prepare(`
        CREATE TABLE IF NOT EXISTS google_oauth_tokens (
          user_id INTEGER PRIMARY KEY,
          refresh_token TEXT NOT NULL,
          updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
      `),
      db.prepare(`
        CREATE TABLE IF NOT EXISTS rate_limits (
          key TEXT PRIMARY KEY,
          count INTEGER NOT NULL DEFAULT 0,
          reset_at INTEGER NOT NULL
        );
      `),
      db.prepare(`CREATE TABLE IF NOT EXISTS recurring_charge_templates (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, name TEXT NOT NULL, description TEXT,
        default_amount INTEGER NOT NULL DEFAULT 0, frequency TEXT NOT NULL DEFAULT 'monthly',
        billing_months TEXT NOT NULL DEFAULT '[1,2,3,4,5,6,7,8,9,10,11,12]', is_active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP, deleted_at TEXT
      );`),
      db.prepare(`CREATE TABLE IF NOT EXISTS room_recurring_charges (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, room_id INTEGER NOT NULL, template_id INTEGER NOT NULL,
        amount_override INTEGER, is_enabled INTEGER NOT NULL DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP, UNIQUE(room_id, template_id)
      );`),
      db.prepare(`CREATE TABLE IF NOT EXISTS bill_charge_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT, bill_id INTEGER NOT NULL, assignment_id INTEGER, label TEXT NOT NULL,
        amount INTEGER NOT NULL DEFAULT 0, kind TEXT NOT NULL DEFAULT 'manual', sort_order INTEGER NOT NULL DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
      );`),
      db.prepare(`CREATE TABLE IF NOT EXISTS housekeeping_tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, room_id INTEGER NOT NULL, assigned_user_id INTEGER,
        contract_id INTEGER, source TEXT NOT NULL DEFAULT 'manual', status TEXT NOT NULL DEFAULT 'pending', note TEXT,
        inspection_note TEXT, created_by INTEGER, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP, completed_at TEXT
      );`),
      db.prepare(`CREATE INDEX IF NOT EXISTS idx_recurring_templates_owner ON recurring_charge_templates(user_id, deleted_at);`),
      db.prepare(`CREATE INDEX IF NOT EXISTS idx_room_recurring_owner_room ON room_recurring_charges(user_id, room_id);`),
      db.prepare(`CREATE INDEX IF NOT EXISTS idx_bill_charge_items_bill ON bill_charge_items(bill_id, sort_order, id);`),
      db.prepare(`CREATE UNIQUE INDEX IF NOT EXISTS idx_housekeeping_checkout_once ON housekeeping_tasks(contract_id) WHERE source = 'checkout' AND contract_id IS NOT NULL;`),
      db.prepare(`CREATE INDEX IF NOT EXISTS idx_housekeeping_owner_status ON housekeeping_tasks(user_id, status, created_at DESC);`),
      db.prepare(`CREATE INDEX IF NOT EXISTS idx_rate_limits_reset_at ON rate_limits(reset_at);`)
    ]);
  } catch (e) {
    console.warn("DB init notice:", e);
  }
}

async function autoSeedD1Database(db: any) {
  if (!db) return;
  try {
    // SECURITY: Only seed sample rooms/bills once an owner already exists (set
    // up via the First Setup Wizard). We deliberately do NOT auto-create an
    // owner account, because that would block the legitimate setup flow and
    // could never be logged into safely.
    const owner = await db.prepare("SELECT id FROM users WHERE role IN ('owner', 'super_admin') AND deleted_at IS NULL ORDER BY id ASC LIMIT 1").first();
    if (!owner) {
      return; // No owner yet — wait for the First Setup Wizard to create one.
    }
    const userId = owner.id;

    const roomCount = await db.prepare("SELECT COUNT(*) as count FROM rooms WHERE deleted_at IS NULL").first();
    if (roomCount && (roomCount.count || 0) > 0) {
      return;
    }


    // 2. Default Settings
    const existingSettings = await db.prepare("SELECT id FROM settings WHERE user_id = ?").bind(userId).first();
    if (!existingSettings) {
      await db.prepare(`
        INSERT INTO settings (user_id, dorm_name, default_elec_rate, default_water_rate, default_due_date_day, default_penalty_rate, promptpay_id, promptpay_name)
        VALUES (?, 'หอพักกรีนวิลล์', 7, 13, 5, 100, '0812345678', 'เจ้าของหอพัก')
      `).bind(userId).run();
    }

    // 3. Seed Rooms
    const room101Res = await db.prepare(`
      INSERT INTO rooms (user_id, room_number, monthly_rent, status, tenant_name, tenant_phone)
      VALUES (?, '101', 3500, 'occupied', 'คุณสมชาย ใจดี', '0812345678')
      RETURNING id
    `).bind(userId).first();
    if (!room101Res || !room101Res.id) return;
    const room101Id = room101Res.id;

    const room102Res = await db.prepare(`
      INSERT INTO rooms (user_id, room_number, monthly_rent, status, tenant_name, tenant_phone)
      VALUES (?, '102', 4000, 'occupied', 'คุณวิภาดา ปัญญา', '0898765432')
      RETURNING id
    `).bind(userId).first();
    if (!room102Res || !room102Res.id) return;
    const room102Id = room102Res.id;

    await db.prepare(`
      INSERT INTO rooms (user_id, room_number, monthly_rent, status, tenant_name, tenant_phone)
      VALUES (?, '103', 3500, 'vacant', NULL, NULL)
    `).bind(userId).run();

    // 4. Seed Unpaid Bills for current month
    const now = new Date();
    const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    const dueDate = `${currentMonth}-05`;

    await db.prepare(`
      INSERT INTO bills (user_id, room_id, bill_month, prior_elec, current_elec, elec_unit_cost, elec_cost, prior_water, current_water, water_unit_cost, water_cost, rent_cost, total_cost, due_date, status, slip_status)
      VALUES (?, ?, ?, 100, 150, 7, 350, 10, 15, 15, 75, 3500, 3925, ?, 'unpaid', 'none')
    `).bind(userId, room101Id, currentMonth, dueDate).run();

    await db.prepare(`
      INSERT INTO bills (user_id, room_id, bill_month, prior_elec, current_elec, elec_unit_cost, elec_cost, prior_water, current_water, water_unit_cost, water_cost, rent_cost, other_cost, other_description, total_cost, due_date, status, slip_status)
      VALUES (?, ?, ?, 200, 270, 7, 490, 20, 32, 13, 156, 4000, 28, 'ขยะและส่วนกลาง', 4674, ?, 'unpaid', 'none')
    `).bind(userId, room102Id, currentMonth, dueDate).run();

  } catch (e) {
    console.warn("Auto-seed D1 notice:", e);
  }
}

export const onRequest: PagesFunction<Env> = async (context) => {
  const { request } = context;
  const env = { ...context.env, DB: context.env.DB as AppD1Database };
  const url = new URL(request.url);
  const path = url.pathname;
  const method = request.method;

  if (method === "OPTIONS") return jsonResponse({ ok: true }, 200, request.headers.get("Origin"));

  const forwardedIp = request.headers.get("X-Forwarded-For")?.split(',')[0]?.trim();
  const clientIp = String(request.headers.get("CF-Connecting-IP") || forwardedIp || "127.0.0.1").slice(0, 64);
  const userAgent = request.headers.get("User-Agent") || "Unknown Browser";

  // Rate Limiting Security Check
  const isAuthRoute = path === "/api/auth/login" || path === "/api/setup/init";
  const isNotesRoute = path === '/api/notes' || path.startsWith('/api/notes/');
  const limitCategory = isAuthRoute
    ? 'auth'
    : path.includes('/upload')
      ? 'upload'
      : isNotesRoute
        ? (method === 'GET' ? 'notes_read' : 'notes_write')
        : 'api';
  const limitCheck = await RateLimiterService.checkRateLimit(env.DB, clientIp, limitCategory);

  if (!limitCheck.allowed) {
    return errorResponse(
      "TOO_MANY_REQUESTS",
      `คุณทำรายการถี่เกินไป กรุณารอ ${limitCheck.retryAfterSeconds} วินาทีก่อนลองใหม่อีกครั้ง`,
      429
    );
  }

  try {
    // 1. Health check
    if (path === "/api/health") {
      return successResponse({ status: "ok", mode: "cloudflare-pages", version: APP_VERSION });
    }

    // Helper: Parse JSON Body
    const getJson = async (): Promise<any> => {
      try { return await request.json(); } catch { return {}; }
    };
    const getTenantSession = async () => {
      const authHeader = request.headers.get("Authorization");
      if (!authHeader?.startsWith("Bearer ")) return null;
      const payload = await verifyToken(authHeader.slice(7), getJwtSecret(env));
      if (!payload || payload.role !== "tenant" || !Number.isInteger(payload.roomId) || !Number.isInteger(payload.userId)) return null;
      return { roomId: payload.roomId as number, userId: payload.userId as number };
    };

    const mapTenantRoom = (room: any) => ({
      id: room.id,
      roomNumber: room.room_number,
      monthlyRent: room.monthly_rent || 0,
      status: room.status,
      tenantName: room.tenant_name,
      tenantPhone: room.tenant_phone,
      lineStatus: room.line_status,
      lineDisplayName: room.line_display_name,
      linePictureUrl: room.line_picture_url,
    });

    const mapTenantBill = (bill: any) => ({
      id: bill.id,
      roomId: bill.room_id,
      userId: bill.user_id,
      billMonth: bill.bill_month,
      priorElec: bill.prior_elec || 0,
      currentElec: bill.current_elec || 0,
      elecDeduct: bill.elec_deduct || 0,
      elecUnitCost: bill.elec_unit_cost || 0,
      elecCost: bill.elec_cost || 0,
      priorWater: bill.prior_water || 0,
      currentWater: bill.current_water || 0,
      waterUnitCost: bill.water_unit_cost || 0,
      waterCost: bill.water_cost || 0,
      rentCost: bill.rent_cost || 0,
      depositCost: bill.deposit_cost || 0,
      otherCost: bill.other_cost || 0,
      otherDescription: bill.other_description,
      totalCost: bill.total_cost || 0,
      dueDate: bill.due_date,
      status: bill.status,
      paidAt: bill.paid_at,
      slipImage: bill.slip_image,
      slipUploadedAt: bill.slip_uploaded_at,
      slipStatus: bill.slip_status,
    });

    const mapTenantSettings = (settings: any) => ({
      id: settings.id,
      userId: settings.user_id,
      dormName: settings.dorm_name || 'หอพักของฉัน',
      promptpayId: settings.promptpay_id,
      promptpayName: settings.promptpay_name,
    });

    const mapMaintenanceTicket = (ticket: any) => ({
      id: ticket.id,
      userId: ticket.user_id,
      roomId: ticket.room_id,
      roomNumber: ticket.room_number,
      tenantName: ticket.tenant_name,
      tenantPhone: ticket.tenant_phone,
      title: ticket.title,
      description: ticket.description,
      category: ticket.category,
      priority: ticket.priority,
      status: ticket.status,
      imageUrl: ticket.image_url,
      repairCost: ticket.repair_cost || 0,
      technicianNote: ticket.technician_note,
      createdAt: ticket.created_at,
      updatedAt: ticket.updated_at,
    });

    const publicRoomMatch = path.match(/^\/api\/public\/rooms\/(\d+)$/);
    if (publicRoomMatch && method === 'GET') {
      const roomId = Number(publicRoomMatch[1]);
      const tenant = await getTenantSession();
      if (!tenant || tenant.roomId !== roomId) {
        return errorResponse('UNAUTHORIZED', 'กรุณายืนยันตัวตนผู้เช่าก่อนดูข้อมูลห้องพัก', 401);
      }
      if (!await ownerHasPlanFeature(tenant.userId, 'tenantPortal')) {
        return errorResponse('PLAN_REQUIRED', 'Tenant Portal อยู่ในแพ็กเกจ Pro', 403);
      }
      if (!env.DB) return errorResponse('DATABASE_ERROR', 'ไม่พบการเชื่อมต่อฐานข้อมูล D1', 500);

      const room = await env.DB.prepare(
        'SELECT * FROM rooms WHERE id = ? AND user_id = ? AND deleted_at IS NULL'
      ).bind(roomId, tenant.userId).first();
      if (!room) return errorResponse('NOT_FOUND', 'ไม่พบข้อมูลห้องพัก', 404);

      const rawSettings = await env.DB.prepare('SELECT * FROM settings WHERE user_id = ?').bind(tenant.userId).first() || {};
      const { results: rawBills } = await env.DB.prepare(
        'SELECT * FROM bills WHERE room_id = ? AND user_id = ? AND deleted_at IS NULL ORDER BY bill_month DESC'
      ).bind(roomId, tenant.userId).all();
      const { results: rawChargeItems } = await env.DB.prepare('SELECT i.* FROM bill_charge_items i JOIN bills b ON b.id=i.bill_id WHERE b.user_id=? AND b.room_id=? AND b.deleted_at IS NULL ORDER BY i.sort_order,i.id').bind(tenant.userId, roomId).all();
      const bills = (rawBills || []).map((row: any) => ({ ...mapTenantBill(row), chargeItems: (rawChargeItems || []).filter((item: any) => Number(item.bill_id) === Number(row.id)).map((item: any) => ({ id: item.id, billId: item.bill_id, assignmentId: item.assignment_id, label: item.label, amount: item.amount, kind: item.kind, sortOrder: item.sort_order })) }));

      return successResponse({
        tenantToken: request.headers.get('Authorization')?.slice(7),
        room: mapTenantRoom(room),
        settings: mapTenantSettings(rawSettings),
        unpaidBills: bills.filter((bill: any) => bill.status === 'unpaid' || bill.slipStatus === 'pending' || bill.slipStatus === 'rejected'),
        paidBills: bills.filter((bill: any) => bill.status === 'paid' && bill.slipStatus !== 'pending').slice(0, 10),
      });
    }

    const uploadSlipMatch = path.match(/^\/api\/public\/bills\/(\d+)\/upload-slip$/);
    if (uploadSlipMatch && method === 'POST') {
      const tenant = await getTenantSession();
      if (!tenant) return errorResponse('UNAUTHORIZED', 'กรุณายืนยันตัวตนผู้เช่าก่อนอัปโหลดสลิป', 401);
      if (!await ownerHasPlanFeature(tenant.userId, 'tenantPortal')) {
        return errorResponse('PLAN_REQUIRED', 'Tenant Portal อยู่ในแพ็กเกจ Pro', 403);
      }
      if (!env.DB) return errorResponse('DATABASE_ERROR', 'ไม่พบการเชื่อมต่อฐานข้อมูล D1', 500);

      const billId = Number(uploadSlipMatch[1]);
      const body = await getJson();
      const slipImage = String(body.slipImage || '');
      const dataUrlMatch = slipImage.match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/i);
      if (!dataUrlMatch) return errorResponse('VALIDATION_ERROR', 'รองรับเฉพาะสลิป JPG, PNG หรือ WEBP', 400);
      const estimatedBytes = Math.floor((dataUrlMatch[2].length * 3) / 4);
      const uploadValidation = UploadValidationService.validateUpload(dataUrlMatch[1], estimatedBytes);
      if (!uploadValidation.valid) return errorResponse('VALIDATION_ERROR', uploadValidation.error || 'ไฟล์สลิปไม่ถูกต้อง', 400);

      const bill = await env.DB.prepare(
        'SELECT id FROM bills WHERE id = ? AND room_id = ? AND user_id = ? AND deleted_at IS NULL'
      ).bind(billId, tenant.roomId, tenant.userId).first();
      if (!bill) return errorResponse('NOT_FOUND', 'ไม่พบบิลที่ระบุ', 404);

      await env.DB.prepare(
        "UPDATE bills SET slip_image = ?, slip_uploaded_at = CURRENT_TIMESTAMP, slip_status = 'pending' WHERE id = ? AND room_id = ? AND user_id = ?"
      ).bind(slipImage, billId, tenant.roomId, tenant.userId).run();
      return successResponse({ success: true }, 'อัปโหลดสลิปเรียบร้อยแล้ว');
    }

    if (path === '/api/tenant/maintenance' && method === 'GET') {
      const tenant = await getTenantSession();
      const requestedRoomId = Number(url.searchParams.get('roomId'));
      if (!tenant || !requestedRoomId || tenant.roomId !== requestedRoomId) {
        return errorResponse('UNAUTHORIZED', 'กรุณายืนยันตัวตนผู้เช่าก่อนดูรายการแจ้งซ่อม', 401);
      }
      if (!await ownerHasPlanFeature(tenant.userId, 'tenantPortal') || !await ownerHasPlanFeature(tenant.userId, 'maintenance')) {
        return errorResponse('PLAN_REQUIRED', 'แจ้งซ่อมผ่าน Tenant Portal อยู่ในแพ็กเกจ Pro', 403);
      }
      if (!env.DB) return errorResponse('DATABASE_ERROR', 'ไม่พบการเชื่อมต่อฐานข้อมูล D1', 500);
      const { results } = await env.DB.prepare(
        'SELECT * FROM maintenance_tickets WHERE room_id = ? AND user_id = ? AND deleted_at IS NULL ORDER BY created_at DESC'
      ).bind(tenant.roomId, tenant.userId).all();
      return successResponse((results || []).map(mapMaintenanceTicket));
    }

    if (path === '/api/public/announcements' && method === 'GET') {
      const tenant = await getTenantSession();
      const requestedRoomId = Number(url.searchParams.get('roomId'));
      if (!tenant || !requestedRoomId || tenant.roomId !== requestedRoomId) {
        return errorResponse('UNAUTHORIZED', 'กรุณายืนยันตัวตนผู้เช่าก่อนดูประกาศ', 401);
      }
      if (!await ownerHasPlanFeature(tenant.userId, 'tenantPortal') || !await ownerHasPlanFeature(tenant.userId, 'announcements')) {
        return errorResponse('PLAN_REQUIRED', 'ประกาศใน Tenant Portal อยู่ในแพ็กเกจ Pro', 403);
      }
      if (!env.DB) return errorResponse('DATABASE_ERROR', 'ไม่พบการเชื่อมต่อฐานข้อมูล D1', 500);
      const { results } = await env.DB.prepare(
        'SELECT * FROM announcements WHERE user_id = ? AND deleted_at IS NULL ORDER BY is_pinned DESC, created_at DESC'
      ).bind(tenant.userId).all();
      const visible = (results || []).filter((item: any) => {
        if (!item.target_room_ids) return true;
        return String(item.target_room_ids).split(',').map((value: string) => value.trim()).includes(String(tenant.roomId));
      });
      return successResponse(visible.map((item: any) => ({
        id: item.id,
        userId: item.user_id,
        title: item.title,
        content: item.content,
        category: item.category,
        isPinned: item.is_pinned,
        targetRoomIds: item.target_room_ids,
        imageUrl: item.image_url,
        createdAt: item.created_at,
        updatedAt: item.updated_at,
      })));
    }

    // ──────────────────────────────────────────────
    // 1.5 PUBLIC API (Tenant Portal & LINE Verification)
    // ──────────────────────────────────────────────
    if (path === "/api/public/line/verify" && method === "POST") {
      const body = await getJson();
      const roomNumber = String(body.roomNumber || '').trim();
      const tenantPhone = String(body.tenantPhone || '').trim();

      if (!roomNumber || !tenantPhone) {
        return errorResponse("VALIDATION_ERROR", "กรุณากรอกเลขห้องและเบอร์โทรศัพท์ให้ครบถ้วน", 400);
      }

      if (env.DB) {
        try {
          const { results: allRooms } = await env.DB.prepare("SELECT * FROM rooms WHERE room_number = ? COLLATE NOCASE AND deleted_at IS NULL").bind(roomNumber).all();
          const cleanPhoneInput = tenantPhone.replace(/[- ]/g, "");

          let roomMatch = allRooms.filter((r: any) => {
            const cleanRoomPhone = (r.tenant_phone || "").replace(/[- ]/g, "");
            return cleanRoomPhone === cleanPhoneInput;
          });

          if (roomMatch.length === 0) {
            return errorResponse("NOT_FOUND", `ไม่พบหมายเลขห้อง "${roomNumber}" ในระบบ`, 404);
          }

          const room = roomMatch[0];
          const userId = room.user_id;
          const cleanRoomPhone = (room.tenant_phone || "").replace(/[- ]/g, "");
          if (!await ownerHasPlanFeature(Number(userId), 'tenantPortal')) {
            return errorResponse('PLAN_REQUIRED', 'Tenant Portal ยังไม่เปิดในแพ็กเกจนี้', 403);
          }

          if (cleanRoomPhone && cleanPhoneInput !== cleanRoomPhone) {
            return errorResponse("VALIDATION_ERROR", "เบอร์โทรศัพท์ไม่ตรงกับข้อมูลในระบบ", 400);
          }

          const rawSettings = await env.DB.prepare("SELECT * FROM settings WHERE user_id = ?").bind(userId).first() || {};
          const userSettings = {
            id: rawSettings.id,
            userId: rawSettings.user_id,
            dormName: rawSettings.dorm_name || "หอพักของฉัน",
            promptpayId: rawSettings.promptpay_id,
            promptpayName: rawSettings.promptpay_name
          };

          const { results: rawUnpaid } = await env.DB.prepare("SELECT * FROM bills WHERE room_id = ? AND user_id = ? AND status = 'unpaid' AND deleted_at IS NULL ORDER BY bill_month DESC").bind(room.id, userId).all();
          const { results: rawPaid } = await env.DB.prepare("SELECT * FROM bills WHERE room_id = ? AND user_id = ? AND status = 'paid' AND deleted_at IS NULL ORDER BY bill_month DESC LIMIT 5").bind(room.id, userId).all();

          const mapBill = (b: any) => ({
            id: b.id,
            roomId: b.room_id,
            userId: b.user_id,
            billMonth: b.bill_month,
            totalCost: b.total_cost || 0,
            rentCost: b.rent_cost || 0,
            priorElec: b.prior_elec || 0,
            currentElec: b.current_elec || 0,
            elecDeduct: b.elec_deduct || 0,
            elecUnitCost: b.elec_unit_cost || 0,
            elecCost: b.elec_cost || 0,
            priorWater: b.prior_water || 0,
            currentWater: b.current_water || 0,
            waterUnitCost: b.water_unit_cost || 0,
            waterCost: b.water_cost || 0,
            depositCost: b.deposit_cost || 0,
            otherCost: b.other_cost || 0,
            status: b.status,
            dueDate: b.due_date,
            slipStatus: b.slip_status,
            slipUrl: b.slip_url,
            slipTimestamp: b.slip_timestamp
          });

          const unpaidBillsList = rawUnpaid.map(mapBill);
          const paidBillsList = rawPaid.map(mapBill);

          return successResponse({
            success: true,
            tenantToken: await generateToken({ role: 'tenant', roomId: room.id, userId }, getJwtSecret(env), 1),
            room: {
              id: room.id,
              roomNumber: room.room_number,
              tenantName: room.tenant_name,
              tenantPhone: room.tenant_phone,
              lineStatus: room.line_status,
              lineDisplayName: room.line_display_name,
              linePictureUrl: room.line_picture_url
            },
            settings: userSettings,
            unpaidBills: unpaidBillsList,
            paidBills: paidBillsList
          });
        } catch (e: any) {
          console.error("Public verify error:", e);
          return errorResponse("SERVER_ERROR", "เกิดข้อผิดพลาดในการตรวจสอบข้อมูล", 500);
        }
      }
      return successResponse({ success: true });
    }

    if (path === "/api/public/line/register" && method === "POST") {
      const body = await getJson();
      const { roomId, lineUserId, lineDisplayName, linePictureUrl } = body;
      if (!roomId || !lineUserId) {
        return errorResponse("VALIDATION_ERROR", "Missing required fields.", 400);
      }

      const authHeader = request.headers.get("Authorization");
      if (!authHeader || !authHeader.startsWith("Bearer ")) return errorResponse("UNAUTHORIZED", "Unauthorized", 401);
      const token = authHeader.split(" ")[1];
      const payload = await verifyToken(token, getJwtSecret(env));
      if (!payload || payload.role !== "tenant" || payload.roomId !== parseInt(roomId)) {
          return errorResponse("UNAUTHORIZED", "กรุณายืนยันตัวตนผู้เช่าก่อนเชื่อมต่อ LINE", 401);
      }
      if (!await ownerHasPlanFeature(Number(payload.userId), 'lineIntegration')) {
        return errorResponse('PLAN_REQUIRED', 'LINE Integration อยู่ในแพ็กเกจ Pro', 403);
      }

      if (env.DB) {
        try {
          const roomObj = await env.DB.prepare("SELECT * FROM rooms WHERE id = ? AND user_id = ? AND deleted_at IS NULL").bind(parseInt(roomId), payload.userId).first();
          if (!roomObj) return errorResponse("NOT_FOUND", "Room not found.", 404);

          await env.DB.prepare(
            "UPDATE rooms SET line_user_id = ?, line_display_name = ?, line_picture_url = ?, line_status = 'linked' WHERE id = ? AND user_id = ?"
          ).bind(lineUserId, lineDisplayName || "LINE User", linePictureUrl || "", roomObj.id, roomObj.user_id).run();

          const updated = await env.DB.prepare("SELECT * FROM rooms WHERE id = ? AND user_id = ?").bind(roomObj.id, roomObj.user_id).first();

          // Send welcome push message
          const userSettings = await env.DB.prepare("SELECT * FROM settings WHERE user_id = ?").bind(updated.user_id).first();
          if (userSettings) {
             const welcomeMsg = `🎉 ยินดีต้อนรับเข้าสู่ระบบแจ้งเตือนบิลหอพัก ${userSettings.dorm_name || 'หอพัก'}!
คุณได้ทำการเชื่อมต่อ LINE สำเร็จสำหรับห้อง ${updated.room_number} เรียบร้อยแล้วค่ะ`;
             await pushLineMessage(userSettings, lineUserId, welcomeMsg);
          }

          return successResponse({ success: true, room: updated }, "ลงทะเบียนเชื่อมต่อ LINE สำเร็จเรียบร้อยแล้ว");
        } catch (e: any) {
          console.error("Public register error:", e);
          return errorResponse("SERVER_ERROR", "เกิดข้อผิดพลาดในการบันทึกการเชื่อมโยง LINE", 500);
        }
      }
      return successResponse({ success: true });
    }
    // ---------------------------------------------------------------------------
    // --- LINE REGISTER & BOT SYSTEM ENDPOINTS ---
    // ---------------------------------------------------------------------------

    async function replyLineMessage(userSettings: any, replyToken: string, text: string) {
      if (userSettings && userSettings.line_channel_access_token) {
        try {
          const response = await fetch('https://api.line.me/v2/bot/message/reply', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${userSettings.line_channel_access_token}`
            },
            body: JSON.stringify({
              replyToken,
              messages: [{ type: 'text', text }]
            })
          });
          if (!response.ok) {
            const errorText = await response.text();
            console.error("Failed to reply via LINE API:", errorText);
            await logLineEvent(userSettings.user_id, 'error', `ตอบกลับ LINE ไม่สำเร็จ (${response.status})`);
          } else {
            await logLineEvent(userSettings.user_id, 'outgoing', text);
          }
        } catch (err) {
          console.error("Error in replyLineMessage:", err);
          await logLineEvent(userSettings.user_id, 'error', 'เชื่อมต่อ LINE API เพื่อส่งข้อความตอบกลับไม่สำเร็จ');
        }
      }
    }

    async function pushLineMessage(userSettings: any, toUserId: string, text: string) {
      const accessToken = userSettings?.line_channel_access_token;
      if (!accessToken) {
        return { success: false, message: "ยังไม่ได้ตั้งค่า LINE Channel Access Token" };
      }
      if (!toUserId) {
        return { success: false, message: "ห้องนี้ไม่มี LINE User ID ของผู้รับ" };
      }

      try {
        const response = await fetch('https://api.line.me/v2/bot/message/push', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`
          },
          body: JSON.stringify({
            to: toUserId,
            messages: [{ type: 'text', text }]
          })
        });
        if (!response.ok) {
          const rawError = await response.text();
          let lineMessage = rawError;
          try {
            const parsed = JSON.parse(rawError) as { message?: string };
            if (parsed.message) lineMessage = parsed.message;
          } catch {
            // LINE can return a non-JSON response during an upstream incident.
          }
          lineMessage = lineMessage.trim().slice(0, 240) || "LINE API ปฏิเสธคำขอ";
          console.error("LINE push rejected", { status: response.status, message: lineMessage });
          await logLineEvent(userSettings.user_id, 'error', `ส่ง LINE ไม่สำเร็จ (${response.status}): ${lineMessage}`);

          if (response.status === 401) {
            return { success: false, message: "LINE Channel Access Token ไม่ถูกต้องหรือหมดอายุ" };
          }
          return { success: false, message: `LINE API ปฏิเสธการส่ง (${response.status}): ${lineMessage}` };
        }
        await logLineEvent(userSettings.user_id, 'outgoing', text);
        return { success: true, message: "ส่งข้อความสำเร็จ" };
      } catch (err) {
        console.error("Error in pushLineMessage:", err);
        if (userSettings?.user_id) {
          await logLineEvent(userSettings.user_id, 'error', 'เชื่อมต่อ LINE API ไม่สำเร็จ');
        }
        return { success: false, message: "เชื่อมต่อ LINE API ไม่สำเร็จ กรุณาลองใหม่" };
      }
    }

    async function logLineEvent(userId: number, type: 'incoming' | 'outgoing' | 'error' | 'system', message: string, roomNumber?: string | null) {
      if (!env.DB) return;
      try {
        await env.DB.prepare(
          'INSERT INTO line_event_logs (user_id, type, message, room_number) VALUES (?, ?, ?, ?)'
        ).bind(userId, type, String(message).slice(0, 1000), roomNumber || null).run();
      } catch (error) {
        console.warn('Unable to persist LINE event log', error);
      }
    }

    if (path === "/api/line/logs" && method === "GET") {
        const user = await getAuthUser();
        if (!user) return errorResponse("UNAUTHORIZED", "Unauthorized", 401);
        if (!hasCaretakerPermission(user, 'manage_settings')) {
          return errorResponse('FORBIDDEN', 'คุณไม่มีสิทธิ์ดูประวัติ LINE', 403);
        }
        if (!env.DB) return successResponse([]);
        const requestedLimit = Number.parseInt(url.searchParams.get('limit') || '50', 10);
        const limit = Number.isFinite(requestedLimit) ? Math.min(100, Math.max(1, requestedLimit)) : 50;
        const ownerId = user.effectiveUserId || user.id;
        const { results } = await env.DB.prepare(
          'SELECT id, type, message, room_number, created_at AS timestamp FROM line_event_logs WHERE user_id = ? ORDER BY created_at DESC, id DESC LIMIT ?'
        ).bind(ownerId, limit).all();
        return successResponse(results || []);
    }

    if (path === "/api/line/webhook" && method === "POST") {
        try {
            if (!env.DB) return new Response("LINE integration is not configured", { status: 503 });

            const signature = request.headers.get('x-line-signature');
            if (!signature) return new Response("Missing LINE signature", { status: 401 });

            const rawBody = await request.text();
            let body: any;
            try {
                body = JSON.parse(rawBody);
            } catch {
                return new Response("Invalid JSON", { status: 400 });
            }

            const { results: configuredSettings } = await env.DB.prepare(
                `SELECT * FROM settings
                 WHERE line_bot_enabled = 1
                   AND line_channel_secret IS NOT NULL
                   AND length(trim(line_channel_secret)) > 0`
            ).all<LineSettingsRow>();

            let userSettings: LineSettingsRow | null = null;
            for (const candidate of configuredSettings || []) {
                if (candidate.line_channel_secret && await verifyLineWebhookSignature(rawBody, signature, candidate.line_channel_secret)) {
                    userSettings = candidate;
                    break;
                }
            }

            if (!userSettings) return new Response("Invalid LINE signature", { status: 401 });

            const events = body.events;
            if (!events || !Array.isArray(events)) {
                return new Response("OK", { status: 200 });
            }

            const userId = userSettings.user_id;

            for (const event of events) {
                if (event.type === "message" && event.message.type === "text") {
                    const lineUserId = event.source.userId;
                    if (!lineUserId) continue;
                    const text = event.message.text.trim();
                    const replyToken = event.replyToken;
                    await logLineEvent(userId, 'incoming', text);

                    // 1. Handle registration keyword: "ลงทะเบียน [เลขห้อง] [เบอร์โทร]"
                    const regRegex = /^(ลงทะเบียน|register)\s+(\S+)\s+(\S+)$/i;
                    const match = text.match(regRegex);

                    if (match) {
                        const roomNum = match[2];
                        const phone = match[3];

                        const { results: allRooms } = await env.DB.prepare("SELECT * FROM rooms WHERE user_id = ? AND deleted_at IS NULL").bind(userId).all<any>();
                        
                        const normalizeRoomName = (name: string) => name ? name.toLowerCase().replace(/\s+/g, '') : '';
                        const normalizedInput = normalizeRoomName(roomNum);
                        
                        let roomMatch = allRooms.filter((r: any) => normalizeRoomName(r.room_number) === normalizedInput);
                        const cleanPhoneInput = phone.replace(/[- ]/g, "");

                        if (roomMatch.length === 0 && cleanPhoneInput) {
                            roomMatch = allRooms.filter((r: any) => {
                                const cleanRoomPhone = (r.tenant_phone || "").replace(/[- ]/g, "");
                                return cleanRoomPhone && cleanRoomPhone === cleanPhoneInput;
                            });
                        }

                        if (roomMatch.length === 0) {
                            const occupiedRooms = allRooms.filter((r: any) => r.status === "occupied");
                            const roomList = occupiedRooms.map((r: any) => (r.room_number || '').trim()).join(", ");
                            await replyLineMessage(
                                userSettings, 
                                replyToken, 
                                `❌ ไม่พบห้องหมายเลข "${roomNum}" ในระบบค่ะ\n\nหมายเลขห้องที่เปิดใช้งานในขณะนี้ เช่น: ${roomList || "ยังไม่มีข้อมูลห้องพัก"}`
                            );
                        } else {
                            const room = roomMatch[0];
                            const cleanRoomPhone = (room.tenant_phone || "").replace(/[- ]/g, "");

                            if (cleanRoomPhone && cleanPhoneInput !== cleanRoomPhone) {
                                await replyLineMessage(userSettings, replyToken, `❌ เบอร์โทรศัพท์ไม่ถูกต้อง สำหรับห้อง ${room.room_number}`);
                            } else {
                                let displayName = `LINE User`;
                                let pictureUrl = "";
                                if (userSettings.line_channel_access_token) {
                                    try {
                                        const profileRes = await fetch(`https://api.line.me/v2/bot/profile/${lineUserId}`, {
                                            headers: { 'Authorization': `Bearer ${userSettings.line_channel_access_token}` }
                                        });
                                        if (profileRes.ok) {
                                            const profile = await profileRes.json<{ displayName?: string; pictureUrl?: string }>();
                                            displayName = profile.displayName || displayName;
                                            pictureUrl = profile.pictureUrl || pictureUrl;
                                        }
                                    } catch (err) {}
                                }

                                await env.DB.prepare(
                                    "UPDATE rooms SET line_user_id = ?, line_display_name = ?, line_picture_url = ?, line_status = 'linked' WHERE id = ?"
                                ).bind(lineUserId, displayName, pictureUrl, room.id).run();

                                await replyLineMessage(userSettings, replyToken, `🎉 ลงทะเบียนสำเร็จ!\nห้อง: ${room.room_number}\nผู้เช่า: ${room.tenant_name || 'ไม่ระบุ'}\nตอนนี้คุณจะได้รับบิลแจ้งเตือนผ่านช่องทางนี้แล้วค่ะ`);
                            }
                        }
                        continue;
                    }

                    // 2. Query bills: "บิล" or "ยอดค้างชำระ"
                    const isQueryBill = ["บิล", "ค่าเช่า", "ยอดค้างชำระ", "ยอดค้าง", "bill", "check"].some(k => text.toLowerCase().includes(k));
                    if (isQueryBill) {
                        const { results: linkedRooms } = await env.DB.prepare("SELECT * FROM rooms WHERE user_id = ? AND line_user_id = ? AND deleted_at IS NULL").bind(userId, lineUserId).all<any>();

                        if (linkedRooms.length === 0) {
                            await replyLineMessage(userSettings, replyToken, `⚠️ คุณยังไม่ได้ลงทะเบียนในระบบค่ะ\nกรุณาลงทะเบียนโดยพิมพ์:\nลงทะเบียน [เลขห้อง] [เบอร์โทร]\nเช่น: ลงทะเบียน 101 0812345678`);
                        } else {
                            const room = linkedRooms[0];
                            const { results: unpaid } = await env.DB.prepare(
                                "SELECT * FROM bills WHERE user_id = ? AND room_id = ? AND status = 'unpaid' AND deleted_at IS NULL ORDER BY bill_month DESC"
                            ).bind(userId, room.id).all<any>();

                            if (unpaid.length === 0) {
                                await replyLineMessage(userSettings, replyToken, `✅ ห้อง ${room.room_number} ไม่มียอดค้างชำระในระบบค่ะ ขอบคุณค่ะ!`);
                            } else {
                                const latestBill = unpaid[0];
                                const currentElec = latestBill.current_elec || 0;
                                const priorElec = latestBill.prior_elec || 0;
                                const elecDeduct = latestBill.elec_deduct || 0;
                                const elecUnitCost = latestBill.elec_unit_cost || 0;
                                const elecCost = latestBill.elec_cost ?? Math.round(Math.max(0, currentElec - priorElec - elecDeduct) * elecUnitCost);
                                
                                const currentWater = latestBill.current_water || 0;
                                const priorWater = latestBill.prior_water || 0;
                                const waterUnitCost = latestBill.water_unit_cost || 0;
                                const waterCost = latestBill.water_cost ?? (currentWater - priorWater > 0 ? (Math.round((currentWater - priorWater) * waterUnitCost) + 10) : 0);

                                const msg = `🧾 บิลค้างชำระ ห้อง ${room.room_number}\n` +
                                            `รอบประจำเดือน: ${latestBill.bill_month}\n` +
                                            `• ค่าเช่าห้อง: ${(latestBill.rent_cost || 0).toLocaleString()} บาท\n` +
                                            `• ค่าไฟ: ${elecCost.toLocaleString()} บาท${elecDeduct > 0 ? ` (หักล้าง ${elecDeduct} หน่วย)` : ''}\n` +
                                            `• ค่าน้ำ: ${waterCost.toLocaleString()} บาท\n` +
                                            `• ยอดรวมสุทธิ: ${(latestBill.total_cost || 0).toLocaleString()} บาท\n` +
                                            `📅 ครบกำหนดชำระ: ${latestBill.due_date}\n\n` +
                                            `🔗 ตรวจสอบรายละเอียดและชำระเงินที่นี่:\n` +
                                            `${new URL(request.url).origin}/line-register?room=${room.room_number}&phone=${room.tenant_phone || ''}`;
                                
                                await replyLineMessage(userSettings, replyToken, msg);
                            }
                        }
                        continue;
                    }

                    // 3. Fallback help message
                    await replyLineMessage(
                        userSettings, 
                        replyToken, 
                        `ยินดีต้อนรับสู่บริการแจ้งบิลอัตโนมัติค่ะ 😊\n\n` +
                        `• หากต้องการลงทะเบียน พิมพ์:\nลงทะเบียน [เลขห้อง] [เบอร์โทร]\n` +
                        `• หากต้องการตรวจสอบบิลล่าสุด พิมพ์:\n"บิล" หรือ "ยอดค้างชำระ"`
                    );
                }
            }
            return new Response("OK", { status: 200 });
        } catch (error) {
            console.error("LINE Webhook error:", error);
            return new Response("Internal Server Error", { status: 500 });
        }
    }

    if (path.match(/^\/api\/line\/send-test\/\d+$/) && method === "POST") {
        const user = await getAuthUser();
        if (!user) return errorResponse("UNAUTHORIZED", "Unauthorized", 401);
        if (!hasCaretakerPermission(user, PERMISSIONS.MANAGE_BILLS)) return errorResponse('FORBIDDEN', 'ไม่มีสิทธิ์จัดการบิล', 403);
        const roomId = parseInt(path.split("/").pop() || "0");
        
        if (env.DB) {
            try {
                const room = await env.DB.prepare("SELECT * FROM rooms WHERE id = ? AND user_id = ?").bind(roomId, user.effectiveUserId).first();
                if (!room) return errorResponse("NOT_FOUND", "ไม่พบห้องพัก", 404);

                const hasMessaging = !!room.line_user_id;
                if (!hasMessaging) {
                    return errorResponse("BAD_REQUEST", "ห้องนี้ยังไม่ได้ลงทะเบียน LINE", 400);
                }

                const userSettings = await env.DB.prepare("SELECT * FROM settings WHERE user_id = ?").bind(user.effectiveUserId).first() || {};
                const msg = `🔔 ข้อความทดสอบจากผู้ดูแลหอพัก ${userSettings.dorm_name || ''}\nระบบแจ้งเตือน LINE ของคุณใช้งานได้ปกติแล้วค่ะ!`;
                
                const pushResult = await pushLineMessage(userSettings, room.line_user_id, msg);

                if (pushResult.success) {
                    return successResponse({ success: true, message: `ส่งข้อความทดสอบสำเร็จ` });
                } else {
                    return errorResponse("LINE_API_ERROR", pushResult.message, 502);
                }
            } catch (err: any) {
                return errorResponse("SERVER_ERROR", "เกิดข้อผิดพลาดในการส่งข้อความทดสอบ", 500);
            }
        }
        return successResponse({ success: true });
    }

    if (path.match(/^\/api\/line\/unlink\/\d+$/) && method === "POST") {
        const user = await getAuthUser();
        if (!user) return errorResponse("UNAUTHORIZED", "Unauthorized", 401);
        const roomId = parseInt(path.split("/").pop() || "0");
        
        if (env.DB) {
            try {
                await env.DB.prepare(
                    "UPDATE rooms SET line_user_id = NULL, line_display_name = NULL, line_picture_url = NULL, line_status = 'unlinked' WHERE id = ? AND user_id = ?"
                ).bind(roomId, user.effectiveUserId).run();

                const updated = await env.DB.prepare("SELECT * FROM rooms WHERE id = ?").bind(roomId).first();
                return successResponse({ success: true, room: updated });
            } catch (err: any) {
                return errorResponse("SERVER_ERROR", "เกิดข้อผิดพลาด", 500);
            }
        }
        return successResponse({ success: true });
    }

    if (path.match(/^\/api\/line\/send-bill\/\d+$/) && method === "POST") {
        const user = await getAuthUser();
        if (!user) return errorResponse("UNAUTHORIZED", "Unauthorized", 401);
        if (!hasCaretakerPermission(user, PERMISSIONS.MANAGE_BILLS)) return errorResponse('FORBIDDEN', 'ไม่มีสิทธิ์จัดการบิล', 403);
        const billId = parseInt(path.split("/").pop() || "0");
        
        if (env.DB) {
            try {
                const billResult = await env.DB.prepare("SELECT * FROM bills WHERE id = ? AND user_id = ?").bind(billId, user.effectiveUserId).first();
                if (!billResult) return errorResponse("NOT_FOUND", "ไม่พบบิลเรียกเก็บเงิน", 404);

                const roomResult = await env.DB.prepare("SELECT * FROM rooms WHERE id = ?").bind(billResult.room_id).first();
                if (!roomResult) return errorResponse("NOT_FOUND", "ไม่พบห้องพัก", 404);

                const hasMessaging = !!(roomResult.line_user_id && roomResult.line_status === 'linked');
                if (!hasMessaging) return errorResponse("BAD_REQUEST", "ห้องนี้ยังไม่ได้ลงทะเบียน LINE ผู้เช่า", 400);

                const userSettings = await env.DB.prepare("SELECT * FROM settings WHERE user_id = ?").bind(user.effectiveUserId).first() || {};

                const currentElec = billResult.current_elec || 0;
                const priorElec = billResult.prior_elec || 0;
                const elecDeduct = billResult.elec_deduct || 0;
                const elecUnitCost = billResult.elec_unit_cost || 0;
                const elecCost = billResult.elec_cost ?? Math.round(Math.max(0, currentElec - priorElec - elecDeduct) * elecUnitCost);
                
                const currentWater = billResult.current_water || 0;
                const priorWater = billResult.prior_water || 0;
                const waterUnitCost = billResult.water_unit_cost || 0;
                const waterCost = billResult.water_cost ?? (currentWater - priorWater > 0 ? Math.round((currentWater - priorWater) * waterUnitCost) : 0);
                const { results: lineChargeItems } = await env.DB.prepare('SELECT label,amount FROM bill_charge_items WHERE bill_id=? ORDER BY sort_order,id').bind(billId).all();
                const lineChargeText = (lineChargeItems || []).length
                    ? (lineChargeItems || []).map((item: any) => `• ${item.label}: ${Number(item.amount).toLocaleString()} บาท\n`).join('')
                    : (billResult.other_cost > 0 ? `• ค่าใช้จ่ายอื่น ๆ: ${(billResult.other_cost).toLocaleString()} บาท\n` : '');

                const msg = `🧾 ใบแจ้งค่าเช่าหอพัก ${userSettings.dorm_name || 'หอพัก'}\n` +
                            `ประจำเดือน: ${billResult.bill_month}\n` +
                            `ห้อง: ${roomResult.room_number}\n` +
                            `-------------------------\n` +
                            `• ค่าเช่าห้อง: ${(billResult.rent_cost || 0).toLocaleString()} บาท\n` +
                            `• ค่าไฟฟ้า: ${elecCost.toLocaleString()} บาท (${priorElec} -> ${currentElec} หน่วย${elecDeduct > 0 ? `, หักล้าง ${elecDeduct} หน่วย` : ''})\n` +
                            `• ค่าน้ำ: ${waterCost.toLocaleString()} บาท (${priorWater} -> ${currentWater} หน่วย)\n` +
                            (billResult.deposit_cost > 0 ? `• ค่าประกัน: ${(billResult.deposit_cost).toLocaleString()} บาท\n` : '') +
                            lineChargeText +
                            `-------------------------\n` +
                            `💰 ยอดรวมทั้งสิ้น: ${(billResult.total_cost || 0).toLocaleString()} บาท\n` +
                            `📅 ครบกำหนดชำระ: ${billResult.due_date}\n\n` +
                            `🔗 ลิงก์ตรวจสอบและชำระเงิน:\n` +
                            `${new URL(request.url).origin}/line-register?room=${roomResult.room_number}&phone=${roomResult.tenant_phone || ''}`;

                const pushResult = await pushLineMessage(userSettings, roomResult.line_user_id, msg);

                if (pushResult.success) {
                    return successResponse({ success: true, message: `ส่งบิลห้อง ${roomResult.room_number} เรียบร้อยแล้ว (ผ่าน LINE Push)` });
                } else {
                    return errorResponse("LINE_API_ERROR", pushResult.message, 502);
                }
            } catch (err: any) {
                return errorResponse("SERVER_ERROR", "เกิดข้อผิดพลาดในการส่งบิล", 500);
            }
        }
        return successResponse({ success: true });
    }

    if (path === "/api/line/send-overdue" && method === "POST") {
        const user = await getAuthUser();
        if (!user) return errorResponse("UNAUTHORIZED", "Unauthorized", 401);
        if (!hasCaretakerPermission(user, PERMISSIONS.MANAGE_BILLS)) return errorResponse('FORBIDDEN', 'ไม่มีสิทธิ์จัดการบิล', 403);
        
        if (env.DB) {
            try {
                // Get unpaid bills
                const { results: overdueBillsList } = await env.DB.prepare(`
                    SELECT * FROM bills WHERE user_id = ? AND status = 'unpaid'
                `).bind(user.effectiveUserId).all();

                const todayStr = new Date().toISOString().substring(0, 10);
                const overdueBills = (overdueBillsList || []).filter((b: any) => b.due_date <= todayStr);

                if (overdueBills.length === 0) {
                    return successResponse({ count: 0, message: "ไม่มีห้องค้างชำระที่เกินกำหนดเวลาส่งแจ้งเตือน" });
                }

                const userSettings = await env.DB.prepare("SELECT * FROM settings WHERE user_id = ?").bind(user.effectiveUserId).first() || {};
                let sentCount = 0;
                let failedCount = 0;
                let firstFailure = "";

                for (const bill of overdueBills) {
                    const roomResult = await env.DB.prepare("SELECT * FROM rooms WHERE id = ?").bind(bill.room_id).first();
                    if (!roomResult) continue;

                    const hasMessaging = !!(roomResult.line_user_id && roomResult.line_status === 'linked');
                    if (!hasMessaging) continue;

                    const msg = `⚠️ แจ้งเตือนยอดค้างชำระหอพัก ${userSettings.dorm_name || 'หอพัก'}\n` +
                                `⚠️ เกินกำหนดชำระเงินเรียบร้อยแล้วค่ะ\n` +
                                `ห้อง: ${roomResult.room_number}\n` +
                                `รอบบิลประจำเดือน: ${bill.bill_month}\n` +
                                `💰 ยอดคงค้างทั้งหมด: ${(bill.total_cost || 0).toLocaleString()} บาท\n` +
                                `📅 ครบกำหนดตั้งแต่วันที่: ${bill.due_date}\n\n` +
                                `🔗 รบกวนสแกนจ่ายหรือแนบสลิปชำระเงินที่ลิงก์นี้:\n` +
                                `${new URL(request.url).origin}/line-register?room=${roomResult.room_number}&phone=${roomResult.tenant_phone || ''}\n\n` +
                                `หากชำระเงินเรียบร้อยแล้ว ขออภัยในความไม่สะดวกนะคะ 🙏`;

                    const pushResult = await pushLineMessage(userSettings, roomResult.line_user_id, msg);
                    if (pushResult.success) {
                        sentCount++;
                    } else {
                        failedCount++;
                        if (!firstFailure) firstFailure = pushResult.message;
                    }
                }

                if (sentCount === 0 && failedCount > 0) {
                    return errorResponse("LINE_API_ERROR", firstFailure || "LINE API ปฏิเสธการส่งข้อความ", 502);
                }
                return successResponse({ count: sentCount, failedCount, message: `ส่งข้อความทวงถามสำเร็จ ${sentCount} ห้อง${failedCount > 0 ? `, ไม่สำเร็จ ${failedCount} ห้อง` : ''}` });
            } catch (err: any) {
                return errorResponse("SERVER_ERROR", "เกิดข้อผิดพลาดในการส่งข้อความแจ้งเตือน", 500);
            }
        }
        return successResponse({ success: true });
    }
    
    // ---------------------------------------------------------------------------


    // Helper: Auth Token & User Lookup
    // Function declaration is intentionally used here so it is hoisted. Several
    // LINE routes above this helper authenticate before execution reaches this
    // section; a `const` function expression caused a temporal-dead-zone
    // ReferenceError and prevented every send/unlink request from reaching LINE.
    const staffRoles = ['caretaker', 'accountant', 'technician', 'housekeeper', 'staff'];
    const isStaffRole = (role?: string | null) => staffRoles.includes(String(role || ''));

    async function getAuthUser(): Promise<any> {
      const secret = getJwtSecret(env);
      const authHeader = request.headers.get("Authorization");
      if (authHeader && authHeader.startsWith("Bearer ")) {
        const token = authHeader.split(" ")[1];
        const payload = await verifyToken(token, secret);
        
        if (payload && payload.id) {
          if (env.DB) {
            try {
              const dbUser = await env.DB.prepare("SELECT * FROM users WHERE id = ? AND deleted_at IS NULL").bind(payload.id).first();
              if (dbUser) {
                const effectiveUserId = isStaffRole(String(dbUser.role)) && dbUser.parent_id ? Number(dbUser.parent_id) : Number(dbUser.id);
                await assertPlanAccessForRequest(effectiveUserId);
                return {
                  ...dbUser,
                  effectiveUserId
                };
              }
            } catch (e) {
              if (e instanceof PlanAccessError) throw e;
              console.warn("Auth user lookup error:", e);
            }
          } else {
            return { id: payload.id, effectiveUserId: payload.id, uid: payload.uid, email: payload.email, role: payload.role, parent_id: null, permissions: 'manage_rooms,manage_bills,edit_payments,manage_settings' };
          }
        }
      }
      return null;
    }

    function hasCaretakerPermission(user: any, requiredPerm: string): boolean {
      return Boolean(user) && hasAppPermission(String(user.role), user.permissions, requiredPerm as any);
    };

    async function getSubscriptionMetadata(ownerId: number) {
      const fallback = { subscriptionPlan: 'pro' as const, subscriptionStatus: 'active', subscriptionExpiresAt: null as string | null };
      if (!env.DB) return fallback;
      try {
        const row = await env.DB.prepare('SELECT subscription_plan, subscription_status, subscription_expires_at FROM settings WHERE user_id = ? LIMIT 1').bind(ownerId).first();
        return {
          subscriptionPlan: normalizeSubscriptionPlan(row?.subscription_plan),
          subscriptionStatus: String(row?.subscription_status || 'active'),
          subscriptionExpiresAt: row?.subscription_expires_at ? String(row.subscription_expires_at) : null,
        };
      } catch (error) {
        console.warn('Subscription metadata lookup warning:', error);
        return fallback;
      }
    }

    async function ownerHasPlanFeature(ownerId: number, feature: PlanFeature): Promise<boolean> {
      const { subscriptionPlan } = await getSubscriptionMetadata(ownerId);
      return hasPlanFeature(subscriptionPlan, feature);
    }


    async function assertPlanAccessForRequest(ownerId: number): Promise<void> {
      const { subscriptionPlan } = await getSubscriptionMetadata(ownerId);
      const requiredFeature = requiredPlanFeatureForApiRequest(path, method);

      if (isDemoPlan(subscriptionPlan) && isDemoMutationRestricted(path, method)) {
        throw new PlanAccessError('PLAN_REQUIRED', 'บัญชี Demo ไม่อนุญาตให้แก้ไขการตั้งค่า ลบข้อมูล หรือจัดการ Integration');
      }

      if (requiredFeature && !hasPlanFeature(subscriptionPlan, requiredFeature)) {
        const requiredPlan = minimumPaidPlanForFeature(requiredFeature);
        throw new PlanAccessError('PLAN_REQUIRED', `ฟีเจอร์นี้อยู่ในแพ็กเกจ ${requiredPlan[0].toUpperCase() + requiredPlan.slice(1)} หรือสูงกว่า`);
      }

      if (!env.DB) return;

      if (method === 'POST' && path === '/api/rooms') {
        const countRow = await env.DB.prepare('SELECT COUNT(*) AS count FROM rooms WHERE user_id = ? AND deleted_at IS NULL').bind(ownerId).first();
        const maxRooms = getPlanLimit(subscriptionPlan, 'maxRooms');
        if (Number(countRow?.count || 0) >= maxRooms) {
          throw new PlanAccessError('PLAN_LIMIT_REACHED', `แพ็กเกจ ${subscriptionPlan} รองรับห้องพักสูงสุด ${maxRooms} ห้อง`);
        }
      }

      if (method === 'POST' && path === '/api/caretakers') {
        const countRow = await env.DB.prepare("SELECT COUNT(*) AS count FROM users WHERE parent_id = ? AND role IN ('caretaker','accountant','technician','housekeeper','staff') AND deleted_at IS NULL").bind(ownerId).first();
        const maxStaff = getPlanLimit(subscriptionPlan, 'maxStaff');
        if (Number(countRow?.count || 0) >= maxStaff) {
          throw new PlanAccessError('PLAN_LIMIT_REACHED', `แพ็กเกจ ${subscriptionPlan} รองรับผู้ดูแลร่วมสูงสุด ${maxStaff} คน`);
        }
      }
    }


    const backupJsonMessages = {
      entityName: 'คำขอ Backup/Restore',
      invalid: 'รูปแบบข้อมูล Backup/Restore ไม่ถูกต้อง',
      tooLarge: 'ข้อมูล Backup/Restore มีขนาดใหญ่เกินกำหนด',
    };
    const isBackupAdminRole = (role?: string | null) => ['owner', 'super_admin'].includes(String(role || ''));
    const requireBackupAdmin = async () => {
      const authUser = await getAuthUser();
      if (!authUser) return { response: errorResponse('UNAUTHORIZED', 'กรุณาล็อกอินเข้าสู่ระบบก่อนใช้งาน', 401), authUser: null };
      if (!isBackupAdminRole(authUser.role)) return { response: errorResponse('FORBIDDEN', 'เฉพาะเจ้าของหอพักหรือผู้ดูแลระบบเท่านั้นที่ใช้ Backup/Restore ได้', 403), authUser: null };
      return { response: null, authUser };
    };
    const auditRestoreFailure = async (authUser: any, body: Record<string, unknown> | null, reasonCode: string, recoveryRequired: boolean) => {
      const manifest = body?.manifest && typeof body.manifest === 'object' ? body.manifest as Record<string, unknown> : null;
      await logAuditAction(env.DB, {
        userId: authUser?.id,
        userEmail: authUser?.email || 'system',
        userRole: authUser?.role || 'owner',
        action: 'RESTORE_BACKUP_FAILED',
        targetType: 'backup',
        targetId: null,
        newValue: {
          dataSha256: typeof manifest?.dataSha256 === 'string' ? manifest.dataSha256 : null,
          formatVersion: Number(manifest?.formatVersion || 1),
          reasonCode,
          recoveryRequired,
        },
        ipAddress: clientIp,
        userAgent,
      });
    };

    if (path === '/api/admin/backup/export' && method === 'GET') {
      const gate = await requireBackupAdmin();
      if (gate.response) return gate.response;
      if (!env.DB) return errorResponse('DATABASE_ERROR', 'ไม่พบการเชื่อมต่อฐานข้อมูล D1', 500);
      try {
        const ownerId = Number(gate.authUser.effectiveUserId || gate.authUser.id);
        return successResponse(await exportBusinessBackup(env.DB, ownerId, APP_VERSION));
      } catch (error: any) {
        return errorResponse('BACKUP_EXPORT_FAILED', error?.message || 'ไม่สามารถสร้างไฟล์สำรองข้อมูลได้', 500);
      }
    }

    if (path === '/api/admin/backup/validate' && method === 'POST') {
      const gate = await requireBackupAdmin();
      if (gate.response) return gate.response;
      if (!env.DB) return errorResponse('DATABASE_ERROR', 'ไม่พบการเชื่อมต่อฐานข้อมูล D1', 500);
      const bodyResult = await readBoundedJson(request, BACKUP_REQUEST_MAX_BYTES, backupJsonMessages);
      if (!bodyResult.ok) return errorResponse(bodyResult.code, bodyResult.message, bodyResult.status);
      try {
        const ownerId = Number(gate.authUser.effectiveUserId || gate.authUser.id);
        const result = await validateBackupForRestore(env.DB, ownerId, getJwtSecret(env), {
          manifest: bodyResult.data.manifest,
          data: bodyResult.data.data,
        });
        return successResponse(result);
      } catch (error: any) {
        if (error instanceof BackupValidationError) return errorResponse(error.code, error.message, error.status);
        return errorResponse('BACKUP_VALIDATION_FAILED', error?.message || 'ตรวจสอบไฟล์ Backup ไม่สำเร็จ', 400);
      }
    }

    if (path === '/api/admin/backup/restore' && method === 'POST') {
      const gate = await requireBackupAdmin();
      if (gate.response) return gate.response;
      if (!env.DB) return errorResponse('DATABASE_ERROR', 'ไม่พบการเชื่อมต่อฐานข้อมูล D1', 500);
      const bodyResult = await readBoundedJson(request, BACKUP_REQUEST_MAX_BYTES, backupJsonMessages);
      if (!bodyResult.ok) return errorResponse(bodyResult.code, bodyResult.message, bodyResult.status);
      const body = bodyResult.data;
      const ownerId = Number(gate.authUser.effectiveUserId || gate.authUser.id);
      const restoreLimit = await RateLimiterService.checkRateLimit(env.DB, `${ownerId}:${clientIp}`, 'backup_restore');
      if (!restoreLimit.allowed) {
        await auditRestoreFailure(gate.authUser, body, 'RESTORE_RATE_LIMIT', false);
        return errorResponse('TOO_MANY_REQUESTS', `คุณทำ Restore ถี่เกินไป กรุณารอ ${restoreLimit.retryAfterSeconds} วินาที`, 429);
      }
      if (body.confirmation !== 'RESTORE') {
        await auditRestoreFailure(gate.authUser, body, 'RESTORE_CONFIRMATION_REQUIRED', false);
        return errorResponse('RESTORE_CONFIRMATION_REQUIRED', 'กรุณาพิมพ์ RESTORE เพื่อยืนยัน', 400);
      }
      try {
        const validation = await validateBackupForRestore(env.DB, ownerId, getJwtSecret(env), {
          manifest: body.manifest,
          data: body.data,
        });
        const manifest = body.manifest as BackupManifestV1;
        const tokenCheck = await verifyRestoreToken(String(body.restoreToken || ''), getJwtSecret(env), {
          ownerId,
          ownerScope: manifest.ownerScope,
          dataSha256: manifest.dataSha256,
          formatVersion: manifest.formatVersion,
        });
        if (!tokenCheck.ok) throw new BackupValidationError('RESTORE_TOKEN_INVALID', 400, 'Restore Token ไม่ถูกต้องหรือหมดอายุ');

        const currentState = await loadRestoreCurrentState(env.DB, ownerId);
        const prepared = prepareRestoreData(body.data as BackupDataV1, currentState, ownerId);
        const restoreResult = await restoreBusinessBackup(env.DB, ownerId, prepared);
        await verifyRestoredBackup(env.DB, ownerId, prepared);
        await logAuditActionStrict(env.DB, {
          userId: gate.authUser.id,
          userEmail: gate.authUser.email,
          userRole: gate.authUser.role,
          action: 'RESTORE_BACKUP',
          targetType: 'backup',
          targetId: manifest.dataSha256.slice(0, 16),
          newValue: { dataSha256: manifest.dataSha256, formatVersion: manifest.formatVersion, preRestoreDataSha256: restoreResult.preRestoreDataSha256 },
          ipAddress: clientIp,
          userAgent,
        });
        return successResponse({
          restored: true,
          preRestoreDataSha256: restoreResult.preRestoreDataSha256,
          warnings: validation.warnings,
        }, 'กู้คืนข้อมูลสำเร็จ');
      } catch (error: any) {
        const recoveryRequired = error instanceof RestorePartialFailure || Boolean(error?.recoveryRequired);
        const reasonCode = String(error?.code || (recoveryRequired ? 'RESTORE_PARTIAL_FAILURE' : 'RESTORE_FAILED'));
        await auditRestoreFailure(gate.authUser, body, reasonCode, recoveryRequired);
        if (error instanceof BackupValidationError) return errorResponse(error.code, error.message, error.status);
        if (recoveryRequired) {
          return jsonResponse({
            success: false,
            error: {
              code: 'RESTORE_PARTIAL_FAILURE',
              message: error?.message || 'กู้คืนข้อมูลไม่สมบูรณ์',
              recoveryRequired: true,
              preRestoreDataSha256: error?.preRestoreDataSha256 || null,
            },
          }, 503);
        }
        return errorResponse(reasonCode, error?.message || 'กู้คืนข้อมูลไม่สำเร็จ', 500);
      }
    }

    const requireGoogleConfig = () => {
      if (!env.GOOGLE_CLIENT_ID || !env.GOOGLE_CLIENT_SECRET) {
        throw new Error('ยังไม่ได้ตั้งค่า GOOGLE_CLIENT_ID และ GOOGLE_CLIENT_SECRET บน Cloudflare Pages');
      }
    }

    if (path === '/api/google-sheets/status' && method === 'GET') {
      const authUser = await getAuthUser();
      if (!authUser || !env.DB) return errorResponse('UNAUTHORIZED', 'กรุณาเข้าสู่ระบบก่อนตรวจสอบ Google Sheets', 401);
      const ownerId = authUser.effectiveUserId || authUser.id;
      const saved = await env.DB.prepare('SELECT 1 AS connected FROM google_oauth_tokens WHERE user_id = ? LIMIT 1').bind(ownerId).first();
      return successResponse({
        connected: !!saved,
        hasClientConfig: !!(env.GOOGLE_CLIENT_ID && env.GOOGLE_CLIENT_SECRET)
      });
    }

    if (path === '/api/google-sheets/disconnect' && (method === 'POST' || method === 'DELETE')) {
      const authUser = await getAuthUser();
      if (!authUser || !env.DB) return errorResponse('UNAUTHORIZED', 'กรุณาเข้าสู่ระบบก่อนยกเลิก Google Sheets', 401);
      const ownerId = authUser.effectiveUserId || authUser.id;
      await env.DB.prepare('DELETE FROM google_oauth_tokens WHERE user_id = ?').bind(ownerId).run();
      return successResponse({ connected: false }, 'ยกเลิกการเชื่อมต่อ Google Sheets เรียบร้อยแล้ว');
    }

    // Google OAuth callback is handled on the server so the client secret and
    // refresh token never have to be exposed to the browser.
    if (path === '/api/google-sheets/connect' && method === 'POST') {
      const authUser = await getAuthUser();
      if (!authUser || !env.DB) return errorResponse('UNAUTHORIZED', 'กรุณาเข้าสู่ระบบก่อนเชื่อมต่อ Google', 401);
      try {
        requireGoogleConfig();
        const state = crypto.randomUUID();
        const ownerId = authUser.effectiveUserId || authUser.id;
        await env.DB.prepare('INSERT INTO google_oauth_states (state, user_id, expires_at) VALUES (?, ?, ?)').bind(state, ownerId, Date.now() + 600000).run();
        const redirectUri = new URL('/api/google-sheets/callback', request.url).toString();
        const url = new URL('https://accounts.google.com/o/oauth2/v2/auth');
        url.search = new URLSearchParams({ client_id: env.GOOGLE_CLIENT_ID, redirect_uri: redirectUri, response_type: 'code', access_type: 'offline', prompt: 'consent', scope: 'https://www.googleapis.com/auth/spreadsheets', state }).toString();
        return jsonResponse({ success: true, data: { authorizationUrl: url.toString() } });
      } catch (e: any) { return errorResponse('GOOGLE_OAUTH_CONFIG', e.message, 500); }
    }

    if (path === '/api/google-sheets/callback' && method === 'GET') {
      try {
        requireGoogleConfig();
        const state = url.searchParams.get('state'); const code = url.searchParams.get('code');
        if (!state || !code || !env.DB) return new Response('Invalid Google authorization response', { status: 400 });
        const record = await env.DB.prepare('SELECT * FROM google_oauth_states WHERE state = ? AND expires_at > ?').bind(state, Date.now()).first();
        await env.DB.prepare('DELETE FROM google_oauth_states WHERE state = ?').bind(state).run();
        if (!record) return new Response('Google authorization has expired. Please try again.', { status: 400 });
        const redirectUri = new URL('/api/google-sheets/callback', request.url).toString();
        const tokenRes = await fetch('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ code, client_id: env.GOOGLE_CLIENT_ID, client_secret: env.GOOGLE_CLIENT_SECRET, redirect_uri: redirectUri, grant_type: 'authorization_code' }) });
        const tokens: any = await tokenRes.json();
        if (!tokenRes.ok || !tokens.refresh_token) return new Response('Google did not return a refresh token. Reconnect and approve access again.', { status: 400 });
        await env.DB.prepare('INSERT INTO google_oauth_tokens (user_id, refresh_token) VALUES (?, ?) ON CONFLICT(user_id) DO UPDATE SET refresh_token = excluded.refresh_token, updated_at = CURRENT_TIMESTAMP').bind(record.user_id, tokens.refresh_token).run();
        return Response.redirect(new URL('/?googleSheets=connected', request.url), 302);
      } catch (e: any) { return new Response(`Google connection failed: ${e.message}`, { status: 500 }); }
    }

    if (path === '/api/google-sheets/token' && method === 'GET') {
      const authUser = await getAuthUser();
      if (!authUser || !env.DB) return errorResponse('UNAUTHORIZED', 'กรุณาเข้าสู่ระบบก่อนใช้งาน Google Sheets', 401);
      try {
        requireGoogleConfig(); const ownerId = authUser.effectiveUserId || authUser.id;
        const saved = await env.DB.prepare('SELECT refresh_token FROM google_oauth_tokens WHERE user_id = ?').bind(ownerId).first();
        if (!saved) return errorResponse('GOOGLE_NOT_CONNECTED', 'กรุณาเชื่อมต่อ Google Sheets ในหน้าตั้งค่าระบบก่อน', 400);
        const tokenRes = await fetch('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ client_id: env.GOOGLE_CLIENT_ID, client_secret: env.GOOGLE_CLIENT_SECRET, refresh_token: saved.refresh_token, grant_type: 'refresh_token' }) });
        const token: any = await tokenRes.json(); if (!tokenRes.ok) return errorResponse('GOOGLE_TOKEN_ERROR', token.error_description || 'ไม่สามารถเชื่อมต่อ Google ได้', 400);
        return jsonResponse({ success: true, data: { accessToken: token.access_token } });
      } catch (e: any) { return errorResponse('GOOGLE_TOKEN_ERROR', e.message, 500); }
    }

    // ──────────────────────────────────────────────
    // 2. FIRST SETUP WIZARD API
    // ──────────────────────────────────────────────
    if (path === "/api/setup/status" && method === "GET") {
      if (!env.DB) {
        return successResponse({ isSetupRequired: false, message: "DB non-existent fallback mode" });
      }
      try {
        const userCount = await env.DB.prepare("SELECT COUNT(*) as count FROM users WHERE deleted_at IS NULL").first();
        const isSetupRequired = (userCount?.count || 0) === 0;
        return successResponse({ isSetupRequired });
      } catch (e: any) {
        return successResponse({ isSetupRequired: false });
      }
    }

    if (path === "/api/setup/init" && method === "POST") {
      if (!env.DB) {
        return errorResponse("DATABASE_ERROR", "ไม่พบการเชื่อมต่อฐานข้อมูล D1", 500);
      }
      try {
        const existingCount = await env.DB.prepare("SELECT COUNT(*) as count FROM users WHERE deleted_at IS NULL").first();
        if ((existingCount?.count || 0) > 0) {
          return errorResponse("FORBIDDEN", "ระบบได้รับการตั้งค่าบัญชีผู้ดูแลระบบหลักไปแล้ว", 403);
        }

        const body = await getJson();
        const validated = validateZod(SetupSchema, body);

        // Validate password policy
        const policyResult = validatePasswordPolicy(validated.password);
        if (!policyResult.isValid) {
          return errorResponse("VALIDATION_ERROR", policyResult.error || "รหัสผ่านไม่ผ่านนโยบายความปลอดภัย", 400);
        }

        const secret = getJwtSecret(env);

        const hashedPassword = await hashPassword(validated.password);
        const cleanUid = validated.email.trim().toLowerCase();
        const dormName = validated.dormName?.trim() || "หอพักของฉัน";

        await env.DB.prepare(
          "INSERT INTO users (uid, email, role, password, permissions) VALUES (?, ?, 'super_admin', ?, 'manage_rooms,manage_bills,edit_payments,manage_settings')"
        ).bind(cleanUid, validated.email.trim(), hashedPassword).run();

        const newUser = await env.DB.prepare("SELECT * FROM users WHERE uid = ?").bind(cleanUid).first();
        if (!newUser || !newUser.id) {
          return errorResponse("SERVER_ERROR", "Failed to resolve created user ID", 500);
        }
        const newUserId = newUser.id;

        await env.DB.prepare(
          "INSERT INTO settings (user_id, dorm_name) VALUES (?, ?)"
        ).bind(newUserId, dormName).run();

        await logAuditAction(env.DB, {
          userId: newUserId,
          userEmail: validated.email.trim(),
          userRole: 'super_admin',
          action: 'INITIAL_SETUP',
          targetType: 'system',
          newValue: { email: validated.email.trim(), dormName },
          ipAddress: clientIp,
          userAgent
        });

        const tokenPayload = {
          id: newUserId,
          uid: cleanUid,
          email: validated.email.trim(),
          role: "super_admin"
        };
        const token = await generateToken(tokenPayload, secret);

        return successResponse({
          user: {
            id: newUserId,
            uid: cleanUid,
            email: validated.email.trim(),
            role: "super_admin",
            displayName: validated.displayName || "Super Admin"
          },
          token
        }, "ตั้งค่าระบบและสร้างบัญชีผู้ดูแลระบบสำเร็จแล้วค่ะ!", 201);
      } catch (e: any) {
        if (e.name === 'ValidationError') {
          return errorResponse("VALIDATION_ERROR", e.message, 400, e.details);
        }
        return errorResponse("DATABASE_ERROR", "เกิดข้อผิดพลาดในการตั้งค่าระบบ: " + (e?.message || e), 500);
      }
    }

    // ──────────────────────────────────────────────
    // 3. AUTHENTICATION API (LOGIN & PASSWORD CHANGE)
    // ──────────────────────────────────────────────
    if (path === "/api/auth/login" && method === "POST") {
      const body = await getJson();
      const cleanUser = String(body.username || body.email || "").trim().toLowerCase();
      const cleanPass = String(body.password || "");

      if (!cleanUser) {
        return errorResponse("VALIDATION_ERROR", "กรุณาระบุชื่อผู้ใช้งาน หรือ อีเมล", 400);
      }
      if (!cleanPass) {
        return errorResponse("VALIDATION_ERROR", "กรุณาระบุรหัสผ่าน", 400);
      }
      if (!env.DB) {
        return errorResponse("DATABASE_ERROR", "ไม่พบการเชื่อมต่อฐานข้อมูล D1", 500);
      }

      // SECURITY: Resolve the user solely from the database. No hardcoded /
      // "bulletproof" admin fallback and no master passwords. Every login is
      // verified strictly against the stored password hash.
      let userObj: any;
      try {
        const { results } = await env.DB.prepare("SELECT * FROM users WHERE deleted_at IS NULL").all();
        const allUsers = results || [];
        userObj = allUsers.find((u: any) => {
          const uEmail = (u.email || "").trim().toLowerCase();
          const uUid = (u.uid || "").trim().toLowerCase();
          return uEmail === cleanUser || uEmail.split('@')[0] === cleanUser || uUid === cleanUser;
        });
      } catch (e: any) {
        console.error("Login DB error:", e);
        return errorResponse("SERVER_ERROR", "เกิดข้อผิดพลาดในการเข้าสู่ระบบ", 500);
      }

      if (!userObj) {
        return errorResponse("UNAUTHORIZED", "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง", 401);
      }

      // SECURITY: Always verify the submitted password against the stored hash.
      const isValid = userObj.password
        ? await verifyPassword(cleanPass, userObj.password)
        : false;

      if (!isValid) {
        return errorResponse("UNAUTHORIZED", "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง", 401);
      }

      try {
        await logAuditAction(env.DB, {
          userId: userObj.id,
          userEmail: userObj.email,
          userRole: userObj.role,
          action: 'LOGIN',
          targetType: 'user',
          targetId: userObj.id,
          ipAddress: clientIp,
          userAgent
        });
      } catch (e) {}

      const secret = getJwtSecret(env);

      const tokenPayload = {
        id: userObj.id,
        uid: userObj.uid,
        email: userObj.email,
        role: userObj.role
      };
      const token = await generateToken(tokenPayload, secret);

      return successResponse({
        user: {
          id: userObj.id,
          uid: userObj.uid,
          email: userObj.email,
          role: userObj.role,
          displayName: userObj.role === 'super_admin' ? "Super Admin" : userObj.role === 'owner' ? "เจ้าของหอพัก" : "ผู้ดูแลหอพัก",
        },
        token
      }, "เข้าสู่ระบบสำเร็จ");
    }

    if (path === "/api/auth/change-password" && method === "PUT") {
      const authUser = await getAuthUser();
      if (!authUser) {
        return errorResponse("UNAUTHORIZED", "กรุณาล็อกอินเข้าสู่ระบบก่อนดำเนินการ", 401);
      }

      const body = await getJson();
      const { currentPassword, newPassword } = body;
      if (!currentPassword || !newPassword) {
        return errorResponse("VALIDATION_ERROR", "กรุณากรอกรหัสผ่านเดิมและรหัสผ่านใหม่", 400);
      }

      const policyResult = validatePasswordPolicy(newPassword);
      if (!policyResult.isValid) {
        return errorResponse("VALIDATION_ERROR", policyResult.error || "รหัสผ่านใหม่ไม่ผ่านนโยบายความปลอดภัย", 400);
      }

      if (!env.DB) return errorResponse("DATABASE_ERROR", "ไม่พบการเชื่อมต่อ D1", 500);

      try {
        const dbUser = await env.DB.prepare("SELECT * FROM users WHERE id = ? AND deleted_at IS NULL").bind(authUser.id).first();
        if (!dbUser) return errorResponse("NOT_FOUND", "ไม่พบบัญชีผู้ใช้ในระบบ", 404);

        const isCorrect = await verifyPassword(String(currentPassword).trim(), dbUser.password);
        if (!isCorrect) {
          return errorResponse("UNAUTHORIZED", "รหัสผ่านเดิมไม่ถูกต้อง", 401);
        }

        const hashedPassword = await hashPassword(String(newPassword).trim());
        await env.DB.prepare("UPDATE users SET password = ? WHERE id = ?").bind(hashedPassword, authUser.id).run();

        await logAuditAction(env.DB, {
          userId: authUser.id,
          userEmail: authUser.email,
          userRole: authUser.role,
          action: 'CHANGE_PASSWORD',
          targetType: 'user',
          targetId: authUser.id,
          ipAddress: clientIp,
          userAgent
        });

        return successResponse({ success: true }, "เปลี่ยนรหัสผ่านสำเร็จแล้วค่ะ");
      } catch (e: any) {
        return errorResponse("DATABASE_ERROR", "เกิดข้อผิดพลาดในการเปลี่ยนรหัสผ่าน", 500);
      }
    }

    // Profile API
    if (path === "/api/profile" && method === "GET") {
      const authUser = await getAuthUser();
      if (authUser) {
        const subscription = await getSubscriptionMetadata(Number(authUser.effectiveUserId || authUser.id));
        return successResponse({
          id: authUser.id,
          uid: authUser.uid,
          email: authUser.email,
          role: authUser.role,
          parentId: authUser.parent_id,
          permissions: authUser.permissions,
          ...subscription,
        });
      }
      return errorResponse("UNAUTHORIZED", "กรุณาล็อกอินเข้าสู่ระบบ", 401);
    }

    // ──────────────────────────────────────────────
    // 4. ROOMS API (With Soft Delete & Audit)
    // ──────────────────────────────────────────────
    // Resolve due charges before broad module routers so a path segment can never
    // be consumed by a generic CRUD handler.
    if (path === '/api/recurring-charges/due' && method === 'GET') {
      const authUser = await getAuthUser();
      if (!authUser || !env.DB) return errorResponse('UNAUTHORIZED', 'กรุณาเข้าสู่ระบบ', 401);
      if (!hasCaretakerPermission(authUser, PERMISSIONS.MANAGE_BILLS)) return errorResponse('FORBIDDEN', 'ไม่มีสิทธิ์ออกบิล', 403);
      const ownerId = Number(authUser.effectiveUserId || authUser.id);
      const billMonth = String(url.searchParams.get('billMonth') || '');
      const roomId = Number(url.searchParams.get('roomId') || 0);
      if (!/^\d{4}-\d{2}$/.test(billMonth)) return errorResponse('VALIDATION_ERROR', 'billMonth ต้องเป็น YYYY-MM', 400);
      const month = Number(billMonth.slice(5, 7));
      let query = `SELECT a.id assignment_id,a.room_id,a.amount_override,t.name,t.default_amount,t.frequency,t.billing_months FROM room_recurring_charges a JOIN recurring_charge_templates t ON t.id=a.template_id WHERE a.user_id=? AND a.is_enabled=1 AND t.is_active=1 AND t.deleted_at IS NULL`;
      const params: any[] = [ownerId];
      if (roomId) { query += ' AND a.room_id=?'; params.push(roomId); }
      const { results } = await env.DB.prepare(query).bind(...params).all();
      const due = (results || []).filter((row: any) => row.frequency === 'monthly' || JSON.parse(row.billing_months || '[]').includes(month)).map((row: any) => ({ roomId: row.room_id, assignmentId: row.assignment_id, label: row.name, amount: row.amount_override ?? row.default_amount, kind: 'recurring' }));
      return successResponse(due);
    }

    if ((path === "/api/rooms" || path.startsWith("/api/rooms/")) && !/^\/api\/rooms\/\d+\/recurring-charges$/.test(path)) {
      const authUser = await getAuthUser();
      if (!authUser) return errorResponse('UNAUTHORIZED', 'กรุณาล็อกอินเข้าสู่ระบบก่อนใช้งาน', 401);

      if (method === "GET") {
        if (!hasCaretakerPermission(authUser, PERMISSIONS.VIEW_ROOMS)) return errorResponse('FORBIDDEN', 'ไม่มีสิทธิ์ดูข้อมูลห้องพัก', 403);
        if (env.DB) {
          try {
            const page = parseInt(url.searchParams.get("page") || "0");
            const limit = parseInt(url.searchParams.get("limit") || "0");
            const userId = authUser.effectiveUserId || authUser.id;

            let query = "SELECT * FROM rooms WHERE user_id = ? AND deleted_at IS NULL ORDER BY room_number ASC";
            if (page > 0 && limit > 0) {
              const offset = (page - 1) * limit;
              query += ` LIMIT ${limit} OFFSET ${offset}`;
            }

            const { results } = await env.DB.prepare(query).bind(userId).all();
            const mapped = (results || []).map((r: any) => ({
              id: r.id,
              roomNumber: r.room_number,
              monthlyRent: r.monthly_rent,
              status: r.status,
              tenantName: r.tenant_name,
              tenantPhone: r.tenant_phone,
              lineUserId: r.line_user_id,
              lineDisplayName: r.line_display_name,
              linePictureUrl: r.line_picture_url,
              lineStatus: r.line_status,
              lineNotifyToken: r.line_notify_token
            }));
            return successResponse(mapped);
          } catch (e) {
            console.warn("D1 fetch rooms error:", e);
          }
        }
        return successResponse([]);
      }

      if (method === "POST") {
        if (authUser && isStaffRole(authUser.role) && !hasCaretakerPermission(authUser, 'manage_rooms')) {
          return errorResponse("FORBIDDEN", "คุณไม่มีสิทธิ์จัดการหรือสร้างห้องพัก", 403);
        }
        const body = await getJson();
        const validated = validateZod(RoomSchema, body);
        const roomNumber = validated.roomNumber.trim();

        if (env.DB) {
          try {
            const existing = await env.DB.prepare(
              "SELECT id FROM rooms WHERE user_id = ? AND lower(trim(room_number)) = lower(?) AND deleted_at IS NULL"
            ).bind(authUser.effectiveUserId || authUser.id, roomNumber).first();
            if (existing) {
              return errorResponse("DUPLICATE_ROOM", "มีเลขห้องนี้อยู่ในระบบแล้ว", 409);
            }

            const res = await env.DB.prepare(
              "INSERT INTO rooms (user_id, room_number, monthly_rent, status, tenant_name, tenant_phone) VALUES (?, ?, ?, ?, ?, ?) RETURNING *"
            ).bind(
              authUser.effectiveUserId || authUser.id, roomNumber, validated.monthlyRent, validated.status, validated.tenantName || null, validated.tenantPhone || null
            ).first();

            await logAuditAction(env.DB, {
              userId: authUser.id,
              userEmail: authUser?.email || 'system',
              userRole: authUser?.role || 'owner',
              action: 'CREATE_ROOM',
              targetType: 'room',
              targetId: res?.id,
              newValue: validated,
              ipAddress: clientIp,
              userAgent
            });

            return successResponse(res, "เพิ่มห้องพักใหม่สำเร็จแล้วค่ะ", 201);
          } catch (e: any) {
            return errorResponse("DATABASE_ERROR", "ไม่สามารถเพิ่มห้องพักได้: " + e.message, 500);
          }
        }
        return successResponse({ id: Date.now(), ...validated });
      }

      if (method === "PUT") {
        if (authUser && isStaffRole(authUser.role) && !hasCaretakerPermission(authUser, 'manage_rooms')) {
          return errorResponse("FORBIDDEN", "คุณไม่มีสิทธิ์จัดการหรือแก้ไขห้องพัก", 403);
        }
        const id = path.split("/").pop();
        const body = await getJson();
        const validated = validateZod(RoomSchema, body);
        const roomNumber = validated.roomNumber.trim();

        if (env.DB) {
          try {
            const existing = await env.DB.prepare(
              "SELECT id FROM rooms WHERE user_id = ? AND lower(trim(room_number)) = lower(?) AND deleted_at IS NULL AND id != ?"
            ).bind(authUser.effectiveUserId || authUser.id, roomNumber, id).first();
            if (existing) {
              return errorResponse("DUPLICATE_ROOM", "มีเลขห้องนี้อยู่ในระบบแล้ว", 409);
            }

            const oldRoom = await env.DB.prepare("SELECT * FROM rooms WHERE id = ? AND user_id = ? AND deleted_at IS NULL").bind(id, authUser.effectiveUserId || authUser.id).first();
            if (!oldRoom) return errorResponse("NOT_FOUND", "ไม่พบห้องพักที่ระบุ", 404);
            await env.DB.prepare(
              "UPDATE rooms SET room_number = ?, monthly_rent = ?, status = ?, tenant_name = ?, tenant_phone = ? WHERE id = ? AND user_id = ?"
            ).bind(
              roomNumber, validated.monthlyRent, validated.status, validated.tenantName || null, validated.tenantPhone || null, id, authUser.effectiveUserId || authUser.id
            ).run();

            await logAuditAction(env.DB, {
              userId: authUser.id,
              userEmail: authUser?.email || 'system',
              userRole: authUser?.role || 'owner',
              action: 'EDIT_ROOM',
              targetType: 'room',
              targetId: id,
              oldValue: oldRoom,
              newValue: validated,
              ipAddress: clientIp,
              userAgent
            });

            return successResponse({ success: true, id }, "แก้ไขข้อมูลห้องพักสำเร็จแล้วค่ะ");
          } catch (e: any) {
            return errorResponse("DATABASE_ERROR", "เกิดข้อผิดพลาดในการแก้ไขห้องพัก", 500);
          }
        }
        return successResponse({ success: true, id });
      }

      if (method === "DELETE") {
        if (authUser && isStaffRole(authUser.role) && !hasCaretakerPermission(authUser, 'manage_rooms')) {
          return errorResponse("FORBIDDEN", "คุณไม่มีสิทธิ์ลบห้องพัก", 403);
        }
        const id = path.split("/").pop();
        if (env.DB) {
          try {
            const oldRoom = await env.DB.prepare("SELECT * FROM rooms WHERE id = ? AND user_id = ? AND deleted_at IS NULL").bind(id, authUser.effectiveUserId || authUser.id).first();
            if (!oldRoom) return errorResponse("NOT_FOUND", "ไม่พบห้องพักที่ระบุ", 404);
            // SOFT DELETE
            await env.DB.prepare("UPDATE rooms SET deleted_at = CURRENT_TIMESTAMP, deleted_by = ? WHERE id = ? AND user_id = ?").bind(authUser.id, id, authUser.effectiveUserId || authUser.id).run();

            await logAuditAction(env.DB, {
              userId: authUser.id,
              userEmail: authUser?.email || 'system',
              userRole: authUser?.role || 'owner',
              action: 'SOFT_DELETE_ROOM',
              targetType: 'room',
              targetId: id,
              oldValue: oldRoom,
              ipAddress: clientIp,
              userAgent
            });

            return successResponse({ success: true, id }, "ลบห้องพักเรียบร้อยแล้ว");
          } catch (e: any) {
            return errorResponse("DATABASE_ERROR", "เกิดข้อผิดพลาดในการลบห้องพัก", 500);
          }
        }
        return successResponse({ success: true });
      }
    }

    // ──────────────────────────────────────────────
    // 5. BILLS API (With D1 Batch Transactions & Soft Delete)
    // ──────────────────────────────────────────────
    if (path === "/api/bills" || path.startsWith("/api/bills/")) {
      const authUser = await getAuthUser();
      if (!authUser) return errorResponse('UNAUTHORIZED', 'กรุณาล็อกอินเข้าสู่ระบบก่อนใช้งาน', 401);
      if (method === 'GET' && !hasCaretakerPermission(authUser, PERMISSIONS.VIEW_BILLS)) return errorResponse('FORBIDDEN', 'ไม่มีสิทธิ์ดูบิล', 403);
      if ((method === 'POST' || method === 'DELETE') && !hasCaretakerPermission(authUser, PERMISSIONS.MANAGE_BILLS)) return errorResponse('FORBIDDEN', 'ไม่มีสิทธิ์จัดการบิล', 403);
      if (method === 'PUT' && !hasCaretakerPermission(authUser, PERMISSIONS.MANAGE_BILLS) && !hasCaretakerPermission(authUser, PERMISSIONS.EDIT_PAYMENTS)) return errorResponse('FORBIDDEN', 'ไม่มีสิทธิ์แก้ไขบิล', 403);

      if (path === "/api/bills/bulk" && method === "POST") {
        if (authUser && isStaffRole(authUser.role) && !hasCaretakerPermission(authUser, 'manage_bills')) {
          return errorResponse("FORBIDDEN", "คุณไม่มีสิทธิ์สร้างบิลค่าเช่า", 403);
        }
        const body = await getJson();
        const { billMonth, dueDate, bills: bulkBills } = body;

        if (!billMonth || !dueDate || !bulkBills || !Array.isArray(bulkBills)) {
          return errorResponse("VALIDATION_ERROR", "กรุณากรอกข้อมูลเดือน กำหนดชำระ และรายการบิลให้ครบถ้วน", 400);
        }

        const userId = authUser.effectiveUserId || authUser.id;

        if (env.DB) {
          try {
            const userSettingsList = await env.DB.prepare("SELECT * FROM settings WHERE user_id = ?").bind(userId).all();
            const userSettings = userSettingsList.results[0] || { default_elec_rate: 7, default_water_rate: 13 };
            const defaultElecRate = (userSettings.default_elec_rate as number) || 7;
            const defaultWaterRate = (userSettings.default_water_rate as number) || 13;

            const stmts = [];
            const pendingChargeItems: Array<{ roomId: number; items: any[] }> = [];
            for (const billItem of bulkBills) {
              const {
                roomId, priorElec, currentElec, elecDeduct, elecCost,
                priorWater, currentWater, waterCost,
                rentCost, depositCost, otherCost, otherDescription, chargeItems: rawChargeItems
              } = billItem;

              const normalizedItems = Array.isArray(rawChargeItems) ? rawChargeItems.map((item: any, index: number) => ({ assignmentId: item.assignmentId ? Number(item.assignmentId) : null, label: String(item.label || '').trim(), amount: Math.max(0, Math.round(Number(item.amount) || 0)), kind: item.kind === 'recurring' ? 'recurring' : 'manual', sortOrder: index })) : null;
              if (normalizedItems && (normalizedItems.length > 50 || normalizedItems.some((item: any) => !item.label || item.label.length > 120 || item.amount > 1_000_000))) return errorResponse('VALIDATION_ERROR', `รายการค่าบริการของห้อง ${roomId} ไม่ถูกต้อง`, 400);
              if (normalizedItems) for (const item of normalizedItems) if (item.assignmentId) { const assignment = await env.DB.prepare('SELECT id FROM room_recurring_charges WHERE id=? AND user_id=? AND room_id=?').bind(item.assignmentId, userId, roomId).first(); if (!assignment) return errorResponse('VALIDATION_ERROR', `มีค่าบริการที่ไม่ตรงกับห้อง ${roomId}`, 400); }

              let finalElecCost = 0;
              if (elecCost !== undefined && elecCost !== null && elecCost !== '') {
                finalElecCost = parseFloat(elecCost) || 0;
              } else {
                const elecUnits = Math.max(0, (parseFloat(currentElec) || 0) - (parseFloat(priorElec) || 0) - (parseFloat(elecDeduct) || 0));
                finalElecCost = Math.round(elecUnits * defaultElecRate);
              }
              
              let finalWaterCost = 0;
              if (waterCost !== undefined && waterCost !== null && waterCost !== '') {
                finalWaterCost = parseFloat(waterCost) || 0;
              } else {
                const waterUnits = Math.max(0, (parseFloat(currentWater) || 0) - (parseFloat(priorWater) || 0));
                finalWaterCost = waterUnits > 0 ? (Math.round(waterUnits * defaultWaterRate) + 10) : 0;
              }

              const finalOtherCost = normalizedItems ? normalizedItems.reduce((sum: number, item: any) => sum + item.amount, 0) : (parseFloat(otherCost) || 0);
              const finalOtherDescription = normalizedItems ? normalizedItems.map((item: any) => item.label).join(', ') : (otherDescription || '');
              const total = (parseInt(rentCost) || 0) + finalElecCost + finalWaterCost + (parseInt(depositCost) || 0) + finalOtherCost;

              stmts.push(
                env.DB.prepare(
                  `INSERT INTO bills (
                    user_id, room_id, bill_month, prior_elec, current_elec, elec_deduct, elec_unit_cost, elec_cost,
                    prior_water, current_water, water_unit_cost, water_cost, rent_cost, deposit_cost, other_cost,
                    other_description, total_cost, due_date, status, slip_status
                  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'unpaid', 'none')`
                ).bind(
                  userId, roomId, billMonth, parseFloat(priorElec) || 0, parseFloat(currentElec) || 0, parseFloat(elecDeduct) || 0, defaultElecRate, finalElecCost,
                  parseFloat(priorWater) || 0, parseFloat(currentWater) || 0, defaultWaterRate, finalWaterCost, parseInt(rentCost) || 0, parseInt(depositCost) || 0, finalOtherCost,
                  finalOtherDescription, total, dueDate
                )
              );
              if (normalizedItems) pendingChargeItems.push({ roomId: Number(roomId), items: normalizedItems });
            }

            if (stmts.length > 0) {
              await env.DB.batch(stmts);
            }
            if (pendingChargeItems.length) {
              const { results: createdBills } = await env.DB.prepare('SELECT id,room_id FROM bills WHERE user_id=? AND bill_month=? AND deleted_at IS NULL').bind(userId, billMonth).all();
              const billByRoom = new Map((createdBills || []).map((row: any) => [Number(row.room_id), Number(row.id)]));
              const itemStatements = pendingChargeItems.flatMap((entry) => entry.items.map((item: any) => env.DB!.prepare('INSERT INTO bill_charge_items (bill_id,assignment_id,label,amount,kind,sort_order) VALUES (?,?,?,?,?,?)').bind(billByRoom.get(entry.roomId), item.assignmentId, item.label, item.amount, item.kind, item.sortOrder)));
              if (itemStatements.length) await env.DB.batch(itemStatements);
            }
            return successResponse({ success: true, count: stmts.length }, "บันทึกบิลแบบกลุ่มสำเร็จ");
          } catch (e: any) {
            console.error(e);
            return errorResponse("DATABASE_ERROR", "เกิดข้อผิดพลาดในการสร้างบิลแบบกลุ่ม: " + (e.message || ''), 500);
          }
        }
        return successResponse({ success: true, count: bulkBills.length });
      }

      if (method === "GET") {
        if (env.DB) {
          try {
            const page = parseInt(url.searchParams.get("page") || "0");
            const limit = parseInt(url.searchParams.get("limit") || "0");
            const userId = authUser.effectiveUserId || authUser.id;

            let query = `SELECT b.*, r.room_number, r.tenant_name, r.tenant_phone 
               FROM bills b 
               JOIN rooms r ON b.room_id = r.id 
               WHERE b.user_id = ? AND b.deleted_at IS NULL AND r.deleted_at IS NULL 
               ORDER BY b.id DESC`;

            if (page > 0 && limit > 0) {
              const offset = (page - 1) * limit;
              query += ` LIMIT ${limit} OFFSET ${offset}`;
            }

            const { results } = await env.DB.prepare(query).bind(userId).all();

            const { results: chargeResults } = await env.DB.prepare(`SELECT i.* FROM bill_charge_items i JOIN bills b ON b.id=i.bill_id WHERE b.user_id=? AND b.deleted_at IS NULL ORDER BY i.sort_order,i.id`).bind(userId).all();
            const chargeMap = new Map<number, any[]>();
            (chargeResults || []).forEach((item: any) => chargeMap.set(item.bill_id, [...(chargeMap.get(item.bill_id) || []), { id: item.id, billId: item.bill_id, assignmentId: item.assignment_id, label: item.label, amount: item.amount, kind: item.kind, sortOrder: item.sort_order }]));
            const mapped = (results || []).map((b: any) => ({
              id: b.id,
              roomId: b.room_id,
              roomNumber: b.room_number,
              billMonth: b.bill_month,
              priorElec: b.prior_elec,
              currentElec: b.current_elec,
              elecDeduct: b.elec_deduct,
              elecUnitCost: b.elec_unit_cost,
              elecCost: b.elec_cost,
              priorWater: b.prior_water,
              currentWater: b.current_water,
              waterUnitCost: b.water_unit_cost,
              waterCost: b.water_cost,
              rentCost: b.rent_cost,
              depositCost: b.deposit_cost,
              otherCost: b.other_cost,
              otherDescription: b.other_description,
              totalCost: b.total_cost,
              dueDate: b.due_date,
              status: b.status,
              paidAt: b.paid_at,
              slipImage: b.slip_image,
              slipUploadedAt: b.slip_uploaded_at,
              slipStatus: b.slip_status,
              tenantName: b.tenant_name,
              tenantPhone: b.tenant_phone,
              chargeItems: chargeMap.get(b.id) || []
            }));
            return successResponse(mapped);
          } catch (e) {
            console.warn("D1 fetch bills error:", e);
          }
        }
        return successResponse([]);
      }

      if (method === "POST") {
        if (authUser && isStaffRole(authUser.role) && !hasCaretakerPermission(authUser, 'manage_bills')) {
          return errorResponse("FORBIDDEN", "คุณไม่มีสิทธิ์สร้างบิลค่าเช่า", 403);
        }
        const body = await getJson();
        const validated = validateZod(BillSchema, body);

        const rawChargeItems = Array.isArray(body.chargeItems) ? body.chargeItems : null;
        const normalizedChargeItems = rawChargeItems ? rawChargeItems.map((item: any, index: number) => ({ assignmentId: item.assignmentId ? Number(item.assignmentId) : null, label: String(item.label || '').trim(), amount: Math.max(0, Math.round(Number(item.amount) || 0)), kind: item.kind === 'recurring' ? 'recurring' : 'manual', sortOrder: index })) : null;
        if (normalizedChargeItems && (normalizedChargeItems.length > 50 || normalizedChargeItems.some((item: any) => !item.label || item.label.length > 120 || item.amount > 1_000_000))) return errorResponse('VALIDATION_ERROR', 'รายการค่าบริการไม่ถูกต้อง', 400);
        if (normalizedChargeItems && env.DB) for (const item of normalizedChargeItems) if (item.assignmentId) { const assignment = await env.DB.prepare('SELECT id FROM room_recurring_charges WHERE id=? AND user_id=? AND room_id=?').bind(item.assignmentId, authUser.effectiveUserId || authUser.id, validated.roomId).first(); if (!assignment) return errorResponse('VALIDATION_ERROR', 'มีค่าบริการที่ไม่ตรงกับห้องพัก', 400); }

        const elecUnits = Math.max(0, validated.currentElec - validated.priorElec - validated.elecDeduct);
        const elecCost = validated.elecCost !== undefined ? validated.elecCost : Math.round(elecUnits * validated.elecUnitCost);
        const waterUnits = Math.max(0, validated.currentWater - validated.priorWater);
        const waterCost = validated.waterCost !== undefined ? validated.waterCost : (waterUnits > 0 ? Math.round(waterUnits * validated.waterUnitCost) : 0);
        const finalOtherCost = normalizedChargeItems ? normalizedChargeItems.reduce((sum: number, item: any) => sum + item.amount, 0) : validated.otherCost;
        const finalOtherDescription = normalizedChargeItems ? normalizedChargeItems.map((item: any) => item.label).join(', ') : validated.otherDescription;
        const totalCost = validated.rentCost + elecCost + waterCost + validated.depositCost + finalOtherCost;

        if (env.DB) {
          try {
            const existingBill = await env.DB.prepare(
              "SELECT id FROM bills WHERE user_id = ? AND room_id = ? AND bill_month = ? AND deleted_at IS NULL"
            ).bind(authUser.effectiveUserId || authUser.id, validated.roomId, validated.billMonth).first();

            if (existingBill) {
              return errorResponse("DUPLICATE_BILL", "มีบิลของห้องนี้ในประจำเดือนนี้แล้วค่ะ", 400);
            }

            // ATOMIC D1 BATCH TRANSACTION
            const insertBillStmt = env.DB.prepare(
              `INSERT INTO bills (
                user_id, room_id, bill_month, prior_elec, current_elec, elec_deduct, elec_unit_cost, elec_cost,
                prior_water, current_water, water_unit_cost, water_cost, rent_cost, deposit_cost, other_cost,
                other_description, total_cost, due_date, status
              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING *`
            ).bind(
              authUser.effectiveUserId || authUser.id, validated.roomId, validated.billMonth, validated.priorElec, validated.currentElec,
              validated.elecDeduct, validated.elecUnitCost, elecCost, validated.priorWater, validated.currentWater,
              validated.waterUnitCost, waterCost, validated.rentCost, validated.depositCost, finalOtherCost,
              finalOtherDescription || null, totalCost, validated.dueDate, validated.status
            );

            // Batch execution ensures bill creation & meter state update atomicity
            const batchResults = await env.DB.batch([insertBillStmt]);
            const createdBill = batchResults[0]?.results?.[0];
            if (createdBill?.id && normalizedChargeItems?.length) await env.DB.batch(normalizedChargeItems.map((item: any) => env.DB!.prepare('INSERT INTO bill_charge_items (bill_id,assignment_id,label,amount,kind,sort_order) VALUES (?,?,?,?,?,?)').bind(createdBill.id, item.assignmentId, item.label, item.amount, item.kind, item.sortOrder)));

            await logAuditAction(env.DB, {
              userId: authUser.id,
              userEmail: authUser?.email || 'system',
              userRole: authUser?.role || 'owner',
              action: 'CREATE_BILL',
              targetType: 'bill',
              targetId: createdBill?.id,
              newValue: { ...validated, totalCost },
              ipAddress: clientIp,
              userAgent
            });

            return successResponse({ ...createdBill, chargeItems: normalizedChargeItems || [] }, "สร้างบิลค่าเช่าสำเร็จแล้วค่ะ", 201);
          } catch (e: any) {
            return errorResponse("DATABASE_TRANSACTION_ERROR", "เกิดข้อผิดพลาดขณะสร้างบิลค่าเช่าในฐานข้อมูล: " + e.message, 500);
          }
        }
        return successResponse({ id: Date.now(), ...validated, totalCost });
      }

      if (method === "PUT") {
        const id = path.split("/").pop();
        const body = await getJson();
        const userId = authUser.effectiveUserId || authUser.id;

        if (env.DB) {
          try {
            const billCheck = await env.DB.prepare(
              "SELECT * FROM bills WHERE id = ? AND user_id = ? AND deleted_at IS NULL"
            ).bind(id, userId).first();

            if (!billCheck) {
              return errorResponse("NOT_FOUND", "ไม่พบบิลค่าเช่าที่ระบุ", 404);
            }

            if (authUser && isStaffRole(authUser.role)) {
              const isStatusChangeOnly = Object.keys(body).every(k => k === 'status' || k === 'paidAt' || k === 'paid_at' || k === 'id');
              if (isStatusChangeOnly) {
                if (!hasCaretakerPermission(authUser, 'edit_payments')) {
                  return errorResponse("FORBIDDEN", "คุณไม่มีสิทธิ์บันทึกหรือแก้ไขสถานะการชำระเงิน", 403);
                }
              } else {
                if (!hasCaretakerPermission(authUser, 'manage_bills')) {
                  return errorResponse("FORBIDDEN", "คุณไม่มีสิทธิ์แก้ไขข้อมูลบิลค่าเช่า", 403);
                }
                if (body.status !== undefined && body.status !== billCheck.status && !hasCaretakerPermission(authUser, 'edit_payments')) {
                  return errorResponse("FORBIDDEN", "คุณไม่มีสิทธิ์บันทึกหรือแก้ไขสถานะการชำระเงิน", 403);
                }
              }
            }

            const rawChargeItems = body.chargeItems === undefined ? null : (Array.isArray(body.chargeItems) ? body.chargeItems : []);
            const normalizedChargeItems = rawChargeItems ? rawChargeItems.map((item: any, index: number) => ({ assignmentId: item.assignmentId ? Number(item.assignmentId) : null, label: String(item.label || '').trim(), amount: Math.max(0, Math.round(Number(item.amount) || 0)), kind: item.kind === 'recurring' ? 'recurring' : 'manual', sortOrder: index })) : null;
            if (normalizedChargeItems && (normalizedChargeItems.length > 50 || normalizedChargeItems.some((item: any) => !item.label || item.label.length > 120 || item.amount > 1_000_000))) return errorResponse('VALIDATION_ERROR', 'รายการค่าบริการไม่ถูกต้อง', 400);
            if (normalizedChargeItems) for (const item of normalizedChargeItems) if (item.assignmentId) { const assignment = await env.DB.prepare('SELECT id FROM room_recurring_charges WHERE id=? AND user_id=? AND room_id=?').bind(item.assignmentId, userId, billCheck.room_id).first(); if (!assignment) return errorResponse('VALIDATION_ERROR', 'มีค่าบริการที่ไม่ตรงกับห้องพัก', 400); }

            const mergedBody = {
              roomId: billCheck.room_id,
              billMonth: billCheck.bill_month,
              priorElec: billCheck.prior_elec,
              currentElec: billCheck.current_elec,
              elecDeduct: billCheck.elec_deduct,
              elecUnitCost: billCheck.elec_unit_cost,
              elecCost: billCheck.elec_cost,
              priorWater: billCheck.prior_water,
              currentWater: billCheck.current_water,
              waterUnitCost: billCheck.water_unit_cost,
              waterCost: billCheck.water_cost,
              rentCost: billCheck.rent_cost,
              depositCost: billCheck.deposit_cost,
              otherCost: billCheck.other_cost,
              otherDescription: billCheck.other_description,
              dueDate: billCheck.due_date,
              status: billCheck.status,
              ...body
            };
            const validated = validateZod(BillSchema, mergedBody);
            const elecUnits = Math.max(0, validated.currentElec - validated.priorElec - validated.elecDeduct);
            const elecCost = validated.elecCost !== undefined ? validated.elecCost : Math.round(elecUnits * validated.elecUnitCost);
            const waterUnits = Math.max(0, validated.currentWater - validated.priorWater);
            const waterCost = validated.waterCost !== undefined ? validated.waterCost : (waterUnits > 0 ? Math.round(waterUnits * validated.waterUnitCost) : 0);
            const finalOtherCost = normalizedChargeItems ? normalizedChargeItems.reduce((sum: number, item: any) => sum + item.amount, 0) : validated.otherCost;
            const finalOtherDescription = normalizedChargeItems ? normalizedChargeItems.map((item: any) => item.label).join(', ') : validated.otherDescription;
            const totalCost = validated.rentCost + elecCost + waterCost + validated.depositCost + finalOtherCost;

            const updatedPaidAt = validated.status === "paid" ? (body.paidAt || billCheck.paid_at || new Date().toISOString()) : null;

            await env.DB.prepare(
              `UPDATE bills SET bill_month = ?, prior_elec = ?, current_elec = ?, elec_deduct = ?, elec_unit_cost = ?, elec_cost = ?,
               prior_water = ?, current_water = ?, water_unit_cost = ?, water_cost = ?, rent_cost = ?, deposit_cost = ?, other_cost = ?,
               other_description = ?, total_cost = ?, due_date = ?, status = ?, paid_at = ? WHERE id = ? AND user_id = ?`
            ).bind(
              validated.billMonth, validated.priorElec, validated.currentElec, validated.elecDeduct, validated.elecUnitCost, elecCost,
              validated.priorWater, validated.currentWater, validated.waterUnitCost, waterCost, validated.rentCost, validated.depositCost, finalOtherCost,
              finalOtherDescription || null, totalCost, validated.dueDate, validated.status, updatedPaidAt, id, userId
            ).run();

            if (normalizedChargeItems) {
              await env.DB.prepare('DELETE FROM bill_charge_items WHERE bill_id=?').bind(id).run();
              if (normalizedChargeItems.length) await env.DB.batch(normalizedChargeItems.map((item: any) => env.DB!.prepare('INSERT INTO bill_charge_items (bill_id,assignment_id,label,amount,kind,sort_order) VALUES (?,?,?,?,?,?)').bind(id, item.assignmentId, item.label, item.amount, item.kind, item.sortOrder)));
            }

            return successResponse({ success: true, id }, "แก้ไขข้อมูลบิลค่าเช่าเรียบร้อยแล้วค่ะ");
          } catch (e: any) {
            if (e.name === 'ValidationError') {
              return errorResponse("VALIDATION_ERROR", e.message || "ข้อมูลไม่ถูกต้อง", 400, e.details);
            }
            return errorResponse("DATABASE_ERROR", "เกิดข้อผิดพลาดในการอัปเดตบิลค่าเช่า: " + (e.message || ''), 500);
          }
        }
        return successResponse({ success: true, id });
      }

      if (method === "DELETE") {
        if (authUser && isStaffRole(authUser.role) && !hasCaretakerPermission(authUser, 'manage_bills')) {
          return errorResponse("FORBIDDEN", "คุณไม่มีสิทธิ์ลบบิลค่าเช่า", 403);
        }
        const id = path.split("/").pop();
        if (env.DB) {
          try {
            const oldBill = await env.DB.prepare("SELECT * FROM bills WHERE id = ? AND user_id = ? AND deleted_at IS NULL").bind(id, authUser.effectiveUserId || authUser.id).first();
            if (!oldBill) return errorResponse("NOT_FOUND", "ไม่พบบิลค่าเช่าที่ระบุ", 404);
            // SOFT DELETE BILL
            await env.DB.prepare("UPDATE bills SET deleted_at = CURRENT_TIMESTAMP, deleted_by = ? WHERE id = ? AND user_id = ?").bind(authUser.id, id, authUser.effectiveUserId || authUser.id).run();

            await logAuditAction(env.DB, {
              userId: authUser.id,
              userEmail: authUser?.email || 'system',
              userRole: authUser?.role || 'owner',
              action: 'SOFT_DELETE_BILL',
              targetType: 'bill',
              targetId: id,
              oldValue: oldBill,
              ipAddress: clientIp,
              userAgent
            });

            return successResponse({ success: true, id }, "ลบบิลค่าเช่าเรียบร้อยแล้วค่ะ");
          } catch (e: any) {
            return errorResponse("DATABASE_ERROR", "เกิดข้อผิดพลาดในการลบบิล", 500);
          }
        }
        return successResponse({ success: true });
      }
    }

    // ──────────────────────────────────────────────
    // 6. SETTINGS API
    // ──────────────────────────────────────────────
    if (path === "/api/settings") {
      const authUser = await getAuthUser();
      if (!authUser) return errorResponse('UNAUTHORIZED', 'กรุณาล็อกอินเข้าสู่ระบบก่อนใช้งาน', 401);

      const userId = authUser.effectiveUserId || authUser.id;
      if (method === "GET") {
        if (env.DB) {
          try {
            const res = await env.DB.prepare("SELECT * FROM settings WHERE user_id = ? LIMIT 1").bind(userId).first();
            if (res) {
              const subscriptionPlan = normalizeSubscriptionPlan(res.subscription_plan);
              return successResponse({
                id: res.id,
                userId: res.user_id,
                dormName: res.dorm_name,
                defaultElecRate: res.default_elec_rate,
                defaultWaterRate: res.default_water_rate,
                defaultDueDateDay: res.default_due_date_day,
                defaultPenaltyRate: res.default_penalty_rate,
                promptpayId: hasPlanFeature(subscriptionPlan, 'promptPay') ? res.promptpay_id : null,
                promptpayName: hasPlanFeature(subscriptionPlan, 'promptPay') ? res.promptpay_name : null,
                lineChannelAccessToken: null,
                lineChannelSecret: null,
                lineTokenConfigured: hasPlanFeature(subscriptionPlan, 'lineIntegration') && !!res.line_channel_access_token,
                lineSecretConfigured: hasPlanFeature(subscriptionPlan, 'lineIntegration') && !!res.line_channel_secret,
                lineBotEnabled: hasPlanFeature(subscriptionPlan, 'lineIntegration') ? res.line_bot_enabled : 0,
                googleSpreadsheetId: hasPlanFeature(subscriptionPlan, 'googleSheets') ? res.google_spreadsheet_id : null,
                subscriptionPlan,
                subscriptionStatus: String(res.subscription_status || 'active'),
                subscriptionExpiresAt: res.subscription_expires_at ? String(res.subscription_expires_at) : null,
                fontScale: res.font_scale || 'medium'
              });
            }
          } catch (e) {
            console.warn("D1 settings fetch error:", e);
          }
        }
        return successResponse({
          dormName: "หอพักของฉัน",
          defaultElecRate: 7,
          defaultWaterRate: 13,
          defaultDueDateDay: 5,
          defaultPenaltyRate: 100,
          lineTokenConfigured: false,
          lineSecretConfigured: false,
          subscriptionPlan: 'pro',
          subscriptionStatus: 'active',
          subscriptionExpiresAt: null,
          fontScale: 'medium'
        });
      }

      if (method === "PUT") {
        if (isStaffRole(authUser.role) && !hasCaretakerPermission(authUser, 'manage_settings')) {
          return errorResponse("FORBIDDEN", "คุณไม่มีสิทธิ์แก้ไขการตั้งค่าระบบ", 403);
        }
        const body = await getJson();
        const validated = validateZod(SettingsSchema, body);
        const { subscriptionPlan } = await getSubscriptionMetadata(Number(userId));
        for (const feature of requiredPlanFeaturesForSettingsUpdate(validated as Record<string, unknown>)) {
          if (!hasPlanFeature(subscriptionPlan, feature)) {
            const requiredPlan = minimumPaidPlanForFeature(feature);
            return errorResponse('PLAN_REQUIRED', `การตั้งค่านี้อยู่ในแพ็กเกจ ${requiredPlan[0].toUpperCase() + requiredPlan.slice(1)} หรือสูงกว่า`, 403);
          }
        }
        let lineTokenConfigured = false;
        let lineSecretConfigured = false;
        let savedFontScale: 'small' | 'medium' | 'large' = 'medium';

        if (env.DB) {
          try {
            const existing = await env.DB.prepare("SELECT * FROM settings WHERE user_id = ? LIMIT 1").bind(userId).first();
            const isSettingsAdmin = authUser.role === 'owner' || authUser.role === 'super_admin';
            const existingFontScale = String(existing?.font_scale || 'medium');
            if (!isSettingsAdmin && validated.fontScale !== undefined && validated.fontScale !== existingFontScale) {
              return errorResponse('FORBIDDEN', 'เฉพาะ Admin หรือเจ้าของหอพักเท่านั้นที่ปรับขนาดตัวอักษรได้', 403);
            }
            const fontScaleToSave = isSettingsAdmin
              ? (validated.fontScale || existingFontScale)
              : existingFontScale;
            savedFontScale = fontScaleToSave === 'small' || fontScaleToSave === 'large' ? fontScaleToSave : 'medium';

            let tokenToSave = validated.lineChannelAccessToken;
            if (tokenToSave === '********' || tokenToSave === undefined) {
              tokenToSave = existing ? existing.line_channel_access_token : null;
            }
            let secretToSave = validated.lineChannelSecret;
            if (secretToSave === '********' || secretToSave === undefined) {
              secretToSave = existing ? existing.line_channel_secret : null;
            }

            if (validated.lineBotEnabled && (!tokenToSave || !secretToSave)) {
              return errorResponse('VALIDATION_ERROR', 'ต้องตั้งค่า LINE Channel Access Token และ Channel Secret ก่อนเปิดใช้งานบอท', 400);
            }
            lineTokenConfigured = !!tokenToSave;
            lineSecretConfigured = !!secretToSave;

            if (existing) {
              await env.DB.prepare(
                `UPDATE settings SET dorm_name = ?, default_elec_rate = ?, default_water_rate = ?, default_due_date_day = ?, default_penalty_rate = ?, promptpay_id = ?, promptpay_name = ?, line_channel_access_token = ?, line_channel_secret = ?, line_bot_enabled = ?, google_spreadsheet_id = ?, font_scale = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?`
              ).bind(
                validated.dormName, validated.defaultElecRate, validated.defaultWaterRate, validated.defaultDueDateDay, validated.defaultPenaltyRate, validated.promptpayId || null, validated.promptpayName || null, tokenToSave || null, secretToSave || null, validated.lineBotEnabled ? 1 : 0, validated.googleSpreadsheetId || null, fontScaleToSave, existing.id, userId
              ).run();
            } else {
              await env.DB.prepare(
                `INSERT INTO settings (user_id, dorm_name, default_elec_rate, default_water_rate, default_due_date_day, default_penalty_rate, promptpay_id, promptpay_name, line_channel_access_token, line_channel_secret, line_bot_enabled, google_spreadsheet_id, font_scale) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
              ).bind(
              authUser.effectiveUserId || authUser.id, validated.dormName, validated.defaultElecRate, validated.defaultWaterRate, validated.defaultDueDateDay, validated.defaultPenaltyRate, validated.promptpayId || null, validated.promptpayName || null, tokenToSave || null, secretToSave || null, validated.lineBotEnabled ? 1 : 0, validated.googleSpreadsheetId || null, fontScaleToSave
              ).run();
            }

            await logAuditAction(env.DB, {
              userId: authUser.id,
              userEmail: authUser?.email || 'system',
              userRole: authUser?.role || 'owner',
              action: 'UPDATE_SETTINGS',
              targetType: 'setting',
              targetId: existing ? String(existing.id) : "new",
              oldValue: redactSettingsForAudit(existing),
              newValue: redactSettingsForAudit(validated),
              ipAddress: clientIp,
              userAgent
            });
          } catch (e: any) {
            return errorResponse("DATABASE_ERROR", "เกิดข้อผิดพลาดในการบันทึกตั้งค่า", 500);
          }
        }
        const subscription = await getSubscriptionMetadata(Number(userId));
        return successResponse({
          ...validated,
          lineChannelAccessToken: null,
          lineChannelSecret: null,
          lineTokenConfigured,
          lineSecretConfigured,
          ...subscription,
          fontScale: savedFontScale
        }, "บันทึกการตั้งค่าระบบเรียบร้อยแล้วค่ะ");
      }
    }

    // ──────────────────────────────────────────────
    // 6.5 CARETAKERS / STAFF API
    // ──────────────────────────────────────────────
    // 6. Dashboard API
    if (path === "/api/dashboard" && method === "GET") {
      const authUser = await getAuthUser();
      if (!authUser) return errorResponse('UNAUTHORIZED', 'กรุณาล็อกอินเข้าสู่ระบบก่อนใช้งาน', 401);
      if (!env.DB) return errorResponse("DATABASE_ERROR", "ไม่พบการเชื่อมต่อฐานข้อมูล D1", 500);
      const userId = authUser.effectiveUserId || authUser.id;
      const now = new Date();
      const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
      const history: Record<string, { month: string; paid: number; unpaid: number; total: number }> = {};
      for (let offset = 5; offset >= 0; offset--) {
        const date = new Date(now.getFullYear(), now.getMonth() - offset, 1);
        const month = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
        history[month] = { month, paid: 0, unpaid: 0, total: 0 };
      }
      const [roomRows, billRows] = await env.DB.batch([
        env.DB.prepare("SELECT id, room_number, status FROM rooms WHERE user_id = ? AND deleted_at IS NULL").bind(userId),
        env.DB.prepare(`SELECT b.id, b.room_id, b.bill_month, b.total_cost, b.status, r.room_number, r.tenant_name
                        FROM bills b JOIN rooms r ON r.id = b.room_id
                        WHERE b.user_id = ? AND b.deleted_at IS NULL AND r.deleted_at IS NULL`).bind(userId)
      ]);
      const rooms = roomRows.results || [];
      const bills = billRows.results || [];
      const occupied = rooms.filter((room: any) => room.status === 'occupied').length;
      let total = 0, paid = 0, unpaid = 0;
      const unpaidRooms: any[] = [];
      for (const bill of bills as any[]) {
        const amount = Number(bill.total_cost) || 0;
        if (bill.bill_month === currentMonth) {
          total += amount;
          if (bill.status === 'paid') paid += amount;
          else unpaid += amount;
        }
        if (bill.status === 'unpaid') {
          unpaidRooms.push({ billId: bill.id, roomId: bill.room_id, roomNumber: bill.room_number, tenantName: bill.tenant_name || 'ไม่ระบุชื่อ', amount, month: bill.bill_month });
        }
        const bucket = history[bill.bill_month];
        if (bucket) {
          bucket.total += amount;
          if (bill.status === 'paid') bucket.paid += amount;
          else bucket.unpaid += amount;
        }
      }
      return successResponse({
        rooms: { total: rooms.length, occupied, vacant: rooms.length - occupied },
        revenueThisMonth: { total, paid, unpaid },
        unpaidRooms,
        revenueHistory: Object.values(history).sort((a, b) => a.month.localeCompare(b.month))
      });
    }

    // 7. Lease Contracts API
    if (path === '/api/maintenance' || path.startsWith('/api/maintenance/')) {
      if (path === '/api/maintenance' && method === 'POST') {
        const body = await getJson();
        const tenant = await getTenantSession();
        const authUser = tenant ? null : await getAuthUser();
        if (!tenant && !authUser) return errorResponse('UNAUTHORIZED', 'กรุณาเข้าสู่ระบบก่อนแจ้งซ่อม', 401);
        if (!env.DB) return errorResponse('DATABASE_ERROR', 'ไม่พบการเชื่อมต่อฐานข้อมูล D1', 500);

        const roomId = Number(body.roomId);
        const effectiveUserId = tenant?.userId || authUser.effectiveUserId || authUser.id;
        if (!Number.isInteger(roomId) || roomId <= 0 || !String(body.title || '').trim()) {
          return errorResponse('VALIDATION_ERROR', 'กรุณาระบุห้องพักและหัวข้อแจ้งซ่อม', 400);
        }
        if (tenant && tenant.roomId !== roomId) return errorResponse('FORBIDDEN', 'ไม่สามารถแจ้งซ่อมแทนห้องอื่นได้', 403);

        const room = await env.DB.prepare(
          'SELECT * FROM rooms WHERE id = ? AND user_id = ? AND deleted_at IS NULL'
        ).bind(roomId, effectiveUserId).first();
        if (!room) return errorResponse('NOT_FOUND', 'ไม่พบห้องพักที่ระบุ', 404);

        const allowedCategories = ['plumbing', 'electrical', 'appliance', 'furniture', 'structure', 'other'];
        const allowedPriorities = ['low', 'medium', 'high', 'urgent'];
        const title = String(body.title).trim().slice(0, 200);
        const description = String(body.description || '').trim().slice(0, 5000) || null;
        const category = allowedCategories.includes(body.category) ? body.category : 'other';
        const priority = allowedPriorities.includes(body.priority) ? body.priority : 'medium';
        const imageUrl = body.imageUrl ? String(body.imageUrl).slice(0, 5 * 1024 * 1024) : null;
        const created = await env.DB.prepare(
          `INSERT INTO maintenance_tickets
            (user_id, room_id, room_number, tenant_name, tenant_phone, title, description, category, priority, status, image_url)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?) RETURNING *`
        ).bind(
          effectiveUserId,
          roomId,
          room.room_number,
          room.tenant_name,
          room.tenant_phone,
          title,
          description,
          category,
          priority,
          imageUrl,
        ).first();
        return successResponse(mapMaintenanceTicket(created), 'สร้างรายการแจ้งซ่อมเรียบร้อยแล้ว', 201);
      }

      const authUser = await getAuthUser();
      if (!authUser) return errorResponse('UNAUTHORIZED', 'กรุณาเข้าสู่ระบบก่อนใช้งาน', 401);
      if (!env.DB) return errorResponse('DATABASE_ERROR', 'ไม่พบการเชื่อมต่อฐานข้อมูล D1', 500);
      const effectiveUserId = authUser.effectiveUserId || authUser.id;

      if (path === '/api/maintenance' && method === 'GET') {
        if (!hasCaretakerPermission(authUser, PERMISSIONS.VIEW_MAINTENANCE)) return errorResponse('FORBIDDEN', 'ไม่มีสิทธิ์ดูงานแจ้งซ่อม', 403);
        const { results } = await env.DB.prepare(
          'SELECT * FROM maintenance_tickets WHERE user_id = ? AND deleted_at IS NULL ORDER BY created_at DESC'
        ).bind(effectiveUserId).all();
        return successResponse((results || []).map(mapMaintenanceTicket));
      }

      const ticketId = Number(path.split('/')[3]);
      if (!Number.isInteger(ticketId) || ticketId <= 0) return errorResponse('VALIDATION_ERROR', 'รหัสรายการแจ้งซ่อมไม่ถูกต้อง', 400);
      const existing = await env.DB.prepare(
        'SELECT * FROM maintenance_tickets WHERE id = ? AND user_id = ? AND deleted_at IS NULL'
      ).bind(ticketId, effectiveUserId).first();
      if (!existing) return errorResponse('NOT_FOUND', 'ไม่พบรายการแจ้งซ่อม', 404);

      if (method === 'PUT') {
        if (!hasCaretakerPermission(authUser, PERMISSIONS.MANAGE_MAINTENANCE)) return errorResponse('FORBIDDEN', 'ไม่มีสิทธิ์จัดการงานแจ้งซ่อม', 403);
        const body = await getJson();
        const allowedStatuses = ['pending', 'in_progress', 'completed', 'cancelled'];
        const allowedPriorities = ['low', 'medium', 'high', 'urgent'];
        const status = allowedStatuses.includes(body.status) ? body.status : existing.status;
        const priority = allowedPriorities.includes(body.priority) ? body.priority : existing.priority;
        const repairCost = body.repairCost === undefined ? existing.repair_cost : Math.max(0, Number(body.repairCost) || 0);
        const technicianNote = body.technicianNote === undefined
          ? existing.technician_note
          : String(body.technicianNote || '').trim().slice(0, 5000) || null;
        const updated = await env.DB.prepare(
          `UPDATE maintenance_tickets
           SET status = ?, priority = ?, repair_cost = ?, technician_note = ?, updated_at = CURRENT_TIMESTAMP
           WHERE id = ? AND user_id = ? RETURNING *`
        ).bind(status, priority, repairCost, technicianNote, ticketId, effectiveUserId).first();
        return successResponse(mapMaintenanceTicket(updated), 'อัปเดตรายการแจ้งซ่อมเรียบร้อยแล้ว');
      }

      if (method === 'DELETE') {
        if (!hasCaretakerPermission(authUser, PERMISSIONS.MANAGE_MAINTENANCE)) return errorResponse('FORBIDDEN', 'ไม่มีสิทธิ์จัดการงานแจ้งซ่อม', 403);
        await env.DB.prepare(
          'UPDATE maintenance_tickets SET deleted_at = CURRENT_TIMESTAMP, deleted_by = ? WHERE id = ? AND user_id = ?'
        ).bind(authUser.id, ticketId, effectiveUserId).run();
        return successResponse({ success: true }, 'ลบรายการแจ้งซ่อมเรียบร้อยแล้ว');
      }

      return errorResponse('METHOD_NOT_ALLOWED', 'ไม่รองรับวิธีการเรียกใช้งานนี้', 405);
    }

    if (path === "/api/contracts" || path.startsWith("/api/contracts/")) {
      const authUser = await getAuthUser();
      if (!authUser) return errorResponse('UNAUTHORIZED', 'กรุณาล็อกอินเข้าสู่ระบบก่อนใช้งาน', 401);
      if (!env.DB) return errorResponse("DATABASE_ERROR", "ไม่พบการเชื่อมต่อฐานข้อมูล D1", 500);

      const mapContract = (c: any) => ({
        id: c.id, userId: c.user_id, roomId: c.room_id, roomNumber: c.room_number,
        tenantName: c.tenant_name, tenantPhone: c.tenant_phone, idCardNumber: c.id_card_number,
        startDate: c.start_date, endDate: c.end_date, monthlyRent: c.monthly_rent,
        depositAmount: c.deposit_amount, advanceRentAmount: c.advance_rent_amount,
        contractDocumentUrl: c.contract_document_url, status: c.status, note: c.note,
        createdAt: c.created_at, updatedAt: c.updated_at
      });

      if (path === "/api/contracts" && method === "GET") {
        if (!hasCaretakerPermission(authUser, PERMISSIONS.VIEW_CONTRACTS)) return errorResponse('FORBIDDEN', 'ไม่มีสิทธิ์ดูสัญญา', 403);
        const { results } = await env.DB.prepare(
          "SELECT * FROM lease_contracts WHERE user_id = ? AND deleted_at IS NULL ORDER BY created_at DESC"
        ).bind(authUser.effectiveUserId || authUser.id).all();
        return successResponse((results || []).map(mapContract));
      }

      if (path === "/api/contracts" && method === "POST") {
        if (!hasCaretakerPermission(authUser, PERMISSIONS.MANAGE_CONTRACTS)) return errorResponse('FORBIDDEN', 'ไม่มีสิทธิ์จัดการสัญญา', 403);
        const body = await getJson();
        const roomId = Number(body.roomId);
        const tenantName = String(body.tenantName || '').trim();
        const startDate = String(body.startDate || '');
        const endDate = String(body.endDate || '');
        if (!roomId || !tenantName || !startDate || !endDate) {
          return errorResponse("VALIDATION_ERROR", "กรุณาระบุห้องพัก ชื่อผู้เช่า วันเริ่ม และวันสิ้นสุดสัญญา", 400);
        }
        if (endDate < startDate) {
          return errorResponse("VALIDATION_ERROR", "วันสิ้นสุดสัญญาต้องไม่ก่อนวันเริ่มสัญญา", 400);
        }
        const room = await env.DB.prepare(
          "SELECT * FROM rooms WHERE id = ? AND user_id = ? AND deleted_at IS NULL"
        ).bind(roomId, authUser.effectiveUserId || authUser.id).first();
        if (!room) return errorResponse("NOT_FOUND", "ไม่พบห้องพักที่เลือก", 404);

        const today = new Date().toISOString().slice(0, 10);
        const in60Days = new Date(Date.now() + 60 * 86400000).toISOString().slice(0, 10);
        const status = endDate < today ? 'expired' : endDate <= in60Days ? 'expiring_soon' : 'active';
        const result = await env.DB.prepare(
          `INSERT INTO lease_contracts (user_id, room_id, room_number, tenant_name, tenant_phone, id_card_number, start_date, end_date, monthly_rent, deposit_amount, advance_rent_amount, contract_document_url, status, note)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING *`
        ).bind(
          authUser.effectiveUserId || authUser.id, roomId, room.room_number, tenantName, body.tenantPhone?.trim() || null,
          body.idCardNumber?.trim() || null, startDate, endDate, Number(body.monthlyRent) || room.monthly_rent,
          Number(body.depositAmount) || 0, Number(body.advanceRentAmount) || 0,
          body.contractDocumentUrl || null, status, body.note?.trim() || null
        ).first();
        await env.DB.prepare(
          "UPDATE rooms SET status = 'occupied', tenant_name = ?, tenant_phone = ? WHERE id = ? AND user_id = ?"
        ).bind(tenantName, body.tenantPhone?.trim() || null, roomId, authUser.effectiveUserId || authUser.id).run();
        return successResponse(mapContract(result), "ทำสัญญาเช่าเรียบร้อยแล้ว", 201);
      }

      const id = Number(path.split("/")[3]);
      if (!id) return errorResponse("VALIDATION_ERROR", "รหัสสัญญาไม่ถูกต้อง", 400);
      const existing = await env.DB.prepare(
        "SELECT * FROM lease_contracts WHERE id = ? AND user_id = ?"
      ).bind(id, authUser.effectiveUserId || authUser.id).first();
      if (!existing) return errorResponse("NOT_FOUND", "ไม่พบสัญญาเช่าที่ระบุ", 404);

      if (path.endsWith("/checkout") && method === "POST") {
        if (!hasCaretakerPermission(authUser, PERMISSIONS.PROCESS_CHECKOUT)) return errorResponse('FORBIDDEN', 'ไม่มีสิทธิ์ดำเนินการย้ายออก', 403);
        await env.DB.batch([
          env.DB.prepare("UPDATE lease_contracts SET status = 'terminated', updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?").bind(id, authUser.effectiveUserId || authUser.id),
          env.DB.prepare("UPDATE rooms SET status = 'vacant', tenant_name = NULL, tenant_phone = NULL, line_user_id = NULL, line_display_name = NULL, line_picture_url = NULL, line_status = 'unlinked', line_notify_token = NULL WHERE id = ? AND user_id = ?").bind(existing.room_id, authUser.effectiveUserId || authUser.id),
          env.DB.prepare("INSERT OR IGNORE INTO housekeeping_tasks (user_id, room_id, contract_id, source, status, note, created_by) VALUES (?, ?, ?, 'checkout', 'pending', ?, ?)").bind(authUser.effectiveUserId || authUser.id, existing.room_id, id, `ทำความสะอาดหลังย้ายออก: ${existing.tenant_name}`, authUser.id)
        ]);
        return successResponse({ success: true }, "ทำรายการย้ายออกเรียบร้อยแล้ว");
      }

      if (method === "PUT") {
        if (!hasCaretakerPermission(authUser, PERMISSIONS.MANAGE_CONTRACTS)) return errorResponse('FORBIDDEN', 'ไม่มีสิทธิ์จัดการสัญญา', 403);
        const body = await getJson();
        const tenantName = String(body.tenantName ?? existing.tenant_name).trim();
        if (!tenantName) return errorResponse("VALIDATION_ERROR", "กรุณาระบุชื่อผู้เช่า", 400);
        const updated = await env.DB.prepare(
          `UPDATE lease_contracts SET tenant_name = ?, tenant_phone = ?, id_card_number = ?, start_date = ?, end_date = ?, monthly_rent = ?, deposit_amount = ?, advance_rent_amount = ?, contract_document_url = ?, note = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ? RETURNING *`
        ).bind(tenantName, body.tenantPhone?.trim() || null, body.idCardNumber?.trim() || null,
          body.startDate || existing.start_date, body.endDate || existing.end_date,
          Number(body.monthlyRent) || 0, Number(body.depositAmount) || 0, Number(body.advanceRentAmount) || 0,
          body.contractDocumentUrl || null, body.note || null, id, authUser.effectiveUserId || authUser.id).first();
        await env.DB.prepare("UPDATE rooms SET tenant_name = ?, tenant_phone = ? WHERE id = ? AND user_id = ?").bind(tenantName, body.tenantPhone?.trim() || null, existing.room_id, authUser.effectiveUserId || authUser.id).run();
        return successResponse(mapContract(updated), "อัปเดตสัญญาเช่าเรียบร้อยแล้ว");
      }

      if (method === "DELETE") {
        if (!hasCaretakerPermission(authUser, PERMISSIONS.MANAGE_CONTRACTS)) return errorResponse('FORBIDDEN', 'ไม่มีสิทธิ์จัดการสัญญา', 403);
        await env.DB.prepare("UPDATE lease_contracts SET deleted_at = CURRENT_TIMESTAMP, deleted_by = ? WHERE id = ? AND user_id = ?").bind(authUser.id, id, authUser.effectiveUserId || authUser.id).run();
        return successResponse({ success: true }, "ลบสัญญาเช่าเรียบร้อยแล้ว");
      }
    }

    // 7. Internal Notes API (authenticated staff only)
    if (path === "/api/notes" || path.startsWith("/api/notes/")) {
      const authUser = await getAuthUser();
      if (!authUser) return errorResponse('UNAUTHORIZED', 'กรุณาเข้าสู่ระบบก่อนใช้งานโน้ต', 401);
      if (!env.DB) return errorResponse('DATABASE_ERROR', 'ไม่พบการเชื่อมต่อฐานข้อมูล D1', 500);

      try {
      const userId = Number(authUser.effectiveUserId || authUser.id);
      const actorId = Number(authUser.id);
      const userLimit = await RateLimiterService.checkRateLimit(
        env.DB,
        `${actorId}:${clientIp}`,
        method === 'GET' ? 'notes_read' : 'notes_write'
      );
      if (!userLimit.allowed) {
        return errorResponse('TOO_MANY_REQUESTS', `ทำรายการโน้ตถี่เกินไป กรุณารอ ${userLimit.retryAfterSeconds} วินาที`, 429);
      }

      const mapNote = (item: any) => ({
        id: item.id,
        userId: item.user_id,
        createdBy: item.created_by,
        createdByEmail: item.created_by_email || null,
        roomId: item.room_id,
        roomNumber: item.room_number || null,
        title: item.title,
        content: item.content,
        color: item.color,
        isPinned: item.is_pinned,
        createdAt: item.created_at,
        updatedAt: item.updated_at,
      });

      if (path === '/api/notes' && method === 'GET') {
        const parsedLimit = Number.parseInt(url.searchParams.get('limit') || '', 10);
        const parsedOffset = Number.parseInt(url.searchParams.get('offset') || '', 10);
        const limit = Number.isFinite(parsedLimit) ? Math.min(Math.max(parsedLimit, 1), NOTE_LIST_MAX_LIMIT) : NOTE_LIST_MAX_LIMIT;
        const offset = Number.isFinite(parsedOffset) ? Math.min(Math.max(parsedOffset, 0), 10_000) : 0;
        const { results } = await env.DB.prepare(
          `SELECT n.*, u.email AS created_by_email, r.room_number
           FROM notes n
           LEFT JOIN users u ON u.id = n.created_by
           LEFT JOIN rooms r ON r.id = n.room_id
           WHERE n.user_id = ? AND n.deleted_at IS NULL
           ORDER BY n.is_pinned DESC, n.updated_at DESC, n.id DESC
           LIMIT ? OFFSET ?`
        ).bind(userId, limit, offset).all();
        return successResponse((results || []).map(mapNote));
      }

      if (path === '/api/notes' && method === 'POST') {
        const bodyResult = await readBoundedJson(request, NOTE_REQUEST_MAX_BYTES, { entityName: 'คำขอโน้ต', invalid: 'รูปแบบ JSON ไม่ถูกต้อง', tooLarge: 'ข้อมูลโน้ตมีขนาดใหญ่เกินกำหนด' });
        if (bodyResult.ok === false) return errorResponse(bodyResult.code, bodyResult.message, bodyResult.status);
        const parsed = NoteCreateSchema.safeParse(bodyResult.data);
        if (!parsed.success) {
          return errorResponse('VALIDATION_ERROR', parsed.error.issues[0]?.message || 'ข้อมูลโน้ตไม่ถูกต้อง', 400, getNoteValidationDetails(parsed.error));
        }

        const input = parsed.data;
        let roomNumber: string | null = null;
        if (input.roomId !== null) {
          const room = await env.DB.prepare(
            'SELECT room_number FROM rooms WHERE id = ? AND user_id = ? AND deleted_at IS NULL'
          ).bind(input.roomId, userId).first();
          if (!room) return errorResponse('INVALID_ROOM', 'ไม่พบห้องพักที่เลือกในหอพักนี้', 400);
          roomNumber = String(room.room_number);
        }

        const created = await env.DB.prepare(
          `INSERT INTO notes (user_id, created_by, room_id, title, content, color, is_pinned)
           VALUES (?, ?, ?, ?, ?, ?, ?) RETURNING *`
        ).bind(userId, actorId, input.roomId, input.title, input.content, input.color, input.isPinned ? 1 : 0).first();
        if (!created) return errorResponse('DATABASE_ERROR', 'ไม่สามารถสร้างโน้ตได้', 500);

        await logAuditAction(env.DB, {
          userId,
          userEmail: authUser.email || 'system',
          userRole: authUser.role || 'owner',
          action: 'CREATE_NOTE',
          targetType: 'note',
          targetId: created ? String(created.id) : null,
          newValue: {
            title: input.title,
            roomId: input.roomId,
            color: input.color,
            isPinned: input.isPinned ? 1 : 0,
            contentLength: input.content.length,
          },
          ipAddress: clientIp,
          userAgent,
        });

        return successResponse(mapNote({ ...created, created_by_email: authUser.email, room_number: roomNumber }), 'สร้างโน้ตเรียบร้อยแล้ว', 201);
      }

      const noteId = Number.parseInt(path.split('/')[3] || '', 10);
      if (!Number.isInteger(noteId) || noteId <= 0) return errorResponse('VALIDATION_ERROR', 'รหัสโน้ตไม่ถูกต้อง', 400);
      const existing = await env.DB.prepare(
        'SELECT * FROM notes WHERE id = ? AND user_id = ? AND deleted_at IS NULL'
      ).bind(noteId, userId).first();
      if (!existing) return errorResponse('NOT_FOUND', 'ไม่พบโน้ตที่ระบุ', 404);

      if (method === 'PUT') {
        const bodyResult = await readBoundedJson(request, NOTE_REQUEST_MAX_BYTES, { entityName: 'คำขอโน้ต', invalid: 'รูปแบบ JSON ไม่ถูกต้อง', tooLarge: 'ข้อมูลโน้ตมีขนาดใหญ่เกินกำหนด' });
        if (bodyResult.ok === false) return errorResponse(bodyResult.code, bodyResult.message, bodyResult.status);
        const parsed = NoteUpdateSchema.safeParse(bodyResult.data);
        if (!parsed.success) {
          return errorResponse('VALIDATION_ERROR', parsed.error.issues[0]?.message || 'ข้อมูลโน้ตไม่ถูกต้อง', 400, getNoteValidationDetails(parsed.error));
        }

        const input = parsed.data;
        if (input.roomId !== undefined && input.roomId !== null) {
          const room = await env.DB.prepare(
            'SELECT id FROM rooms WHERE id = ? AND user_id = ? AND deleted_at IS NULL'
          ).bind(input.roomId, userId).first();
          if (!room) return errorResponse('INVALID_ROOM', 'ไม่พบห้องพักที่เลือกในหอพักนี้', 400);
        }

        const title = input.title ?? String(existing.title);
        const content = input.content ?? String(existing.content);
        const roomId = input.roomId === undefined ? (existing.room_id ?? null) : input.roomId;
        const color = input.color ?? String(existing.color);
        const isPinned = input.isPinned === undefined ? Number(existing.is_pinned) : (input.isPinned ? 1 : 0);
        const updated = await env.DB.prepare(
          `UPDATE notes SET title = ?, content = ?, room_id = ?, color = ?, is_pinned = ?, updated_at = CURRENT_TIMESTAMP
           WHERE id = ? AND user_id = ? AND deleted_at IS NULL RETURNING *`
        ).bind(title, content, roomId, color, isPinned, noteId, userId).first();
        if (!updated) return errorResponse('DATABASE_ERROR', 'ไม่สามารถแก้ไขโน้ตได้', 500);

        await logAuditAction(env.DB, {
          userId,
          userEmail: authUser.email || 'system',
          userRole: authUser.role || 'owner',
          action: 'UPDATE_NOTE',
          targetType: 'note',
          targetId: noteId,
          newValue: { title, roomId, color, isPinned, contentLength: content.length },
          ipAddress: clientIp,
          userAgent,
        });
        return successResponse(mapNote({ ...updated, created_by_email: authUser.email }), 'แก้ไขโน้ตเรียบร้อยแล้ว');
      }

      if (method === 'DELETE') {
        await env.DB.prepare(
          'UPDATE notes SET deleted_at = CURRENT_TIMESTAMP, deleted_by = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ? AND deleted_at IS NULL'
        ).bind(actorId, noteId, userId).run();
        await logAuditAction(env.DB, {
          userId,
          userEmail: authUser.email || 'system',
          userRole: authUser.role || 'owner',
          action: 'DELETE_NOTE',
          targetType: 'note',
          targetId: noteId,
          newValue: { title: String(existing.title) },
          ipAddress: clientIp,
          userAgent,
        });
        return successResponse({ success: true }, 'ลบโน้ตเรียบร้อยแล้ว');
      }

      return errorResponse('METHOD_NOT_ALLOWED', 'ไม่รองรับวิธีการเรียกใช้งานนี้', 405);
      } catch (error) {
        console.error(JSON.stringify({
          message: 'notes request failed',
          method,
          path,
          error: error instanceof Error ? error.message : String(error),
        }));
        return errorResponse('DATABASE_ERROR', 'ไม่สามารถดำเนินการโน้ตได้', 500);
      }
    }

    // 8. Announcements API
    if (path === "/api/announcements" || path.startsWith("/api/announcements/")) {
      const authUser = await getAuthUser();
      if (!authUser) return errorResponse('UNAUTHORIZED', 'กรุณาล็อกอินเข้าสู่ระบบก่อนใช้งาน', 401);
      if (!env.DB) return errorResponse("DATABASE_ERROR", "ไม่พบการเชื่อมต่อฐานข้อมูล D1", 500);
      const mapAnnouncement = (item: any) => ({
        id: item.id, userId: item.user_id, title: item.title, content: item.content,
        category: item.category, isPinned: item.is_pinned, targetRoomIds: item.target_room_ids,
        imageUrl: item.image_url, createdAt: item.created_at, updatedAt: item.updated_at
      });

      if (path === "/api/announcements" && method === "GET") {
        const { results } = await env.DB.prepare(
          "SELECT * FROM announcements WHERE user_id = ? AND deleted_at IS NULL ORDER BY is_pinned DESC, created_at DESC"
        ).bind(authUser.effectiveUserId || authUser.id).all();
        return successResponse((results || []).map(mapAnnouncement));
      }

      if (path === "/api/announcements" && method === "POST") {
        const body = await getJson();
        const title = String(body.title || '').trim();
        const content = String(body.content || '').trim();
        if (!title || !content) {
          return errorResponse("VALIDATION_ERROR", "กรุณาระบุหัวข้อและรายละเอียดประกาศ", 400);
        }
        const created = await env.DB.prepare(
          `INSERT INTO announcements (user_id, title, content, category, is_pinned, target_room_ids, image_url)
           VALUES (?, ?, ?, ?, ?, ?, ?) RETURNING *`
        ).bind(authUser.effectiveUserId || authUser.id, title, content, body.category || 'general', body.isPinned ? 1 : 0,
          body.targetRoomIds?.trim() || null, body.imageUrl || null).first();
        return successResponse(mapAnnouncement(created), "สร้างประกาศเรียบร้อยแล้ว", 201);
      }

      const id = Number(path.split("/")[3]);
      if (!id) return errorResponse("VALIDATION_ERROR", "รหัสประกาศไม่ถูกต้อง", 400);
      const existing = await env.DB.prepare(
        "SELECT * FROM announcements WHERE id = ? AND user_id = ?"
      ).bind(id, authUser.effectiveUserId || authUser.id).first();
      if (!existing) return errorResponse("NOT_FOUND", "ไม่พบประกาศที่ระบุ", 404);

      if (method === "PUT") {
        const body = await getJson();
        const title = body.title === undefined ? existing.title : String(body.title).trim();
        const content = body.content === undefined ? existing.content : String(body.content).trim();
        if (!title || !content) return errorResponse("VALIDATION_ERROR", "กรุณาระบุหัวข้อและรายละเอียดประกาศ", 400);
        const updated = await env.DB.prepare(
          `UPDATE announcements SET title = ?, content = ?, category = ?, is_pinned = ?, target_room_ids = ?, image_url = ?, updated_at = CURRENT_TIMESTAMP
           WHERE id = ? AND user_id = ? RETURNING *`
        ).bind(title, content, body.category ?? existing.category,
          body.isPinned === undefined ? existing.is_pinned : (body.isPinned ? 1 : 0),
          body.targetRoomIds === undefined ? existing.target_room_ids : (body.targetRoomIds?.trim() || null),
          body.imageUrl === undefined ? existing.image_url : (body.imageUrl || null), id, authUser.effectiveUserId || authUser.id).first();
        return successResponse(mapAnnouncement(updated), "อัปเดตประกาศเรียบร้อยแล้ว");
      }

      if (method === "DELETE") {
        await env.DB.prepare("UPDATE announcements SET deleted_at = CURRENT_TIMESTAMP, deleted_by = ? WHERE id = ? AND user_id = ?").bind(authUser.id, id, authUser.effectiveUserId || authUser.id).run();
        return successResponse({ success: true }, "ลบประกาศเรียบร้อยแล้ว");
      }
    }

    // Recurring charge templates, room assignments, and resolved charges.
    if (path === '/api/recurring-charges/templates' || path.startsWith('/api/recurring-charges/templates/')) {
      const authUser = await getAuthUser(); if (!authUser) return errorResponse('UNAUTHORIZED', 'กรุณาเข้าสู่ระบบ', 401); if (!env.DB) return errorResponse('DATABASE_ERROR', 'ไม่พบฐานข้อมูล', 500);
      const ownerId = Number(authUser.effectiveUserId || authUser.id);
      const mapTemplate = (row: any) => ({ id: row.id, userId: row.user_id, name: row.name, description: row.description, defaultAmount: row.default_amount, frequency: row.frequency, billingMonths: (() => { try { return JSON.parse(row.billing_months || '[]'); } catch { return []; } })(), isActive: row.is_active === 1, createdAt: row.created_at, updatedAt: row.updated_at });
      if (method === 'GET' && path === '/api/recurring-charges/templates') {
        if (!hasCaretakerPermission(authUser, PERMISSIONS.VIEW_BILLS) && !hasCaretakerPermission(authUser, PERMISSIONS.MANAGE_RECURRING_CHARGES)) return errorResponse('FORBIDDEN', 'ไม่มีสิทธิ์ดูค่าบริการประจำ', 403);
        const { results } = await env.DB.prepare('SELECT * FROM recurring_charge_templates WHERE user_id = ? AND deleted_at IS NULL ORDER BY name').bind(ownerId).all(); return successResponse((results || []).map(mapTemplate));
      }
      if (!hasCaretakerPermission(authUser, PERMISSIONS.MANAGE_RECURRING_CHARGES)) return errorResponse('FORBIDDEN', 'ไม่มีสิทธิ์จัดการค่าบริการประจำ', 403);
      if (method === 'POST') {
        try { const body = await getJson(); const name = String(body.name || '').trim(); const frequency = String(body.frequency || 'monthly') as any; if (!name || name.length > 120 || !['monthly','quarterly','yearly'].includes(frequency)) return errorResponse('VALIDATION_ERROR', 'ข้อมูลแม่แบบไม่ถูกต้อง', 400); const months = normalizeBillingMonths(frequency, Array.isArray(body.billingMonths) ? body.billingMonths : []); const created = await env.DB.prepare('INSERT INTO recurring_charge_templates (user_id,name,description,default_amount,frequency,billing_months,is_active) VALUES (?,?,?,?,?,?,?) RETURNING *').bind(ownerId, name, String(body.description || '').trim() || null, Math.max(0, Math.round(Number(body.defaultAmount) || 0)), frequency, JSON.stringify(months), body.isActive === false ? 0 : 1).first(); await logAuditAction(env.DB, { userId: ownerId, userEmail: authUser.email, userRole: authUser.role, action: 'CREATE_RECURRING_TEMPLATE', targetType: 'recurring_charge_template', targetId: created?.id, newValue: { name, frequency, months }, ipAddress: clientIp, userAgent }); return successResponse(mapTemplate(created), 'สร้างแม่แบบค่าบริการแล้ว', 201); } catch (error) { return errorResponse('VALIDATION_ERROR', error instanceof Error ? error.message : 'ข้อมูลไม่ถูกต้อง', 400); }
      }
      const id = Number(path.split('/')[4]); if (!id) return errorResponse('VALIDATION_ERROR', 'รหัสแม่แบบไม่ถูกต้อง', 400);
      if (method === 'PUT') { try { const body = await getJson(); const name = String(body.name || '').trim(); const frequency = String(body.frequency || 'monthly') as any; const months = normalizeBillingMonths(frequency, Array.isArray(body.billingMonths) ? body.billingMonths : []); const updated = await env.DB.prepare('UPDATE recurring_charge_templates SET name=?,description=?,default_amount=?,frequency=?,billing_months=?,is_active=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND user_id=? AND deleted_at IS NULL RETURNING *').bind(name, String(body.description || '').trim() || null, Math.max(0, Math.round(Number(body.defaultAmount) || 0)), frequency, JSON.stringify(months), body.isActive === false ? 0 : 1, id, ownerId).first(); if (!updated) return errorResponse('NOT_FOUND', 'ไม่พบแม่แบบ', 404); await logAuditAction(env.DB, { userId: authUser.id, userEmail: authUser.email, userRole: authUser.role, action: 'UPDATE_RECURRING_TEMPLATE', targetType: 'recurring_charge_template', targetId: id, newValue: { name, frequency, months }, ipAddress: clientIp, userAgent }); return successResponse(mapTemplate(updated)); } catch (error) { return errorResponse('VALIDATION_ERROR', error instanceof Error ? error.message : 'ข้อมูลไม่ถูกต้อง', 400); } }
      if (method === 'DELETE') { await env.DB.batch([env.DB.prepare('UPDATE recurring_charge_templates SET deleted_at=CURRENT_TIMESTAMP,is_active=0 WHERE id=? AND user_id=?').bind(id, ownerId), env.DB.prepare('UPDATE room_recurring_charges SET is_enabled=0,updated_at=CURRENT_TIMESTAMP WHERE template_id=? AND user_id=?').bind(id, ownerId)]); await logAuditAction(env.DB, { userId: authUser.id, userEmail: authUser.email, userRole: authUser.role, action: 'DELETE_RECURRING_TEMPLATE', targetType: 'recurring_charge_template', targetId: id, ipAddress: clientIp, userAgent }); return successResponse({ id }); }
    }

    const roomRecurringMatch = path.match(/^\/api\/rooms\/(\d+)\/recurring-charges$/);
    if (roomRecurringMatch) {
      const authUser = await getAuthUser(); if (!authUser || !env.DB) return errorResponse('UNAUTHORIZED', 'กรุณาเข้าสู่ระบบ', 401); const ownerId = Number(authUser.effectiveUserId || authUser.id); const roomId = Number(roomRecurringMatch[1]);
      if (method === 'GET') { if (!hasCaretakerPermission(authUser, PERMISSIONS.VIEW_ROOMS)) return errorResponse('FORBIDDEN', 'ไม่มีสิทธิ์ดูข้อมูลห้องพัก', 403); const { results } = await env.DB.prepare(`SELECT a.*,t.name,t.description,t.default_amount,t.frequency,t.billing_months,t.is_active FROM room_recurring_charges a JOIN recurring_charge_templates t ON t.id=a.template_id WHERE a.user_id=? AND a.room_id=? AND t.deleted_at IS NULL ORDER BY t.name`).bind(ownerId, roomId).all(); return successResponse((results || []).map((row: any) => ({ id: row.id, userId: row.user_id, roomId: row.room_id, templateId: row.template_id, amountOverride: row.amount_override, isEnabled: row.is_enabled === 1, template: { id: row.template_id, userId: ownerId, name: row.name, description: row.description, defaultAmount: row.default_amount, frequency: row.frequency, billingMonths: JSON.parse(row.billing_months || '[]'), isActive: row.is_active === 1 } }))); }
      if (method === 'PUT') { if (!hasCaretakerPermission(authUser, PERMISSIONS.MANAGE_RECURRING_CHARGES) && !hasCaretakerPermission(authUser, PERMISSIONS.MANAGE_ROOMS)) return errorResponse('FORBIDDEN', 'ไม่มีสิทธิ์ผูกค่าบริการ', 403); const body = await getJson(); const assignments = Array.isArray(body.assignments) ? body.assignments : []; const room = await env.DB.prepare('SELECT id FROM rooms WHERE id=? AND user_id=? AND deleted_at IS NULL').bind(roomId, ownerId).first(); if (!room) return errorResponse('NOT_FOUND', 'ไม่พบห้องพัก', 404); for (const item of assignments) { const template = await env.DB.prepare('SELECT id FROM recurring_charge_templates WHERE id=? AND user_id=? AND deleted_at IS NULL').bind(Number(item.templateId), ownerId).first(); if (!template) return errorResponse('VALIDATION_ERROR', 'มีแม่แบบที่ไม่อยู่ในหอพักนี้', 400); } const statements = [env.DB.prepare('DELETE FROM room_recurring_charges WHERE user_id=? AND room_id=?').bind(ownerId, roomId), ...assignments.map((item: any) => env.DB!.prepare('INSERT INTO room_recurring_charges (user_id,room_id,template_id,amount_override,is_enabled) VALUES (?,?,?,?,?)').bind(ownerId, roomId, Number(item.templateId), item.amountOverride === null || item.amountOverride === '' ? null : Math.max(0, Math.round(Number(item.amountOverride) || 0)), item.isEnabled === false ? 0 : 1))]; await env.DB.batch(statements); await logAuditAction(env.DB, { userId: authUser.id, userEmail: authUser.email, userRole: authUser.role, action: 'UPDATE_ROOM_RECURRING_CHARGES', targetType: 'room', targetId: roomId, newValue: { assignments: assignments.length }, ipAddress: clientIp, userAgent }); return successResponse({ roomId }); }
    }

    if (path === '/api/housekeeping' || path.startsWith('/api/housekeeping/')) {
      const authUser = await getAuthUser(); if (!authUser || !env.DB) return errorResponse('UNAUTHORIZED', 'กรุณาเข้าสู่ระบบ', 401); const ownerId = Number(authUser.effectiveUserId || authUser.id);
      if (method === 'GET' && path === '/api/housekeeping') { if (!hasCaretakerPermission(authUser, PERMISSIONS.VIEW_HOUSEKEEPING)) return errorResponse('FORBIDDEN', 'ไม่มีสิทธิ์ดูงานแม่บ้าน', 403); const { results } = await env.DB.prepare(`SELECT h.*,r.room_number,u.email assigned_user_email FROM housekeeping_tasks h JOIN rooms r ON r.id=h.room_id LEFT JOIN users u ON u.id=h.assigned_user_id WHERE h.user_id=? ORDER BY h.id DESC`).bind(ownerId).all(); return successResponse((results || []).map((row: any) => ({ id: row.id, userId: row.user_id, roomId: row.room_id, roomNumber: row.room_number, assignedUserId: row.assigned_user_id, assignedUserEmail: row.assigned_user_email, contractId: row.contract_id, source: row.source, status: row.status, note: row.note, inspectionNote: row.inspection_note, createdBy: row.created_by, createdAt: row.created_at, updatedAt: row.updated_at, completedAt: row.completed_at }))); }
      if (!hasCaretakerPermission(authUser, PERMISSIONS.MANAGE_HOUSEKEEPING)) return errorResponse('FORBIDDEN', 'ไม่มีสิทธิ์จัดการงานแม่บ้าน', 403);
      if (method === 'POST' && path === '/api/housekeeping') { const body = await getJson(); const roomId = Number(body.roomId); const room = await env.DB.prepare('SELECT id FROM rooms WHERE id=? AND user_id=? AND deleted_at IS NULL').bind(roomId, ownerId).first(); if (!room) return errorResponse('NOT_FOUND', 'ไม่พบห้องพัก', 404); const assignedUserId = body.assignedUserId ? Number(body.assignedUserId) : null; if (assignedUserId && !await env.DB.prepare("SELECT id FROM users WHERE id=? AND parent_id=? AND role='housekeeper' AND deleted_at IS NULL").bind(assignedUserId, ownerId).first()) return errorResponse('VALIDATION_ERROR', 'ผู้รับผิดชอบต้องเป็นแม่บ้านในหอพักนี้', 400); const created = await env.DB.prepare(`INSERT INTO housekeeping_tasks (user_id,room_id,assigned_user_id,source,status,note,created_by) VALUES (?,?,?,'manual','pending',?,?) RETURNING *`).bind(ownerId, roomId, assignedUserId, String(body.note || '').trim().slice(0,2000) || null, authUser.id).first(); await logAuditAction(env.DB, { userId: authUser.id, userEmail: authUser.email, userRole: authUser.role, action: 'CREATE_HOUSEKEEPING_TASK', targetType: 'housekeeping', targetId: created?.id, newValue: { roomId }, ipAddress: clientIp, userAgent }); return successResponse(created, 'สร้างงานแม่บ้านแล้ว', 201); }
      if (method === 'PUT') { const id = Number(path.split('/')[3]); const body = await getJson(); const status = String(body.status || ''); if (!['pending','in_progress','ready_for_inspection','completed','cancelled'].includes(status)) return errorResponse('VALIDATION_ERROR', 'สถานะไม่ถูกต้อง', 400); const existing = await env.DB.prepare('SELECT * FROM housekeeping_tasks WHERE id=? AND user_id=?').bind(id, ownerId).first(); if (!existing) return errorResponse('NOT_FOUND', 'ไม่พบงานแม่บ้าน', 404); if (!canTransitionHousekeeping(String(existing.status), status)) return errorResponse('CONFLICT', 'ไม่สามารถเปลี่ยนสถานะงานตามลำดับนี้ได้', 409); const assignedUserId = body.assignedUserId ? Number(body.assignedUserId) : null; if (assignedUserId && !await env.DB.prepare("SELECT id FROM users WHERE id=? AND parent_id=? AND role='housekeeper' AND deleted_at IS NULL").bind(assignedUserId, ownerId).first()) return errorResponse('VALIDATION_ERROR', 'ผู้รับผิดชอบต้องเป็นแม่บ้านในหอพักนี้', 400); const updated = await env.DB.prepare(`UPDATE housekeeping_tasks SET status=?,assigned_user_id=?,note=?,inspection_note=?,updated_at=CURRENT_TIMESTAMP,completed_at=? WHERE id=? AND user_id=? RETURNING *`).bind(status, assignedUserId, String(body.note || '').trim().slice(0,2000) || null, String(body.inspectionNote || '').trim().slice(0,2000) || null, status === 'completed' ? new Date().toISOString() : null, id, ownerId).first(); await logAuditAction(env.DB, { userId: authUser.id, userEmail: authUser.email, userRole: authUser.role, action: 'UPDATE_HOUSEKEEPING_TASK', targetType: 'housekeeping', targetId: id, oldValue: { status: existing.status }, newValue: { status }, ipAddress: clientIp, userAgent }); return successResponse(updated); }
    }

    if (path === "/api/caretakers" || path.startsWith("/api/caretakers/")) {
      const authUser = await getAuthUser();
      if (!authUser || (authUser.role !== 'owner' && authUser.role !== 'super_admin' && !isStaffRole(authUser.role))) {
        return errorResponse("FORBIDDEN", "เฉพาะผู้ดูแลระบบ เจ้าของหอพัก และผู้ดูแลร่วมเท่านั้นที่สามารถเข้าถึงได้ค่ะ", 403);
      }

      const ownerId = (isStaffRole(authUser.role) && (authUser.parent_id || authUser.parentId))
        ? (authUser.parent_id || authUser.parentId)
        : authUser.id;

      if (path === "/api/caretakers" && method === "GET") {
        if (env.DB) {
          try {
            const { results } = await env.DB.prepare(
              "SELECT id, uid, email, role, permissions, parent_id, created_at FROM users WHERE role IN ('caretaker','accountant','technician','housekeeper','staff') AND parent_id = ? AND deleted_at IS NULL ORDER BY id DESC"
            ).bind(ownerId).all();
            return successResponse(results || []);
          } catch (e) {
            console.warn("D1 caretakers fetch notice:", e);
          }
        }
        return successResponse([]);
      }

      if (path === "/api/caretakers" && method === "POST") {
        if (isStaffRole(authUser.role)) {
          return errorResponse("FORBIDDEN", "เฉพาะเจ้าของหอพักและผู้ดูแลระบบเท่านั้นที่สามารถเพิ่มผู้ดูแลร่วมได้", 403);
        }
        const body = await getJson();
        const email = String(body.email || "").trim().toLowerCase();
        const rawPassword = String(body.password || "").trim();
        const staffRole = staffRoles.includes(String(body.role || 'caretaker')) ? String(body.role || 'caretaker') : '';
        if (!staffRole) return errorResponse('VALIDATION_ERROR', 'บทบาทพนักงานไม่ถูกต้อง', 400);
        const permissions = String(body.permissions || permissionsForRole(staffRole).join(','));

        if (!email) {
          return errorResponse("VALIDATION_ERROR", "กรุณาระบุ Username / User ID หรืออีเมลผู้ดูแลร่วม", 400);
        }

        const passwordPolicy = validatePasswordPolicy(rawPassword);
        if (!passwordPolicy.isValid) {
          return errorResponse("VALIDATION_ERROR", passwordPolicy.error || "รหัสผ่านไม่ผ่านนโยบายความปลอดภัย", 400);
        }

        if (env.DB) {
          try {
            const existing = await env.DB.prepare("SELECT * FROM users WHERE (email = ? OR uid = ?) AND deleted_at IS NULL").bind(email, email).first();
            if (existing) {
              return errorResponse("CONFLICT", `ชื่อผู้ใช้หรืออีเมล "${email}" ถูกใช้งานในระบบแล้วค่ะ`, 409);
            }

            const hashedPassword = await hashPassword(rawPassword);
            const tempUid = `caretaker_${crypto.randomUUID()}`;

            await env.DB.prepare(
              "INSERT INTO users (uid, email, role, password, permissions, parent_id) VALUES (?, ?, ?, ?, ?, ?)"
            ).bind(tempUid, email, staffRole, hashedPassword, permissions, ownerId).run();

            const created = await env.DB.prepare("SELECT id, uid, email, role, permissions, parent_id, created_at FROM users WHERE email = ? AND parent_id = ? AND deleted_at IS NULL").bind(email, ownerId).first();

            await logAuditAction(env.DB, {
              userId: authUser.id,
              userEmail: authUser.email || 'admin@dorm.com',
              userRole: authUser.role || 'super_admin',
              action: 'CREATE_CARETAKER',
              targetType: 'user',
              targetId: created ? String(created.id) : null,
              newValue: { email, role: staffRole, permissions },
              ipAddress: clientIp,
              userAgent
            });

            return successResponse(created, "เพิ่มผู้ดูแลร่วมสำเร็จเรียบร้อยแล้วค่ะ", 201);
          } catch (e: any) {
            return errorResponse("DATABASE_ERROR", "เกิดข้อผิดพลาดในการเพิ่มผู้ดูแลร่วม: " + (e?.message || e), 500);
          }
        }
        return successResponse({ id: Date.now(), email, role: staffRole, permissions, parent_id: ownerId });
      }

      if (path.startsWith("/api/caretakers/") && method === "PUT") {
        if (isStaffRole(authUser.role)) {
          return errorResponse("FORBIDDEN", "เฉพาะเจ้าของหอพักและผู้ดูแลระบบเท่านั้นที่สามารถแก้ไขผู้ดูแลร่วมได้", 403);
        }
        const id = parseInt(path.split("/")[3]);
        const body = await getJson();
        const permissions = body.permissions !== undefined ? String(body.permissions) : undefined;
        const staffRole = body.role !== undefined && staffRoles.includes(String(body.role)) ? String(body.role) : undefined;
        if (body.role !== undefined && !staffRole) return errorResponse('VALIDATION_ERROR', 'บทบาทพนักงานไม่ถูกต้อง', 400);
        const rawPassword = body.password ? String(body.password).trim() : undefined;

        if (env.DB && id) {
          try {
            const existing = await env.DB.prepare(
              "SELECT * FROM users WHERE id = ? AND role IN ('caretaker','accountant','technician','housekeeper','staff') AND parent_id = ? AND deleted_at IS NULL"
            ).bind(id, ownerId).first();

            if (!existing) {
              return errorResponse("NOT_FOUND", "ไม่พบข้อมูลผู้ดูแลหอพักนี้ หรือไม่มีสิทธิ์เข้าถึง", 404);
            }

            if (rawPassword && rawPassword.length >= 4) {
              const hashedPassword = await hashPassword(rawPassword);
              await env.DB.prepare("UPDATE users SET password = ? WHERE id = ? AND parent_id = ?").bind(hashedPassword, id, ownerId).run();
            }
            if (permissions !== undefined) {
              await env.DB.prepare("UPDATE users SET permissions = ? WHERE id = ? AND parent_id = ?").bind(permissions, id, ownerId).run();
            }
            if (staffRole !== undefined) {
              await env.DB.prepare("UPDATE users SET role = ? WHERE id = ? AND parent_id = ?").bind(staffRole, id, ownerId).run();
            }

            await logAuditAction(env.DB, { userId: authUser.id, userEmail: authUser.email, userRole: authUser.role, action: 'UPDATE_STAFF_ACCESS', targetType: 'user', targetId: id, oldValue: { role: existing.role, permissions: existing.permissions }, newValue: { role: staffRole ?? existing.role, permissions: permissions ?? existing.permissions }, ipAddress: clientIp, userAgent });

            return successResponse({ success: true, id }, "อัปเดตข้อมูลผู้ดูแลร่วมเรียบร้อยแล้วค่ะ");
          } catch (e: any) {
            return errorResponse("DATABASE_ERROR", "เกิดข้อผิดพลาดในการอัปเดตข้อมูลผู้ดูแลร่วม", 500);
          }
        }
        return successResponse({ success: true, id });
      }

      if (path.startsWith("/api/caretakers/") && method === "DELETE") {
        if (isStaffRole(authUser.role)) {
          return errorResponse("FORBIDDEN", "เฉพาะเจ้าของหอพักและผู้ดูแลระบบเท่านั้นที่สามารถลบผู้ดูแลร่วมได้", 403);
        }
        const id = parseInt(path.split("/")[3]);
        if (env.DB && id) {
          try {
            const existing = await env.DB.prepare(
              "SELECT * FROM users WHERE id = ? AND role IN ('caretaker','accountant','technician','housekeeper','staff') AND parent_id = ? AND deleted_at IS NULL"
            ).bind(id, ownerId).first();

            if (!existing) {
              return errorResponse("NOT_FOUND", "ไม่พบข้อมูลผู้ดูแลหอพักนี้ หรือไม่มีสิทธิ์เข้าถึง", 404);
            }

            await env.DB.prepare(
              "UPDATE users SET deleted_at = CURRENT_TIMESTAMP, deleted_by = ? WHERE id = ? AND parent_id = ?"
            ).bind(authUser.id, id, ownerId).run();

            await logAuditAction(env.DB, { userId: authUser.id, userEmail: authUser.email, userRole: authUser.role, action: 'DELETE_STAFF', targetType: 'user', targetId: id, oldValue: { role: existing.role, permissions: existing.permissions }, ipAddress: clientIp, userAgent });

            return successResponse({ success: true, id }, "ลบผู้ดูแลร่วมออกจากระบบเรียบร้อยแล้วค่ะ");
          } catch (e: any) {
            return errorResponse("DATABASE_ERROR", "เกิดข้อผิดพลาดในการลบผู้ดูแลร่วม", 500);
          }
        }
        return successResponse({ success: true, id });
      }
    }

    // ──────────────────────────────────────────────
    // 7. AUDIT LOGS API
    // ──────────────────────────────────────────────
    if (path === "/api/audit-logs" && method === "GET") {
      const authUser = await getAuthUser();
      if (!authUser) return errorResponse('UNAUTHORIZED', 'กรุณาล็อกอินเข้าสู่ระบบก่อนใช้งาน', 401);
      if (isStaffRole(authUser.role)) {
        return errorResponse('FORBIDDEN', 'เฉพาะเจ้าของหอพักหรือผู้ดูแลระบบเท่านั้นที่ดูประวัติกิจกรรมได้', 403);
      }
      if (!env.DB) return errorResponse("DATABASE_ERROR", "ไม่พบการเชื่อมต่อฐานข้อมูล D1", 500);
      const auditUserId = authUser.effectiveUserId || authUser.id;
      try {
        const { results } = await env.DB.prepare(
          "SELECT * FROM audit_logs WHERE user_id = ? OR user_id IN (SELECT id FROM users WHERE parent_id = ?) ORDER BY id DESC LIMIT 100"
        ).bind(auditUserId, auditUserId).all();
        const mapped = (results || []).map((a: any) => ({
          id: a.id,
          userId: a.user_id,
          userEmail: a.user_email,
          userRole: a.user_role,
          action: a.action,
          targetType: a.target_type,
          targetId: a.target_id,
          oldValue: a.old_value,
          newValue: a.new_value,
          ipAddress: a.ip_address,
          userAgent: a.user_agent,
          createdAt: a.created_at
        }));
        return successResponse(mapped);
      } catch (e) {
        console.warn("Audit logs fetch error:", e);
      }
      return successResponse([]);
    }

    return errorResponse("NOT_FOUND", `ไม่พบเอนด์พอยต์ ${path} ในระบบ`, 404);
  } catch (error: any) {
    if (error instanceof PlanAccessError) {
      return errorResponse(error.code, error.message, error.status);
    }
    console.error("Cloudflare Pages Function Exception:", error);
    return errorResponse("SERVER_ERROR", error.message || "เกิดข้อผิดพลาดภายในเซิร์ฟเวอร์", 500);
  }
};
