# คู่มือส่งมอบและ Deploy ลูกค้า — V14

## วิธีแนะนำ

1. แตก ZIP ลงโฟลเดอร์ใหม่
2. รัน `SETUP-WINDOWS.cmd` หรือ `bash SETUP-ANDROID.sh`
3. เลือกบัญชี Cloudflare ของลูกค้า
4. กรอกชื่อ Pages Project และ D1 Database
5. ให้ Wizard ตรวจ `JWT_SECRET`, Local migration และ build
6. ก่อน Production ให้ release checks ผ่าน
7. ถ้าเป็นฐานเดิม Wizard จะ Backup ก่อน migration
8. พิมพ์ `DEPLOY` เมื่อยืนยันว่าจะ Deploy จริง
9. ใช้ URL จริงที่ Wizard อ่านจาก Cloudflare `Project Domains`

## ตรวจเองก่อนส่งมอบ

```bash
npm ci
npm run release:check
npm run build:pages
```

ถ้ามีคำสั่งใด fail ให้หยุดและแก้ error ก่อน Production

## Backup และ Recovery 3 ชั้น

V14 มี Recovery 3 ชั้นที่ใช้คนละวัตถุประสงค์ และไม่ควรใช้แทนกัน:

1. **Application Backup (`.dormbackup`)** — ใช้จากหน้า Admin/Settings สำหรับ Backup/Restore ข้อมูลธุรกิจของระบบหอพัก
2. **D1 raw export** — ใช้ `npm run d1:backup` เพื่อเก็บ SQL ระดับฐานข้อมูลสำหรับงานดูแลระบบ/กู้ภัย
3. **Cloudflare D1 Time Travel** — ใช้ความสามารถของ Cloudflare เมื่อเกิดเหตุฐานข้อมูลเสียหายหรือจำเป็นต้องย้อนสถานะระดับ D1

`.dormbackup` ไม่ใช่ตัวแทนของ D1 raw export หรือ D1 Time Travel. Application Backup ตั้งใจไม่ย้อน identity/security/integration state: **users/password not restored**, **LINE/Google credentials not restored**, audit history ไม่ถูกย้อน และ subscription metadata ไม่ถูกย้อน

### ก่อนอัปเดตใหญ่หรือ Migration สำคัญ

ทำทั้งสองอย่าง:

```text
1. ดาวน์โหลด .dormbackup จากหน้า Settings > Backup/Restore
2. รัน npm run d1:backup
```

เก็บสองไฟล์แยกจากเครื่อง/โฟลเดอร์ที่กำลัง Deploy

### Restore ผ่านหน้า Admin

1. Login ด้วย Owner หรือ Super Admin
2. เปิด Settings > Backup/Restore
3. เลือกไฟล์ `.dormbackup`
4. ให้ Server Validate format/schema/hash/owner/reference ก่อน
5. ตรวจ Before / Backup counts และ warnings
6. ติ๊กยืนยันและพิมพ์ `RESTORE`
7. ระบบต้องดาวน์โหลด **pre-restore** `.dormbackup` สำเร็จก่อนส่งคำสั่ง Restore
8. เมื่อ Restore สำเร็จ ระบบ refresh ข้อมูลใหม่และต้องตรวจ Login, ห้อง, บิล และ integration state อีกครั้ง

Demo สามารถดาวน์โหลด Backup ได้ แต่ **Demo ไม่สามารถ Restore ได้**. Restore เปิดสำหรับ Basic / Standard / Pro ตาม Plan Entitlement

### ถ้า Restore fail

ถ้า UI แสดง `RESTORE_PARTIAL_FAILURE` หรือ `recoveryRequired: true`:

1. ห้ามแก้ข้อมูลต่อ เพื่อไม่เพิ่มความต่างของฐาน
2. เก็บ error, เวลาเกิดเหตุ และ `preRestoreDataSha256`
3. ใช้ไฟล์ **pre-restore** ที่ระบบดาวน์โหลดก่อน Restore เป็นตัวเลือก Application Recovery แรก
4. ถ้า Application Recovery ไม่เพียงพอ ให้ใช้ **D1 raw export**
5. ถ้าเหตุการณ์เป็นระดับฐาน D1 หรือจำเป็นต้องย้อนทั้งฐาน ให้พิจารณา **Cloudflare D1 Time Travel**
6. หลัง Recovery ตรวจ owner login, users, LINE/Google credentials, subscription state และจำนวน business records

## D1

ระบบใช้ binding ชื่อ `DB` และ migrations ใน `d1-migrations/`

Backup ฐาน remote:

```bash
npm run d1:backup
```

Migration remote:

```bash
npm run d1:migrate:remote
```

## Security

- `JWT_SECRET` เก็บใน Cloudflare Secret
- ห้าม commit `.env`, `.dev.vars` หรือ token จริง
- `wrangler.template.jsonc` เป็นแม่แบบ; `wrangler.jsonc` จริงถูกสร้างหลัง Setup
- Setup จะเก็บ JWT_SECRET เดิมไว้ถ้ามี และสร้างใหม่เมื่อ Project เดิมขาด Secret
- `.dormbackup` ไม่มี users/password และไม่ใช้เพื่อย้าย LINE/Google credentials
- Restore rewrite ownership เป็น Owner ปัจจุบันและรักษา integration/subscription state ปัจจุบัน

## Google Sheets (เฉพาะแพ็กเกจที่รองรับ)

Authorized redirect URI ต้องใช้ **โดเมนจริงของ Deployment** เช่น:

```text
https://<ACTUAL_PROJECT_DOMAIN>/api/google-sheets/callback
```

ห้ามเดาโดเมนจากชื่อ Project ให้คัดลอกจาก URL ที่ Wizard แสดงหลัง Deploy หรือจาก Cloudflare Dashboard

## Upgrade

ใช้ `UPGRADE-WINDOWS.cmd` / `UPGRADE-ANDROID.sh` และใช้ Pages Project + D1 เดิมเท่านั้น ดู `UPGRADE_GUIDE_TH.md`

ก่อน Upgrade ใหญ่ ให้เก็บทั้ง `.dormbackup` และ D1 raw export เสมอ
