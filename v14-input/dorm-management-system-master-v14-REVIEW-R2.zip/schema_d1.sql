-- Current schema snapshot for Cloudflare D1 (SQLite).
-- Deploy schema changes through d1-migrations/ instead of executing this file
-- against production directly.

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  uid TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'owner',
  parent_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  password TEXT NOT NULL DEFAULT '',
  permissions TEXT NOT NULL DEFAULT 'manage_rooms,manage_bills,edit_payments',
  deleted_at DATETIME,
  deleted_by INTEGER
);

CREATE TABLE IF NOT EXISTS rooms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  room_number TEXT NOT NULL,
  monthly_rent INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'vacant',
  tenant_name TEXT,
  tenant_phone TEXT,
  line_user_id TEXT,
  line_display_name TEXT,
  line_picture_url TEXT,
  line_status TEXT DEFAULT 'unlinked',
  line_notify_token TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  deleted_at DATETIME,
  deleted_by INTEGER
);

CREATE TABLE IF NOT EXISTS bills (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  room_id INTEGER NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  bill_month TEXT NOT NULL,
  prior_elec REAL NOT NULL DEFAULT 0,
  current_elec REAL NOT NULL DEFAULT 0,
  elec_deduct REAL NOT NULL DEFAULT 0,
  elec_unit_cost REAL NOT NULL DEFAULT 7,
  elec_cost REAL NOT NULL DEFAULT 0,
  prior_water REAL NOT NULL DEFAULT 0,
  current_water REAL NOT NULL DEFAULT 0,
  water_unit_cost REAL NOT NULL DEFAULT 13,
  water_cost REAL NOT NULL DEFAULT 0,
  rent_cost INTEGER NOT NULL DEFAULT 0,
  deposit_cost INTEGER NOT NULL DEFAULT 0,
  other_cost INTEGER NOT NULL DEFAULT 0,
  other_description TEXT,
  total_cost INTEGER NOT NULL DEFAULT 0,
  due_date TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'unpaid',
  paid_at DATETIME,
  slip_image TEXT,
  slip_uploaded_at DATETIME,
  slip_status TEXT NOT NULL DEFAULT 'none',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  deleted_at DATETIME,
  deleted_by INTEGER
);

CREATE TABLE IF NOT EXISTS settings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  dorm_name TEXT NOT NULL DEFAULT 'หอพักของฉัน',
  default_elec_rate REAL NOT NULL DEFAULT 7,
  default_water_rate REAL NOT NULL DEFAULT 13,
  default_due_date_day INTEGER NOT NULL DEFAULT 5,
  default_penalty_rate REAL NOT NULL DEFAULT 100,
  promptpay_id TEXT,
  promptpay_name TEXT,
  line_channel_access_token TEXT,
  line_channel_secret TEXT,
  line_bot_enabled INTEGER DEFAULT 0,
  google_spreadsheet_id TEXT,
  subscription_plan TEXT NOT NULL DEFAULT 'pro',
  subscription_status TEXT NOT NULL DEFAULT 'active',
  subscription_expires_at TEXT,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS maintenance_tickets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  room_id INTEGER NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  room_number TEXT NOT NULL,
  tenant_name TEXT,
  tenant_phone TEXT,
  title TEXT NOT NULL,
  description TEXT,
  category TEXT NOT NULL DEFAULT 'other',
  priority TEXT NOT NULL DEFAULT 'medium',
  status TEXT NOT NULL DEFAULT 'pending',
  image_url TEXT,
  repair_cost INTEGER NOT NULL DEFAULT 0,
  technician_note TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  deleted_at DATETIME,
  deleted_by INTEGER
);

CREATE TABLE IF NOT EXISTS lease_contracts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  room_id INTEGER NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  room_number TEXT NOT NULL,
  tenant_name TEXT NOT NULL,
  tenant_phone TEXT,
  id_card_number TEXT,
  start_date TEXT NOT NULL,
  end_date TEXT NOT NULL,
  monthly_rent INTEGER NOT NULL DEFAULT 0,
  deposit_amount INTEGER NOT NULL DEFAULT 0,
  advance_rent_amount INTEGER NOT NULL DEFAULT 0,
  contract_document_url TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  note TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  deleted_at DATETIME,
  deleted_by INTEGER
);

CREATE TABLE IF NOT EXISTS announcements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'general',
  is_pinned INTEGER NOT NULL DEFAULT 0,
  target_room_ids TEXT,
  image_url TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  deleted_at DATETIME,
  deleted_by INTEGER
);

CREATE TABLE IF NOT EXISTS notes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_by INTEGER NOT NULL REFERENCES users(id),
  room_id INTEGER REFERENCES rooms(id) ON DELETE SET NULL,
  title TEXT NOT NULL CHECK(length(title) BETWEEN 1 AND 120),
  content TEXT NOT NULL CHECK(length(content) BETWEEN 1 AND 5000),
  color TEXT NOT NULL DEFAULT 'yellow' CHECK(color IN ('yellow', 'green', 'blue', 'pink', 'purple', 'gray')),
  is_pinned INTEGER NOT NULL DEFAULT 0 CHECK(is_pinned IN (0, 1)),
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  deleted_by INTEGER
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  user_email TEXT NOT NULL,
  user_role TEXT NOT NULL DEFAULT 'owner',
  action TEXT NOT NULL,
  target_type TEXT NOT NULL,
  target_id TEXT,
  old_value TEXT,
  new_value TEXT,
  ip_address TEXT,
  user_agent TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- B-Tree Performance Indexes
CREATE INDEX IF NOT EXISTS idx_rooms_user_id ON rooms(user_id);
CREATE INDEX IF NOT EXISTS idx_rooms_room_number ON rooms(room_number);
CREATE INDEX IF NOT EXISTS idx_rooms_status ON rooms(status);
CREATE INDEX IF NOT EXISTS idx_rooms_deleted_at ON rooms(deleted_at);
CREATE UNIQUE INDEX IF NOT EXISTS idx_rooms_unique_active_number ON rooms(user_id, room_number COLLATE NOCASE) WHERE deleted_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_bills_user_id ON bills(user_id);
CREATE INDEX IF NOT EXISTS idx_bills_room_id ON bills(room_id);
CREATE INDEX IF NOT EXISTS idx_bills_bill_month ON bills(bill_month);
CREATE INDEX IF NOT EXISTS idx_bills_status ON bills(status);
CREATE INDEX IF NOT EXISTS idx_bills_due_date ON bills(due_date);
CREATE INDEX IF NOT EXISTS idx_bills_deleted_at ON bills(deleted_at);
CREATE UNIQUE INDEX IF NOT EXISTS idx_bills_unique_active ON bills(user_id, room_id, bill_month) WHERE deleted_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_tickets_user_id ON maintenance_tickets(user_id);
CREATE INDEX IF NOT EXISTS idx_tickets_room_id ON maintenance_tickets(room_id);
CREATE INDEX IF NOT EXISTS idx_tickets_status ON maintenance_tickets(status);
CREATE INDEX IF NOT EXISTS idx_notes_user_active_updated ON notes(user_id, deleted_at, is_pinned, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_notes_room_id ON notes(room_id);

CREATE INDEX IF NOT EXISTS idx_contracts_user_id ON lease_contracts(user_id);
CREATE INDEX IF NOT EXISTS idx_contracts_room_id ON lease_contracts(room_id);
CREATE INDEX IF NOT EXISTS idx_contracts_status ON lease_contracts(status);

CREATE INDEX IF NOT EXISTS idx_audit_user_id ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_logs(action);

CREATE TABLE IF NOT EXISTS rate_limits (
  key TEXT PRIMARY KEY,
  count INTEGER NOT NULL DEFAULT 0,
  reset_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_rate_limits_reset_at ON rate_limits(reset_at);

CREATE TABLE IF NOT EXISTS google_oauth_states (
  state TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS google_oauth_tokens (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  refresh_token TEXT NOT NULL,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_google_oauth_states_expires_at ON google_oauth_states(expires_at);

CREATE TABLE IF NOT EXISTS recurring_charge_templates (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL, description TEXT, default_amount INTEGER NOT NULL DEFAULT 0 CHECK(default_amount >= 0),
  frequency TEXT NOT NULL DEFAULT 'monthly' CHECK(frequency IN ('monthly','quarterly','yearly')),
  billing_months TEXT NOT NULL DEFAULT '[1,2,3,4,5,6,7,8,9,10,11,12]', is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP, deleted_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_recurring_templates_owner ON recurring_charge_templates(user_id, deleted_at);

CREATE TABLE IF NOT EXISTS room_recurring_charges (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  room_id INTEGER NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  template_id INTEGER NOT NULL REFERENCES recurring_charge_templates(id) ON DELETE CASCADE,
  amount_override INTEGER CHECK(amount_override IS NULL OR amount_override >= 0), is_enabled INTEGER NOT NULL DEFAULT 1,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP, UNIQUE(room_id, template_id)
);
CREATE INDEX IF NOT EXISTS idx_room_recurring_owner_room ON room_recurring_charges(user_id, room_id);

CREATE TABLE IF NOT EXISTS bill_charge_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT, bill_id INTEGER NOT NULL REFERENCES bills(id) ON DELETE CASCADE,
  assignment_id INTEGER REFERENCES room_recurring_charges(id) ON DELETE SET NULL,
  label TEXT NOT NULL, amount INTEGER NOT NULL DEFAULT 0 CHECK(amount >= 0),
  kind TEXT NOT NULL DEFAULT 'manual' CHECK(kind IN ('recurring','manual','legacy')),
  sort_order INTEGER NOT NULL DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_bill_charge_items_bill ON bill_charge_items(bill_id, sort_order, id);

CREATE TABLE IF NOT EXISTS housekeeping_tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  room_id INTEGER NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  assigned_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  contract_id INTEGER REFERENCES lease_contracts(id) ON DELETE SET NULL,
  source TEXT NOT NULL DEFAULT 'manual' CHECK(source IN ('manual','checkout')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','in_progress','ready_for_inspection','completed','cancelled')),
  note TEXT, inspection_note TEXT, created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP, completed_at TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_housekeeping_checkout_once ON housekeeping_tasks(contract_id) WHERE source = 'checkout' AND contract_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_housekeeping_owner_status ON housekeeping_tasks(user_id, status, created_at DESC);
