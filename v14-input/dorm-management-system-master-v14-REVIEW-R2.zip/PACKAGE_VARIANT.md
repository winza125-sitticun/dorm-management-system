# PACKAGE VARIANT — V14 Master

ไฟล์นี้อยู่ใน Master เท่านั้น แพ็กเกจ Demo / Basic / Standard / Pro จะถูกสร้างและเขียนไฟล์ `PACKAGE_VARIANT.md` ใหม่โดย V14 Master Package Builder

ห้ามส่ง Master นี้แทน customer package และห้ามสร้าง CUSTOMER-READY โดยข้าม `npm run packages:release`
